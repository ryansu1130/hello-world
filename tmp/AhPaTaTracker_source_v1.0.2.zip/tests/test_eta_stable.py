import tempfile
import unittest
from dataclasses import fields
from datetime import datetime, timezone
from pathlib import Path

from core_loader import load_core

core = load_core()


def make_parsed(order='W1000000001', email_date='2026-10-20T12:00:00+00:00', eta_date='', eta_text='', mid='m1'):
    kw={f.name:'' for f in fields(core.ParsedOrder)}
    kw.update(order_number=order, order_type='Shipping', item_summary='Test device', qty=1,
              address='Demo address', status='Processing', total='$1.00', order_date='2026-10-16',
              eta_date=eta_date, eta_text=eta_text, subject="We're processing your order "+order,
              email_date=email_date, message_id=mid)
    return core.ParsedOrder(**kw)


class EtaParserStableTests(unittest.TestCase):
    def test_duo_delivery_range(self):
        raw=(
            b'From: Apple Store <your_order_US@orders.apple.com>\r\n'
            b'To: example@example.com\r\n'
            b'Subject: We\'re processing your order W1477775326\r\n'
            b'Date: Fri, 16 Oct 2026 12:25:13 +0000\r\n'
            b'Message-ID: <eta-range>\r\n'
            b'X-EmailType-Id: 1020897861\r\n'
            b'Content-Type: text/plain; charset=UTF-8\r\n\r\n'
            b'Order Number W1477775326\r\n'
            b'Ordered on Oct 16, 2026\r\n'
            b'Items to Be Shipped\r\n'
            b'Shipment 1:\r\n'
            b'Ships: 8-9 weeks\r\n'
            b'Delivers: Dec 15 - Dec 22 by Express Delivery\r\n'
            b'iPhone Duo 256GB Star White\r\n'
            b'$1,999.00\r\nQty 1\r\n'
            b'Shipping Address\r\n123 Main St\r\nPortland OR 97201\r\n'
        )
        p=core.AppleMailParser().parse(raw,'example@example.com')
        self.assertIsNotNone(p)
        self.assertEqual(p.order_number,'W1477775326')
        self.assertEqual(p.eta_date,'2026-12-15')
        self.assertEqual(p.eta_text,'December 15\u201322, 2026')
        self.assertEqual(core.display_eta_value(p.eta_date,p.eta_text),'December 15\u201322, 2026')

    def test_cross_year_range(self):
        d,t=core.iso_date_from_text('Delivers: Dec 30 - Jan 5', datetime(2026,10,16,tzinfo=timezone.utc))
        self.assertEqual(d,'2026-12-30')
        self.assertEqual(t,'December 30, 2026 \u2013 January 5, 2027')

    def test_older_event_can_fill_blank_eta(self):
        with tempfile.TemporaryDirectory() as td:
            db=core.Database(Path(td)/'orders.db')
            aid=db.add_account('example@example.com')
            db.save_update(aid,2,make_parsed(email_date='2026-10-20T12:00:00+00:00',mid='later'))
            old=make_parsed(email_date='2026-10-16T12:00:00+00:00',eta_date='2026-12-15',eta_text='December 15\u201322, 2026',mid='older')
            db.refresh_from_parsed(aid,1,old)
            row=db.query_orders()[0]
            self.assertEqual(row['eta_date'],'2026-12-15')
            self.assertEqual(row['eta_text'],'December 15\u201322, 2026')
            db.close()


if __name__=='__main__':
    unittest.main()
