"""Run the DOM contract scenarios in isolated browser/driver processes.
No external network navigation; see browser_contract.py.
"""
import ast
import subprocess
import sys
from pathlib import Path
import time
p=Path(__file__).with_name('browser_contract.py')
tree=ast.parse(p.read_text())
cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='BrowserContracts')
names=[n.name for n in cls.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
started=time.perf_counter();failures=[]
for name in names:
    try:
        result=subprocess.run([sys.executable,str(p),'BrowserContracts.'+name],capture_output=True,text=True,timeout=50)
        print(result.stdout+result.stderr,flush=True)
        if result.returncode:failures.append(name)
    except subprocess.TimeoutExpired:
        failures.append(name);print('TIMEOUT: '+name,flush=True)
print(f'{len(names)-len(failures)}/{len(names)} isolated Chromium DOM scenarios passed in {time.perf_counter()-started:.2f}s',flush=True)
if failures:print('FAILED: '+', '.join(failures))
raise SystemExit(bool(failures))
