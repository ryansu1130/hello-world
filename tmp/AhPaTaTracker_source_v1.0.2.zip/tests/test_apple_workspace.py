from __future__ import annotations
import io
import json
import sqlite3
import tempfile
import time
import unittest
from dataclasses import fields
from pathlib import Path
from unittest.mock import patch
from core_loader import load_core
from apple_profiles import email_key,normalize_phone,candidates,iter_records,parse_proxy,safe_paths,_array_stream
from apple_accounts import AppleStore,backup_before_apple_migration,safe_message
from apple_browser import parse_snapshot,aggregate_item_states,normalize_state,AppleFlowError,BrowserSession,apple_host
from apple_jobs import AppleRunner
from apple_secrets import SecretVault

core=load_core()

def profile(email='User+Tag@example.test',phone='(503) 555-0119',country='United States',order=''):
    return {'email':email,'shipping':{'phone':phone,'country':country},'orderNumber':order,
            'payment':{'num':'PRIVATE_CARD_SENTINEL','cvv':'PRIVATE_CVV_SENTINEL','password':'PRIVATE_PASSWORD_SENTINEL'}}

def event(number='W1000000001',mid='a',status='Processing',kind='Shipping',alias='User+Tag@example.test',qty=2):
    kw={f.name:'' for f in fields(core.ParsedOrder)}
    kw.update(order_number=number,message_id=mid,email_date='2026-10-17T10:00:00+00:00',order_date='2026-10-17',
              order_type=kind,status=status,alias_emails=alias,item_summary='Example phone',qty=qty,total='$200.00',eta_date='2026-11-01')
    return core.ParsedOrder(**kw)

class ProfilesTests(unittest.TestCase):
    def test_plus_alias_and_local_case_preserved(self):
        self.assertEqual(email_key(' User+Tag@EXAMPLE.TEST '),'User+Tag@example.test')
        self.assertNotEqual(email_key('User+Tag@example.test'),email_key('user+tag@example.test'))
        self.assertNotEqual(email_key('User+Tag@example.test'),email_key('User@example.test'))
    def test_equivalent_country_format(self):
        a=normalize_phone('(503) 555-0119','United States');b=normalize_phone('+1 503 555 0119')
        self.assertEqual(a.comparison,b.comparison);self.assertEqual(a.state,'valid')
    def test_ambiguous_without_country(self):self.assertEqual(normalize_phone('5035550119').state,'ambiguous')
    def test_extension_is_preserved(self):
        a=normalize_phone('+1 503 555 0119 ext 22');b=normalize_phone('+1 503 555 0119')
        self.assertNotEqual(a.comparison,b.comparison);self.assertEqual(a.extension,'22')
    def test_invalid_phone_is_flagged(self):self.assertEqual(normalize_phone('XXX','US').state,'invalid')
    def test_shipping_and_billing_candidates_same_record(self):
        p=profile();p['billing']={'phone':'+1 212 555 0133'}
        self.assertEqual(len(candidates(p)),2)
    def test_no_pairing_unrelated_array(self):
        p={'emails':['wrong@example.test'],'profiles':[{'phone':'+15035550119'}]}
        with self.assertRaises(ValueError):candidates(p)
    def test_block_sensitive_mapping(self):
        with self.assertRaises(ValueError):candidates(profile(),{'email':'email','phone':'payment.num'})
        self.assertNotIn('payment.num',safe_paths(profile()))
    def test_custom_mapping(self):
        data={'contactData':{'mail':'a+one@example.test','tel':'+15035550119'}}
        c=candidates(data,{'email':'contactData.mail','phone':'contactData.tel'})
        self.assertEqual(c[0]['email'],'a+one@example.test')
    def test_array_stream_whitespace_unicode(self):
        rows=list(_array_stream(io.StringIO(json.dumps([profile(),profile(phone='+15035550120')]))))
        self.assertEqual(len(rows),2)
    def test_reject_trailing_comma(self):
        with self.assertRaises(ValueError):list(_array_stream(io.StringIO('[{},]')))
    def test_reject_trailing_comma_at_chunk_boundary(self):
        class Tiny(io.StringIO):
            def read(self,size=-1):return super().read(min(size,1) if size>=0 else 1)
        with self.assertRaises(ValueError):list(_array_stream(Tiny('[{},]')))
    def test_nested_records_do_not_cross_pair(self):
        with tempfile.TemporaryDirectory() as folder:
            p=Path(folder)/'nested.json';p.write_text(json.dumps({'profiles':[profile('a@example.test'),profile('b@example.test','+15035550120')]}))
            rows=list(iter_records(p));self.assertEqual(len(rows),2)
            self.assertEqual(candidates(rows[1][1])[0]['email'],'b@example.test')
    def test_valid_proxy(self):
        p=parse_proxy('http://alice:password@proxy.example:8080');self.assertEqual(p['server'],'http://proxy.example:8080');self.assertEqual(p['username'],'alice')
    def test_proxy_short_form(self):self.assertEqual(parse_proxy('proxy.example:8000:user:pass')['password'],'pass')
    def test_invalid_proxy(self):
        for v in ('socks4://x:9','x','http://x:0','https://x:999999','http://x:80/path'):
            with self.assertRaises(ValueError):parse_proxy(v)
    def test_proxy_ipv6(self):self.assertEqual(parse_proxy('http://[::1]:8080')['server'],'http://[::1]:8080')

class WorkspaceTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.path=Path(self.tmp.name)/'orders.db';self.db=core.Database(self.path);self.store=AppleStore(self.db)
        self.aid=self.db.add_account('mail@example.test');self.db.save_update(self.aid,1,event());self.oid=self.db.query_orders()[0]['id']
        self.cid=self.store.add_connection('owner@example.test');self.store.connection_state(self.cid,'connected','', 'owner@example.test','Apple page')
    def tearDown(self):self.db.close();self.tmp.cleanup()
    def file(self,name,data):
        p=Path(self.tmp.name)/name;p.write_text(json.dumps(data));return p
    def job(self,action='refresh',ids=None):
        snapshot=self.store.snapshot(ids or [self.oid],self.cid,action)
        return self.store.create_job(snapshot,confirmed=action!='refresh')
    def task(self,action='refresh'):
        self.job(action);return self.store.take_next({self.cid},5)
    def obs(self,state='Delivered',**kw):
        d={'authenticated':True,'order_number':'W1000000001','status':state,'raw_status':state,'items':[]};d.update(kw);return d
    def test_import_multiple_dedup_provenance(self):
        one=self.file('a.json',[profile(),profile(phone='+1 503 555 0119')]);two=self.file('b.json',[profile(phone='+1 503 555 0120')])
        result=self.store.import_files([one,two]);self.assertEqual(result['new_candidates'],2)
        rows=self.store.phone_candidates(self.db.order_by_id(self.oid),self.cid);self.assertEqual(len(rows),2)
        self.assertEqual(len(self.store.phone_sources(rows[0]['id'])),2)
        self.assertEqual(self.store.import_files([one,two])['new_candidates'],0)
    def test_payment_content_never_persisted(self):
        self.store.import_files([self.file('p.json',[profile()])]);dump='\n'.join(self.db.conn.iterdump())
        for v in ('PRIVATE_CARD_SENTINEL','PRIVATE_CVV_SENTINEL','PRIVATE_PASSWORD_SENTINEL'):self.assertNotIn(v,dump)
    def test_bad_file_does_not_stop_good_file(self):
        bad=Path(self.tmp.name)/'bad.json';bad.write_text('{bad!')
        r=self.store.import_files([bad,self.file('good.json',[profile()])]);self.assertEqual(r['accepted'],1);self.assertEqual(len(r['errors']),1)
    def test_order_hint_priority_all_candidates_remain(self):
        self.store.import_files([self.file('p.json',[profile(phone='+15035550120'),profile(order='W1000000001')])])
        p=self.store.phone_candidates(self.db.order_by_id(self.oid),self.cid);self.assertEqual(len(p),2);self.assertEqual(p[0]['order_match'],1)
    def test_two_orders_same_alias_distinct_verified_phone(self):
        self.db.save_update(self.aid,2,event(number='W1000000002',mid='b'));oid2=self.db.conn.execute("SELECT id FROM orders WHERE order_number='W1000000002'").fetchone()[0]
        self.store.import_files([self.file('p.json',[profile(),profile(phone='+15035550120')])]);p=self.store.phone_candidates(self.db.order_by_id(self.oid),self.cid)
        self.store.record_phone_result(self.oid,p[0]['id'],self.cid,'Verified');self.store.record_phone_result(oid2,p[1]['id'],self.cid,'Verified')
        a=self.store.phone_candidates(self.db.order_by_id(self.oid),self.cid);b=self.store.phone_candidates(self.db.order_by_id(oid2),self.cid)
        self.assertNotEqual(next(x['id'] for x in a if x['verification']=='Verified'),next(x['id'] for x in b if x['verification']=='Verified'))
    def test_new_order_matches_existing_mapping(self):
        self.store.import_files([self.file('p.json',[profile('Later+x@example.test')])]);self.db.save_update(self.aid,2,event(number='W1000000002',mid='b',alias='Later+x@example.test'))
        row=self.db.conn.execute("SELECT * FROM orders WHERE order_number='W1000000002'").fetchone();self.assertEqual(len(self.store.phone_candidates(row)),1)
    def test_unmatched_summary(self):
        r=self.store.import_files([self.file('p.json',[profile('no@example.test')])]);self.assertEqual(r['unmatched_aliases'],1)
    def test_no_candidate_actionable(self):self.assertEqual(self.store.phone_candidates(self.db.order_by_id(self.oid)),[])
    def test_manual_highest_then_apple_then_email(self):
        self.db.apply_manual_overrides({self.oid:{'status':'Processing'}});task=self.task();self.store.save_observation(task,self.obs('Delivered'))
        self.assertEqual(self.db.order_by_id(self.oid)['status'],'Processing')
        self.assertEqual(self.db.order_by_id(self.oid)['account_status'],'Delivered')
        self.db.apply_manual_overrides({self.oid:{'status':''}});self.assertEqual(self.db.order_by_id(self.oid)['status'],'Delivered');self.assertEqual(self.db.order_by_id(self.oid)['status_source'],'Apple Account')
    def test_apple_beats_later_email_recompute(self):
        self.store.save_observation(self.task(),self.obs('Canceled'));self.db.save_update(self.aid,9,event(mid='new',status='Shipped'))
        self.assertEqual(self.db.order_by_id(self.oid)['status'],'Canceled')
    def test_failed_refresh_preserves_observation(self):
        self.store.save_observation(self.task(),self.obs('Delivered'));self.store.record_attempt(self.oid,'Timeout')
        r=self.db.order_by_id(self.oid);self.assertEqual(r['account_status'],'Delivered');self.assertEqual(r['account_status_error'],'Timeout')
    def test_out_of_order_response_rejected(self):
        t=self.task();t['sequence']=50;self.assertTrue(self.store.save_observation(t,self.obs('Delivered')))
        t['sequence']=49;self.assertFalse(self.store.save_observation(t,self.obs('Shipped')))
        self.assertEqual(self.db.order_by_id(self.oid)['status'],'Delivered')
    def test_older_source_event_rejected(self):
        t=self.task();self.store.save_observation(t,self.obs('Delivered',event_at='2026-10-18'))
        t['sequence']+=1;self.assertFalse(self.store.save_observation(t,self.obs('Shipped',event_at='2026-10-17')))
    def test_unauthenticated_or_wrong_order_rejected(self):
        t=self.task()
        for change in ({'authenticated':False},{'order_number':'W9999999999'}):
            with self.assertRaises(ValueError):self.store.save_observation(t,self.obs(**change))
    def test_manual_qty_beats_apple_and_email(self):
        self.db.apply_manual_overrides({self.oid:{'qty':1}})
        self.store.save_observation(self.task(),self.obs('Processing',items=[{'id':'x','stable_id':True,'qty':3,'status':'Processing'}],all_items_known=True))
        self.db.save_update(self.aid,2,event(mid='other',qty=8));self.assertEqual(self.db.order_by_id(self.oid)['qty'],1)
    def test_apple_qty_beats_email_without_manual(self):
        self.store.save_observation(self.task(),self.obs('Processing',items=[{'id':'x','stable_id':True,'qty':3,'status':'Processing'}],all_items_known=True))
        self.db.save_update(self.aid,2,event(mid='other',qty=8));self.assertEqual(self.db.order_by_id(self.oid)['qty'],3)
    def test_restart_retains_apple_status(self):
        self.store.save_observation(self.task(),self.obs('Delivered'));self.db.close();self.db=core.Database(self.path);self.store=AppleStore(self.db)
        self.assertEqual(self.db.order_by_id(self.oid)['status'],'Delivered')
    def test_frozen_batch_no_extra_orders(self):
        snap=self.store.snapshot([self.oid],self.cid,'cancel');self.db.save_update(self.aid,2,event(number='W1000000002',mid='b'))
        jid=self.store.create_job(snap,confirmed=True);self.assertEqual(len(self.store.tasks(jid)),1)
    def test_mutation_needs_confirmation(self):
        with self.assertRaises(ValueError):self.store.create_job(self.store.snapshot([self.oid],self.cid,'cancel'))
    def test_masked_payment_only(self):
        with self.assertRaises(ValueError):self.store.snapshot([self.oid],self.cid,'payment','4111111111111111')
        self.assertEqual(self.store.snapshot([self.oid],self.cid,'payment','Visa ****1234')['method'],'Visa ****1234')
    def test_archived_scope_rejected(self):
        snap=self.store.snapshot([self.oid],self.cid,'cancel');self.db.archive_order_day('2026-10-17')
        with self.assertRaises(ValueError):self.store.create_job(snap,True)
    def test_dedup_refresh(self):
        a=self.job();b=self.job();self.assertEqual(self.store.tasks(b)[0]['state'],'skipped');self.assertEqual(self.store.tasks(a)[0]['state'],'queued')
    def test_same_order_conflict_locked(self):
        self.job('cancel');self.job('payment');t=self.store.take_next({self.cid},5)
        self.db.conn.execute('UPDATE apple_connections SET next_at=0');self.db.conn.commit()
        self.assertIsNone(self.store.take_next({self.cid},5))
    def test_restart_reconciles_mutation_never_resubmits(self):
        t=self.task('cancel');self.store.mark_submitted(t);self.store.recover();row=self.store.tasks(t['job_id'])[0]
        self.assertEqual(row['state'],'uncertain');self.assertEqual(row['submitted'],1)
    def test_restart_readonly_returns_to_queue(self):
        t=self.task();self.store.recover();self.assertEqual(self.store.tasks(t['job_id'])[0]['state'],'queued')
    def test_completed_not_repeated_on_resume(self):
        t=self.task();self.store.result(t,'succeeded');self.store.job_control(t['job_id'],'resume')
        self.db.conn.execute('UPDATE apple_connections SET next_at=0');self.db.conn.commit();self.assertIsNone(self.store.take_next({self.cid},5))
    def test_stop_does_not_undo_completed(self):
        t=self.task();self.store.result(t,'succeeded');self.store.job_control(t['job_id'],'stop');self.assertEqual(self.store.tasks(t['job_id'])[0]['state'],'succeeded')
    def test_stop_submitted_is_uncertain(self):
        t=self.task('cancel');self.store.mark_submitted(t);self.store.job_control(t['job_id'],'stop');self.assertEqual(self.store.tasks(t['job_id'])[0]['state'],'uncertain')
    def test_decline_not_automatically_retried(self):
        t=self.task('payment');self.store.mark_submitted(t);self.store.result(t,'declined');self.store.job_control(t['job_id'],'retry')
        self.assertEqual(self.store.tasks(t['job_id'])[0]['state'],'declined')
    def test_pause_resume(self):
        jid=self.job();self.store.job_control(jid,'pause');self.assertIsNone(self.store.take_next({self.cid}))
        self.store.job_control(jid,'resume');self.assertIsNotNone(self.store.take_next({self.cid}))
    def test_cooldown_persists_and_blocks_other_account(self):
        t=self.task();runner=AppleRunner(core.Database,self.path,lambda r:'',lambda a,b:('', ''));runner.ready={self.cid}
        runner._failure(self.store,t,AppleFlowError('throttled','rate limit',600))
        other=self.store.add_connection('other@example.test');self.store.connection_state(other,'connected');self.store.create_job(self.store.snapshot([self.oid],other,'refresh'))
        self.assertIsNone(self.store.take_next({other}));self.assertGreater(float(self.db.conn.execute("SELECT value FROM apple_meta WHERE key='global_cooldown'").fetchone()[0]),time.time())
    def test_auth_expiry_pauses_and_does_not_mark_phone_mismatch(self):
        t=self.task('associate');runner=AppleRunner(core.Database,self.path,lambda r:'',None);runner.ready={self.cid}
        runner._failure(self.store,t,AppleFlowError('auth_required','sign in'))
        self.assertNotIn(self.cid,runner.ready);self.assertEqual(self.store.tasks(t['job_id'])[0]['state'],'auth_required');self.assertEqual(self.db.conn.execute('SELECT COUNT(*) FROM apple_phone_verification').fetchone()[0],0)
    def test_transient_failure_backoff(self):
        t=self.task();runner=AppleRunner(core.Database,self.path,lambda r:'',None);runner._failure(self.store,t,AppleFlowError('timeout','timeout'))
        row=self.store.tasks(t['job_id'])[0];self.assertEqual(row['state'],'cooling_down');self.assertGreater(row['next_at'],time.time())
    def test_uncertain_submission_not_retried(self):
        t=self.task('cancel');self.store.mark_submitted(t);runner=AppleRunner(core.Database,self.path,lambda r:'',None);runner._failure(self.store,t,AppleFlowError('timeout','timeout'))
        self.assertEqual(self.store.tasks(t['job_id'])[0]['state'],'uncertain')
    def test_export_sanitized(self):
        t=self.task();self.store.result(t,'failed','Authorization: BearerXYZ https://example.test/private?token=secret')
        p=Path(self.tmp.name)/'report.csv';self.store.export_job(t['job_id'],p);text=p.read_text()
        self.assertNotIn('BearerXYZ',text);self.assertNotIn('token=secret',text)
    def test_account_isolation(self):
        jid=self.job();other=self.store.add_connection('other@example.test');self.store.connection_state(other,'connected')
        self.assertIsNone(self.store.take_next({other}));self.assertEqual(self.store.tasks(jid)[0]['connection_id'],self.cid)
    def test_calendar_uses_reported_apple_date(self):
        self.store.save_observation(self.task(),self.obs('Delivered',event_at='2026-10-18'))
        self.assertEqual(len(self.db.orders_for_activity_date('2026-10-18')),1)
    def test_plain_fields_survive_schema_restart(self):
        self.db.apply_manual_overrides({self.oid:{'status':'Shipped','qty':4}});self.db.close();self.db=core.Database(self.path);self.store=AppleStore(self.db)
        row=self.db.order_by_id(self.oid);self.assertEqual(row['manual_qty'],4);self.assertEqual(row['status'],'Shipped');self.assertTrue(self.store.connection(self.cid))
    def test_unverified_phone_does_not_become_verified(self):
        self.store.import_files([self.file('p.json',[profile()])]);p=self.store.phone_candidates(self.db.order_by_id(self.oid),self.cid)[0]
        t=self.task('associate');self.store.association(t,'awaiting_verification',p['id']);self.assertEqual(self.store.phone_candidates(self.db.order_by_id(self.oid),self.cid)[0]['verification'],'Untried')

class BrowserParserTests(unittest.TestCase):
    def snap(self,heading='Processing',**kw):
        s={'url':'https://secure.store.apple.com/shop/order/detail/W1000000001','text':'Order Number: W1000000001', 'headings':[heading], 'statusLabels':[], 'items':[], 'controls':[], 'password_prompt':False};s.update(kw);return s
    def test_progress_labels_not_completion(self):
        with self.assertRaises(AppleFlowError):parse_snapshot(self.snap('',text='W1000000001 Order Placed Processing Ready for Pickup Picked Up'),'W1000000001',True)
    def test_pickedup_heading(self):self.assertEqual(parse_snapshot(self.snap('Picked Up Sep 19'),'W1000000001',True)['status'],'Picked Up')
    def test_guest_page_is_not_authentication(self):
        with self.assertRaises(AppleFlowError):parse_snapshot(self.snap(),'W1000000001',False)
    def test_wrong_page_number(self):
        with self.assertRaises(AppleFlowError):parse_snapshot(self.snap(),'W2222222222',True)
    def test_nonapple_domain(self):self.assertFalse(apple_host('https://apple.com.evil.test/'));self.assertFalse(apple_host('http://store.apple.com/'));self.assertFalse(apple_host('https://x@store.apple.com/'))
    def test_unknown_visible_not_dropped(self):
        r=parse_snapshot(self.snap('',statusLabels=['Awaiting special review']),'W1000000001',True);self.assertEqual(r['status'],'Apple Update');self.assertEqual(r['raw_status'],'Awaiting special review')
    def test_mixed_partial_cancel(self):
        items=[{'id':'a','text':'Qty 1','headings':['iPhone test','Canceled']},{'id':'b','text':'Qty 2','headings':['iPhone test','Shipped']}]
        r=parse_snapshot(self.snap('',items=items),'W1000000001',True);self.assertEqual(r['status'],'Partially Canceled');self.assertEqual(len(r['items']),2)
    def test_unknown_item_prevents_complete_status(self):
        items=[{'id':'a','text':'Qty 1','headings':['Delivered']},{'id':'b','text':'Qty 1','headings':['Review']}]
        self.assertEqual(parse_snapshot(self.snap('',items=items),'W1000000001',True)['status'],'Apple Update')
    def test_payment_success_not_delivery(self):
        r=parse_snapshot(self.snap('Processing',text='W1000000001 Payment method updated'),'W1000000001',True);self.assertEqual(r['status'],'Processing')
    def test_network_error_is_not_phone_mismatch(self):self.assertFalse(BrowserSession._mismatch({'text':'Network timeout. Try again later.'}))
    def test_explicit_phone_mismatch(self):self.assertTrue(BrowserSession._mismatch({'text':'The phone number you entered does not match this order.'}))
    def test_partial_delivery_and_split_status(self):self.assertEqual(aggregate_item_states(['Delivered','Shipped']),'Partially Delivered')
    def test_login_gate(self):
        with self.assertRaises(AppleFlowError) as cm:parse_snapshot(self.snap(password_prompt=True),'W1000000001',True)
        self.assertEqual(cm.exception.code,'auth_required')
    def test_rate_limit_gate(self):
        with self.assertRaises(AppleFlowError) as cm:parse_snapshot(self.snap(text='W1000000001 Too many attempts'),'W1000000001',True)
        self.assertEqual(cm.exception.code,'throttled')
    def test_sign_in_link_is_not_identity(self):self.assertFalse(BrowserSession._account_view({'text':'Sign in with your Apple Account','headings':['Orders'],'order_links':[],'signed_in':False}))

class SecretTests(unittest.TestCase):
    def test_secret_vault_roundtrip_no_plaintext_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            v=SecretVault(tmp);v.put('test-session',{'cookies':[{'value':'SECRET_SESSION_SENTINEL'}]})
            self.assertIn('cookies',v.get('test-session'))
            for p in Path(tmp).rglob('*'):
                if p.is_file():self.assertNotIn(b'SECRET_SESSION_SENTINEL',p.read_bytes())
            v.delete('test-session');self.assertIsNone(v.get('test-session'))
    def test_invalid_secret_path(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(Exception):SecretVault(tmp).put('../bad',{})

if __name__=='__main__':unittest.main()
