"""Offline UPS fixtures: no network or real tracking numbers are used."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import time
import unittest
import requests
from ups_tracking import UPSClient, UPSCheckError, UPSResult, classify, parse_ups_response, aggregate_results

N1 = '1Z0000000000000001'
N2 = '1Z0000000000000002'

def response(description='On the Way', number=N1, scans=None, **extra):
    p = {'trackingNumber': number, 'currentStatus': {'description': description, 'code': 'TEST'},
         'activity': scans or []}
    p.update(extra)
    return {'trackResponse': {'shipment': [{'package': [p]}]}}

def scan(description, day='20260924', hour='130000', typ='I'):
    return {'status': {'description': description, 'code': 'TEST_SCAN', 'type': typ},
            'date': day, 'time': hour, 'gmtOffset': '-07:00'}

class ParsingTests(unittest.TestCase):
    def test_returning_explicit(self):
        self.assertEqual(parse_ups_response(response('Returning to Sender'), N1).status, 'Returning to Sender')
    def test_returned_explicit(self):
        self.assertEqual(parse_ups_response(response('Returned to Sender'), N1).status, 'Returned to Sender')
    def test_future_return_not_completed(self):
        self.assertEqual(classify('This package will be returned to the sender.'), 'Returning to Sender')
    def test_ongoing_return_not_completed(self):
        self.assertEqual(classify('Your package is being returned to the shipper.'), 'Returning to Sender')
    def test_generic_current_preserves_return_history(self):
        r = parse_ups_response(response(scans=[scan('Departed from Facility'),scan('Returning to Sender','20260923')]), N1)
        self.assertEqual(r.status, 'Returning to Sender')
        self.assertIn('history', r.inference)
    def test_return_delivery_not_customer_delivery(self):
        r = parse_ups_response(response('Delivered', scans=[scan('Delivered',typ='D'),scan('Return to Sender','20260923')]), N1)
        self.assertEqual(r.status, 'Returned to Sender')
        self.assertFalse(r.delivered_at)
        self.assertTrue(r.returned_at)
        self.assertTrue(r.inference)
    def test_reversed_return_allows_customer_delivery(self):
        r = parse_ups_response(response('Delivered', scans=[scan('Delivered',typ='D'),scan('Return to sender request canceled','20260923'),scan('Returning to Sender','20260922')]), N1)
        self.assertEqual(r.status, 'Delivered')
    def test_unsorted_scans(self):
        r = parse_ups_response(response(scans=[scan('Returning to Sender','20260923'),scan('Departed from Facility')]), N1)
        self.assertEqual(r.activity_description, 'Departed from Facility')
        self.assertEqual(r.status, 'Returning to Sender')
    def test_attempted_delivery_is_exception(self):
        self.assertEqual(classify('Not delivered - delivery attempted'), 'Exception')
    def test_delay_not_shipped(self):
        self.assertEqual(parse_ups_response(response('On the Way',scans=[scan('Weather delay',typ='X')]),N1).status,'Delayed')
    def test_out_for_delivery(self):
        self.assertEqual(parse_ups_response(response('Out for Delivery'),N1).status,'Out for Delivery')
    def test_photo_is_not_delivery_proof(self):
        self.assertEqual(parse_ups_response(response('On the Way',deliveryPhoto={'photo':'ignored'}),N1).status,'In Transit')
    def test_unknown_keeps_raw_wording(self):
        r = parse_ups_response(response('Awaiting special handling review'),N1)
        self.assertEqual(r.status,'Tracking Update'); self.assertEqual(r.description,'Awaiting special handling review')
        self.assertEqual(r.status_code,'TEST')
    def test_exact_package_match_not_first(self):
        d = response('Delivered',N2)
        d['trackResponse']['shipment'][0]['package'].append(response('Returning to Sender')['trackResponse']['shipment'][0]['package'][0])
        self.assertEqual(parse_ups_response(d,N1).status,'Returning to Sender')
    def test_mismatched_package_rejected(self):
        with self.assertRaises(UPSCheckError): parse_ups_response(response(number=N2),N1)
    def test_no_status_is_error(self):
        with self.assertRaises(UPSCheckError): parse_ups_response(response(''),N1)
    def test_rescheduled_eta_preferred(self):
        r=parse_ups_response(response(deliveryDate=[{'type':'SDD','date':'20260925'},{'type':'RDD','date':'20260927'}],deliveryTime={'startTime':'090000','endTime':'130000'}),N1)
        self.assertEqual(r.eta_date,'2026-09-27'); self.assertEqual(r.delivery_window,'9:00 AM - 1:00 PM')
    def test_return_eta_not_customer_delivery(self):
        r=parse_ups_response(response('Returning to Sender',deliveryDate=[{'type':'SDD','date':'20260925'}]),N1)
        self.assertFalse(r.eta_date)
    def test_label_void_is_not_apple_cancellation(self):
        self.assertEqual(classify('Order Processed: Canceled'), 'Label Voided')
    def test_delivery_local_date_not_shifted_to_utc(self):
        event = scan('Delivered','20260923','230000','D')
        event.update(gmtDate='20260924',gmtTime='060000')
        r=parse_ups_response(response('Delivered',scans=[event]),N1)
        self.assertTrue(r.delivered_at.startswith('2026-09-23T23:00:00'))
    def test_actual_delivery_time(self):
        r=parse_ups_response(response('Delivered',scans=[scan('Delivered',typ='D')]),N1)
        self.assertTrue(r.delivered_at.startswith('2026-09-24T13:00:00-07:00'))

class AggregateTests(unittest.TestCase):
    def result(self,state,**extra): return dict(status=state,**extra)
    def test_one_package_delivered_other_missing(self):
        self.assertEqual(aggregate_results([N1,N2],{N1:self.result('Delivered')})[0],'Partially Delivered')
    def test_one_returned_other_delivered(self):
        self.assertEqual(aggregate_results([N1,N2],{N1:self.result('Returned to Sender'),N2:self.result('Delivered')})[0],'Mixed Shipments')
    def test_all_delivered(self):
        self.assertEqual(aggregate_results([N1,N2],{N1:self.result('Delivered'),N2:self.result('Delivered')})[0],'Delivered')
    def test_all_returned(self):
        self.assertEqual(aggregate_results([N1,N2],{N1:self.result('Returned to Sender'),N2:self.result('Returned to Sender')})[0],'Returned to Sender')
    def test_one_return_missing_other(self):
        self.assertEqual(aggregate_results([N1,N2],{N1:self.result('Returned to Sender')})[0],'Mixed Shipments')
    def test_ups_additional_packages_prevent_whole_completion(self):
        result = aggregate_results([N1],{N1:self.result('Delivered',package_count=2)})
        self.assertEqual(result[0],'Partially Delivered')
        self.assertIn('only 1 tracking',result[1])
    def test_inference_and_codes_are_kept_in_details(self):
        result=aggregate_results([N1],{N1:self.result('Returned to Sender',status_code='TEST',inference='Return-history inference')})
        self.assertIn('TEST',result[1]); self.assertIn('Return-history inference',result[1])
    def test_errors_only_never_change_status(self):
        self.assertFalse(aggregate_results([N1],{N1:{'error':'Connection failed'}})[0])

class Reply:
    def __init__(self, status=200, body=None, headers=None): self.status_code=status; self.body=body; self.headers=headers or {}
    def json(self):
        if isinstance(self.body,Exception): raise self.body
        return self.body
class Session:
    def __init__(self,replies): self.replies=list(replies); self.calls=[]
    def request(self,*a,**kw):
        self.calls.append((a,kw)); reply=self.replies.pop(0)
        if isinstance(reply,Exception): raise reply
        return reply
    def close(self): pass

def token(): return Reply(body={'access_token':'secret-token','expires_in':'3600'})

class ClientTests(unittest.TestCase):
    def setUp(self): UPSClient._blocked_until=0
    def tearDown(self): UPSClient._blocked_until=0
    def client(self,replies):
        s=Session(replies); return UPSClient('test-client','test-secret',s,sleep=lambda _:None),s
    def test_token_cached_for_batch(self):
        c,s=self.client([token(),Reply(body=response()),Reply(body=response(number=N2))])
        c.track(N1);c.track(N2)
        self.assertEqual([a[0] for a,k in s.calls],['POST','GET','GET'])
        self.assertIn('onlinetools.ups.com/api/track/v1/details/',s.calls[1][0][1])
        self.assertIn('transId',s.calls[1][1]['headers'])
    def test_401_token_renewed_once(self):
        c,s=self.client([token(),Reply(401,{}),token(),Reply(body=response())]);c.track(N1)
        self.assertEqual(len(s.calls),4)
    def test_403_visible(self):
        c,s=self.client([token(),Reply(403,{'response':{'errors':[{'code':'TEST','message':'Not enabled'}]}})])
        with self.assertRaisesRegex(UPSCheckError,'access denied'):c.track(N1)
    def test_429_respected_no_burst(self):
        c,s=self.client([token(),Reply(429,{}, {'Retry-After':'60'})])
        with self.assertRaises(UPSCheckError) as ctx:c.track(N1)
        self.assertEqual(ctx.exception.retry_after,60)
        with self.assertRaises(UPSCheckError):c.track(N2)
        self.assertEqual(len(s.calls),2)
    def test_timeout_retried_bounded(self):
        c,s=self.client([token(),requests.Timeout(),requests.Timeout(),requests.Timeout()])
        with self.assertRaisesRegex(UPSCheckError,'connection failed'):c.track(N1)
        self.assertEqual(len(s.calls),4)
    def test_500_retried_bounded(self):
        c,s=self.client([token(),Reply(503,{}),Reply(503,{}),Reply(503,{})])
        with self.assertRaisesRegex(UPSCheckError,'HTTP 503'):c.track(N1)
        self.assertEqual(len(s.calls),4)
    def test_secrets_redacted_from_errors(self):
        c,s=self.client([token(),Reply(400,{'response':{'errors':[{'message':'test-secret test-client secret-token'}]}})])
        with self.assertRaises(UPSCheckError) as ctx:c.track(N1)
        for word in ('test-secret','test-client','secret-token'): self.assertNotIn(word,str(ctx.exception))
    def test_invalid_number_never_sent(self):
        c,s=self.client([])
        with self.assertRaises(UPSCheckError):c.track('bad / number')
        self.assertFalse(s.calls)
    def test_malformed_package_shape_is_reported(self):
        c,s=self.client([token(),Reply(body={'trackResponse':{'shipment':42}})])
        with self.assertRaisesRegex(UPSCheckError,'malformed'):c.track(N1)
    def test_bad_json(self):
        c,s=self.client([token(),Reply(200,ValueError())])
        with self.assertRaisesRegex(UPSCheckError,'non-JSON'):c.track(N1)

if __name__ == '__main__': unittest.main()
