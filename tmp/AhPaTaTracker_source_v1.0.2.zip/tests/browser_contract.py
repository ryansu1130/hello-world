"""Real Chromium/Playwright DOM contract tests with in-memory fixture navigation.

No HTTP navigation or live Apple request is made. A test-only Page facade
uses set_content() and returns a fixture URL; network events are simulated. Synthetic pages are intentionally NOT presented as
Apple's production DOM. This suite verifies adapter behavior and interaction,
not production support. Run separately from ordinary unit discovery.
"""
from __future__ import annotations
import json
import os
import shutil
import sys
import tempfile
import time
import unittest
from pathlib import Path
from urllib.parse import urlsplit
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'))
from core_loader import load_core
from test_apple_workspace import event,profile
from apple_accounts import AppleStore
from apple_browser import BrowserSession,AppleFlowError,SNAPSHOT_JS,parse_snapshot,installed_browser
from apple_secrets import SecretVault
from playwright.sync_api import sync_playwright
core=load_core()
NUMBER='W1000000001'
ORDER_LIST='http://127.0.0.1:8765/shop/order/list'
ORDER='http://127.0.0.1:8765/shop/order/detail/'+NUMBER

class FixturePage:
    # Production BrowserSession is NOT changed. The test facade replaces only
    # navigation/URL and leaves Chromium DOM, forms, selectors and clicks real.
    def __init__(self,raw,owner):self.raw=raw;self.owner=owner;self.url='about:blank'
    def __getattr__(self,key):return getattr(self.raw,key)
    def goto(self,url,**kwargs):
        self.url=url;self.raw.set_content(self.owner.fixture_html(url),wait_until='domcontentloaded',timeout=5000)
    def evaluate(self,script,*args):
        value=self.raw.evaluate(script,*args)
        if script==SNAPSHOT_JS:value['url']=self.url
        return value

class FixtureContext:
    def __init__(self,raw,owner):self.raw=raw;self.owner=owner
    def new_page(self):return FixturePage(self.raw.new_page(),self.owner)
    def cookies(self):return []

class BrowserContracts(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.p=sync_playwright().start()
        path=os.environ.get('AOT_TEST_BROWSER') or shutil.which('chromium')
        if not path:
            try:path=installed_browser('Edge')
            except AppleFlowError:path=installed_browser('Chrome')
        cls.browser_path=path
    @classmethod
    def tearDownClass(cls):cls.p.stop()
    def setUp(self):
        self.started=time.perf_counter();self.browser=self.p.chromium.launch(headless=True,executable_path=self.browser_path)
        self.tmp=tempfile.TemporaryDirectory();self.db=core.Database(Path(self.tmp.name)/'orders.db');self.store=AppleStore(self.db)
        aid=self.db.add_account('mail@example.test');self.db.save_update(aid,1,event());self.row=self.db.query_orders()[0];self.oid=self.row['id']
        self.cid=self.store.add_connection('owner@example.test');self.store.connection_state(self.cid,'connected','', 'owner@example.test','Apple page')
        f=Path(self.tmp.name)/'profiles.json';f.write_text(json.dumps([profile(phone='+15035550119'),profile(phone='+15035550120')]))
        self.store.import_files([f]);self.mode='normal';self.linked=False;self.calls=[];self.seen=[];self.status='Processing';self.identity='owner@example.test';self.rate=0
        self.host_patch=patch('apple_browser.apple_host',lambda u:urlsplit(u).hostname=='127.0.0.1');self.host_patch.start()
        self.list_patch=patch('apple_browser.ORDER_LIST',ORDER_LIST);self.list_patch.start()
        self.ctx=self.browser.new_context();self.ctx.set_default_timeout(5000);self.ctx.route('**/*',lambda r:r.abort())
        self.ctx.expose_binding('fixturePhone',self.phone_reply)
        self.s=BrowserSession.__new__(BrowserSession);self.s.connection=self.store.connection(self.cid);self.s.vault=SecretVault(Path(self.tmp.name));self.s.validated=True
        self.s.identity_method='Apple page';self.s.observed_email=self.identity;self.s.rate_limit=0;self.s.response_error='';self.s.task_pages={}
        self.s.context=FixtureContext(self.ctx,self);self.s.page=self.s.context.new_page();self.s.eta_parser=core.iso_date_from_text

    def tearDown(self):
        self.ctx.close();self.browser.close();self.db.close();self.tmp.cleanup();self.list_patch.stop();self.host_patch.stop()
        print(f' [{time.perf_counter()-self.started:.2f}s]',end='',flush=True)
    def phone_reply(self,source,phone):
        self.calls.append(phone)
        if self.mode=='uncertain':return {'unknown':True}
        if phone=='+15035550120':self.linked=True;return {'ok':True}
        return {'ok':False}
    def fixture_html(self,url):
        from types import SimpleNamespace
        u=urlsplit(url);self.seen.append(u.path)
        if self.rate:
            self.s._response(SimpleNamespace(url=url,status=self.rate,headers={'retry-after':'600'}))
            return '<h1>Too many requests</h1>'
        if u.path.endswith('/shop/order/list'):
            if self.mode=='expired':body='<h1>Sign in with your Apple Account</h1><input type="password">'
            else:
                body='<h1>Your Orders</h1><div id="account-email">'+self.identity+'</div><button>Sign Out</button>'
                body+=f'<a href="{ORDER}">{NUMBER}</a>' if self.linked else '<p>No recent orders</p>'
            return body
        if '/shop/order/detail/' in u.path:
            num='W9999999999' if self.mode=='wrong_order' else NUMBER
            body=f'<h1>Order Number {num}</h1><h2>{self.status}</h2><input value="PAYMENT_INPUT_SENTINEL"><input type="password" style="display:none" value="PASSWORD_SENTINEL">'
            if self.linked or self.mode in ('wrong_order','guest_controls'):body+='<button>Cancel Order</button><button>Update Payment Method</button>'
            else:
                body+='''<button id="add" onclick="this.style.display='none';document.querySelector('form').style.display='block'">Add to Apple Account</button>
                <form style="display:none" onsubmit="event.preventDefault();window.fixturePhone(document.querySelector('input[type=tel]').value).then(r=>{document.querySelector('#message').textContent=r.ok?'Order added to your Apple Account':r.unknown?'Please wait':'The phone number does not match this order';})">
                <label>Phone number used for this order</label><input type="tel"><button type="submit">Continue</button><p id="message"></p></form>'''
            return body
        raise AssertionError('Unknown fixture path')
    def task(self,action='associate'):
        j=self.store.create_job(self.store.snapshot([self.oid],self.cid,action),confirmed=action!='refresh')
        return self.store.take_next({self.cid},5)
    def test_real_dom_does_not_read_form_values(self):
        page=self.s.context.new_page();page.goto(ORDER);snap=page.evaluate(SNAPSHOT_JS)
        self.assertNotIn('PAYMENT_INPUT_SENTINEL',json.dumps(snap));self.assertNotIn('PASSWORD_SENTINEL',json.dumps(snap));self.assertFalse(snap['password_prompt'])
    def test_real_dom_signed_in_identity(self):
        self.s.navigate(self.s.page,ORDER_LIST);identity=self.s.verify_identity();self.assertEqual(identity['method'],'Apple page')
    def test_identity_switch_between_tasks_is_rejected(self):
        self.identity='other@example.test'
        with self.assertRaises(AppleFlowError) as cm:self.s._linked_in_listing(NUMBER)
        self.assertEqual(cm.exception.code,'identity_mismatch');self.assertFalse(self.s.validated)
    def test_exact_candidate_sequence_stops_on_success(self):
        t=self.task();state,_=self.s.associate(self.store,t,self.row,ORDER,0,lambda:False)
        self.assertEqual(state,'associated');self.assertEqual(self.calls,['+15035550119','+15035550120'])
        results=self.store.phone_candidates(self.row,self.cid);self.assertEqual([r['verification'] for r in sorted(results,key=lambda r:r['id'])],['Mismatch','Verified'])
        self.assertEqual(self.db.order_by_id(self.oid)['linked_apple_connection'],self.cid)
    def test_uncertain_response_keeps_current_candidate(self):
        self.mode='uncertain';t=self.task();state,_=self.s.associate(self.store,t,self.row,ORDER,0,lambda:False)
        self.assertEqual(state,'uncertain');self.assertEqual(self.calls,['+15035550119'])
        state,_=self.s.associate(self.store,t,self.row,ORDER,0,lambda:False)
        self.assertEqual(state,'uncertain');self.assertEqual(len(self.calls),1)
    def test_reconcile_uncertain_after_manual_link(self):
        self.mode='uncertain';t=self.task();self.s.associate(self.store,t,self.row,ORDER,0,lambda:False);self.linked=True
        state,_=self.s.associate(self.store,t,self.row,ORDER,0,lambda:False)
        self.assertEqual(state,'associated');self.assertEqual(len(self.calls),1)
        p=self.store.phone_candidates(self.row,self.cid);self.assertEqual(sum(r['verification']=='Verified' for r in p),1)
    def test_wrong_order_does_not_accept_management_controls(self):
        self.mode='wrong_order';t=self.task()
        with self.assertRaises(AppleFlowError) as cm:self.s.associate(self.store,t,self.row,ORDER,0,lambda:False)
        self.assertEqual(cm.exception.code,'order_mismatch');self.assertFalse(self.calls)
    def test_unlinked_guest_management_controls_require_association_handoff(self):
        self.mode='guest_controls';t=self.task()
        state,_=self.s.associate(self.store,t,self.row,ORDER,0,lambda:False)
        self.assertEqual(state,'awaiting_verification');self.assertFalse(self.calls)
        self.assertFalse(self.db.order_by_id(self.oid)['linked_apple_connection'])
        self.assertTrue(all(p['verification']=='Untried' for p in self.store.phone_candidates(self.row,self.cid)))
    def test_unlinked_guest_management_controls_do_not_verify_submitted_phone(self):
        self.mode='guest_controls';t=self.task();candidate=self.store.phone_candidates(self.row,self.cid)[0]
        self.store.mark_submitted(t,candidate['id']);self.store.record_phone_result(self.oid,candidate['id'],self.cid,'Uncertain')
        state,_=self.s.associate(self.store,t,self.row,ORDER,0,lambda:False)
        self.assertEqual(state,'uncertain');self.assertTrue(t['submitted']);self.assertFalse(self.calls)
        self.assertFalse(self.db.order_by_id(self.oid)['linked_apple_connection'])
        self.assertEqual(self.store.phone_candidates(self.row,self.cid)[0]['verification'],'Uncertain')
    def test_unlinked_guest_management_controls_do_not_authenticate_observations(self):
        self.mode='guest_controls';t=self.task('refresh')
        with self.assertRaises(AppleFlowError) as cm:self.s.read_order(t,self.row,ORDER)
        self.assertEqual(cm.exception.code,'needs_association')
        self.assertFalse(self.db.order_by_id(self.oid)['account_status_success_at'])
    def test_expired_session_preserves_candidates(self):
        self.mode='expired';t=self.task()
        with self.assertRaises(AppleFlowError) as cm:self.s.associate(self.store,t,self.row,ORDER,0,lambda:False)
        self.assertEqual(cm.exception.code,'auth_required');self.assertFalse(self.calls)
        self.assertTrue(all(p['verification']=='Untried' for p in self.store.phone_candidates(self.row,self.cid)))
    def test_rate_limit_is_not_phone_mismatch(self):
        self.rate=429
        with self.assertRaises(AppleFlowError) as cm:self.s.navigate(self.s.page,ORDER_LIST)
        self.assertEqual(cm.exception.code,'throttled');self.assertGreaterEqual(cm.exception.retry_after,600);self.assertFalse(self.calls)
    def test_read_current_status_from_authenticated_order(self):
        self.linked=True;t=self.task('refresh');_,_,obs=self.s.read_order(t,self.row,ORDER)
        self.assertEqual(obs['status'],'Processing');self.assertTrue(obs['authenticated'])
    def test_cancel_handoff_no_false_success(self):
        self.linked=True;t=self.task('cancel');state,message=self.s.mutation(self.store,t,self.row,ORDER)
        self.assertEqual(state,'awaiting_verification');self.assertTrue(t['submitted'])
        state,_=self.s.mutation(self.store,t,self.row,ORDER);self.assertEqual(state,'uncertain')
    def test_cancel_confirmation_after_handoff(self):
        self.linked=True;t=self.task('cancel');self.s.mutation(self.store,t,self.row,ORDER)
        page=self.s.task_pages[t['id']];page.evaluate("document.querySelector('h2').textContent='Canceled';document.body.insertAdjacentHTML('beforeend','<p>Your order has been canceled.</p>')")
        t['sequence']+=1;state,_=self.s.mutation(self.store,t,self.row,ORDER);self.assertEqual(state,'succeeded')
    def test_payment_method_confirmation_not_paid(self):
        self.linked=True;t=self.task('payment');state,_=self.s.mutation(self.store,t,self.row,ORDER);self.assertEqual(state,'awaiting_verification')
        page=self.s.task_pages[t['id']];page.evaluate("document.body.insertAdjacentHTML('beforeend','<p>Your payment details have been updated.</p>')")
        t['sequence']+=1;state,message=self.s.mutation(self.store,t,self.row,ORDER)
        self.assertEqual(state,'succeeded');self.assertIn('does not prove',message)
        self.assertEqual(self.db.order_by_id(self.oid)['status'],'Processing')

if __name__=='__main__':unittest.main(verbosity=2)
