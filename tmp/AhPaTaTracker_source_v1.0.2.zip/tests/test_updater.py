import hashlib
import io
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import app_updater as u


class FakeResponse:
    def __init__(self, status=200, json_data=None, text='', body=b'', headers=None):
        self.status_code=status; self._json=json_data; self.text=text; self._body=body; self.headers=headers or {}
    def json(self): return self._json
    def raise_for_status(self):
        if self.status_code >= 400:
            err=RuntimeError(f'HTTP {self.status_code}'); err.response=self; raise err
    def iter_content(self, chunk_size=1024):
        for i in range(0,len(self._body),max(1,chunk_size)):
            yield self._body[i:i+chunk_size]


class FakeSession:
    def __init__(self, responses): self.responses=list(responses); self.calls=[]
    def get(self, url, **kwargs):
        self.calls.append((url,kwargs)); return self.responses.pop(0)


class UpdaterTests(unittest.TestCase):
    def release(self, version='1.0.2'):
        return {
            'tag_name':'v'+version,'name':'Release '+version,'body':'notes','html_url':'https://github.com/x/y/releases/tag/v'+version,
            'draft':False,'prerelease':False,'published_at':'2026-10-17T00:00:00Z',
            'assets':[
                {'name':u.EXE_ASSET_NAME,'browser_download_url':'https://example/exe','size':4},
                {'name':u.SHA_ASSET_NAME,'browser_download_url':'https://example/sha','size':80},
            ]
        }

    def test_version_compare(self):
        self.assertTrue(u.is_newer_version('1.0.2','1.0.1'))
        self.assertFalse(u.is_newer_version('1.0.1','1.0.1'))
        self.assertFalse(u.is_newer_version('1.0.0','1.0.1'))

    def test_check_latest_release(self):
        s=FakeSession([FakeResponse(json_data=self.release())])
        info=u.check_latest_release('1.0.1','x/y',s)
        self.assertEqual(info.version,'1.0.2')
        self.assertEqual(info.exe_url,'https://example/exe')

    def test_up_to_date_returns_none(self):
        s=FakeSession([FakeResponse(json_data=self.release('1.0.1'))])
        self.assertIsNone(u.check_latest_release('1.0.1','x/y',s))

    def test_missing_assets_is_not_installable(self):
        data=self.release(); data['assets']=[]
        with self.assertRaises(u.UpdateError):
            u.check_latest_release('1.0.1','x/y',FakeSession([FakeResponse(json_data=data)]))

    def test_download_verifies_sha(self):
        body=b'fake-windows-exe-data'
        digest=hashlib.sha256(body).hexdigest()
        info=u.UpdateInfo('1.0.2','v1.0.2','t','n','https://r','https://e','https://s')
        s=FakeSession([FakeResponse(text=digest+'  AhPaTaTracker.exe\n'),FakeResponse(body=body,headers={'Content-Length':str(len(body))})])
        with tempfile.TemporaryDirectory() as td:
            out=Path(td)/'AhPaTaTracker.exe'
            got=u.download_and_verify(info,out,session=s)
            self.assertEqual(got.read_bytes(),body)

    def test_bad_sha_is_deleted(self):
        body=b'bad'
        info=u.UpdateInfo('1.0.2','v1.0.2','t','n','https://r','https://e','https://s')
        s=FakeSession([FakeResponse(text='0'*64),FakeResponse(body=body)])
        with tempfile.TemporaryDirectory() as td:
            out=Path(td)/'AhPaTaTracker.exe'
            with self.assertRaises(u.UpdateError): u.download_and_verify(info,out,session=s)
            self.assertFalse(out.exists())
            self.assertFalse(Path(str(out)+'.part').exists())

    def test_self_update_false_in_source_mode(self):
        with mock.patch.object(u.os,'name','posix'):
            self.assertFalse(u.can_self_update())


if __name__=='__main__': unittest.main()
