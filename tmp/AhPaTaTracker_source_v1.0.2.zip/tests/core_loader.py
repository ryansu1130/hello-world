"""Load the actual non-UI production code without requiring Qt.

No business logic is copied or mocked. Qt's worker/signals are replaced only to
run the production worker synchronously in tests. HTTP/credentials are mocked
by individual tests. The separate GUI smoke test uses real Qt.
"""
import ast
from pathlib import Path
import sys
import types

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

class BoundSignal:
    def __init__(self): self.calls = []; self.callbacks = []
    def connect(self, callback): self.callbacks.append(callback)
    def emit(self, *args):
        self.calls.append(args)
        for cb in self.callbacks: cb(*args)

class Signal:
    def __init__(self, *args): self.name = ''
    def __set_name__(self, owner, name): self.name = name
    def __get__(self, obj, owner):
        if obj is None: return self
        return obj.__dict__.setdefault('_signal_' + self.name, BoundSignal())

class Thread:
    def __init__(self, *args, **kwargs): pass

def load_core():
    path = ROOT / 'AppleOrderTracker.py'
    parsed = ast.parse(path.read_text(encoding='utf-8'), str(path))
    wanted_classes = {'ParsedOrder', 'AppleMailParser', 'Database', 'GmailIMAPClient', 'VerificationWorker', 'UPSConnectionTestWorker', 'SyncWorker'}
    nodes = []
    for node in parsed.body:
        if isinstance(node, ast.Import):
            if all(a.name not in ('keyring',) for a in node.names): nodes.append(node)
        elif isinstance(node, ast.ImportFrom):
            if not (node.module or '').startswith(('PySide6', 'ui_support')): nodes.append(node)
        elif isinstance(node, (ast.Assign, ast.AnnAssign)):
            nodes.append(node)
        elif isinstance(node, ast.Expr) and node.lineno < 1368:
            nodes.append(node)
        elif isinstance(node, ast.FunctionDef) and node.name not in ('main',):
            nodes.append(node)
        elif isinstance(node, ast.ClassDef) and node.name in wanted_classes:
            nodes.append(node)
    module = types.ModuleType('tracker_core_test')
    module.__file__ = str(path)
    module.__dict__.update(keyring=types.SimpleNamespace(get_password=lambda *args: ''),
                           Signal=Signal, QThread=Thread)
    sys.modules[module.__name__] = module
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(path), 'exec'), module.__dict__)
    return module
