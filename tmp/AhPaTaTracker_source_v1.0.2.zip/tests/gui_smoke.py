"""Real Qt startup / interaction gate, run by build_windows.bat.

Uses a temporary database and temporary QSettings. Makes no network requests and
does not read/write the user's normal database, credentials or browser profile.
"""
from __future__ import annotations
import os
os.environ['QT_QPA_PLATFORM'] = 'offscreen'
import sys
import tempfile
import traceback
from dataclasses import fields
from pathlib import Path
from unittest.mock import patch
import unittest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from PySide6.QtCore import Qt, QSettings, QDate, QPoint
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QApplication, QDialog, QStyle, QStyleOptionViewItem
from PySide6.QtTest import QTest
import AppleOrderTracker as m
from ui_support import ReadableCalendar, row_option

APP=QApplication.instance() or QApplication([])
TEMP=tempfile.TemporaryDirectory(prefix='aot_gui_test_')
TMP=Path(TEMP.name)
QSettings.setDefaultFormat(QSettings.IniFormat)
QSettings.setPath(QSettings.IniFormat,QSettings.UserScope,str(TMP/'settings'))
GUI_ERRORS=[]
sys.excepthook=lambda typ,value,tb:GUI_ERRORS.append(''.join(traceback.format_exception(typ,value,tb)))

class GUITests(unittest.TestCase):
    def setUp(self):
        self.folder=Path(tempfile.mkdtemp(dir=TMP))
        self.patchers=[patch.object(m,'db_path',lambda:self.folder/'orders.db'),
                       patch.object(m,'app_data_dir',lambda:self.folder),
                       patch.object(m.MainWindow,'show_first_run_hint',lambda _self:None),
                       patch.object(m.ProductImageCache,'icon_for',lambda _self,url:QIcon()),
                       patch.object(m.keyring,'get_password',lambda *a:None),
                       patch('requests.sessions.Session.request',side_effect=AssertionError('No network permitted in GUI tests'))]
        for p in self.patchers:p.start()
        self.window=m.MainWindow(); self.window.resize(1400,920)
        account=self.window.db.add_account('demo@example.com')
        self.order_ids=[]
        for i,(kind,state,store) in enumerate([('Shipping','Shipped',''),('Shipping','Shipped',''),('Pickup','Ready for Pickup','Apple Beta'),('Pickup','Processing','Apple Alpha')]):
            kw={f.name:'' for f in fields(m.ParsedOrder)}
            kw.update(order_number=f'W100000000{i}',order_type=kind,status=state,item_summary='Demo phone',qty=2,
                      address='Demo address',pickup_store=store,pickup_time='10:30 AM - 10:45 AM',
                      order_date='2026-09-12',eta_date='2026-09-24',email_date='2026-09-20T12:00:00-07:00',
                      message_id=f'demo-{i}',tracking_number=f'1Z000000000000000{i}' if kind=='Shipping' else '',carrier='UPS' if kind=='Shipping' else '')
            self.window.db.save_update(account,i+1,m.ParsedOrder(**kw))
        self.window.filter_start='2026-09-01';self.window.filter_end='2026-09-30'
        self.window.refresh_all();self.window.show();APP.processEvents()
    def tearDown(self):
        self.window.close();APP.processEvents();self.window.deleteLater();APP.processEvents()
        for p in reversed(self.patchers):p.stop()
        if GUI_ERRORS:
            self.fail('\n'.join(GUI_ERRORS))
    def test_branding_and_sync_mode_defaults(self):
        w=self.window
        self.assertIn('Ah Pa Ta Tracker', w.windowTitle())
        self.assertIn(m.APP_VERSION, w.windowTitle())
        dlg=m.SyncRangeDialog(w.db,w.settings,w)
        self.assertEqual(dlg.sync_mode(),'new')
        dlg.mode_combo.setCurrentIndex(1)
        self.assertEqual(dlg.sync_mode(),'full')
        dlg.close();dlg.deleteLater();APP.processEvents()

    def test_startup_all_pages_and_themes(self):
        for theme in ('light','dark'):
            self.window.apply_theme(theme)
            for page in range(5):
                self.window.show_page(page)
                APP.processEvents()
            self.window.open_release_day('2026-09-12');APP.processEvents()
            self.assertEqual(self.window.day_model.rowCount(),4)
            self.assertEqual(self.window.db.tab_counts()['All Orders'],4)
    def test_pickup_check_uncheck_and_select_export(self):
        w=self.window;w.show_page(w.PAGE_PICKUP_TRACKING,w.pickup_nav)
        APP.processEvents()
        idx=w.pickup_tracking_model.index(0,0)
        pos=w.pickup_table.visualRect(idx).center()
        QTest.mouseClick(w.pickup_table.viewport(),Qt.LeftButton,pos=pos);APP.processEvents()
        self.assertEqual(len(w.pickup_selected_ids()),1)
        with patch.object(m,'save_rows_csv') as writer:
            w.export_selected_pickup_orders()
            self.assertEqual(len(writer.call_args.args[2]),1)
        QTest.mouseClick(w.pickup_table.viewport(),Qt.LeftButton,pos=pos);APP.processEvents()
        self.assertEqual(w.pickup_selected_ids(),[])
    def test_main_and_shipping_check_uncheck(self):
        w=self.window
        for page,table,model in ((w.PAGE_ORDERS,w.table,w.table_model),(w.PAGE_TRACKING,w.tracking_table,w.tracking_model)):
            w.show_page(page);APP.processEvents()
            idx=model.index(0,0);pos=table.visualRect(idx).center()
            QTest.mouseClick(table.viewport(),Qt.LeftButton,pos=pos);APP.processEvents()
            self.assertEqual(len(model.checked_order_ids()),1)
            QTest.mouseClick(table.viewport(),Qt.LeftButton,pos=pos);APP.processEvents()
            self.assertEqual(model.checked_order_ids(),[])
    def test_bulk_save_updates_tracking_and_counts(self):
        w=self.window;w.pickup_tracking_model.set_all_checked(True)
        with patch.object(m,'BulkStatusDialog') as dialog:
            dialog.return_value.exec.return_value=QDialog.Accepted
            dialog.return_value.selected_status.return_value='Picked Up'
            w.bulk_change_status(w.pickup_tracking_model)
        self.assertEqual(w.db.tab_counts()['Picked Up'],2)
        self.assertEqual(w.pickup_tracking_model.rowCount(),0)
        self.assertEqual(w.db.counts()['All'],4)
    def test_calendar_rendering_and_two_digit_days(self):
        w=self.window;cal=w.date_picker.calendarWidget()
        self.assertIsInstance(cal,ReadableCalendar)
        self.assertGreaterEqual(cal.minimumWidth(),350)
        for theme in ('light','dark'):
            w.apply_theme(theme)
            cal.setCurrentPage(2026,9);cal.setSelectedDate(QDate(2026,9,24))
            cal.set_activity_counts({'2026-09-24':142});cal.resize(cal.sizeHint());cal.show()
            APP.processEvents()
            pix=cal.grab();self.assertFalse(pix.isNull())
            self.assertEqual(cal._activity_counts['2026-09-24'],142)
            cal.hide()
    def test_hover_marks_whole_row_without_checking(self):
        w=self.window;table=w.table;table._hover_row=0
        for col in (1,3,5,7):
            opt=QStyleOptionViewItem();opt.widget=table
            opt=row_option(opt,w.table_model.index(0,col))
            self.assertTrue(opt.state & QStyle.State_Selected)
        self.assertEqual(w.table_model.checked_order_ids(),[])
    def test_archiving_refreshes_all_pages_and_restores(self):
        w=self.window;w.set_release_archive('2026-09-12',True)
        self.assertEqual(w.table_model.rowCount(),0);self.assertEqual(w.tracking_model.rowCount(),0);self.assertEqual(w.pickup_tracking_model.rowCount(),0)
        w.set_release_archive('2026-09-12',False)
        self.assertEqual(w.table_model.rowCount(),4);self.assertEqual(w.pickup_tracking_model.rowCount(),2)
    def test_sort_keeps_checked_identity(self):
        model=self.window.pickup_tracking_model
        idx=model.index(0,0);model.setData(idx,Qt.Checked,Qt.CheckStateRole)
        selected=model.checked_order_ids();model.sort(3,Qt.AscendingOrder)
        self.assertEqual(model.checked_order_ids(),selected)
        self.assertEqual(model.rows[0]['pickup_store'],'Apple Alpha')
    def test_settings_render_and_read_legacy_keys(self):
        from ups_credentials import LEGACY_ID_KEY, LEGACY_SECRET_KEY
        creds={LEGACY_ID_KEY:'gui-test-client',LEGACY_SECRET_KEY:'gui-test-secret'}
        with patch.object(m.keyring,'get_password',lambda service,key:creds.get(key)):
            for theme in ('light','dark'):
                self.window.apply_theme(theme)
                dlg=m.SettingsDialog(self.window.settings,self.window)
                dlg.show();APP.processEvents()
                self.assertEqual(dlg.ups_client_id.text(),'gui-test-client')
                self.assertTrue(dlg.test_tracking_button.isEnabled())
                self.assertFalse(dlg.grab().isNull())
                dlg.close();dlg.deleteLater();APP.processEvents()

    def test_settings_rejects_mismatched_pair_without_testing_old_values(self):
        from ups_credentials import LEGACY_ID_KEY, LEGACY_SECRET_KEY
        creds={LEGACY_ID_KEY:'old-gui-client',LEGACY_SECRET_KEY:'old-gui-secret'}
        with patch.object(m.keyring,'get_password',lambda service,key:creds.get(key)), patch.object(m.keyring,'set_password') as write, patch.object(m.QMessageBox,'warning'), patch.object(m,'UPSConnectionTestWorker') as worker:
            dlg=m.SettingsDialog(self.window.settings,self.window)
            dlg.ups_client_id.setText('different-gui-client')
            dlg.ups_client_secret.clear()
            dlg._test_ups()
            write.assert_not_called();worker.assert_not_called()
            dlg.close();dlg.deleteLater();APP.processEvents()

    def test_settings_successful_oauth_never_says_tracking_passed(self):
        class FakeWorker:
            report={'oauth_ok':True,'tracking_ok':None,'lines':['OAuth token: PASS. Tracking API: NOT TESTED.']}
            def deleteLater(self): pass
            def isRunning(self): return False
        dlg=m.SettingsDialog(self.window.settings,self.window)
        dlg.ups_test_worker=FakeWorker()
        with patch.object(m.QDialog,'exec',return_value=m.QDialog.Rejected):
            dlg._ups_test_finished()
        self.assertIn('NOT tested',dlg.ups_status.text())
        dlg.close();dlg.deleteLater();APP.processEvents()

    def test_details_dialog_both_themes(self):
        w=self.window
        for theme in ('light','dark'):
            w.apply_theme(theme);dlg=m.OrderDetailDialog(w.db,w.db.query_orders()[0],w)
            dlg.show();APP.processEvents();self.assertFalse(dlg.grab().isNull());dlg.close();dlg.deleteLater()

    def test_details_refresh_lifecycle(self):
        from apple_account_ui import AppleDetailSection
        w=self.window;dlg=m.OrderDetailDialog(w.db,w.db.query_orders()[0],w)
        section=dlg.findChild(AppleDetailSection)
        timers=(dlg._phone_refresh_timer,section.timer)
        for timer in timers:timer.setInterval(10)
        try:
            with patch.object(w.db,'order_by_id',wraps=w.db.order_by_id) as read:
                self.assertTrue(all(not timer.isActive() for timer in timers))
                dlg.show();APP.processEvents();QTest.qWait(30)
                self.assertTrue(all(timer.isActive() for timer in timers));self.assertTrue(read.called)
                for hide in (dlg.hide,dlg.close,dlg.reject):
                    hide();APP.processEvents()
                    self.assertTrue(all(not timer.isActive() for timer in timers))
                    read.reset_mock();QTest.qWait(30);read.assert_not_called()
                    dlg.show();APP.processEvents();QTest.qWait(30)
                    self.assertTrue(all(timer.isActive() for timer in timers));self.assertTrue(read.called)
                # The owner closes its database before the dialogs are deleted.
                # No visible or deferred child timer may continue using it.
                w.close();APP.processEvents()
                self.assertTrue(all(not timer.isActive() for timer in timers))
                read.reset_mock();QTest.qWait(30);read.assert_not_called()
        finally:
            dlg.close();dlg.deleteLater();APP.processEvents()

if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(GUITests))
    APP.processEvents();TEMP.cleanup()
    if GUI_ERRORS:
        print('\n'.join(GUI_ERRORS));sys.exit(1)
    sys.exit(0 if result.wasSuccessful() else 1)
