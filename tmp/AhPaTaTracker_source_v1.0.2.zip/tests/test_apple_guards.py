import json
import tempfile
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from test_apple_workspace import core,event,profile
from apple_accounts import AppleStore
from apple_browser import BrowserSession,AppleFlowError
from apple_profiles import candidates,safe_paths
from apple_jobs import AppleRunner

class GuardTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.db=core.Database(Path(self.tmp.name)/'db');self.store=AppleStore(self.db)
        a=self.db.add_account('mail@example.test');self.db.save_update(a,1,event());self.oid=self.db.query_orders()[0]['id'];self.cid=self.store.add_connection('owner@example.test');self.store.connection_state(self.cid,'connected')
    def tearDown(self):self.db.close();self.tmp.cleanup()
    def queued(self,action='refresh'):
        return self.store.create_job(self.store.snapshot([self.oid],self.cid,action),confirmed=action!='refresh')
    def guest_controls_session(self):
        session=BrowserSession.__new__(BrowserSession)
        session.connection=self.store.connection(self.cid);session.validated=True
        session._linked_in_listing=lambda number:False
        session.task_page=lambda *a,**k:SimpleNamespace(locator=lambda selector:SimpleNamespace(count=lambda:0))
        session._unique_button=lambda *a,**k:None
        row=self.db.order_by_id(self.oid)
        session.snapshot=lambda page:{'url':'https://secure.store.apple.com/shop/order/guest/'+row['order_number']+'/fixture',
            'text':row['order_number']+' Processing','headings':['Processing'],'identities':[],
            'password_prompt':False,'auth_prompt':False,'controls':[{'text':'Cancel Order'},{'text':'Update Payment Method'}]}
        path=Path(self.tmp.name)/'profiles.json';path.write_text(json.dumps([profile()]))
        self.store.import_files([path])
        return session,row
    def test_unlinked_guest_controls_do_not_confirm_association(self):
        session,row=self.guest_controls_session();self.queued('associate');task=self.store.take_next({self.cid})
        state,_=session.associate(self.store,task,row,'',12,lambda:False)
        self.assertEqual(state,'awaiting_verification')
        self.assertFalse(self.db.order_by_id(self.oid)['linked_apple_connection'])
        self.assertTrue(all(p['verification']=='Untried' for p in self.store.phone_candidates(row,self.cid)))
    def test_unlinked_guest_controls_do_not_verify_submitted_phone(self):
        session,row=self.guest_controls_session();self.queued('associate');task=self.store.take_next({self.cid})
        candidate=self.store.phone_candidates(row,self.cid)[0]
        self.store.mark_submitted(task,candidate['id']);self.store.record_phone_result(self.oid,candidate['id'],self.cid,'Uncertain')
        state,_=session.associate(self.store,task,row,'',12,lambda:False)
        self.assertEqual(state,'uncertain');self.assertTrue(task['submitted'])
        self.assertFalse(self.db.order_by_id(self.oid)['linked_apple_connection'])
        self.assertEqual(self.store.phone_candidates(row,self.cid)[0]['verification'],'Uncertain')
    def test_unlinked_guest_controls_are_not_authenticated_observation(self):
        session,row=self.guest_controls_session();self.queued();task=self.store.take_next({self.cid})
        with self.assertRaises(AppleFlowError) as cm:session.read_order(task,row,'')
        self.assertEqual(cm.exception.code,'needs_association')
        self.assertFalse(self.db.order_by_id(self.oid)['account_status_success_at'])
    def test_previously_proven_link_can_refresh_without_current_listing_match(self):
        session,row=self.guest_controls_session();self.queued('associate');task=self.store.take_next({self.cid})
        self.store.association(task,'already_associated')
        _,_,observation=session.read_order(task,self.db.order_by_id(self.oid),'')
        self.assertTrue(observation['authenticated']);self.assertEqual(observation['status'],'Processing')
    def test_frozen_scope_tampering_rejected(self):
        j=self.queued('cancel')
        with self.db.conn:self.db.conn.execute("UPDATE apple_tasks SET scope='{}' WHERE job_id=?",(j,))
        self.assertIsNone(self.store.take_next({self.cid}));self.assertEqual(self.store.tasks(j)[0]['error_code'],'scope_changed')
    def test_frozen_job_hash_tampering_rejected(self):
        j=self.queued('cancel')
        with self.db.conn:self.db.conn.execute("UPDATE apple_jobs SET confirmation_hash='broken' WHERE id=?",(j,))
        self.assertIsNone(self.store.take_next({self.cid}));self.assertEqual(self.store.tasks(j)[0]['state'],'failed')
    def test_payment_root_paths_not_mappable(self):
        for key in ('creditCardNumber','card_number','PAN','cvvCode','access_token','password'):
            data=profile();data[key]='SECRET_SENTINEL';self.assertNotIn(key,safe_paths(data))
            with self.assertRaises(ValueError):candidates(data,{'email':'email','phone':key})
    def test_stop_request_observed_inside_candidate_loop(self):
        j=self.queued('associate');t=self.store.take_next({self.cid})
        runner=AppleRunner(core.Database,self.db.path,lambda r:'',lambda t,b:None);runner.send('stop_job',job_id=j)
        self.assertTrue(runner._halted(self.store,t))
    def test_pause_observed_inside_candidate_loop(self):
        j=self.queued('associate');t=self.store.take_next({self.cid});self.store.job_control(j,'pause')
        runner=AppleRunner(core.Database,self.db.path,lambda r:'',lambda t,b:None);self.assertTrue(runner._halted(self.store,t))
    def test_retry_after_http_date(self):
        from email.utils import formatdate
        s=BrowserSession.__new__(BrowserSession);s.rate_limit=0
        s._response(SimpleNamespace(url='https://secure.store.apple.com/shop/order/list',status=429,headers={'retry-after':formatdate(time.time()+900,usegmt=True)}))
        self.assertGreaterEqual(s.rate_limit,898)
    def test_masked_payment_mismatch_not_success(self):
        j=self.queued('payment');t=self.store.take_next({self.cid});t['submitted']=1
        snap=json.loads(t['snapshot']);snap['method']='Visa ****1234';t['snapshot']=json.dumps(snap)
        session=BrowserSession.__new__(BrowserSession);obs={'authenticated':True,'order_number':'W1000000001','status':'Processing','raw_status':'Processing','items':[]}
        session.read_order=lambda *a,**k:(None,{'text':'Your payment details have been updated.','payment_last4':'9999'},obs)
        state,_=session.mutation(self.store,t,self.db.order_by_id(self.oid),'')
        self.assertEqual(state,'uncertain')
    def test_masked_payment_match_can_confirm_method_only(self):
        j=self.queued('payment');t=self.store.take_next({self.cid});t['submitted']=1
        snap=json.loads(t['snapshot']);snap['method']='Visa ****1234';t['snapshot']=json.dumps(snap)
        session=BrowserSession.__new__(BrowserSession);obs={'authenticated':True,'order_number':'W1000000001','status':'Processing','raw_status':'Processing','items':[]}
        session.read_order=lambda *a,**k:(None,{'text':'Your payment details have been updated.','payment_last4':'1234'},obs)
        state,message=session.mutation(self.store,t,self.db.order_by_id(self.oid),'')
        self.assertEqual(state,'succeeded');self.assertIn('does not prove',message)
        self.assertEqual(self.db.order_by_id(self.oid)['status'],'Processing')

class AuthenticationGuardTests(unittest.TestCase):
    def test_verification_code_is_not_order_phone(self):
        from apple_browser import parse_snapshot
        snap={'url':'https://secure.store.apple.com/shop/order/guest/W1000000001/token','text':'W1000000001 Processing','headings':['Processing'],'auth_prompt':True}
        with self.assertRaises(AppleFlowError) as cm:parse_snapshot(snap,'W1000000001',True)
        self.assertEqual(cm.exception.code,'auth_required')
    def test_wrong_url_order_rejected_even_if_body_mentions_target(self):
        from apple_browser import parse_snapshot
        snap={'url':'https://secure.store.apple.com/shop/order/guest/W1000000002/token','text':'W1000000001 Processing','headings':['Processing']}
        with self.assertRaises(AppleFlowError) as cm:parse_snapshot(snap,'W1000000001',True)
        self.assertEqual(cm.exception.code,'order_mismatch')

if __name__=='__main__':unittest.main()
