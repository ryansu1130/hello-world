"""Offline authentication regression tests. All credentials/tokens are fictional."""
from __future__ import annotations
import base64
import json
import sys
from pathlib import Path
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import requests
from requests.adapters import BaseAdapter
from ups_tracking import UPSClient, UPSCheckError, BearerAuth, api_errors
from ups_credentials import (PAIR_KEY, LEGACY_ID_KEY, LEGACY_SECRET_KEY, UPSCredentialError,
                             load_pair, save_pair, clear_pair, clean_credential)
from test_ups import Session, Reply, response, N1

CID = 'fictional-client-id'
SECRET = 'fictional-client-secret'
TOKEN = 'fictional-token-12345'


def token(value=TOKEN):
    return Reply(body={'access_token': value, 'token_type': 'Bearer', 'expires_in': '3600'})


def rejection(code='250002', http=401):
    return Reply(http, {'response': {'errors': [{'code': code, 'message': 'Invalid Authentication Information.'}]}})


class CredentialBackend:
    def __init__(self): self.data = {}; self.fail = False
    def get_password(self, service, key): return self.data.get((service, key))
    def set_password(self, service, key, value):
        if self.fail: raise RuntimeError('Storage failure')
        self.data[(service, key)] = value
    def delete_password(self, service, key): self.data.pop((service, key), None)


class CredentialTests(unittest.TestCase):
    def setUp(self): self.backend = CredentialBackend(); self.service = 'test-tracker'
    def legacy(self):
        self.backend.set_password(self.service, LEGACY_ID_KEY, CID)
        self.backend.set_password(self.service, LEGACY_SECRET_KEY, SECRET)
    def test_read_legacy_without_changing_it(self):
        self.legacy(); before=dict(self.backend.data)
        self.assertEqual(load_pair(self.backend,self.service),(CID,SECRET))
        self.assertEqual(before,self.backend.data)
    def test_new_id_cannot_reuse_saved_secret(self):
        self.legacy(); before=dict(self.backend.data)
        with self.assertRaisesRegex(UPSCredentialError,'Client ID changed'):
            save_pair(self.backend,self.service,'different-client','')
        self.assertEqual(before,self.backend.data)
    def test_same_id_can_retain_saved_secret(self):
        self.legacy();save_pair(self.backend,self.service,CID,'')
        self.assertEqual(load_pair(self.backend,self.service),(CID,SECRET))
    def test_pair_saved_atomically_in_one_key(self):
        self.legacy(); old_id=self.backend.data[(self.service,LEGACY_ID_KEY)]
        save_pair(self.backend,self.service,'new-client','new-secret')
        self.assertEqual(load_pair(self.backend,self.service),('new-client','new-secret'))
        self.assertEqual(self.backend.data[(self.service,LEGACY_ID_KEY)],old_id)
        record=json.loads(self.backend.data[(self.service,PAIR_KEY)])
        self.assertEqual(record['format'],2)
    def test_failed_save_preserves_old_pair(self):
        save_pair(self.backend,self.service,CID,SECRET)
        self.backend.fail=True
        with self.assertRaises(UPSCredentialError):save_pair(self.backend,self.service,'new-client','new-secret')
        self.assertEqual(load_pair(self.backend,self.service),(CID,SECRET))
    def test_remove_clears_new_and_old_entries(self):
        self.legacy();save_pair(self.backend,self.service,CID,SECRET)
        clear_pair(self.backend,self.service)
        self.assertEqual(load_pair(self.backend,self.service),('',''))
    def test_whitespace_edges_trimmed_not_embedded(self):
        self.assertEqual(clean_credential('  abc-123\n','Client Secret'),'abc-123')
        for value in ('abc def','abc\ndef','abc\u200bdef'):
            with self.subTest(value=value),self.assertRaises(UPSCredentialError):clean_credential(value,'Client Secret')
    def test_invalid_credential_error_does_not_echo_value(self):
        secret='very-secret\nvalue'
        with self.assertRaises(UPSCredentialError) as ctx:clean_credential(secret,'Client Secret')
        self.assertNotIn(secret,str(ctx.exception))
    def test_malformed_canonical_pair_does_not_fallback_to_old_keys(self):
        self.legacy();self.backend.set_password(self.service,PAIR_KEY,'corrupt-data')
        with self.assertRaises(UPSCredentialError):load_pair(self.backend,self.service)
    def test_blank_id_does_not_save(self):
        with self.assertRaises(UPSCredentialError):save_pair(self.backend,self.service,'',SECRET)
        self.assertEqual(self.backend.data,{})


class DiagnosticTests(unittest.TestCase):
    def setUp(self): UPSClient._blocked_until=0
    def tearDown(self): UPSClient._blocked_until=0
    def client(self,replies):
        session=Session(replies)
        return UPSClient(CID,SECRET,session,sleep=lambda _:None),session
    def test_success_checks_both_steps(self):
        c,s=self.client([token(),Reply(body=response('Returned to Sender'))])
        report=c.diagnose(N1)
        self.assertTrue(report['oauth_ok']);self.assertTrue(report['tracking_ok'])
        self.assertEqual(report['status'],'Returned to Sender')
        self.assertEqual([a[0] for a,kw in s.calls],['POST','GET'])
    def test_oauth_only_does_not_claim_tracking_success(self):
        c,s=self.client([token()]);r=c.diagnose()
        self.assertTrue(r['oauth_ok']);self.assertIsNone(r['tracking_ok'])
        self.assertIn('NOT TESTED',' '.join(r['lines']));self.assertEqual(len(s.calls),1)
    def test_oauth_rejection_stops_before_tracking(self):
        c,s=self.client([rejection('10401')]);r=c.diagnose(N1)
        self.assertFalse(r['oauth_ok']);self.assertEqual(r['stage'],'OAuth token')
        self.assertEqual(r['ups_codes'],['10401']);self.assertEqual(len(s.calls),1)
    def test_tracking_250002_explains_oauth_success_and_retries_once(self):
        c,s=self.client([token(),rejection(),token('another-fictional-token'),rejection()]);r=c.diagnose(N1)
        self.assertTrue(r['oauth_ok']);self.assertFalse(r['tracking_ok'])
        self.assertEqual(r['stage'],'Tracking API');self.assertEqual(r['ups_codes'],['250002'])
        self.assertEqual(len(s.calls),4)
        self.assertIn('SAME UPS app',' '.join(r['lines']))
    def test_250002_in_http_400_also_gets_one_fresh_token(self):
        c,s=self.client([token(),rejection(http=400),token(),Reply(body=response())]);r=c.diagnose(N1)
        self.assertTrue(r['tracking_ok']);self.assertEqual(len(s.calls),4)
    def test_tracking_403_does_not_retry(self):
        c,s=self.client([token(),Reply(403,{'response':{'errors':[{'code':'10403','message':'Access Denied'}]}})])
        r=c.diagnose(N1)
        self.assertEqual(r['stage'],'Tracking API');self.assertEqual(r['error_kind'],'access');self.assertEqual(len(s.calls),2)
    def test_production_token_and_tracking_share_same_host(self):
        c,s=self.client([token(),Reply(body=response())]);c.track(N1)
        self.assertTrue(all(a[1].startswith('https://onlinetools.ups.com/') for a,kw in s.calls))
        self.assertTrue(all(kw['allow_redirects'] is False for a,kw in s.calls))
    def test_redirect_not_followed_or_called_success(self):
        c,s=self.client([Reply(302,{}, {'Location':'https://bad.example/'})]);r=c.diagnose(N1)
        self.assertEqual(r['error_kind'],'redirect');self.assertFalse(r['oauth_ok']);self.assertEqual(len(s.calls),1)
    def test_no_keys_or_tokens_in_diagnostic_output(self):
        encoded=base64.b64encode(f'{CID}:{SECRET}'.encode()).decode()
        c,s=self.client([token(),Reply(400,{'response':{'errors':[{'message':f'{CID} {SECRET} {TOKEN} {encoded}'}]}})])
        r=c.diagnose(N1);rendered=json.dumps(r)
        for value in (CID,SECRET,TOKEN,encoded):self.assertNotIn(value,rendered)
    def test_retired_token_is_redacted(self):
        other='replacement-token-12345'
        c,s=self.client([token(),rejection(),token(other),Reply(400,{'response':{'errors':[{'message':TOKEN+' '+other}]}})])
        r=c.diagnose(N1)
        self.assertNotIn(TOKEN,json.dumps(r));self.assertNotIn(other,json.dumps(r))
    def test_token_with_whitespace_is_rejected_not_modified(self):
        c,s=self.client([token('token with space')]);r=c.diagnose(N1)
        self.assertFalse(r['oauth_ok']);self.assertEqual(len(s.calls),1)
    def test_invalid_input_no_network(self):
        c,s=self.client([]);r=c.diagnose('https://tracking.example/a')
        self.assertEqual(r['error_kind'],'invalid_number');self.assertFalse(s.calls)
    def test_invalid_credential_no_network(self):
        s=Session([]);c=UPSClient('fake id',SECRET,s);r=c.diagnose(N1)
        self.assertEqual(r['stage'],'Credentials');self.assertFalse(s.calls)
    def test_expired_token_response_rejected(self):
        c,s=self.client([Reply(body={'access_token':TOKEN,'expires_in':'0'})]);r=c.diagnose()
        self.assertFalse(r['oauth_ok'])
    def test_oauth_standard_error_fields(self):
        c,s=self.client([Reply(400,{'error':'invalid_client','error_description':'Application rejected'})]);r=c.diagnose(N1)
        self.assertEqual(r['error_kind'],'auth');self.assertIn('invalid_client',r['ups_codes'])
    def test_errors_object_does_not_crash_error_handler(self):
        self.assertIn('250002',api_errors({'response':{'errors':{'code':'250002','message':'Rejected'}}}))


class RecordingAdapter(BaseAdapter):
    """Exercise requests' REAL prepare/auth pipeline without leaving this process."""
    def __init__(self): self.requests=[]
    def send(self, request, **kwargs):
        self.requests.append(request)
        r=requests.Response();r.status_code=200;r.request=request;r.url=request.url
        r.headers['Content-Type']='application/json'
        body={'access_token':TOKEN,'expires_in':'3600','token_type':'Bearer'} if '/oauth/token' in request.url else response('Returned to Sender')
        r._content=json.dumps(body).encode();return r
    def close(self):pass


class PreparedRequestTests(unittest.TestCase):
    def setUp(self):UPSClient._blocked_until=0
    def test_old_header_only_is_overwritten_by_netrc(self):
        session=requests.Session()
        with patch('requests.sessions.get_netrc_auth',return_value=('old-user','old-password')):
            prepared=session.prepare_request(requests.Request('GET','https://onlinetools.ups.com/api/track',headers={'Authorization':'Bearer '+TOKEN}))
        self.assertTrue(prepared.headers['Authorization'].startswith('Basic '))
        session.close()
    def test_explicit_bearer_survives_netrc_and_full_real_session_pipeline(self):
        session=requests.Session();adapter=RecordingAdapter();session.mount('https://',adapter)
        client=UPSClient(CID,SECRET,session,sleep=lambda _:None)
        with patch('requests.sessions.get_netrc_auth',return_value=('old-user','old-password')):
            result=client.track(N1)
        self.assertEqual(result.status,'Returned to Sender')
        post,get=adapter.requests
        expected='Basic '+base64.b64encode(f'{CID}:{SECRET}'.encode()).decode()
        self.assertEqual(post.headers['Authorization'],expected)
        self.assertEqual(post.body,'grant_type=client_credentials')
        self.assertEqual(get.headers['Authorization'],'Bearer '+TOKEN)
        self.assertIn('transId',get.headers);self.assertIn('transactionSrc',get.headers)
        self.assertNotIn(SECRET,get.url);self.assertNotIn(TOKEN,get.url)
        self.assertEqual(len(adapter.requests),2);client.close()
    def test_explicit_bearer_overrides_session_basic(self):
        session=requests.Session();session.auth=('unrelated-user','unrelated-secret')
        request=session.prepare_request(requests.Request('GET','https://onlinetools.ups.com/api/track',auth=BearerAuth(TOKEN)))
        self.assertEqual(request.headers['Authorization'],'Bearer '+TOKEN);session.close()



class TestWorkerChecks(unittest.TestCase):
    def test_worker_report_contains_stages_without_kept_credentials(self):
        from core_loader import load_core
        core=load_core()
        w=core.UPSConnectionTestWorker(CID,SECRET,N1)
        report={'oauth_ok':True,'tracking_ok':False,'lines':['OAuth token: PASS','Tracking API: HTTP 401; UPS code 250002']}
        with patch.object(core,'UPSClient') as client:
            client.return_value.diagnose.return_value=report
            w.run()
            client.return_value.diagnose.assert_called_once_with(N1)
            client.return_value.close.assert_called_once()
        self.assertEqual(w.report,report)
        self.assertEqual(w.client_id,'');self.assertEqual(w.client_secret,'')
    def test_worker_unexpected_exception_does_not_expose_credentials(self):
        from core_loader import load_core
        core=load_core();w=core.UPSConnectionTestWorker(CID,SECRET,N1)
        with patch.object(core,'UPSClient') as client:
            client.return_value.diagnose.side_effect=RuntimeError(SECRET)
            w.run()
        self.assertNotIn(SECRET,json.dumps(w.report));self.assertFalse(w.report['oauth_ok'])

if __name__=='__main__':unittest.main()
