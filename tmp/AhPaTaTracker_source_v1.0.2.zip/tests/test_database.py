import json
import sqlite3
import sys
import tempfile
import unittest
from dataclasses import fields
from datetime import date, timedelta
from pathlib import Path
from unittest.mock import patch
from core_loader import load_core
from test_ups import N1, N2, response, scan
from ups_tracking import parse_ups_response, UPSCheckError
from apple_accounts import AppleStore

core = load_core()

def parsed(order='W1000000001',status='Shipped',kind='Shipping',day='2026-09-12',tracking=N1,mid='event-1',qty=2):
    kw={f.name:'' for f in fields(core.ParsedOrder)}
    kw.update(order_number=order,status=status,order_type=kind,order_date=day,
              email_date='2026-09-20T12:00:00-07:00', message_id=mid,
              item_summary='Test device',qty=qty,total='$100.00',
              tracking_number=tracking if kind=='Shipping' else '',
              carrier='UPS' if kind=='Shipping' else '',
              eta_date=date.today().isoformat(),address='Demo address',
              pickup_store='Apple Demo' if kind=='Pickup' else '')
    return core.ParsedOrder(**kw)

class DatabaseTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.path=Path(self.tmp.name)/'orders.db'
        self.db=core.Database(self.path); self.account=self.db.add_account('example@example.com')
    def tearDown(self): self.db.close();self.tmp.cleanup()
    def add(self,**kw):
        p=parsed(**kw); self.db.save_update(self.account,1,p)
        return self.db.conn.execute('SELECT id FROM orders WHERE order_number=?',(p.order_number,)).fetchone()[0]
    def result(self,oid,st='Returning to Sender',n=N1):
        r=parse_ups_response(response(st,number=n,scans=[scan(st)]),n)
        self.db.save_ups_package(oid,n,r);self.db.refresh_ups_aggregate(oid)
    def test_return_moves_tab_and_not_incoming(self):
        oid=self.add();self.result(oid)
        self.assertEqual(self.db.order_by_id(oid)['status'],'Returning to Sender')
        self.assertEqual(len(self.db.query_orders('Shipped')),0)
        self.assertEqual(self.db.tab_counts()['Returning to Sender'],1)
        self.assertFalse(self.db.upcoming_deliveries())
        self.assertFalse(self.db.orders_for_activity_date(date.today().isoformat()))
    def test_completed_return_is_not_delivered(self):
        oid=self.add();self.result(oid,'Returned to Sender')
        self.assertEqual(self.db.order_by_id(oid)['status'],'Returned to Sender')
        self.assertFalse(self.db.tracking_rows());self.assertEqual(self.db.tab_counts()['Active'],0)
        self.assertEqual(self.db.tab_counts()['Delivered'],0)
    def test_api_status_survives_restart(self):
        oid=self.add();self.result(oid,'Delayed');self.db.close();self.db=core.Database(self.path)
        self.assertEqual(self.db.order_by_id(oid)['status'],'Delayed')
    def test_manual_status_highest_after_api_email_and_restart(self):
        oid=self.add();self.db.apply_manual_overrides({oid:{'status':'Processing','qty':1}})
        self.result(oid,'Returned to Sender')
        self.db.save_update(self.account,2,parsed(status='Delivered',mid='new',qty=4))
        self.db.close();self.db=core.Database(self.path)
        row=self.db.order_by_id(oid)
        self.assertEqual(row['status'],'Processing');self.assertEqual(row['qty'],1)
        self.assertEqual(row['detected_status'],'Returned to Sender')
        self.db.apply_manual_overrides({oid:{'status':''}})
        row=self.db.order_by_id(oid)
        self.assertEqual(row['status'],'Returned to Sender');self.assertEqual(row['qty'],1)
    def test_bulk_save_atomic(self):
        a=self.add();b=self.add(order='W1000000002',mid='b')
        self.db.apply_manual_overrides({a:{'status':'Delivered'},b:{'status':'Delivered'}})
        self.assertEqual(self.db.tab_counts()['Delivered'],2)
        with self.assertRaises((ValueError,RuntimeError)):
            self.db.apply_manual_overrides({a:{'status':'Processing'},99999:{'status':'Processing'}})
        self.assertEqual(self.db.order_by_id(a)['status'],'Delivered')
        with self.assertRaises(ValueError):self.db.apply_manual_overrides({a:{'status':'NotAStatus'}})
    def test_one_returned_one_delivered_not_delivered(self):
        oid=self.add(tracking=N1+', '+N2)
        self.result(oid,'Delivered',N1);self.result(oid,'Returned to Sender',N2)
        self.assertEqual(self.db.order_by_id(oid)['status'],'Mixed Shipments')
    def test_one_missing_never_completes_order(self):
        oid=self.add(tracking=N1+', '+N2);self.result(oid,'Delivered',N1)
        self.assertEqual(self.db.order_by_id(oid)['status'],'Partially Delivered')
    def test_failed_api_retains_successful_state(self):
        oid=self.add();self.result(oid,'Delayed')
        success=self.db.order_by_id(oid)['tracking_success_at']
        self.db.save_ups_package(oid,N1,error='UPS HTTP 503');self.db.refresh_ups_aggregate(oid)
        row=self.db.order_by_id(oid)
        self.assertEqual(row['status'],'Delayed');self.assertEqual(row['tracking_success_at'],success)
        self.assertIn('503',row['tracking_error'])
    def test_first_failure_does_not_fabricate_status(self):
        oid=self.add();self.db.save_ups_package(oid,N1,error='No access');self.db.refresh_ups_aggregate(oid)
        row=self.db.order_by_id(oid)
        self.assertEqual(row['status'],'Shipped');self.assertFalse(row['tracking_success_at'])
        self.assertIn('No access',row['tracking_error'])
    def test_archive_hides_every_query_and_restore(self):
        a=self.add();b=self.add(order='W1000000002',kind='Pickup',status='Ready for Pickup',mid='b')
        self.assertEqual(len(self.db.query_orders()),2)
        self.db.archive_order_day('2026-09-12')
        self.assertFalse(self.db.query_orders()); self.assertFalse(self.db.tracking_rows());self.assertFalse(self.db.pickup_tracking_rows())
        self.assertFalse(self.db.orders_by_ids([a,b]));self.assertFalse(self.db.tracking_candidates(force=True))
        self.assertFalse(self.db.orders_for_order_date('2026-09-12'));self.assertEqual(self.db.tab_counts()['All Orders'],0)
        self.assertFalse(self.db.upcoming_deliveries());self.assertFalse(self.db.activity_days('2026-01-01','2026-12-31'))
        self.assertFalse(self.db.orders_for_activity_date(date.today().isoformat()))
        self.assertFalse(self.db.release_summaries())
        self.assertEqual(len(self.db.release_summaries(include_archived=True)),1)
        self.db.restore_order_day('2026-09-12')
        self.assertEqual(len(self.db.query_orders()),2);self.assertEqual(len(self.db.tracking_rows()),1);self.assertEqual(len(self.db.pickup_tracking_rows()),1)
    def test_new_email_cannot_unarchive_date(self):
        oid=self.add();self.db.archive_order_day('2026-09-12')
        self.db.save_update(self.account,2,parsed(status='Delivered',mid='second'))
        self.assertFalse(self.db.query_orders());self.assertEqual(self.db.order_by_id(oid)['status'],'Delivered')
        self.db.restore_order_day('2026-09-12');self.assertEqual(self.db.query_orders()[0]['status'],'Delivered')
    def test_archive_rejects_late_api_result(self):
        oid=self.add();self.db.archive_order_day('2026-09-12');self.result(oid,'Returned to Sender')
        self.assertFalse(self.db.ups_package_results(oid))
    def test_archive_rejects_bulk_without_partial_writes(self):
        a=self.add();b=self.add(order='W1000000002',day='2026-09-13',mid='b')
        self.db.archive_order_day('2026-09-13')
        with self.assertRaises((ValueError,RuntimeError)):self.db.apply_manual_overrides({a:{'status':'Delivered'},b:{'status':'Delivered'}})
        self.assertEqual(self.db.order_by_id(a)['status'],'Shipped')
    def test_backup_migration_is_non_destructive(self):
        oid=self.add();self.db.conn.execute('DROP TABLE ups_package_state');self.db.conn.commit()
        core.backup_before_ups_migration(self.path)
        backups=list((self.path.parent/'backups').glob('*.db'))
        self.assertEqual(len(backups),1)
        self.assertEqual(self.db.order_by_id(oid)['status'],'Shipped')
    def test_calendar_badges_match_cards_after_override(self):
        oid=self.add(status='Delivered')
        self.db.apply_manual_overrides({oid:{'status':'Processing'}})
        today=date.today().isoformat()
        cards=self.db.orders_for_activity_date(today)
        counts=self.db.activity_days(today,today)
        self.assertEqual(sum(r['order_count'] for r in counts),len(cards))
        self.assertEqual(len(cards),1)
    def test_raw_ups_detail_export_available(self):
        oid=self.add();self.result(oid,'Returning to Sender')
        row=self.db.query_orders()[0]
        self.assertIn('Returning',core.export_value_for_field(row,'tracking_detail'))
    def test_cancel_only_import_and_override(self):
        raw=b'From: Apple <noreply@email.apple.com>\r\nTo: example@example.com\r\nSubject: Information about your order W1000000001\r\nDate: Sun, 20 Sep 2026 21:47:41 +0000\r\nMessage-ID: <cancel-demo>\r\nX-EmailType-Id: 1020756471\r\nContent-Type: text/plain\r\n\r\nYour order has been cancelled\r\nOrder Number: W1000000001\r\nOrdered On September 12, 2026\r\nSince we haven\'t received your payment, your order has been cancelled.'
        p=core.AppleMailParser().parse(raw,'example@example.com')
        self.assertEqual(p.status,'Canceled')
        self.db.save_update(self.account,1,p)
        oid=self.db.query_orders()[0]['id']
        self.assertEqual(self.db.order_by_id(oid)['status'],'Canceled')
        self.db.apply_manual_overrides({oid:{'status':'Processing'}})
        self.db.refresh_from_parsed(self.account,1,p)
        self.assertEqual(self.db.order_by_id(oid)['status'],'Processing')

    def test_cache_rebuild_preserves_submitted_apple_task_and_history(self):
        oid=self.add()
        with self.db.conn:
            self.db.conn.execute("UPDATE orders SET alias_emails='guest+tag@example.test' WHERE id=?",(oid,))
            self.db.conn.execute('UPDATE accounts SET last_uid=321 WHERE id=?',(self.account,))
        store=AppleStore(self.db);cid=store.add_connection('owner@example.test')
        store.connection_state(cid,'connected','', 'owner@example.test','Apple page')
        profiles=self.path.parent/'profiles.json'
        profiles.write_text(json.dumps([{'email':'guest+tag@example.test','shipping':{'phone':'+15035550119'}}]))
        store.import_files([profiles]);candidate=store.phone_candidates(self.db.order_by_id(oid),cid)[0]
        store.record_phone_result(oid,candidate['id'],cid,'Verified')
        job=store.create_job(store.snapshot([oid],cid,'cancel'),confirmed=True)
        task=store.take_next({cid})
        store.save_observation(task,{'authenticated':True,'order_number':'W1000000001',
                                    'status':'Processing','raw_status':'Processing','items':[]})
        store.mark_submitted(task);store.result(task,'uncertain','Verify the existing submission before continuing')
        before=list(self.db.conn.iterdump())

        with self.assertRaisesRegex(ValueError,'Full Account Sync'):
            self.db.reset_order_cache()

        self.assertEqual(list(self.db.conn.iterdump()),before)
        saved=store.tasks(job)[0]
        self.assertEqual(saved['state'],'uncertain');self.assertEqual(saved['submitted'],1)
        self.assertEqual(store.phone_candidates(self.db.order_by_id(oid),cid)[0]['verification'],'Verified')
        self.assertEqual(self.db.conn.execute('SELECT COUNT(*) FROM apple_observations').fetchone()[0],1)
        self.assertFalse(self.db.conn.in_transaction)

    def test_cache_rebuild_preserves_verification_without_any_job(self):
        oid=self.add();store=AppleStore(self.db);cid=store.add_connection('owner@example.test')
        with self.db.conn:
            self.db.conn.execute("UPDATE orders SET alias_emails='guest+tag@example.test' WHERE id=?",(oid,))
        profiles=self.path.parent/'profiles.json'
        profiles.write_text(json.dumps([{'email':'guest+tag@example.test','shipping':{'phone':'+15035550119'}}]))
        store.import_files([profiles]);candidate=store.phone_candidates(self.db.order_by_id(oid),cid)[0]
        store.record_phone_result(oid,candidate['id'],cid,'Verified')
        before=list(self.db.conn.iterdump())
        with self.assertRaisesRegex(ValueError,'Full Account Sync'):
            self.db.reset_order_cache()
        self.assertEqual(list(self.db.conn.iterdump()),before)

    def test_cache_rebuild_without_order_linked_apple_history_still_works(self):
        self.add();store=AppleStore(self.db);cid=store.add_connection('owner@example.test')
        with self.db.conn:self.db.conn.execute('UPDATE accounts SET last_uid=321 WHERE id=?',(self.account,))
        self.db.reset_order_cache()
        self.assertFalse(self.db.query_orders())
        self.assertEqual(self.db.conn.execute('SELECT COUNT(*) FROM email_events').fetchone()[0],0)
        self.assertEqual(self.db.conn.execute('SELECT last_uid FROM accounts WHERE id=?',(self.account,)).fetchone()[0],0)
        self.assertIsNotNone(store.connection(cid))

    def test_cache_rebuild_prevents_new_apple_state_between_check_and_delete(self):
        oid=self.add();check=self.db.order_cache_rebuild_block_reason
        other=sqlite3.connect(self.path,timeout=0)
        def check_with_concurrent_writer():
            reason=check()
            with self.assertRaisesRegex(sqlite3.OperationalError,'locked'):
                other.execute("UPDATE orders SET association_state='uncertain' WHERE id=?",(oid,))
            other.rollback()
            return reason
        try:
            with patch.object(self.db,'order_cache_rebuild_block_reason',side_effect=check_with_concurrent_writer):
                self.db.reset_order_cache()
        finally:other.close()
        self.assertFalse(self.db.query_orders())

class WorkerTests(DatabaseTests):
    # Reuse setup/helpers without re-running all inherited tests.
    def test_worker_empty_selection_is_not_all(self):
        self.add();w=core.VerificationWorker(self.path,force=True,order_ids=[])
        with patch.object(core,'UPSClient') as cl:w.run();cl.assert_not_called()
        self.assertEqual(w.stats['checked'],0)
    def test_worker_api_to_sqlite(self):
        oid=self.add();w=core.VerificationWorker(self.path,force=True)
        with patch.object(core,'UPSClient') as cl:
            cl.return_value.track.return_value=parse_ups_response(response('Returned to Sender'),N1)
            w.run()
        self.assertEqual(self.db.order_by_id(oid)['status'],'Returned to Sender')
        self.assertEqual(w.stats['success'],1);self.assertEqual(w.stats['changed'],1)
        self.assertEqual(w.all_done.calls[-1],(1,1))
    def test_worker_duplicate_tracking_one_request(self):
        self.add();self.add(order='W1000000002',mid='b');w=core.VerificationWorker(self.path,force=True)
        with patch.object(core,'UPSClient') as cl:
            cl.return_value.track.return_value=parse_ups_response(response('Delayed'),N1);w.run()
            cl.return_value.track.assert_called_once_with(N1)
        self.assertEqual(w.stats['changed'],2)
    def test_worker_403_stops_not_claim_success(self):
        self.add();self.add(order='W1000000002',mid='b',tracking=N2);w=core.VerificationWorker(self.path,force=True)
        with patch.object(core,'UPSClient') as cl:
            cl.return_value.track.side_effect=UPSCheckError('access','UPS access denied',403);w.run()
            self.assertEqual(cl.return_value.track.call_count,1)
        self.assertEqual(w.stats['errors'],1);self.assertEqual(w.stats['success'],0);self.assertEqual(w.stats['skipped'],1)
        self.assertTrue(any('FAILED' in l for l in w.report_lines))
    def test_worker_archived_requests_skipped(self):
        self.add();self.db.archive_order_day('2026-09-12');w=core.VerificationWorker(self.path,force=True)
        with patch.object(core,'UPSClient') as cl:w.run();cl.assert_not_called()
    def test_worker_cancellation_stops(self):
        self.add();w=core.VerificationWorker(self.path,force=True);w.request_stop()
        with patch.object(core,'UPSClient') as cl:w.run();cl.return_value.track.assert_not_called()
        self.assertTrue(w.stats['canceled'])

# Avoid inherited tests being counted twice.
for name in list(vars(DatabaseTests)):
    if name.startswith('test_') and name not in WorkerTests.__dict__: setattr(WorkerTests,name,None)

if __name__=='__main__':unittest.main()
