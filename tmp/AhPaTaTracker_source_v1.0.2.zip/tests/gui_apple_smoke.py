"""Additional real-Qt gate: Apple workspace, mapping, batch confirmation and
source priority. Temporary data only; no browser launch or network calls.
"""
import json
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parent))
import gui_smoke as g
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QDialog,QLabel,QPushButton,QMessageBox
from PySide6.QtTest import QTest
import apple_account_ui as ui
from apple_accounts import AppleStore

class AppleGUITests(unittest.TestCase):
    setUp=g.GUITests.setUp
    tearDown=g.GUITests.tearDown
    def connection(self):
        s=AppleStore(self.window.db);cid=s.add_connection('owner@example.test');self.window.apple_page.refresh();return s,cid
    def test_workspace_navigation_and_themes_without_browser(self):
        w=self.window
        for theme in ('light','dark'):
            w.apply_theme(theme);w.show_page(w.PAGE_APPLE,w.apple_nav);g.APP.processEvents()
            self.assertEqual(w.apple_page.tabs.count(),4)
            for i in range(4):w.apple_page.tabs.setCurrentIndex(i);g.APP.processEvents();self.assertFalse(w.apple_page.grab().isNull())
        self.assertIsNone(w.apple_page.worker)
    def test_connection_ui_is_not_falsely_authenticated(self):
        s,cid=self.connection();self.assertEqual(s.connection(cid)['state'],'disconnected')
        self.assertIn('owner@example.test',self.window.apple_page.connection_info.text());self.assertIsNone(self.window.apple_page.worker)
    def test_empty_selection_cannot_queue(self):
        s,cid=self.connection();d=ui.PreviewDialog(s,[],'cancel',self.window)
        self.assertFalse(d.go.isEnabled());self.assertIsNone(d.data);d.close()
    def test_concrete_preview_requires_confirmation(self):
        s,cid=self.connection();rows=self.window.db.query_orders();ids=[r['id'] for r in rows[:2]]
        d=ui.PreviewDialog(s,ids,'cancel',self.window);d.show();g.APP.processEvents()
        self.assertEqual(d.model.rowCount(),2);self.assertFalse(d.confirm.isChecked())
        with patch.object(ui.QMessageBox,'warning'):
            d.submit()
        self.assertNotEqual(d.result(),QDialog.Accepted)
        d.confirm.setChecked(True);d.submit();self.assertEqual(d.result(),QDialog.Accepted)
        jid=s.create_job(d.data,confirmed=True);self.assertEqual(len(s.tasks(jid)),2);d.close()
    def test_payment_preview_rejects_raw_card_label(self):
        s,cid=self.connection();oid=self.window.db.query_orders()[0]['id'];d=ui.PreviewDialog(s,[oid],'payment',self.window)
        d.method.setText('RAW_CARD_LABEL_NOT_ALLOWED');d.refresh();self.assertFalse(d.go.isEnabled())
        d.method.setText('Visa ****1234');d.refresh();self.assertTrue(d.go.isEnabled());d.close()
    def test_detail_phone_field_and_live_import_refresh(self):
        s,cid=self.connection();oid=self.window.db.query_orders()[0]['id']
        with self.window.db.conn:self.window.db.conn.execute('UPDATE orders SET alias_emails=? WHERE id=?',('user+tag@example.test',oid))
        row=self.window.db.order_by_id(oid);d=g.m.OrderDetailDialog(self.window.db,row,self.window);d.show();g.APP.processEvents()
        self.assertIn('No matching',d._phone_value_label.text())
        f=self.folder/'profiles.json';f.write_text(json.dumps([{'email':'user+tag@example.test','shipping':{'phone':'+15035550119'}}]))
        s.import_files([f]);d._refresh_phone_values();self.assertIn('+15035550119',d._phone_value_label.text())
        self.assertIn('Untried',d._phone_value_label.text());d.close()
    def test_job_models_page_and_filter(self):
        s,cid=self.connection();oid=self.window.db.query_orders()[0]['id'];jid=s.create_job(s.snapshot([oid],cid,'refresh'))
        page=self.window.apple_page;page.active_job=jid;page.refresh_jobs();self.assertEqual(page.tasks_model.rowCount(),1)
        page.state_filter.setCurrentText('failed');g.APP.processEvents();self.assertEqual(page.tasks_model.rowCount(),0)
        page.state_filter.setCurrentText('All');g.APP.processEvents();self.assertEqual(page.tasks_model.rowCount(),1)
    def test_status_priority_refreshes_existing_dashboard(self):
        s,cid=self.connection();oid=self.window.db.query_orders()[0]['id'];s.connection_state(cid,'connected','', 'owner@example.test','Apple page')
        s.create_job(s.snapshot([oid],cid,'refresh'));t=s.take_next({cid});row=self.window.db.order_by_id(oid)
        self.window.db.apply_manual_overrides({oid:{'status':'Processing'}})
        s.save_observation(t,{'authenticated':True,'order_number':row['order_number'],'status':'Canceled','raw_status':'Canceled','items':[]})
        self.window.refresh_all();self.assertEqual(self.window.db.order_by_id(oid)['status'],'Processing')
        self.window.db.apply_manual_overrides({oid:{'status':''}});self.window.refresh_all()
        self.assertEqual(self.window.db.order_by_id(oid)['status_source'],'Apple Account')

    def test_cache_rebuild_blocks_active_workers_before_confirmation(self):
        w=self.window;page=w.apple_page;busy=SimpleNamespace(isRunning=lambda:True)
        for owner,attribute in ((w,'sync_worker'),(w,'verify_worker'),(w,'_update_download_worker'),
                                (page,'worker'),(page,'importer'),(page,'route_worker')):
            with self.subTest(worker=attribute), patch.object(owner,attribute,busy,create=True), \
                    patch.object(g.m.QMessageBox,'information') as notice, \
                    patch.object(g.m.QMessageBox,'question') as confirm, \
                    patch.object(w.db,'reset_order_cache') as reset:
                w.full_rescan()
                notice.assert_called_once();confirm.assert_not_called();reset.assert_not_called()
                self.assertIn('Full Account Sync',notice.call_args.args[2])
        self.assertEqual(w.db.tab_counts()['All Orders'],4)

    def test_cache_rebuild_rechecks_apple_history_after_confirmation(self):
        w=self.window;s,cid=self.connection();oid=w.db.query_orders()[0]['id'];jobs=[]
        def confirm_and_create_job(*args):
            jobs.append(s.create_job(s.snapshot([oid],cid,'cancel'),confirmed=True))
            return QMessageBox.Yes
        with patch.object(g.m.QMessageBox,'question',side_effect=confirm_and_create_job) as confirm, \
                patch.object(g.m.QMessageBox,'information') as notice, \
                patch.object(w.db,'reset_order_cache') as reset, patch.object(w,'start_sync') as sync:
            w.full_rescan()
            confirm.assert_called_once();notice.assert_called_once();reset.assert_not_called();sync.assert_not_called()
            self.assertIn('Refresh Details',notice.call_args.args[2])
        self.assertEqual(len(s.tasks(jobs[0])),1)
        self.assertEqual(w.db.tab_counts()['All Orders'],4)

if __name__=='__main__':unittest.main(verbosity=2)
