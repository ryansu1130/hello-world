"""Single browser-owner job runner. One shared scheduler, stable routes, no retries
of uncertain mutations. Suitable for a QThread or a regular background thread.
"""
from __future__ import annotations
import json
import queue
import random
import threading
import time
from pathlib import Path
from apple_accounts import AppleStore, safe_message, utc_now
from apple_browser import BrowserSession, AppleFlowError
from apple_secrets import SecretVault

class AppleRunner:
    def __init__(self,db_factory,db_path,url_for,eta_parser,notify=None):
        self.db_factory=db_factory;self.path=Path(db_path);self.url_for=url_for;self.eta_parser=eta_parser
        self.notify=notify or (lambda event,data:None)
        self.commands=queue.Queue();self.stop_event=threading.Event();self.sessions={};self.ready=set()
        self.pace=12;self.playwright=None;self.global_next=0;self.vault=SecretVault(self.path.parent);self.stop_jobs=set()
    def send(self,command,**data):
        if command=='stop_job':self.stop_jobs.add(data.get('job_id'))
        self.commands.put((command,data))
    def stop(self):self.stop_event.set()
    def emit(self,event,data=None):self.notify(event,data or {})
    def run(self):
        db=self.db_factory(self.path);store=AppleStore(db);store.recover()
        try:
            while not self.stop_event.is_set():
                try:
                    command,data=self.commands.get(timeout=.2);self._command(store,command,data)
                except queue.Empty:pass
                except Exception as exc:
                    code=exc.code if isinstance(exc,AppleFlowError) else 'operation_error'
                    message=str(exc) if isinstance(exc,AppleFlowError) else 'Apple operation failed: '+type(exc).__name__+'. Existing data is preserved.'
                    self.emit('error',{'code':code,'message':safe_message(message)})
                if self.stop_event.is_set():break
                for cid,session in list(self.sessions.items()):
                    try:session.page.wait_for_timeout(30)
                    except Exception:
                        self.ready.discard(cid);store.connection_state(cid,'disconnected','Browser closed; reconnect to resume jobs')
                if time.time()<self.global_next:continue
                task=store.take_next(self.ready,self.pace)
                if task:
                    self.global_next=time.time()+max(5,self.pace)
                    self._execute(store,task)
                self._auto_refresh(store)
        finally:
            for session in self.sessions.values():
                try:session.close()
                except Exception:pass
            if self.playwright:
                try:self.playwright.stop()
                except Exception:pass
            for cid in self.sessions:
                store.connection_state(cid,'disconnected','Browser closed; reconnect to resume eligible work')
            db.close()
    def _command(self,store,command,data):
        cid=data.get('connection_id','')
        if command=='pace':self.pace=max(5,min(600,int(data.get('seconds',12))));return
        if command=='connect':
            cooldown=store.c.execute("SELECT value FROM apple_meta WHERE key='global_cooldown'").fetchone()
            if cooldown and float(cooldown[0])>time.time():raise AppleFlowError('throttled','Shared Apple cooldown is active; reconnect after it expires')
            connection=store.connection(cid)
            if not connection:raise AppleFlowError('missing_account','Select an Apple Account')
            if cid in self.sessions:
                self.sessions[cid].close();del self.sessions[cid];self.ready.discard(cid)
            if not self.playwright:
                try:
                    from playwright.sync_api import sync_playwright
                    self.playwright=sync_playwright().start()
                except Exception:raise AppleFlowError('browser_missing','Browser automation runtime could not start. Reinstall the complete release; Edge/Chrome/Brave must be installed.') from None
            proxy=None
            if connection['route_id']:
                proxy=self.vault.get('route-'+connection['route_id'])
                if not proxy:raise AppleFlowError('route_secret','Selected proxy credentials/route are unavailable for this Windows user. Re-enter the route or explicitly choose Direct.')
            store.connection_state(cid,'connecting','Sign in directly on Apple, including any two-factor check')
            try:
                session=BrowserSession(self.playwright,connection,self.vault,proxy)
                session.eta_parser=self.eta_parser;self.sessions[cid]=session
            except Exception:
                store.connection_state(cid,'disconnected','Browser did not open or connect. Check the chosen browser/route.');raise
            self.emit('state',{'message':'Apple browser opened. Complete sign-in, then Verify Sign-in.'});return
        if command=='verify':
            session=self.sessions.get(cid)
            if not session:raise AppleFlowError('auth_required','Open the Apple browser first')
            try:identity=session.verify_identity(bool(data.get('identity_confirmed')))
            except AppleFlowError as exc:
                self.ready.discard(cid);store.connection_state(cid,exc.code,str(exc));self.emit('changed');raise
            self.ready.add(cid);store.connection_state(cid,'connected','',identity['observed_email'],identity['method'])
            # Restore only blocked, unsubmitted work. Uncertain actions require explicit reconciliation.
            with store.c:
                store.c.execute("UPDATE apple_tasks SET state='queued' WHERE job_id IN (SELECT id FROM apple_jobs WHERE connection_id=? AND state!='stopped') AND state='auth_required' AND submitted=0",(cid,))
            self.emit('changed');return
        if command in ('signout','disconnect'):
            session=self.sessions.pop(cid,None);self.ready.discard(cid)
            if session:session.close(forget=command=='signout')
            elif command=='signout':self.vault.delete('session-'+cid)
            store.connection_state(cid,'disconnected','App session forgotten' if command=='signout' else 'Disconnected; encrypted session retained')
            self.emit('changed');return
        if command=='continue':
            task=store.c.execute('SELECT t.*,j.connection_id FROM apple_tasks t JOIN apple_jobs j ON j.id=t.job_id WHERE t.id=?',(int(data['task_id']),)).fetchone()
            if not task:return
            cid=task['connection_id'];session=self.sessions.get(cid)
            if not session or not session.validated:raise AppleFlowError('auth_required','Reconnect and verify the destination Apple Account before continuing')
            connection=store.connection(cid)
            if connection['next_at']>time.time():raise AppleFlowError('throttled','The Apple cooldown has not finished',int(connection['next_at']-time.time()))
            self.ready.add(cid);store.connection_state(cid,'connected','',session.observed_email,session.identity_method)
            store.resume_task(task['id']);self.emit('changed');return
        if command=='focus':
            session=self.sessions.get(cid)
            if session:
                page=session.task_pages.get(int(data.get('task_id') or 0),session.page)
                if not page.is_closed():page.bring_to_front()
            return
        if command=='stop_job':
            jid=data['job_id'];store.job_control(jid,'stop')
            for t in store.tasks(jid,limit=100000):
                session=self.sessions.get(t['connection_id'])
                if session:session.finish_page(t['id'])
            self.emit('changed');return
        if command=='wake':return
    def _execute(self,store,task):
        cid=task['connection_id'];session=self.sessions.get(cid)
        if not session:return
        row=store.db.order_by_id(task['order_id']);store.record_attempt(task['order_id'])
        self.emit('progress',{'message':f"Apple {task['action']}: {row['order_number']} (attempt {task['attempts']})"})
        try:
            job=store.c.execute('SELECT state FROM apple_jobs WHERE id=?',(task['job_id'],)).fetchone()
            if job[0] not in ('queued','running'):
                store.result(task,'queued','Job paused before browser work');return
            if task['action']=='associate':
                state,message=session.associate(store,task,row,self.url_for(row),self.pace,lambda:self._halted(store,task))
                if state in ('associated','already_associated'):
                    try:
                        _,_,obs=session.read_order(task,store.db.order_by_id(row['id']),self.url_for(row))
                        store.save_observation(task,obs)
                    except AppleFlowError as e:
                        store.record_attempt(row['id'],'Linked, but refresh needs attention: '+e.code)
            elif task['action']=='refresh':
                _,_,obs=session.read_order(task,row,self.url_for(row))
                store.save_observation(task,obs);state='succeeded';message='Authenticated Apple status stored; manual override still wins'
            else:state,message=session.mutation(store,task,row,self.url_for(row))
            if self._halted(store,task) and state=='queued':
                job_state=store.c.execute('SELECT state FROM apple_jobs WHERE id=?',(task['job_id'],)).fetchone()[0]
                if task['job_id'] in self.stop_jobs or job_state=='stopped':state='stopped'
            store.result(task,state,message)
            if state in ('succeeded','associated','already_associated'):
                with store.c:store.c.execute('UPDATE apple_connections SET failures=0 WHERE id=?',(cid,))
            if state in ('uncertain','awaiting_verification'):
                self.ready.discard(cid);store.connection_state(cid,'awaiting_action',message)
            elif state not in ('queued','cooling_down'):session.finish_page(task['id'])
            self.emit('changed')
        except AppleFlowError as exc:
            self._failure(store,task,exc)
        except Exception as exc:
            # Playwright messages often contain tokenized URLs/DOM snippets. Never log them.
            code='timeout' if 'timeout' in type(exc).__name__.lower() else 'connection_failure'
            self._failure(store,task,AppleFlowError(code,'Apple browser request did not finish. Cached observations are unchanged.'))
    def _halted(self,store,task):
        if self.stop_event.is_set() or task['job_id'] in self.stop_jobs:return True
        state=store.c.execute('SELECT state FROM apple_jobs WHERE id=?',(task['job_id'],)).fetchone()
        return not state or state[0] in ('paused','stopped')
    def _failure(self,store,task,exc):
        cid=task['connection_id'];now=time.time()
        store.record_attempt(task['order_id'],exc.code+': '+str(exc))
        if exc.code in ('auth_required','identity_mismatch','unexpected_origin'):
            self.ready.discard(cid);state='uncertain' if task['submitted'] else 'auth_required'
            store.connection_state(cid,exc.code,str(exc));store.result(task,state,str(exc),exc.code)
        elif exc.code in ('throttled','blocked'):
            delay=max(300,int(exc.retry_after or 0));self.global_next=max(self.global_next,now+delay)
            with store.c:
                store.c.execute('UPDATE apple_connections SET next_at=? WHERE id=?',(now+delay,cid))
                store.c.execute("INSERT OR REPLACE INTO apple_meta VALUES('global_cooldown',?)",(str(now+delay),))
            # Do not change proxy or cookies. A possibly submitted mutation stays uncertain.
            store.result(task,'uncertain' if task['submitted'] else 'cooling_down',str(exc),exc.code,now+delay)
        elif task['submitted']:
            self.ready.discard(cid);store.connection_state(cid,'awaiting_action','Reconcile the uncertain action in the open Apple page')
            store.result(task,'uncertain',str(exc),exc.code)
        elif exc.code=='needs_association':store.result(task,'ineligible',str(exc),exc.code)
        elif exc.code in ('page_changed','order_mismatch','another_account'):
            store.result(task,'ineligible' if exc.code=='another_account' else 'awaiting_verification',str(exc),exc.code)
            if exc.code!='another_account':self.ready.discard(cid);store.connection_state(cid,'awaiting_action',str(exc))
        else:
            connection=store.connection(cid);failures=connection['failures']+1
            with store.c:store.c.execute('UPDATE apple_connections SET failures=? WHERE id=?',(failures,cid))
            delay=min(900,15*(2**min(task['attempts'],5)))+random.uniform(1,10)
            store.result(task,'cooling_down',str(exc),exc.code,now+delay)
            if failures>=3:
                self.ready.discard(cid);store.connection_state(cid,'circuit_open','Repeated browser/network errors. Reconnect or verify the session to resume.')
        self.emit('changed');self.emit('progress',{'message':f"Apple job: {exc.code}. {safe_message(str(exc))}"})
    def _auto_refresh(self,store):
        now=time.time()
        for connection in store.connections():
            cid=connection['id']
            if not connection['auto_refresh'] or cid not in self.ready or connection['state']!='connected':continue
            interval=max(15,int(connection['refresh_minutes']))*60
            if now-connection['last_auto']<interval:continue
            rows=store.c.execute('''SELECT id FROM visible_orders WHERE linked_apple_connection=?
                AND COALESCE(status,'') NOT IN ('Delivered','Picked Up','Canceled','Refunded','Returned to Sender')
                ORDER BY account_status_success_at LIMIT 50''',(cid,)).fetchall()
            if rows:
                try:store.create_job(store.snapshot([r[0] for r in rows],cid,'refresh'),priority=50)
                except ValueError:pass
            with store.c:store.c.execute('UPDATE apple_connections SET last_auto=? WHERE id=?',(now,cid))
