"""Atomic UPS credential-pair storage using the application's existing keyring.

The one JSON record lives in Windows Credential Manager, never in orders.db.
Legacy two-key entries are read only until the user saves a new pair.
"""
from __future__ import annotations

import json
import unicodedata

PAIR_KEY = 'ups_oauth_pair_v2'
LEGACY_ID_KEY = 'ups_client_id'
LEGACY_SECRET_KEY = 'ups_client_secret'


class UPSCredentialError(ValueError):
    """Safe to display: messages must never contain a credential's value."""


def clean_credential(value: str, label: str) -> str:
    value = str(value or '').strip()
    if not value:
        return ''
    if any(c.isspace() or unicodedata.category(c).startswith('C') for c in value):
        raise UPSCredentialError(f'{label} contains an embedded space, line break, or invisible character. Copy the complete value again from UPS.')
    if not value.isascii() or value[0] in "\"'" or value[-1] in "\"'":
        raise UPSCredentialError(f'{label} contains quotation marks or unsupported characters. Paste the value only, without quotes.')
    if value.lower().startswith(('http:', 'https:')) or (label == 'Client ID' and ':' in value):
        raise UPSCredentialError(f'{label} does not look like a UPS application credential. Use the Client ID and Client Secret, not a URL or bearer token.')
    return value


def load_pair(backend, service: str) -> tuple[str, str]:
    try:
        record = backend.get_password(service, PAIR_KEY)
        if record:
            data = json.loads(record)
            if not isinstance(data, dict) or data.get('format') != 2:
                raise ValueError('Unexpected format')
            cid, secret = data.get('client_id'), data.get('client_secret')
            if not isinstance(cid, str) or not isinstance(secret, str) or not cid or not secret:
                raise ValueError('Incomplete pair')
            return cid, secret
        return (backend.get_password(service, LEGACY_ID_KEY) or '',
                backend.get_password(service, LEGACY_SECRET_KEY) or '')
    except Exception as exc:
        raise UPSCredentialError('Could not read the saved UPS credential pair. Reopen Settings and save both fields again.') from None


def resolve_pair(client_id: str, client_secret: str, saved_pair: tuple[str, str]) -> tuple[str, str]:
    cid = clean_credential(client_id, 'Client ID')
    secret = clean_credential(client_secret, 'Client Secret')
    old_id, old_secret = saved_pair
    if not cid:
        raise UPSCredentialError('Enter your UPS Client ID.')
    if not secret:
        if cid != old_id:
            raise UPSCredentialError('The Client ID changed. Enter the matching Client Secret from the SAME UPS application; the previous secret will not be reused.')
        secret = clean_credential(old_secret, 'Client Secret')
    if not secret:
        raise UPSCredentialError('Enter your UPS Client Secret.')
    return cid, secret


def save_pair(backend, service: str, client_id: str, client_secret: str) -> tuple[str, str]:
    pair = resolve_pair(client_id, client_secret, load_pair(backend, service))
    record = json.dumps({'format': 2, 'client_id': pair[0], 'client_secret': pair[1]}, separators=(',', ':'))
    try:
        # One atomic entry prevents new-ID/old-secret combinations on partial saves.
        backend.set_password(service, PAIR_KEY, record)
    except Exception:
        raise UPSCredentialError('Windows Credential Manager could not save the UPS pair. Nothing was confirmed saved; try again before testing.') from None
    return pair


def clear_pair(backend, service: str) -> None:
    try:
        # Delete legacy keys first, so removing the canonical pair cannot revive them.
        for key in (LEGACY_ID_KEY, LEGACY_SECRET_KEY, PAIR_KEY):
            if backend.get_password(service, key) is not None:
                backend.delete_password(service, key)
    except Exception:
        raise UPSCredentialError('Could not remove all UPS credentials. Close other tracker copies and try again.') from None
