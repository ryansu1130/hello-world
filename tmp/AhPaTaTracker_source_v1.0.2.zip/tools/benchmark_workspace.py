"""Synthetic local load test. Does not contact Apple, Gmail, UPS or read real profiles."""
import json
import sqlite3
import sys
import tempfile
import time
import tracemalloc
from pathlib import Path
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root));sys.path.insert(0,str(root/'tests'))
from core_loader import load_core
from apple_accounts import AppleStore
N_ORDERS=20000;N_PROFILES=50000
with tempfile.TemporaryDirectory(prefix='ahpata_load_') as folder:
    base=Path(folder);db=load_core().Database(base/'synthetic.db');aid=db.add_account('synthetic@example.test');store=AppleStore(db)
    start=time.perf_counter()
    with db.conn:
        db.conn.executemany('''INSERT INTO orders(account_id,order_number,order_type,item_summary,qty,address,status,total,alias_emails,order_date,eta_date,updated_at)
              VALUES(?,?,?,?,?,?,?,?,?,?,?,?)''',
          ((aid,'W'+str(9000000000+i),'Shipping','Synthetic phone',1,'Synthetic address','Processing','$100.00',f'user+{i}@example.test','2026-10-17','2026-11-01','2026-10-17') for i in range(N_ORDERS)))
    order_seconds=time.perf_counter()-start
    profiles=base/'synthetic.json'
    with profiles.open('w') as f:
        f.write('[')
        for i in range(N_PROFILES):
            if i:f.write(',')
            json.dump({'email':f'user+{i//2}@example.test','shipping':{'phone':'+1'+str(2025550000+i),'country':'United States'},'payment':{'num':'DO_NOT_IMPORT','cvv':'DO_NOT_IMPORT'}},f)
        f.write(']')
    tracemalloc.start();t=time.perf_counter();report=store.import_files([profiles]);import_seconds=time.perf_counter()-t
    _,peak=tracemalloc.get_traced_memory();tracemalloc.stop()
    t=time.perf_counter();selected=db.query_orders('Processing','',start_date='2026-10-01',end_date='2026-10-31');query_seconds=time.perf_counter()-t
    t=time.perf_counter();matched=store.phone_candidates(selected[0]);match_seconds=time.perf_counter()-t
    cid=store.add_connection('synthetic-owner@example.test')
    t=time.perf_counter();snapshot=store.snapshot([r['id'] for r in selected[:1000]],cid,'refresh');job=store.create_job(snapshot);queue_seconds=time.perf_counter()-t
    t=time.perf_counter();tasks=store.tasks(job,limit=250);page_seconds=time.perf_counter()-t
    output={'orders':N_ORDERS,'profile_records':N_PROFILES,'accepted':report['accepted'],'candidates':report['new_candidates'],
      'unmatched_aliases':report['unmatched_aliases'],'file_MiB':round(profiles.stat().st_size/1048576,2),
      'order_seed_seconds':round(order_seconds,3),'profile_import_seconds':round(import_seconds,3),'Python_peak_import_MiB':round(peak/1048576,2),
      'filter_20000_seconds':round(query_seconds,3),'exact_alias_lookup_seconds':round(match_seconds,5),'matching_candidates':len(matched),
      'queue_1000_seconds':round(queue_seconds,3),'task_page_250_seconds':round(page_seconds,4),
      'notes':'Local synthetic data; Python tracemalloc only, excluding SQLite/native/browser memory. No live service traffic. Timings are not service-throughput claims.'}
    print(json.dumps(output,indent=2));db.close()
