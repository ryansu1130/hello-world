from __future__ import annotations

import csv
import hashlib
import html
import imaplib
import json
import os
import re
import sqlite3
import subprocess
import shutil
import socket
import sys
import traceback
import time
import uuid
import math

from apple_profiles import email_key as exact_email_key, aliases as exact_aliases
from apple_accounts import (install_schema as install_apple_schema, backup_before_apple_migration, APPLE_EXTRA_STATUSES)
from ups_tracking import UPSClient, UPSResult, UPSCheckError, UPS_STATES, RETURN_STATES, aggregate_results
from ups_credentials import (load_pair as load_ups_pair, save_pair as save_ups_pair,
                             clear_pair as clear_ups_pair, UPSCredentialError)
from ui_support import (HoverTableView, RowHoverDelegate, ReadableCalendar, LiveIndicator,
                        BulkStatusDialog, configure_date_edit, paint_cell_background, row_option)
from app_updater import (UpdateError, UpdateInfo, check_latest_release, download_and_verify,
                         update_download_path, make_update_script, launch_update_script, can_self_update)

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from email import policy
from email.headerregistry import Address
from email.parser import BytesParser
from email.utils import getaddresses, parsedate_to_datetime
from pathlib import Path
from typing import Iterable, Optional
from urllib.parse import quote, quote_plus, urlparse

import keyring
from bs4 import BeautifulSoup
from dateutil import parser as date_parser
from PySide6.QtCore import (
    QAbstractTableModel,
    QDate,
    QEvent,
    QModelIndex,
    QObject,
    QSettings,
    QSize,
    QThread,
    QTimer,
    Qt,
    QUrl,
    Signal,
)
from PySide6.QtGui import (
    QBrush,
    QColor,
    QDesktopServices,
    QFont,
    QIcon,
    QPainter,
    QPen,
    QPixmap,
    QTextCharFormat,
)
from PySide6.QtNetwork import QNetworkAccessManager, QNetworkRequest
from PySide6.QtWidgets import (
    QApplication,
    QAbstractItemView,
    QCalendarWidget,
    QCheckBox,
    QComboBox,
    QDateEdit,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QPlainTextEdit,
    QScrollArea,
    QSpinBox,
    QSplitter,
    QStackedWidget,
    QStyledItemDelegate,
    QStyle,
    QStyleOptionButton,
    QStyleOptionViewItem,
    QTableView,
    QTableWidget,
    QTableWidgetItem,
    QTabBar,
    QTextBrowser,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

try:
    from PySide6.QtWebEngineCore import QWebEnginePage, QWebEngineProfile
    WEBENGINE_AVAILABLE = True
except Exception:
    QWebEnginePage = None
    QWebEngineProfile = None
    WEBENGINE_AVAILABLE = False


APP_NAME = "Ah Pa Ta Tracker"
APP_VERSION = "1.0.2"
APP_KEYRING_SERVICE = "AppleOrderTracker"
APPLE_ORDER_FALLBACK = "https://www.apple.com/orderstatus/"
DEFAULT_IMAP_SERVER = "imap.gmail.com"
DEFAULT_IMAP_PORT = 993

# Increment this whenever the historical cancellation discovery logic changes.
# A versioned marker is used instead of the old boolean so existing databases
# that already ran an older, incomplete recovery are automatically retried once.
CANCEL_RECOVERY_VERSION = 2

STATUS_ORDER = [
    "Order Placed",
    "Processing",
    "Preparing to Ship",
    "Action Required",
    "Shipped",
    "Shipping to Store",
    "Check in Today",
    "Ready for Pickup",
    "Delivered",
    "Picked Up",
    "Canceled",
    "Refunded",
    "Unknown",
]

STATUS_ORDER[STATUS_ORDER.index("Delivered"):STATUS_ORDER.index("Delivered")] = list(UPS_STATES)
STATUS_ORDER.extend(s for s in APPLE_EXTRA_STATUSES if s not in STATUS_ORDER)
STATUS_RANK = {name: i for i, name in enumerate(STATUS_ORDER)}

# Manual overrides are intentionally limited to the user-facing order states.
# "Automatic" clears a manual status override and returns the order to email-derived logic.
MANUAL_STATUS_AUTOMATIC = "Automatic (use detected status)"
MANUAL_STATUS_OPTIONS = [
    "Order Placed",
    "Processing",
    "Preparing to Ship",
    "Action Required",
    "Shipped",
    "Ready for Pickup",
    "Delivered",
    "Picked Up",
    "Canceled",
    "Refunded",
]

MANUAL_STATUS_OPTIONS[MANUAL_STATUS_OPTIONS.index("Delivered"):MANUAL_STATUS_OPTIONS.index("Delivered")] = list(UPS_STATES)

KNOWN_TRACKING_HOSTS = (
    "ups.com",
    "fedex.com",
    "usps.com",
    "dhl.com",
    "ontrac.com",
    "lasership.com",
    "veho.com",
)

PRODUCT_WORDS = (
    "iphone",
    "ipad",
    "macbook",
    "mac mini",
    "mac studio",
    "imac",
    "mac pro",
    "apple watch",
    "airpods",
    "vision pro",
    "homepod",
    "apple tv",
    "studio display",
    "pro display",
    "magic keyboard",
    "magic mouse",
    "magic trackpad",
    "apple pencil",
    "airtag",
    "applecare",
)


def app_data_dir() -> Path:
    if sys.platform.startswith("win"):
        base = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
    else:
        base = os.environ.get("XDG_DATA_HOME") or str(Path.home() / ".local" / "share")
    path = Path(base) / "AppleOrderTracker"
    path.mkdir(parents=True, exist_ok=True)
    return path


def db_path() -> Path:
    return app_data_dir() / "orders.db"


def clean_text(value: str | None) -> str:
    if not value:
        return ""
    value = html.unescape(value)
    value = value.replace("\u00a0", " ")
    value = re.sub(r"[\t\r]+", " ", value)
    value = re.sub(r" {2,}", " ", value)
    return value.strip()


def check_state_is_checked(value) -> bool:
    """Normalize PySide6 check-state values across enum/int representations."""
    try:
        if value == Qt.CheckState.Checked:
            return True
    except Exception:
        pass
    raw = getattr(value, "value", value)
    target = getattr(Qt.CheckState.Checked, "value", 2)
    try:
        return int(raw) == int(target)
    except Exception:
        return False


def safe_email_list(values: Iterable[str]) -> list[str]:
    emails: list[str] = []
    seen = set()
    for _, addr in getaddresses(list(values)):
        addr = addr.strip()
        if "@" in addr:
            local,domain=addr.rsplit("@",1);addr=local+"@"+domain.lower()
        if addr and "@" in addr and addr not in seen:
            seen.add(addr)
            emails.append(addr)
    return emails


def normalize_money(text: str | None) -> str:
    if not text:
        return ""
    m = re.search(r"\$\s*([\d,]+(?:\.\d{2})?)", text)
    return f"${m.group(1)}" if m else clean_text(text)


def host_allowed(url: str, suffixes: tuple[str, ...]) -> bool:
    try:
        host = (urlparse(url).hostname or "").lower()
    except Exception:
        return False
    return any(host == s or host.endswith("." + s) for s in suffixes)


def safe_apple_url(url: str) -> str:
    url = clean_text(url)
    if not url:
        return ""
    if host_allowed(url, ("apple.com",)):
        return url
    return ""


def apple_order_url_rank(url: str, order_number: str = "") -> int:
    url = safe_apple_url(url)
    if not url:
        return -1
    low = url.lower()
    order = clean_text(order_number).lower()
    if order and f"/shop/order/guest/{order}/" in low:
        return 120
    if "/shop/order/guest/" in low and (not order or order in low):
        return 115
    if order and f"/vieworder/{order}" in low:
        return 105
    if order and order in low and "order" in low:
        return 90
    if "/shop/order/list" in low or "/shop/signin/orders" in low:
        return 20
    if url == APPLE_ORDER_FALLBACK or "orderstatus" in low:
        return 10
    return 30 if "order" in low else 0


def best_apple_order_url(existing: str, candidate: str, order_number: str = "") -> str:
    choices = [safe_apple_url(existing), safe_apple_url(candidate)]
    choices = [u for u in choices if u]
    if not choices:
        return APPLE_ORDER_FALLBACK
    return max(choices, key=lambda u: apple_order_url_rank(u, order_number))


def _email_values(value: str) -> list[str]:
    found, seen = [], set()
    for email in re.findall(r"[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}", clean_text(value), re.I):
        low = email.lower()
        if low not in seen:
            seen.add(low); found.append(email)
    return found


def apple_vieworder_urls(order_number: str, alias_emails: str = "", source_email: str = "") -> list[str]:
    order = clean_text(order_number).upper()
    if not re.fullmatch(r"W\d{8,12}", order, re.I):
        return []
    emails = _email_values(alias_emails) + _email_values(source_email)
    seen, urls = set(), []
    for email in emails[:8]:
        low = email.lower()
        if low in seen:
            continue
        seen.add(low)
        segment = quote(email, safe="@+._-")
        # Apple transactional emails have used both the newer /xc/us/vieworder
        # route and the older AOS-tagged route. Try the exact historical route
        # shapes as well because they can redirect to the tokenized secure6
        # guest-order URL shown in the browser.
        urls.append(f"https://store.apple.com/vieworder/{order}/{segment}/AOS-104820-OrderStatus")
        urls.append(f"https://store.apple.com/vieworder/{order}/{segment}/AOS-104820-OrderNumber")
        urls.append(f"https://store.apple.com/xc/us/vieworder/{order}/{segment}/")
        urls.append(f"https://store.apple.com/vieworder/{order}/{segment}/")
    return urls


def row_value(row, key: str) -> str:
    try:
        return clean_text(str(row[key] or ""))
    except Exception:
        return ""


def effective_apple_order_url(row) -> str:
    order = row_value(row, "order_number")
    stored = safe_apple_url(row_value(row, "order_url"))
    if apple_order_url_rank(stored, order) >= 90:
        return stored
    synthesized = apple_vieworder_urls(order, row_value(row, "alias_emails"), row_value(row, "source_email"))
    return synthesized[0] if synthesized else (stored or APPLE_ORDER_FALLBACK)


def browser_history_guest_urls(order_number: str) -> list[str]:
    """Find exact Apple secure guest-order URLs already visited in Chrome/Edge.

    Apple redirects legacy vieworder links to a tokenized secure6 guest URL. If
    the user has opened that order in Chrome/Edge, the final URL is often in
    browser history even when a background HTTP client cannot reproduce the
    redirect. Only Apple URLs containing the requested order number are read.
    """
    order = clean_text(order_number).upper()
    if not sys.platform.startswith("win") or not re.fullmatch(r"W\d{8,12}", order, re.I):
        return []
    local = os.environ.get("LOCALAPPDATA", "")
    if not local:
        return []
    roots = [
        Path(local) / "Google/Chrome/User Data",
        Path(local) / "Microsoft/Edge/User Data",
    ]
    found: list[tuple[int, str]] = []
    probe_dir = app_data_dir() / "history_probe"
    probe_dir.mkdir(parents=True, exist_ok=True)
    for root in roots:
        if not root.exists():
            continue
        profiles = [root / "Default"] + sorted(root.glob("Profile *"))
        for profile in profiles:
            history = profile / "History"
            if not history.exists():
                continue
            copy_path = probe_dir / f"{uuid.uuid4().hex}.sqlite"
            try:
                shutil.copy2(history, copy_path)
                conn = sqlite3.connect(copy_path)
                rows = conn.execute(
                    "SELECT url, COALESCE(last_visit_time,0) FROM urls WHERE url LIKE ? ORDER BY last_visit_time DESC LIMIT 20",
                    (f"%{order}%",),
                ).fetchall()
                conn.close()
                for url, visit in rows:
                    url = safe_apple_url(clean_text(url))
                    if not url or order.lower() not in url.lower():
                        continue
                    if "/shop/order/guest/" in url.lower() or "/vieworder/" in url.lower():
                        found.append((int(visit or 0), url))
            except Exception:
                pass
            finally:
                try:
                    copy_path.unlink(missing_ok=True)
                except Exception:
                    pass
    seen, result = set(), []
    for _, url in sorted(found, key=lambda x: (apple_order_url_rank(x[1], order), x[0]), reverse=True):
        if url not in seen:
            seen.add(url); result.append(url)
    return result


def safe_tracking_url(url: str) -> str:
    url = clean_text(url)
    if not url:
        return ""
    # Apple shipment emails sometimes route the Track Shipment button through
    # an official Apple URL before redirecting to the carrier.
    if host_allowed(url, KNOWN_TRACKING_HOSTS + ("apple.com",)):
        return url
    return ""


def safe_product_image_url(url: str) -> str:
    """Allow only Apple-hosted product images before the UI downloads them."""
    url = clean_text(url)
    if not url or not url.lower().startswith(("https://", "http://")):
        return ""
    if not host_allowed(url, ("apple.com", "cdn-apple.com")):
        return ""
    lower = url.lower()
    if any(bad in lower for bad in ("spacer", "pixel", "beacon", "apple_icon", "icon-pickup", "add-to-wallet", "qr")):
        return ""
    return url


def normalize_carrier_name(value: str) -> str:
    v = clean_text(value).lower()
    if not v:
        return ""
    if "ups" in v or "united parcel" in v:
        return "UPS"
    if "fedex" in v or "federal express" in v:
        return "FedEx"
    if "usps" in v or "postal service" in v or "united states postal" in v:
        return "USPS"
    if "dhl" in v:
        return "DHL"
    if "ontrac" in v or "laser ship" in v or "lasership" in v:
        return "OnTrac"
    if "veho" in v:
        return "Veho"
    if any(x in v for x in ("connect on your own", "activate later", "no carrier", "carrier later")):
        return ""
    raw = clean_text(value)
    if raw and len(raw) <= 40 and re.fullmatch(r"[A-Za-z0-9 .&'/-]+", raw):
        return raw
    return ""


def direct_tracking_url(number: str, carrier: str = "") -> str:
    """Build a direct carrier tracking URL when the carrier or number is recognizable."""
    n = re.sub(r"[^A-Za-z0-9]", "", clean_text(number)).upper()
    if not n:
        return ""
    carrier = normalize_carrier_name(carrier) or infer_carrier(n)
    if carrier == "UPS" or re.fullmatch(r"1Z[0-9A-Z]{16}", n):
        return f"https://www.ups.com/track?tracknum={quote_plus(n)}"
    if carrier == "FedEx":
        return f"https://www.fedex.com/fedextrack/?trknbr={quote_plus(n)}"
    if carrier == "USPS":
        return f"https://tools.usps.com/go/TrackConfirmAction?tLabels={quote_plus(n)}"
    if carrier == "DHL":
        return f"https://www.dhl.com/us-en/home/tracking.html?tracking-id={quote_plus(n)}"
    if carrier == "OnTrac":
        return f"https://www.ontrac.com/tracking/?number={quote_plus(n)}"
    if carrier == "Veho":
        return f"https://track.shipveho.com/?trackingNumber={quote_plus(n)}"
    # Conservative format-only fallbacks when Apple did not name the carrier.
    if re.fullmatch(r"9[2345]\d{18,21}", n) or re.fullmatch(r"[A-Z]{2}\d{9}US", n):
        return f"https://tools.usps.com/go/TrackConfirmAction?tLabels={quote_plus(n)}"
    if re.fullmatch(r"\d{12}", n) or re.fullmatch(r"\d{15}", n):
        return f"https://www.fedex.com/fedextrack/?trknbr={quote_plus(n)}"
    return ""


def display_date_long(value: str) -> str:
    value = clean_text(value)
    if not value:
        return ""
    try:
        d = date.fromisoformat(value[:10])
        return f"{d.strftime('%A, %B')} {d.day}, {d.year}"
    except Exception:
        return value


def _format_eta_range(start_day: date, end_day: date) -> str:
    """Human-readable Apple delivery range used by the table/export UI."""
    if start_day.year == end_day.year and start_day.month == end_day.month:
        return f"{start_day.strftime('%B')} {start_day.day}–{end_day.day}, {start_day.year}"
    if start_day.year == end_day.year:
        return f"{start_day.strftime('%B')} {start_day.day} – {end_day.strftime('%B')} {end_day.day}, {start_day.year}"
    return f"{start_day.strftime('%B')} {start_day.day}, {start_day.year} – {end_day.strftime('%B')} {end_day.day}, {end_day.year}"


def iso_date_from_text(text: str, base_dt: datetime) -> tuple[str, str]:
    raw = clean_text(text)
    if not raw:
        return "", ""
    lower = raw.lower()
    if "today" in lower:
        return base_dt.date().isoformat(), raw
    if "tomorrow" in lower:
        return (base_dt.date() + timedelta(days=1)).isoformat(), raw

    # Apple processing emails can express a promised delivery range without a year,
    # for example: "Delivers: Dec 15 – Dec 22 by Express Delivery".
    month_token = r"(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:t(?:ember)?)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)"
    range_rx = re.compile(
        rf"\b(?P<m1>{month_token})\s+(?P<d1>\d{{1,2}})(?:,?\s*(?P<y1>20\d{{2}}))?"
        rf"\s*[\-–—]\s*(?:(?P<m2>{month_token})\s+)?(?P<d2>\d{{1,2}})(?:,?\s*(?P<y2>20\d{{2}}))?\b",
        re.I,
    )
    match = range_rx.search(raw)
    if match:
        try:
            default = base_dt.replace(month=1, day=1, hour=0, minute=0, second=0, microsecond=0)
            y1 = int(match.group("y1")) if match.group("y1") else base_dt.year
            start_dt = date_parser.parse(
                f"{match.group('m1')} {match.group('d1')} {y1}",
                fuzzy=False, default=default,
            )
            start_day = start_dt.date()
            if not match.group("y1") and start_day < base_dt.date() - timedelta(days=120):
                start_day = start_day.replace(year=start_day.year + 1)

            m2 = match.group("m2") or match.group("m1")
            if match.group("y2"):
                y2 = int(match.group("y2"))
            elif match.group("y1"):
                y2 = int(match.group("y1"))
            else:
                y2 = start_day.year
            end_dt = date_parser.parse(
                f"{m2} {match.group('d2')} {y2}",
                fuzzy=False, default=default,
            )
            end_day = end_dt.date()
            if not match.group("y2") and end_day < start_day:
                end_day = end_day.replace(year=end_day.year + 1)
            return start_day.isoformat(), _format_eta_range(start_day, end_day)
        except Exception:
            pass

    default = base_dt.replace(month=1, day=1, hour=0, minute=0, second=0, microsecond=0)
    try:
        dt = date_parser.parse(raw, fuzzy=True, default=default)
        if not re.search(r"\b20\d{2}\b", raw):
            dt = dt.replace(year=base_dt.year)
            if dt.date() < base_dt.date() - timedelta(days=120):
                dt = dt.replace(year=base_dt.year + 1)
        return dt.date().isoformat(), raw
    except Exception:
        return "", raw


def display_eta_value(eta_date: str, eta_text: str = "") -> str:
    """Prefer a parsed Apple delivery range when present; otherwise show one date."""
    value = clean_text(eta_text)
    if value and re.match(
        r"^(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2}.*[–—-].*\d{1,2}",
        value,
    ):
        return value
    return display_date_long(eta_date) or value


@dataclass
class ParsedOrder:
    order_number: str
    order_type: str
    item_summary: str
    qty: int
    address: str
    status: str
    total: str
    alias_emails: str
    order_date: str
    eta_date: str
    eta_text: str
    tracking_number: str
    pickup_store: str
    pickup_time: str
    delivery_time: str
    carrier: str
    order_url: str
    tracking_url: str
    image_url: str
    subject: str
    email_date: str
    message_id: str


class AppleMailParser:
    """Heuristic parser for Apple Store order emails.

    Apple changes email templates over time. The parser intentionally relies on
    multiple text and link cues instead of a single HTML layout.
    """

    ORDER_PATTERNS = (
        re.compile(r"\bW\d{8,12}\b", re.I),
        re.compile(r"(?:order(?:\s+number|\s*#)?|order no\.?)[\s:#-]*([A-Z0-9-]{8,20})", re.I),
    )

    def parse(self, raw: bytes, source_account: str) -> Optional[ParsedOrder]:
        msg = BytesParser(policy=policy.default).parsebytes(raw)
        subject = clean_text(str(msg.get("Subject", "")))
        from_header = clean_text(str(msg.get("From", ""))).lower()

        plain, html_body = self._extract_bodies(msg)
        soup = BeautifulSoup(html_body, "html.parser") if html_body else None
        text = plain or (soup.get_text("\n") if soup else "")
        lines = self._to_lines(plain, soup)
        joined = "\n".join(lines)

        if not self._looks_like_apple_order(from_header, subject, joined, soup):
            return None

        order_number = self._extract_order_number(subject + "\n" + joined)
        if not order_number:
            return None

        email_dt = self._email_datetime(msg)
        order_type, address = self._extract_type_and_address(lines, subject)
        status = self._extract_status(subject, joined, order_type)
        # Apple cancellation template observed in production: X-EmailType-Id 1020756471
        # with a generic subject such as "Information about your order W...".  Treat
        # the template ID as authoritative so wording/encoding changes cannot hide it.
        if clean_text(str(msg.get("X-EmailType-Id", ""))) == "1020756471":
            status = "Canceled"
        items, qty = self._extract_items(lines, soup)
        total = self._extract_total(lines, joined)
        order_date = self._extract_order_date(lines, email_dt)
        eta_date, eta_text = self._extract_eta(lines, email_dt, order_type)
        tracking_number = self._extract_tracking_number(joined)
        pickup_store, pickup_time = self._extract_pickup_metadata(lines, order_type, address)
        delivery_time = self._extract_delivery_time(lines, order_type)
        carrier = self._extract_carrier(lines, joined, tracking_number)
        order_url, tracking_url, image_url = self._extract_links_and_image(soup, order_number)
        if not order_url:
            order_url = APPLE_ORDER_FALLBACK
        carrier_url = direct_tracking_url(tracking_number, carrier)
        if carrier_url:
            tracking_url = carrier_url

        alias_emails = self._extract_aliases(msg, source_account, lines)
        message_id = clean_text(str(msg.get("Message-ID", "")))
        if not message_id:
            message_id = "sha256:" + hashlib.sha256(raw).hexdigest()

        return ParsedOrder(
            order_number=order_number.upper(),
            order_type=order_type,
            item_summary=items,
            qty=qty,
            address=address,
            status=status,
            total=total,
            alias_emails=", ".join(alias_emails),
            order_date=order_date,
            eta_date=eta_date,
            eta_text=eta_text,
            tracking_number=tracking_number,
            pickup_store=pickup_store,
            pickup_time=pickup_time,
            delivery_time=delivery_time,
            carrier=carrier,
            order_url=order_url,
            tracking_url=tracking_url,
            image_url=image_url,
            subject=subject,
            email_date=email_dt.isoformat(),
            message_id=message_id,
        )

    def _extract_bodies(self, msg) -> tuple[str, str]:
        plain_parts: list[str] = []
        html_parts: list[str] = []
        if msg.is_multipart():
            for part in msg.walk():
                if part.get_content_disposition() == "attachment":
                    continue
                ctype = part.get_content_type()
                try:
                    content = part.get_content()
                except Exception:
                    continue
                if ctype == "text/plain" and isinstance(content, str):
                    plain_parts.append(content)
                elif ctype == "text/html" and isinstance(content, str):
                    html_parts.append(content)
        else:
            try:
                content = msg.get_content()
            except Exception:
                content = ""
            if msg.get_content_type() == "text/html":
                html_parts.append(content if isinstance(content, str) else "")
            else:
                plain_parts.append(content if isinstance(content, str) else "")
        return "\n".join(plain_parts), "\n".join(html_parts)

    def _to_lines(self, plain: str, soup: Optional[BeautifulSoup]) -> list[str]:
        src = plain if plain.strip() else (soup.get_text("\n") if soup else "")
        out: list[str] = []
        for raw_line in src.splitlines():
            line = clean_text(raw_line)
            if not line:
                continue
            # Drop common invisible/boilerplate artifacts.
            if line in {"|", "•", "·"}:
                continue
            out.append(line)
        return out

    def _looks_like_apple_order(self, from_header: str, subject: str, text: str, soup) -> bool:
        sender_ok = "apple.com" in from_header or "@apple" in from_header
        order_cues = any(
            cue in (subject + "\n" + text).lower()
            for cue in (
                "order number",
                "order #",
                "your order",
                "ready for pickup",
                "pickup notification",
                "shipment notification",
                "track shipment",
                "order total",
            )
        )
        link_ok = False
        if soup:
            for a in soup.find_all("a", href=True):
                href = str(a.get("href", ""))
                if host_allowed(href, ("apple.com",)) and any(k in href.lower() for k in ("order", "shop")):
                    link_ok = True
                    break
        return (sender_ok and order_cues) or (sender_ok and link_ok)

    def _extract_order_number(self, text: str) -> str:
        for pattern in self.ORDER_PATTERNS:
            m = pattern.search(text)
            if not m:
                continue
            value = m.group(1) if m.lastindex else m.group(0)
            value = clean_text(value).upper()
            if value.startswith("W") and any(ch.isdigit() for ch in value):
                return value
            # Avoid classifying generic words as an order number.
            if re.fullmatch(r"[A-Z0-9-]{8,20}", value) and any(ch.isdigit() for ch in value):
                return value
        return ""

    def _email_datetime(self, msg) -> datetime:
        try:
            dt = parsedate_to_datetime(str(msg.get("Date", "")))
            if dt is None:
                raise ValueError
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt.astimezone()
        except Exception:
            return datetime.now().astimezone()

    def _extract_aliases(self, msg, source_account: str, lines: list[str]) -> list[str]:
        headers: list[str] = []
        for name in (
            "To", "Cc", "Delivered-To", "X-Original-To", "Envelope-To",
            "X-Forwarded-To", "Resent-To", "Resent-From"
        ):
            headers.extend(str(v) for v in msg.get_all(name, []))

        emails = safe_email_list(headers)

        # Apple often repeats the order-related address in the message body under
        # Shipment Notifications or Billing Contact. Capture those too, while
        # excluding Apple sender/support addresses. Stop before the long help/footer
        # area so legal/support addresses do not pollute the alias list.
        body_window: list[str] = []
        for line in lines:
            if re.match(r"^(?:Questions|Copyright|Terms of Use|Privacy Policy)$", line, re.I):
                break
            body_window.append(line)
        body_emails = re.findall(r"[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}", "\n".join(body_window), re.I)
        for addr in body_emails:
            addr = addr.strip()
            if "@" in addr:
                local,domain=addr.rsplit("@",1);addr=local+"@"+domain.lower()
            # Ignore email-like image asset names such as standardpadding_icon@3x.png.
            if re.search(r"@(?:\d+x\.)?(?:png|jpe?g|gif|webp|svg)$", addr, re.I):
                continue
            if addr.endswith("@apple.com") or addr.endswith(".apple.com"):
                continue
            if addr not in emails:
                emails.append(addr)

        source = source_account.lower().strip()
        aliases = [e for e in emails if e != source and not e.endswith("@apple.com")]
        return aliases or [e for e in emails if not e.endswith("@apple.com")]

    def _extract_type_and_address(self, lines: list[str], subject: str) -> tuple[str, str]:
        def is_rule(line: str) -> bool:
            compact = re.sub(r"\s", "", line)
            return bool(compact) and len(compact) >= 5 and set(compact) <= {"-", "_", "="}

        def is_url(line: str) -> bool:
            return line.lower().startswith(("http://", "https://", "www."))

        def is_phone(line: str) -> bool:
            digits = re.sub(r"\D", "", line)
            return 10 <= len(digits) <= 13 and not re.search(r"\b\d{5}(?:-\d{4})?\b", line)

        def is_masked(line: str) -> bool:
            compact = re.sub(r"\s", "", line)
            return bool(re.fullmatch(r"[•●·*xX#-]*\d{0,4}", compact)) and any(ch in compact for ch in "•●·*xX")

        def find_label(pattern: str) -> int | None:
            rx = re.compile(pattern, re.I)
            for idx, line in enumerate(lines):
                if rx.search(line):
                    return idx
            return None

        def collect_after(start: int, stop_rx: re.Pattern[str], limit: int = 18) -> list[str]:
            out: list[str] = []
            for line in lines[start + 1 : start + 1 + limit]:
                if stop_rx.search(line):
                    break
                if is_rule(line) or is_url(line) or is_phone(line) or is_masked(line):
                    continue
                value = clean_text(line)
                if value:
                    out.append(value)
            return out

        combined = (subject + "\n" + "\n".join(lines[:140])).lower()
        pickup_idx = find_label(r"^pickup\s+store\b|^pickup\s+location\b")
        shipping_idx = find_label(r"^shipping\s+address\s*:?$")

        if pickup_idx is not None or any(
            cue in combined
            for cue in ("items to be picked up", "pickup notification", "ready for pickup", "pickup date:", "check-in time:")
        ):
            kind = "Pickup"
        elif shipping_idx is not None or any(
            cue in combined for cue in ("items to be shipped", "your items have shipped", "track shipment", "shipment 1", "delivers ")
        ):
            kind = "Shipping"
        else:
            # In this Apple-only tracker an order is either pickup or shipping.
            # If no pickup-specific cue is present, treat it as shipping.
            kind = "Shipping"

        if pickup_idx is not None:
            stop = re.compile(
                r"^(?:hours\s*&\s*directions|pickup\s+policy|payment|billing|questions|to see all items|personal setup)\b",
                re.I,
            )
            parts = collect_after(pickup_idx, stop, 18)
            if len(parts) >= 2 and parts[0].strip().lower() == "apple":
                parts = ["Apple " + parts[1].lstrip(" ,")] + parts[2:]
            i = 0
            normalized: list[str] = []
            while i < len(parts):
                if (
                    i + 2 < len(parts)
                    and parts[i].rstrip().endswith(",")
                    and re.fullmatch(r"[A-Z]{2}", parts[i + 1].strip(), re.I)
                    and re.fullmatch(r"\d{5}(?:-\d{4})?", parts[i + 2].strip())
                ):
                    normalized.append(f"{parts[i].rstrip()} {parts[i + 1].strip().upper()} {parts[i + 2].strip()}")
                    i += 3
                    continue
                normalized.append(parts[i])
                i += 1
            return kind, ", ".join(normalized)

        if shipping_idx is not None:
            stop = re.compile(
                r"^(?:shipment\s+notifications?|carrier\s+name|tracking\s+number|billing|subtotal|order\s+total|questions)\s*:?$",
                re.I,
            )
            raw_parts = collect_after(shipping_idx, stop, 22)
            start = 0
            for idx, value in enumerate(raw_parts):
                if re.search(r"\d", value):
                    start = idx
                    break
            parts = raw_parts[start:]
            return kind, ", ".join(parts)

        return kind, ""

    def _extract_pickup_metadata(self, lines: list[str], order_type: str, address: str) -> tuple[str, str]:
        if order_type != "Pickup":
            return "", ""
        store = ""
        for i, line in enumerate(lines):
            if re.search(r"^pickup\s+(?:store|location)\b", line, re.I):
                parts: list[str] = []
                for value in lines[i + 1 : i + 8]:
                    value = clean_text(value)
                    compact = re.sub(r"\s", "", value)
                    if not value or value.startswith(("http://", "https://")) or (len(compact) >= 5 and set(compact) <= {"-", "_", "="}):
                        continue
                    if re.search(r"^(?:hours|pickup policy|payment|billing|questions|to see all items)\b", value, re.I):
                        break
                    digits = re.sub(r"\D", "", value)
                    if re.search(r"\d{3,}", value) or (10 <= len(digits) <= 13):
                        break
                    parts.append(value)
                if parts:
                    if len(parts) >= 2 and parts[0].lower() == "apple":
                        store = "Apple " + parts[1].lstrip(" ,")
                    else:
                        store = parts[0]
                    break
        if not store and address:
            store = clean_text(address.split(",", 1)[0])
        if store and not store.lower().startswith("apple"):
            store = "Apple " + store

        pickup_time = ""
        for i, line in enumerate(lines):
            m = re.search(r"(?:check[ -]?in\s+time|arrival\s+time|pickup\s+time)\s*:\s*(.+)$", line, re.I)
            if m:
                pickup_time = clean_text(m.group(1))
                break
            if re.fullmatch(r"(?:check[ -]?in\s+time|arrival\s+time|pickup\s+time)\s*:?", line, re.I):
                if i + 1 < len(lines):
                    pickup_time = clean_text(lines[i + 1])
                    break
        return store, pickup_time

    def _extract_delivery_time(self, lines: list[str], order_type: str) -> str:
        if order_type != "Shipping":
            return ""
        label_rx = re.compile(r"(?:delivery|arrival|estimated delivery)\s+(?:time|window)\s*:\s*(.+)$", re.I)
        window_rx = re.compile(r"\b(?:by\s+)?(\d{1,2}:\d{2}\s*(?:AM|PM|a\.m\.|p\.m\.))\s*(?:-|–|to)\s*(\d{1,2}:\d{2}\s*(?:AM|PM|a\.m\.|p\.m\.))\b", re.I)
        for i, line in enumerate(lines):
            m = label_rx.search(line)
            if m:
                return clean_text(m.group(1))
            if re.fullmatch(r"(?:delivery|arrival|estimated delivery)\s+(?:time|window)\s*:?", line, re.I) and i + 1 < len(lines):
                return clean_text(lines[i + 1])
            m = window_rx.search(line)
            if m and any(word in line.lower() for word in ("deliver", "arrival", "arrive")):
                return f"{clean_text(m.group(1))} - {clean_text(m.group(2))}"
        return ""

    def _extract_carrier(self, lines: list[str], text: str, tracking_number: str) -> str:
        for i, line in enumerate(lines):
            m = re.search(r"^carrier(?:\s+name)?\s*:\s*(.+)$", line, re.I)
            if m:
                name = normalize_carrier_name(m.group(1))
                if name:
                    return name
            if re.fullmatch(r"carrier(?:\s+name)?\s*:?", line, re.I) and i + 1 < len(lines):
                name = normalize_carrier_name(lines[i + 1])
                if name:
                    return name
        # Apple sometimes places the carrier beside the item instead of under a label.
        for name in ("UPS", "FedEx", "USPS", "DHL", "OnTrac", "LaserShip", "Veho"):
            if re.search(rf"\b{re.escape(name)}\b", text[:9000], re.I):
                return normalize_carrier_name(name)
        return infer_carrier(tracking_number)

    def _extract_status(self, subject: str, text: str, order_type: str) -> str:
        subj = subject.lower()
        body = text[:6000].lower()
        # Apple sends a Personal Setup invitation only after the customer has the new
        # device. Treat this as a possession-confirmation event. The database maps
        # it to Delivered for shipping orders and Picked Up for pickup orders.
        if ("personal setup" in subj and ("get your new" in subj or "ready" in subj)) or (
            "set up your new" in body and "grab your new device" in body and "personal setup" in body
        ):
            return "Possession Confirmed"
        # Subject lines are the strongest signal because Apple may mention words
        # such as "canceled" or "shipped" later in help/legal copy.
        subject_checks = [
            (("action required", "payment problem", "problem with your payment", "payment issue"), "Action Required"),
            (("canceled", "cancelled", "cancellation"), "Canceled"),
            (("refund", "refunded"), "Refunded"),
            (("picked up", "pickup complete", "pickup completed", "thanks for picking up", "thank you for picking up"), "Picked Up"),
            (("ready for pickup", "ready to pick up", "pickup information"), "Ready for Pickup"),
            (("check in today",), "Check in Today"),
            (("shipping to store",), "Shipping to Store"),
            (("delivered",), "Delivered"),
            (("out for delivery", "shipped", "shipment notification", "on its way"), "Shipped"),
            (("preparing to ship", "preparing your order", "preparing shipment"), "Preparing to Ship"),
            (("processing",), "Processing"),
            (("thanks for your order", "order acknowledgment", "order received", "order placed"), "Order Placed"),
        ]
        for phrases, status in subject_checks:
            if any(p in subj for p in phrases):
                return status

        body_checks = [
            (("we're having a problem with your payment", "we are having a problem with your payment", "action required"), "Action Required"),
            (("your order was canceled", "your order has been canceled", "your order was cancelled",
              "your order has been cancelled", "order has been cancelled", "order has been canceled",
              "since we haven't received your payment, your order has been cancelled",
              "since we have not received your payment, your order has been cancelled"), "Canceled"),
            (("your refund has been issued", "has been refunded"), "Refunded"),
            (("your item has been picked up", "your order has been picked up", "picked up successfully",
              "thanks for picking up your order", "thank you for picking up your order",
              "your pickup is complete", "pickup is complete", "pickup completed"), "Picked Up"),
            (("your item is ready for pickup", "your order is ready for pickup", "ready for pickup"), "Ready for Pickup"),
            (("check in today",), "Check in Today"),
            (("shipping to store", "on the way to the apple store"), "Shipping to Store"),
            (("your order has been delivered", "your item has been delivered", "delivered successfully"), "Delivered"),
            (("your items have shipped", "your order has shipped", "your item has shipped", "track shipment", "shipped"), "Shipped"),
            (("preparing to ship", "we're preparing your order", "we are preparing your order"), "Preparing to Ship"),
            (("processing your order",), "Processing"),
            (("thank you for your order", "we received your order", "thanks for your order", "order placed"), "Order Placed"),
        ]
        for phrases, status in body_checks:
            if any(p in body for p in phrases):
                return status
        if order_type == "Pickup" and "pickup" in body:
            return "Processing"
        return "Unknown"

    def _extract_items(self, lines: list[str], soup: Optional[BeautifulSoup]) -> tuple[str, int]:
        qty_re = re.compile(r"(?:Qty|Quantity)\s*[:x]?\s*(\d+)", re.I)

        def product_like(value: str) -> bool:
            value = clean_text(value)
            lower = value.lower()
            if not (4 <= len(value) <= 150):
                return False
            if value.startswith(("http://", "https://", "[http")) or re.search(r"\$\s*[\d,]+", value):
                return False
            if not any(word in lower for word in PRODUCT_WORDS):
                return False
            if any(
                bad in lower
                for bad in (
                    "instructions", "how to", "set up", "setup", "support", "shop iphone",
                    "compare iphone", "protect your", "applecare coverage", "recycle", "terms",
                    "activation", "wireless account", "apple store app", "questions"
                )
            ):
                return False
            # Long explanatory sentences are not merchandise rows.
            if len(value.split()) > 16 or value.endswith(("?", ".")):
                return False
            return True

        # Restrict parsing to the merchandise block. This prevents footer copy such
        # as "iPhone Instructions" from being mistaken for an ordered item.
        start = 0
        for i, line in enumerate(lines[:160]):
            if re.search(r"^(?:items to be picked up|items to be shipped|ready for pickup|shipped)$", line, re.I):
                start = i + 1
                break
        end = min(len(lines), max(start + 1, 180))
        for i in range(start, min(len(lines), start + 120)):
            if re.search(r"^(?:pickup store|shipping address|shipment notifications|billing(?: and payment)?|payment|questions)\s*:?$", lines[i], re.I):
                end = i
                break
        region = lines[start:end]

        found: list[tuple[str, int]] = []
        for i, line in enumerate(region):
            name = clean_text(line)
            if not product_like(name):
                continue
            qty = 1
            for j in range(i + 1, min(len(region), i + 9)):
                nxt = clean_text(region[j])
                if product_like(nxt):
                    break
                m = qty_re.search(nxt)
                if m:
                    qty = max(1, int(m.group(1)))
                    break
                # Some newer Apple pickup confirmations put a bare quantity between
                # two price lines rather than using a Qty label.
                if re.fullmatch(r"\d{1,2}", nxt):
                    qty = max(1, int(nxt))
                    break
            found.append((name, qty))

        if not found:
            # Conservative fallback for older templates without a clear item section.
            for line in lines[:120]:
                if product_like(line):
                    found.append((clean_text(line), 1))
                    if len(found) >= 8:
                        break

        if not found and soup:
            for img in soup.find_all("img"):
                alt = clean_text(str(img.get("alt", "")))
                if product_like(alt):
                    found.append((alt, 1))
                    break

        if not found:
            return "Apple order", 1

        # Preserve item order but SUM duplicate line items. Two identical iPhones with
        # Qty 1 each must be shown as x2 rather than deduplicated to a single unit.
        quantities: dict[str, int] = {}
        display_names: dict[str, str] = {}
        order: list[str] = []
        for name, qty in found:
            key = re.sub(r"\s+", " ", name).strip().lower()
            if key not in quantities:
                quantities[key] = 0
                display_names[key] = re.sub(r"\s+", " ", name).strip()
                order.append(key)
            quantities[key] += max(1, qty)

        summary_parts = []
        for key in order:
            name = display_names[key]
            qty = quantities[key]
            summary_parts.append(f"{name} x{qty}" if qty != 1 else name)
        return " | ".join(summary_parts), sum(quantities.values())

    def _extract_total(self, lines: list[str], text: str) -> str:
        for i, line in enumerate(lines):
            if re.search(r"\border\s+total\b", line, re.I):
                if re.search(r"\$\s*[\d,]+(?:\.\d{2})?", line):
                    return normalize_money(line)
                for nxt in lines[i + 1 : i + 3]:
                    if re.search(r"\$\s*[\d,]+(?:\.\d{2})?", nxt):
                        return normalize_money(nxt)
        for line in reversed(lines):
            if re.search(r"order\s*total|ordertotallabel|\btotal\b", line, re.I) and not re.search(r"subtotal|tax total", line, re.I):
                if re.search(r"\$\s*[\d,]+(?:\.\d{2})?", line):
                    return normalize_money(line)
        return ""

    def _extract_order_date(self, lines: list[str], email_dt: datetime) -> str:
        for i, line in enumerate(lines):
            if re.search(r"\border(?:ed)?\s+(?:on|date)\b|\border date\b", line, re.I):
                candidates = [line] + lines[i + 1 : i + 3]
                for c in candidates:
                    try:
                        dt = date_parser.parse(c, fuzzy=True, default=email_dt.replace(hour=0, minute=0, second=0, microsecond=0))
                        return dt.date().isoformat()
                    except Exception:
                        pass
        return email_dt.date().isoformat()

    def _extract_eta(self, lines: list[str], email_dt: datetime, order_type: str) -> tuple[str, str]:
        cue_re = re.compile(
            r"\b(?:delivers?|delivery|arrives?|arrival|estimated delivery|available for pickup|pickup date|pick up|ready)\b",
            re.I,
        )
        month_re = re.compile(
            r"\b(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:t(?:ember)?)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\b",
            re.I,
        )
        for i, line in enumerate(lines):
            if not cue_re.search(line):
                continue
            candidates = [line] + lines[i + 1 : i + 3]
            for c in candidates:
                if month_re.search(c) or re.search(r"\b(today|tomorrow)\b", c, re.I):
                    d, raw = iso_date_from_text(c, email_dt)
                    if d:
                        return d, raw
        return "", ""

    def _extract_tracking_number(self, text: str) -> str:
        # Most reliable: value immediately following an explicit tracking label.
        label = re.search(r"tracking(?:\s+number|\s*#)?\s*[:#-]?\s*([A-Z0-9-]{8,30})", text, re.I)
        if label:
            candidate = label.group(1).upper()
            if candidate not in {"INFORMATION", "AVAILABLE"}:
                return candidate
        ups = re.search(r"\b1Z[0-9A-Z]{16}\b", text, re.I)
        if ups:
            return ups.group(0).upper()
        usps = re.search(r"\b(?:9[2345]\d{18,21}|[A-Z]{2}\d{9}US)\b", text, re.I)
        if usps:
            return usps.group(0).upper()
        # FedEx numbers are ambiguous, so require proximity to a tracking cue.
        prox = re.search(r"tracking.{0,160}?\b(\d{12,22})\b", text, re.I | re.S)
        if prox:
            return prox.group(1)
        return ""

    def _extract_links_and_image(self, soup: Optional[BeautifulSoup], order_number: str) -> tuple[str, str, str]:
        if not soup:
            return "", "", ""
        order_url = ""
        fallback_order_url = ""
        tracking_url = ""
        target = order_number.lower()
        for a in soup.find_all("a", href=True):
            href = clean_text(str(a.get("href", "")))
            label = clean_text(a.get_text(" ")).lower()
            if host_allowed(href, ("apple.com",)):
                lower_href = href.lower()
                if target and target in lower_href and ("vieworder" in lower_href or "order" in lower_href):
                    order_url = safe_apple_url(href)
                elif not fallback_order_url and ("order" in lower_href or "view order" in label or "order status" in label):
                    fallback_order_url = safe_apple_url(href)
            if not tracking_url and ("track" in label or "track" in href.lower()):
                tracking_url = safe_tracking_url(href)
        if not order_url:
            order_url = fallback_order_url

        # Prefer Apple Store product CDN images over logos, pickup icons, QR codes,
        # AppleCare tiles, and marketing artwork.
        image_url = ""
        fallback_image = ""
        for img in soup.find_all("img"):
            src = safe_product_image_url(str(img.get("src", "")))
            if not src:
                continue
            alt = clean_text(str(img.get("alt", ""))).lower()
            lower_src = src.lower()
            if "storeimages" in lower_src or "as-images.apple.com/is/" in lower_src:
                image_url = src
                break
            width = str(img.get("width", ""))
            height = str(img.get("height", ""))
            try:
                w = int(re.sub(r"\D", "", width) or "0")
                h = int(re.sub(r"\D", "", height) or "0")
            except Exception:
                w = h = 0
            if not fallback_image and (any(word in alt for word in PRODUCT_WORDS) or (w >= 80 and h >= 80)):
                fallback_image = src
        return order_url, tracking_url, image_url or fallback_image




def resource_path(name: str) -> Path:
    """Return a bundled PyInstaller resource or a source-tree resource."""
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
    return base / name


def infer_carrier(tracking_number: str) -> str:
    n = re.sub(r"[^A-Za-z0-9]", "", clean_text(tracking_number)).upper()
    if re.fullmatch(r"1Z[0-9A-Z]{16}", n):
        return "UPS"
    if re.fullmatch(r"9[2345]\d{18,21}", n) or re.fullmatch(r"[A-Z]{2}\d{9}US", n):
        return "USPS"
    if re.fullmatch(r"\d{12}", n) or re.fullmatch(r"\d{15}", n):
        return "FedEx"
    if re.fullmatch(r"JD\d{18}", n, re.I) or re.fullmatch(r"\d{10}", n):
        return "DHL"
    if re.fullmatch(r"(?:C|D)\d{14}", n, re.I) or n.startswith("1LS"):
        return "OnTrac"
    return ""


def split_tracking_numbers(value: str) -> list[str]:
    parts = re.split(r"[,;\n]+", clean_text(value))
    out: list[str] = []
    seen: set[str] = set()
    for part in parts:
        n = re.sub(r"[^A-Za-z0-9]", "", part).upper()
        if n and n not in seen:
            seen.add(n)
            out.append(n)
    return out


def derive_storage(item_text: str) -> str:
    m = re.search(r"\b(\d+(?:\.\d+)?\s*(?:TB|GB))\b", clean_text(item_text), flags=re.I)
    return m.group(1).replace(" ", "").upper() if m else ""


def derive_color(item_text: str) -> str:
    text = clean_text(item_text)
    colors = [
        "Natural Titanium", "Desert Titanium", "Blue Titanium", "White Titanium", "Black Titanium",
        "Space Black", "Space Gray", "Space Grey", "Product Red", "Rose Gold",
        "Glacier", "Burgundy", "Midnight", "Starlight", "Graphite", "Silver", "Gold",
        "Black", "White", "Blue", "Purple", "Pink", "Green", "Yellow", "Orange", "Red",
    ]
    for color in colors:
        if re.search(rf"\b{re.escape(color)}\b", text, flags=re.I):
            return color
    return ""



STATUS_COLORS = {
    "Order Placed": ("#64748b", "#f1f5f9"),
    "Processing": ("#2563eb", "#dbeafe"),
    "Preparing to Ship": ("#7c3aed", "#ede9fe"),
    "Action Required": ("#d97706", "#fff7ed"),
    "Shipped": ("#0284c7", "#e0f2fe"),
    "Shipping to Store": ("#7c3aed", "#f3e8ff"),
    "Check in Today": ("#7c3aed", "#f3e8ff"),
    "Ready for Pickup": ("#7c3aed", "#f3e8ff"),
    "Delivered": ("#16a34a", "#dcfce7"),
    "Picked Up": ("#16a34a", "#dcfce7"),
    "Canceled": ("#dc2626", "#fee2e2"),
    "Refunded": ("#dc2626", "#fee2e2"),
    "Unknown": ("#64748b", "#f1f5f9"),
}

STATUS_GLYPHS = {
    "Order Placed": "●", "Processing": "↻", "Preparing to Ship": "▣",
    "Action Required": "⚠", "Shipped": "➜", "Shipping to Store": "⇢",
    "Check in Today": "◷", "Ready for Pickup": "⌂", "Delivered": "✓",
    "Picked Up": "✓", "Canceled": "×", "Refunded": "↶", "Unknown": "?",
}

SHIPPING_PHASE = {
    "Unknown": 0, "Order Placed": 10, "Processing": 20, "Action Required": 25,
    "Preparing to Ship": 30, "Shipped": 40, "Delivered": 50,
}
PICKUP_PHASE = {
    "Unknown": 0, "Order Placed": 10, "Processing": 20, "Action Required": 25,
    "Shipping to Store": 30, "Check in Today": 40, "Ready for Pickup": 50, "Picked Up": 60,
}
TERMINAL_STATUSES = {"Delivered", "Picked Up", "Canceled", "Refunded", "Returned to Sender"}
STATUS_COLORS.update({
    "Label Created": ("#475569", "#f1f5f9"), "In Transit": ("#0369a1", "#e0f2fe"),
    "Out for Delivery": ("#047857", "#d1fae5"), "Delayed": ("#b45309", "#fef3c7"),
    "Exception": ("#b91c1c", "#fee2e2"), "Returning to Sender": ("#b91c1c", "#ffedd5"),
    "Returned to Sender": ("#991b1b", "#fee2e2"), "Partially Delivered": ("#0f766e", "#ccfbf1"),
    "Mixed Shipments": ("#9a3412", "#ffedd5"), "Tracking Update": ("#475569", "#e2e8f0"),
})
STATUS_GLYPHS.update({status: "!" if status in ("Exception", "Delayed", "Returning to Sender", "Returned to Sender", "Mixed Shipments") else ">" for status in UPS_STATES})


def ups_numbers_for_order(row):
    carrier = normalize_carrier_name(row_value(row, "carrier"))
    result = []
    for n in split_tracking_numbers(row_value(row, "tracking_number")):
        guessed = infer_carrier(n)
        if guessed == "UPS" or (not guessed and carrier == "UPS"):
            result.append(n.upper())
    return list(dict.fromkeys(result))


def tracking_status_tip(row):
    parts = [f"Order status: {row_value(row, 'status')}", f"Source: {row_value(row, 'status_source') or 'Apple Email'}"]
    if row_value(row, "manual_status"):
        parts.append("Manual override is active. UPS details below do not overwrite your saved choice.")
    if row_value(row, "tracking_status"):
        parts.append("UPS/carrier status: " + row_value(row, "tracking_status"))
    for key, label in (("tracking_detail", "Package details"), ("tracking_success_at", "Last successful UPS check"), ("tracking_error", "Last UPS check error")):
        if row_value(row, key):
            parts.append(label + ": " + row_value(row, key))
    return "\n".join(parts)


def backup_before_ups_migration(path):
    if not Path(path).exists(): return
    source = sqlite3.connect(path, timeout=30)
    try:
        if source.execute("SELECT 1 FROM sqlite_master WHERE name='ups_package_state'").fetchone(): return
        folder = Path(path).parent / "backups"
        folder.mkdir(parents=True, exist_ok=True)
        destination = folder / ("orders_before_ups_repair_" + datetime.now().strftime("%Y%m%d_%H%M%S_%f") + ".db")
        target = sqlite3.connect(destination)
        try: source.backup(target)
        finally: target.close()
    finally:
        source.close()


def pickup_store_from_address(address: str) -> str:
    value = clean_text(address)
    if not value:
        return ""
    first = clean_text(value.split(",", 1)[0])
    if not first:
        return ""
    return first if first.lower().startswith("apple") else "Apple " + first


def advance_status(current: str, incoming: str, order_type: str) -> str:
    current = current or "Unknown"
    incoming = incoming or "Unknown"
    kind = (order_type or "").lower()
    if incoming == "Unknown":
        return current
    if incoming == "Possession Confirmed":
        # This Apple email is the strongest fulfillment signal available from
        # email: shipment -> Delivered, store pickup -> Picked Up.
        return "Picked Up" if kind == "pickup" else "Delivered"
    # Do not let generic page/help text cross the shipping/pickup state machines.
    if kind == "pickup" and incoming == "Delivered":
        return current
    if kind == "shipping" and incoming == "Picked Up":
        return current
    if incoming in ("Canceled", "Refunded"):
        return incoming
    if current in ("Canceled", "Refunded"):
        return current
    if incoming in ("Delivered", "Picked Up"):
        return incoming
    if current in ("Delivered", "Picked Up"):
        return current
    phases = PICKUP_PHASE if kind == "pickup" else SHIPPING_PHASE
    if current == "Action Required" and incoming not in ("Order Placed", "Unknown"):
        return incoming
    if incoming == "Action Required":
        advanced_threshold = 40 if kind == "shipping" else 50
        return current if phases.get(current, 0) >= advanced_threshold else incoming
    return incoming if phases.get(incoming, 0) >= phases.get(current, 0) else current

class Database:
    """SQLite store shared with v2 so an upgrade does not require another full sync."""

    def __init__(self, path: Path):
        self.path = path
        self.conn = sqlite3.connect(path, timeout=30)
        self.conn.row_factory = sqlite3.Row
        self._init_schema()

    def close(self):
        self.conn.close()

    def _init_schema(self):
        cur = self.conn.cursor()
        cur.executescript(
            """
            PRAGMA journal_mode=WAL;
            PRAGMA foreign_keys=ON;
            PRAGMA synchronous=NORMAL;
            PRAGMA temp_store=MEMORY;
            PRAGMA cache_size=-32000;

            CREATE TABLE IF NOT EXISTS accounts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT NOT NULL UNIQUE,
                server TEXT NOT NULL DEFAULT 'imap.gmail.com',
                port INTEGER NOT NULL DEFAULT 993,
                last_uid INTEGER NOT NULL DEFAULT 0,
                enabled INTEGER NOT NULL DEFAULT 1,
                added_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                account_id INTEGER NOT NULL,
                order_number TEXT NOT NULL,
                order_type TEXT,
                item_summary TEXT,
                qty INTEGER NOT NULL DEFAULT 1,
                address TEXT,
                status TEXT,
                total TEXT,
                alias_emails TEXT,
                order_date TEXT,
                eta_date TEXT,
                eta_text TEXT,
                tracking_number TEXT,
                order_url TEXT,
                tracking_url TEXT,
                image_url TEXT,
                subject TEXT,
                last_email_date TEXT,
                updated_at TEXT NOT NULL,
                UNIQUE(account_id, order_number),
                FOREIGN KEY(account_id) REFERENCES accounts(id) ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS email_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                account_id INTEGER NOT NULL,
                uid INTEGER NOT NULL,
                message_id TEXT NOT NULL,
                order_number TEXT,
                subject TEXT,
                event_status TEXT,
                email_date TEXT,
                processed_at TEXT NOT NULL,
                UNIQUE(account_id, message_id),
                FOREIGN KEY(account_id) REFERENCES accounts(id) ON DELETE CASCADE
            );

            CREATE INDEX IF NOT EXISTS idx_orders_eta ON orders(eta_date);
            CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
            CREATE INDEX IF NOT EXISTS idx_orders_order_date ON orders(order_date);
            CREATE INDEX IF NOT EXISTS idx_orders_account_status ON orders(account_id, status);
            CREATE INDEX IF NOT EXISTS idx_events_order ON email_events(account_id, order_number);
            CREATE INDEX IF NOT EXISTS idx_events_status_date ON email_events(event_status, email_date);

            CREATE TABLE IF NOT EXISTS archived_order_dates (
                order_day TEXT PRIMARY KEY,
                archived_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS sync_failures (
                account_id INTEGER NOT NULL,
                mailbox TEXT NOT NULL,
                uid INTEGER NOT NULL,
                attempts INTEGER NOT NULL DEFAULT 1,
                last_error TEXT NOT NULL DEFAULT '',
                last_attempt_at TEXT NOT NULL DEFAULT '',
                PRIMARY KEY(account_id, mailbox, uid),
                FOREIGN KEY(account_id) REFERENCES accounts(id) ON DELETE CASCADE
            );
            CREATE INDEX IF NOT EXISTS idx_sync_failures_account_mailbox
                ON sync_failures(account_id, mailbox, uid);
            """
        )
        self._ensure_account_sync_columns()
        self._ensure_v5_columns()
        install_apple_schema(self.conn)
        calendar_sql = self.conn.execute("SELECT sql FROM sqlite_master WHERE name='tracker_calendar_activity'").fetchone()
        if calendar_sql and 'account_status_event_at' not in (calendar_sql[0] or ''):
            self.conn.execute('DROP VIEW tracker_calendar_activity')
        self.conn.executescript("""
            CREATE VIEW IF NOT EXISTS visible_orders AS
                SELECT o.* FROM orders o WHERE NOT EXISTS (
                    SELECT 1 FROM archived_order_dates d
                    WHERE d.order_day=substr(COALESCE(o.order_date,''),1,10));
            CREATE VIEW IF NOT EXISTS tracker_calendar_activity AS
                SELECT o.*,
                    CASE WHEN o.status='Delivered' THEN substr(COALESCE(CASE WHEN o.status_source='Apple Account' THEN NULLIF(o.account_status_event_at,'') END,NULLIF(o.tracking_delivered_at,''),
                         (SELECT MAX(e.email_date) FROM email_events e WHERE e.account_id=o.account_id AND e.order_number=o.order_number
                           AND e.event_status IN ('Delivered','Possession Confirmed')),
                         NULLIF(o.status_updated_at,''),o.eta_date),1,10)
                         WHEN o.status='Picked Up' THEN substr(COALESCE(CASE WHEN o.status_source='Apple Account' THEN NULLIF(o.account_status_event_at,'') END,
                         (SELECT MAX(e.email_date) FROM email_events e WHERE e.account_id=o.account_id AND e.order_number=o.order_number
                           AND e.event_status IN ('Picked Up','Possession Confirmed')),
                         NULLIF(o.status_updated_at,''),o.eta_date),1,10)
                         ELSE o.eta_date END AS activity_date,
                    CASE WHEN o.status='Delivered' THEN 'Delivered' WHEN o.status='Picked Up' THEN 'Picked Up'
                         WHEN lower(o.order_type)='pickup' THEN 'Scheduled Pickup' ELSE 'Scheduled Delivery' END AS activity_label
                FROM visible_orders o WHERE COALESCE(o.status,'') NOT IN
                    ('Canceled','Refunded','Returning to Sender','Returned to Sender','Mixed Shipments','Label Voided');
            CREATE TABLE IF NOT EXISTS ups_package_state (
                order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
                tracking_number TEXT NOT NULL,
                payload_json TEXT NOT NULL DEFAULT '{}',
                checked_at TEXT NOT NULL DEFAULT '',
                success_at TEXT NOT NULL DEFAULT '',
                error TEXT NOT NULL DEFAULT '',
                PRIMARY KEY(order_id, tracking_number)
            );
        """)
        # Apple orders have only two fulfillment types in this app. Existing
        # legacy rows that were previously labeled Unknown are shipping unless
        # the parser positively identified them as Pickup.
        self.conn.execute("UPDATE orders SET order_type='Shipping' WHERE lower(COALESCE(order_type,'')) NOT IN ('pickup','shipping')")
        # Backfill carrier names for legacy rows so the Tracking page can filter
        # correctly even before the next email refresh.
        for legacy in self.conn.execute("SELECT id, tracking_number FROM orders WHERE COALESCE(carrier,'')='' AND COALESCE(tracking_number,'')<>''").fetchall():
            guessed = infer_carrier(legacy["tracking_number"] or "")
            if guessed:
                self.conn.execute("UPDATE orders SET carrier=? WHERE id=?", (guessed, legacy["id"]))
        self.conn.commit()
        self.recompute_all_statuses()

    def _ensure_account_sync_columns(self):
        """Add per-mailbox sync checkpoints without invalidating existing databases."""
        existing = {row[1] for row in self.conn.execute("PRAGMA table_info(accounts)").fetchall()}
        additions = {
            "spam_last_uid": "INTEGER NOT NULL DEFAULT 0",
            "trash_last_uid": "INTEGER NOT NULL DEFAULT 0",
            "cancel_recovery_done": "INTEGER NOT NULL DEFAULT 0",
            "cancel_recovery_version": "INTEGER NOT NULL DEFAULT 0",
        }
        for name, ddl in additions.items():
            if name not in existing:
                self.conn.execute(f"ALTER TABLE accounts ADD COLUMN {name} {ddl}")

    def _ensure_v5_columns(self):
        existing = {row[1] for row in self.conn.execute("PRAGMA table_info(orders)").fetchall()}
        additions = {
            "pickup_store": "TEXT",
            "pickup_time": "TEXT",
            "delivery_time": "TEXT",
            "carrier": "TEXT",
            "tracking_status": "TEXT",
            "tracking_detail": "TEXT",
            "tracking_checked_at": "TEXT",
            "tracking_delivered_at": "TEXT",
            "tracking_success_at": "TEXT",
            "tracking_error": "TEXT",
            "tracking_event_at": "TEXT",
            "tracking_returned_at": "TEXT",
            "status_source": "TEXT",
            "status_updated_at": "TEXT",
            "apple_checked_at": "TEXT",
            "apple_status": "TEXT",
            "apple_status_detail": "TEXT",
            # Manual overrides are stored separately from detected values so
            # Gmail re-syncs can keep learning without ever overwriting a user decision.
            "manual_status": "TEXT",
            "manual_qty": "INTEGER",
            "detected_status": "TEXT",
            "detected_qty": "INTEGER",
            "manual_override_updated_at": "TEXT",
        }
        for name, ddl in additions.items():
            if name not in existing:
                self.conn.execute(f"ALTER TABLE orders ADD COLUMN {name} {ddl}")
        # One-time migration for databases created by older builds.
        self.conn.execute("UPDATE orders SET detected_status=COALESCE(NULLIF(detected_status,''), status, 'Unknown') WHERE detected_status IS NULL OR detected_status='' ")
        self.conn.execute("UPDATE orders SET detected_qty=COALESCE(detected_qty, qty, 1) WHERE detected_qty IS NULL")

    def _merge_detected_qty(self, account_id: int, order_number: str, incoming_qty: int | None):
        row = self.conn.execute(
            "SELECT id, qty, detected_qty, manual_qty, account_qty FROM orders WHERE account_id=? AND order_number=?",
            (account_id, order_number),
        ).fetchone()
        if not row:
            return
        try:
            incoming = max(1, int(incoming_qty or 1))
        except Exception:
            incoming = 1
        try:
            current_auto = max(1, int(row["detected_qty"] if row["detected_qty"] is not None else (row["qty"] or 1)))
        except Exception:
            current_auto = 1
        detected = max(current_auto, incoming)
        effective = int(row["manual_qty"]) if row["manual_qty"] is not None else (int(row["account_qty"]) if row["account_qty"] is not None else detected)
        self.conn.execute("UPDATE orders SET detected_qty=?, qty=? WHERE id=?", (detected, effective, row["id"]))

    def apply_manual_overrides(self, changes: dict[int, dict]):
        """Validate all checked rows before committing any manual overrides."""
        if not changes:
            return
        normalized = {}
        for order_id, change in changes.items():
            oid = int(order_id)
            value = {}
            if "status" in change:
                status = clean_text(str(change.get("status") or ""))
                if status and status not in MANUAL_STATUS_OPTIONS:
                    raise ValueError(f"Unsupported status: {status}")
                value["status"] = status
            if "qty" in change:
                qty = int(change["qty"])
                if not 1 <= qty <= 9999:
                    raise ValueError("Quantity must be from 1 to 9999.")
                value["qty"] = qty
            normalized[oid] = value
        now = datetime.now().astimezone().isoformat()
        with self.conn:
            for oid, change in normalized.items():
                row = self.conn.execute("SELECT * FROM visible_orders WHERE id=?", (oid,)).fetchone()
                if not row:
                    raise ValueError("An order no longer exists in the active view. No changes were saved.")
                if "status" in change:
                    self.conn.execute("UPDATE orders SET manual_status=?, manual_override_updated_at=?, updated_at=? WHERE id=?", (change["status"], now, now, oid))
                if "qty" in change:
                    self.conn.execute("UPDATE orders SET manual_qty=?, qty=?, manual_override_updated_at=?, updated_at=? WHERE id=?", (change["qty"], change["qty"], now, now, oid))
                self.recompute_order_status(int(row["account_id"]), row["order_number"], commit=False)

    def list_accounts(self):
        return self.conn.execute("SELECT * FROM accounts ORDER BY email").fetchall()

    def add_account(self, email: str, server: str = DEFAULT_IMAP_SERVER, port: int = DEFAULT_IMAP_PORT) -> int:
        now = datetime.now().astimezone().isoformat()
        self.conn.execute(
            "INSERT INTO accounts(email, server, port, added_at) VALUES(?,?,?,?) "
            "ON CONFLICT(email) DO UPDATE SET server=excluded.server, port=excluded.port, enabled=1",
            (email.lower().strip(), server, port, now),
        )
        self.conn.commit()
        row = self.conn.execute("SELECT id FROM accounts WHERE email=?", (email.lower().strip(),)).fetchone()
        return int(row[0])

    def remove_account(self, account_id: int):
        row = self.conn.execute("SELECT email FROM accounts WHERE id=?", (account_id,)).fetchone()
        self.conn.execute("DELETE FROM accounts WHERE id=?", (account_id,))
        self.conn.commit()
        if row:
            try:
                keyring.delete_password(APP_KEYRING_SERVICE, row["email"])
            except Exception:
                pass

    def set_last_uid(self, account_id: int, uid: int, commit: bool = True):
        self.conn.execute("UPDATE accounts SET last_uid=? WHERE id=?", (uid, account_id))
        if commit:
            self.conn.commit()

    def set_mailbox_last_uid(self, account_id: int, label: str, uid: int, commit: bool = True):
        column = {"Spam": "spam_last_uid", "Trash": "trash_last_uid"}.get(label, "last_uid")
        self.conn.execute(f"UPDATE accounts SET {column}=? WHERE id=?", (max(0, int(uid or 0)), account_id))
        if commit:
            self.conn.commit()

    def pending_sync_uids(self, account_id: int, mailbox: str) -> list[int]:
        rows = self.conn.execute(
            "SELECT uid FROM sync_failures WHERE account_id=? AND mailbox=? ORDER BY uid",
            (int(account_id), clean_text(mailbox)),
        ).fetchall()
        return [int(r[0]) for r in rows]

    def record_sync_failure(self, account_id: int, mailbox: str, uid: int, error: str, commit: bool = True):
        now = datetime.now().astimezone().isoformat()
        self.conn.execute(
            """INSERT INTO sync_failures(account_id,mailbox,uid,attempts,last_error,last_attempt_at)
               VALUES(?,?,?,?,?,?)
               ON CONFLICT(account_id,mailbox,uid) DO UPDATE SET
                 attempts=sync_failures.attempts+1,
                 last_error=excluded.last_error,
                 last_attempt_at=excluded.last_attempt_at""",
            (int(account_id), clean_text(mailbox), int(uid), 1, clean_text(error)[:1200], now),
        )
        if commit:
            self.conn.commit()

    def clear_sync_failure(self, account_id: int, mailbox: str, uid: int, commit: bool = True):
        self.conn.execute(
            "DELETE FROM sync_failures WHERE account_id=? AND mailbox=? AND uid=?",
            (int(account_id), clean_text(mailbox), int(uid)),
        )
        if commit:
            self.conn.commit()

    def sync_failure_count(self, account_id: int | None = None) -> int:
        if account_id is None:
            row = self.conn.execute("SELECT COUNT(*) FROM sync_failures").fetchone()
        else:
            row = self.conn.execute("SELECT COUNT(*) FROM sync_failures WHERE account_id=?", (int(account_id),)).fetchone()
        return int(row[0] or 0) if row else 0

    def mark_cancel_recovery_done(self, account_id: int, commit: bool = True):
        # Keep the legacy boolean in sync, but the version is authoritative.
        self.conn.execute(
            "UPDATE accounts SET cancel_recovery_done=1, cancel_recovery_version=? WHERE id=?",
            (CANCEL_RECOVERY_VERSION, account_id),
        )
        if commit:
            self.conn.commit()

    def latest_event_day(self, account_id: int) -> str:
        row = self.conn.execute("SELECT MAX(email_date) AS latest FROM email_events WHERE account_id=?", (account_id,)).fetchone()
        value = clean_text(str(row["latest"] or "")) if row else ""
        if not value:
            return ""
        try:
            return datetime.fromisoformat(value.replace("Z", "+00:00")).date().isoformat()
        except Exception:
            return value[:10] if re.fullmatch(r"\d{4}-\d{2}-\d{2}.*", value) else ""

    def save_update(self, account_id: int, uid: int, parsed: ParsedOrder, commit: bool = True) -> bool:
        """Merge one parsed email. Returns False when the message was already imported."""
        now = datetime.now().astimezone().isoformat()
        cur = self.conn.execute(
            "INSERT OR IGNORE INTO email_events(account_id, uid, message_id, order_number, subject, event_status, email_date, processed_at) "
            "VALUES(?,?,?,?,?,?,?,?)",
            (
                account_id,
                uid,
                parsed.message_id,
                parsed.order_number,
                parsed.subject,
                parsed.status,
                parsed.email_date,
                now,
            ),
        )
        if cur.rowcount == 0:
            return False

        existing = self.conn.execute(
            "SELECT * FROM orders WHERE account_id=? AND order_number=?",
            (account_id, parsed.order_number),
        ).fetchone()

        if not existing:
            self.conn.execute(
                """
                INSERT INTO orders(
                    account_id, order_number, order_type, item_summary, qty, address, status, total,
                    alias_emails, order_date, eta_date, eta_text, tracking_number, order_url,
                    tracking_url, image_url, subject, last_email_date, updated_at
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    account_id,
                    parsed.order_number,
                    parsed.order_type,
                    parsed.item_summary,
                    parsed.qty,
                    parsed.address,
                    parsed.status,
                    parsed.total,
                    parsed.alias_emails,
                    parsed.order_date,
                    parsed.eta_date,
                    parsed.eta_text,
                    parsed.tracking_number,
                    parsed.order_url,
                    parsed.tracking_url,
                    parsed.image_url,
                    parsed.subject,
                    parsed.email_date,
                    now,
                ),
            )
        else:
            new_is_newer = parsed.email_date >= (existing["last_email_date"] or "")
            item_summary = self._merge_piped(existing["item_summary"], parsed.item_summary)
            aliases = ", ".join(dict.fromkeys(exact_aliases(existing["alias_emails"] or "") + exact_aliases(parsed.alias_emails or "")))
            tracking = self._merge_csv(existing["tracking_number"], parsed.tracking_number)
            qty = max(int(existing["qty"] or 1), int(parsed.qty or 1))
            status = existing["status"] or "Unknown"
            if new_is_newer and parsed.status != "Unknown":
                status = parsed.status

            values = {
                "order_type": "Pickup" if (parsed.order_type or "").lower() == "pickup" or (existing["order_type"] or "").lower() == "pickup" else "Shipping",
                "item_summary": item_summary,
                "qty": qty,
                "address": parsed.address or existing["address"],
                "status": status,
                "total": parsed.total or existing["total"],
                "alias_emails": aliases,
                "order_date": existing["order_date"] or parsed.order_date,
                "eta_date": parsed.eta_date if (parsed.eta_date and (new_is_newer or not existing["eta_date"])) else existing["eta_date"],
                "eta_text": parsed.eta_text if (parsed.eta_text and (new_is_newer or not existing["eta_text"])) else existing["eta_text"],
                "tracking_number": tracking,
                "order_url": best_apple_order_url(existing["order_url"], parsed.order_url, parsed.order_number),
                "tracking_url": parsed.tracking_url or existing["tracking_url"],
                "image_url": parsed.image_url or existing["image_url"],
                "subject": parsed.subject or existing["subject"],
                "last_email_date": max(existing["last_email_date"] or "", parsed.email_date),
                "updated_at": now,
            }
            self.conn.execute(
                """
                UPDATE orders SET
                    order_type=:order_type, item_summary=:item_summary, qty=:qty, address=:address,
                    status=:status, total=:total, alias_emails=:alias_emails, order_date=:order_date,
                    eta_date=:eta_date, eta_text=:eta_text, tracking_number=:tracking_number,
                    order_url=:order_url, tracking_url=:tracking_url, image_url=:image_url,
                    subject=:subject, last_email_date=:last_email_date, updated_at=:updated_at
                WHERE id=:id
                """,
                {**values, "id": existing["id"]},
            )
        self._apply_parsed_metadata(account_id, parsed)
        self._merge_detected_qty(account_id, parsed.order_number, parsed.qty)
        self.recompute_order_status(account_id, parsed.order_number, commit=False)
        if commit:
            self.conn.commit()
        return True

    def _apply_parsed_metadata(self, account_id: int, parsed: ParsedOrder):
        existing = self.conn.execute(
            "SELECT * FROM orders WHERE account_id=? AND order_number=?", (account_id, parsed.order_number)
        ).fetchone()
        if not existing:
            return
        store = parsed.pickup_store or existing["pickup_store"] or (
            pickup_store_from_address(parsed.address or existing["address"] or "")
            if ((parsed.order_type or "").lower() == "pickup" or (existing["order_type"] or "").lower() == "pickup") else ""
        )
        carrier = parsed.carrier or existing["carrier"] or infer_carrier(parsed.tracking_number or existing["tracking_number"] or "")
        self.conn.execute(
            """UPDATE orders SET pickup_store=?, pickup_time=?, delivery_time=?, carrier=? WHERE account_id=? AND order_number=?""",
            (store, parsed.pickup_time or existing["pickup_time"] or "",
             parsed.delivery_time or existing["delivery_time"] or "", carrier, account_id, parsed.order_number),
        )

    def refresh_from_parsed(self, account_id: int, uid: int, parsed: ParsedOrder, commit: bool = True) -> bool:
        now = datetime.now().astimezone().isoformat()
        self.conn.execute(
            """INSERT INTO email_events(account_id, uid, message_id, order_number, subject, event_status, email_date, processed_at)
               VALUES(?,?,?,?,?,?,?,?)
               ON CONFLICT(account_id, message_id) DO UPDATE SET
                 uid=excluded.uid, order_number=excluded.order_number, subject=excluded.subject,
                 event_status=excluded.event_status, email_date=excluded.email_date""",
            (account_id, uid, parsed.message_id, parsed.order_number, parsed.subject, parsed.status, parsed.email_date, now),
        )
        existing = self.conn.execute(
            "SELECT * FROM orders WHERE account_id=? AND order_number=?", (account_id, parsed.order_number)
        ).fetchone()
        if not existing:
            # Event exists now, so insert the order directly rather than calling save_update.
            self.conn.execute(
                """INSERT INTO orders(account_id, order_number, order_type, item_summary, qty, address, status, total,
                   alias_emails, order_date, eta_date, eta_text, tracking_number, order_url, tracking_url, image_url,
                   subject, last_email_date, updated_at, pickup_store, pickup_time, delivery_time, carrier, status_source, status_updated_at)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (account_id, parsed.order_number, parsed.order_type, parsed.item_summary, parsed.qty, parsed.address,
                 parsed.status, parsed.total, parsed.alias_emails, parsed.order_date, parsed.eta_date, parsed.eta_text,
                 parsed.tracking_number, parsed.order_url, parsed.tracking_url, parsed.image_url, parsed.subject,
                 parsed.email_date, now, parsed.pickup_store, parsed.pickup_time, parsed.delivery_time, parsed.carrier, "Apple Email", parsed.email_date),
            )
        else:
            new_is_newer = parsed.email_date >= (existing["last_email_date"] or "")
            self.conn.execute(
                """UPDATE orders SET order_type=?, item_summary=?, qty=?, address=?, total=?, alias_emails=?, order_date=?,
                   eta_date=?, eta_text=?, tracking_number=?, order_url=?, tracking_url=?, image_url=?, subject=?,
                   last_email_date=?, updated_at=? WHERE id=?""",
                ("Pickup" if (parsed.order_type or "").lower() == "pickup" or (existing["order_type"] or "").lower() == "pickup" else "Shipping", self._merge_piped(existing["item_summary"], parsed.item_summary),
                 max(int(existing["qty"] or 1), int(parsed.qty or 1)), parsed.address or existing["address"],
                 parsed.total or existing["total"], ", ".join(dict.fromkeys(exact_aliases(existing["alias_emails"] or "") + exact_aliases(parsed.alias_emails or ""))),
                 existing["order_date"] or parsed.order_date,
                 parsed.eta_date if (parsed.eta_date and (new_is_newer or not existing["eta_date"])) else existing["eta_date"],
                 parsed.eta_text if (parsed.eta_text and (new_is_newer or not existing["eta_text"])) else existing["eta_text"],
                 self._merge_csv(existing["tracking_number"], parsed.tracking_number),
                 best_apple_order_url(existing["order_url"], parsed.order_url, parsed.order_number),
                 parsed.tracking_url or existing["tracking_url"], parsed.image_url or existing["image_url"],
                 parsed.subject or existing["subject"], max(existing["last_email_date"] or "", parsed.email_date), now, existing["id"]),
            )
        self._apply_parsed_metadata(account_id, parsed)
        self._merge_detected_qty(account_id, parsed.order_number, parsed.qty)
        self.recompute_order_status(account_id, parsed.order_number, commit=False)
        if commit:
            self.conn.commit()
        return True

    def recompute_order_status(self, account_id: int, order_number: str, commit: bool = True):
        order = self.conn.execute(
            "SELECT * FROM orders WHERE account_id=? AND order_number=?", (account_id, order_number)
        ).fetchone()
        if not order:
            return
        events = self.conn.execute(
            """SELECT event_status, email_date FROM email_events WHERE account_id=? AND order_number=?
               ORDER BY email_date ASC, id ASC""", (account_id, order_number)
        ).fetchall()
        status = "Unknown"
        status_date = ""
        for event in events:
            before = status
            status = advance_status(status, event["event_status"] or "Unknown", order["order_type"] or "")
            if status != before:
                status_date = event["email_date"] or status_date
        source = "Apple Email" if status != "Unknown" else ""

        # Persisted Apple Order Status checks are another authoritative signal,
        # especially for pickup orders that have no carrier scan. Re-applying it
        # here prevents a restart from regressing to an older email status.
        astatus = clean_text(order["apple_status"] or "")
        if astatus:
            before_apple = status
            status = advance_status(status, astatus, order["order_type"] or "")
            if status != before_apple:
                source = "Apple Order Status"
                status_date = order["apple_checked_at"] or status_date

        tstatus = clean_text(order["tracking_status"] or "")
        if (order["order_type"] or "").lower() == "shipping" and tstatus:
            known = set(UPS_STATES) | {"Delivered", "Canceled", "Shipped"}
            if tstatus in known:
                return_evidence = tstatus in RETURN_STATES or tstatus == "Mixed Shipments"
                if status not in ("Canceled", "Refunded") and (return_evidence or status not in ("Delivered", "Picked Up") or tstatus == "Delivered"):
                    status = tstatus
                    source = "UPS API" if order["tracking_success_at"] or (order["carrier"] or "").upper() == "UPS" else (order["carrier"] or "Carrier")
                    status_date = order["tracking_event_at"] or order["tracking_success_at"] or order["tracking_checked_at"] or status_date
                    if status == "Delivered":
                        status_date = order["tracking_delivered_at"] or status_date
        if status == "Unknown":
            status = clean_text(order["detected_status"] or "") or "Unknown"

        # Authenticated Apple observations are second only to active manual input.
        # Failed attempts never clear this last successful observation.
        if order['account_status'] and order['account_status_success_at']:
            status = order['account_status']
            source = 'Apple Account'
            status_date = order['account_status_event_at'] or order['account_status_success_at']
        detected_status = status
        manual_status = clean_text(order["manual_status"] or "")
        if manual_status:
            status = manual_status
            source = "Manual Override"
            status_date = order["manual_override_updated_at"] or status_date

        self.conn.execute(
            "UPDATE orders SET status=?, detected_status=?, status_source=?, status_updated_at=? WHERE id=?",
            (status, detected_status, source, status_date or order["last_email_date"] or datetime.now().astimezone().isoformat(), order["id"]),
        )
        if commit:
            self.conn.commit()

    def recompute_all_statuses(self):
        rows = self.conn.execute("SELECT account_id, order_number FROM orders").fetchall()
        for row in rows:
            self.recompute_order_status(int(row["account_id"]), row["order_number"], commit=False)
        if rows:
            self.conn.commit()

    def tracking_candidates(self, max_age_minutes: int = 20, start_date: str = "", end_date: str = "", force: bool = False):
        cutoff = (datetime.now().astimezone() - timedelta(minutes=max_age_minutes)).isoformat()
        sql = """SELECT o.*, a.email AS source_email FROM visible_orders o JOIN accounts a ON a.id=o.account_id
                 WHERE COALESCE(o.tracking_number,'')<>''
                   AND lower(COALESCE(o.order_type,''))='shipping'
                   AND COALESCE(o.status,'') NOT IN ('Delivered','Picked Up','Canceled','Refunded','Returned to Sender')"""
        params: list[object] = []
        if start_date:
            sql += " AND substr(COALESCE(o.order_date,''),1,10)>=?"
            params.append(start_date)
        if end_date:
            sql += " AND substr(COALESCE(o.order_date,''),1,10)<=?"
            params.append(end_date)
        if not force:
            sql += " AND (COALESCE(o.tracking_checked_at,'')='' OR o.tracking_checked_at<?)"
            params.append(cutoff)
        sql += " ORDER BY COALESCE(o.order_date,'') DESC, o.id DESC"
        return self.conn.execute(sql, params).fetchall()

    def apple_web_candidates(self, limit: int = 250, max_age_minutes: int = 20, start_date: str = "", end_date: str = "", force: bool = False):
        # Pickup orders have no carrier scan, so Apple Order Status is the secondary signal.
        # The check remains conservative: if Apple requires authentication or does not expose
        # a clear status, the existing email-derived status is left unchanged.
        cutoff = (datetime.now().astimezone() - timedelta(minutes=max_age_minutes)).isoformat()
        sql = """SELECT o.*, a.email AS source_email FROM visible_orders o JOIN accounts a ON a.id=o.account_id
                 WHERE lower(COALESCE(o.order_type,''))='pickup'
                   AND COALESCE(o.status,'')='Ready for Pickup'"""
        params: list[object] = []
        if start_date:
            sql += " AND substr(COALESCE(o.order_date,''),1,10)>=?"
            params.append(start_date)
        if end_date:
            sql += " AND substr(COALESCE(o.order_date,''),1,10)<=?"
            params.append(end_date)
        if not force:
            sql += " AND (COALESCE(o.apple_checked_at,'')='' OR o.apple_checked_at<?)"
            params.append(cutoff)
        sql += """ ORDER BY CASE WHEN COALESCE(o.apple_checked_at,'')='' THEN 0 ELSE 1 END,
                          COALESCE(o.apple_checked_at,''), COALESCE(o.updated_at,'') DESC
                   LIMIT ?"""
        params.append(int(limit))
        return self.conn.execute(sql, params).fetchall()

    def mark_apple_web_checked(self, order_id: int, status: str = "", detail: str = "", resolved_url: str = ""):
        now = datetime.now().astimezone().isoformat()
        row = self.conn.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
        if not row:
            return
        resolved = best_apple_order_url(row["order_url"], resolved_url, row["order_number"]) if resolved_url else row["order_url"]
        if status:
            self.conn.execute(
                "UPDATE orders SET apple_checked_at=?, apple_status=?, apple_status_detail=?, order_url=? WHERE id=?",
                (now, status, detail, resolved, order_id),
            )
        else:
            self.conn.execute("UPDATE orders SET apple_checked_at=?, order_url=? WHERE id=?", (now, resolved, order_id))
        self.recompute_order_status(int(row["account_id"]), row["order_number"], commit=False)
        self.conn.commit()

    def apply_apple_web_status(self, order_id: int, status: str, detail: str = "", commit: bool = True):
        # Compatibility helper for any direct caller. The durable source-of-truth
        # is apple_status; recompute_order_status resolves it against email/carrier
        # evidence so the order still has exactly one current status.
        now = datetime.now().astimezone().isoformat()
        row = self.conn.execute("SELECT account_id, order_number FROM orders WHERE id=?", (order_id,)).fetchone()
        if not row or status == "Unknown":
            return
        self.conn.execute(
            "UPDATE orders SET apple_checked_at=?, apple_status=?, apple_status_detail=? WHERE id=?",
            (now, status, detail, order_id),
        )
        self.recompute_order_status(int(row["account_id"]), row["order_number"], commit=False)
        if commit:
            self.conn.commit()

    @staticmethod
    def _merge_csv(old: str | None, new: str | None) -> str:
        parts: list[str] = []
        seen: set[str] = set()
        for source in (old or "", new or ""):
            for part in source.split(","):
                v = clean_text(part)
                if v and v.lower() not in seen:
                    seen.add(v.lower())
                    parts.append(v)
        return ", ".join(parts)

    @staticmethod
    def _merge_piped(old: str | None, new: str | None) -> str:
        parts: list[str] = []
        seen: set[str] = set()
        for source in (old or "", new or ""):
            for part in source.split("|"):
                v = clean_text(part)
                if v and v.lower() not in seen:
                    seen.add(v.lower())
                    parts.append(v)
        # Generic follow-up emails can parse as "Apple order". Once we already
        # know the real product, do not let that placeholder clutter the item name.
        real = [v for v in parts if v.lower() not in {"apple order", "order"}]
        if real:
            parts = real
        return " | ".join(parts)

    def apply_tracking_result(self, order_id: int, status: str, detail: str = "", delivered_at: str = "",
                              eta_date: str = "", delivery_time: str = "", commit: bool = True):
        """Persist one carrier check, then recompute the order's single authoritative status."""
        now = datetime.now().astimezone().isoformat()
        row = self.conn.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
        if not row:
            return
        delivered = clean_text(delivered_at) or (row["tracking_delivered_at"] or "")
        if status == "Delivered" and not delivered:
            delivered = now
        new_eta = clean_text(eta_date) or row["eta_date"] or ""
        new_delivery_time = clean_text(delivery_time) or row["delivery_time"] or ""
        self.conn.execute(
            """UPDATE orders SET tracking_status=?, tracking_detail=?, tracking_checked_at=?,
               tracking_delivered_at=?, eta_date=?, delivery_time=?, updated_at=? WHERE id=?""",
            (clean_text(status), clean_text(detail), now, delivered, new_eta, new_delivery_time, now, order_id),
        )
        self.recompute_order_status(int(row["account_id"]), row["order_number"], commit=False)
        if commit:
            self.conn.commit()

    def query_orders(self, status_filter: str = "All Orders", search: str = "", start_date: str = "", end_date: str = ""):
        sql = """
            SELECT o.*, a.email AS source_email
            FROM visible_orders o JOIN accounts a ON a.id=o.account_id
            WHERE 1=1
        """
        params: list[object] = []
        if start_date:
            sql += " AND substr(COALESCE(o.order_date,''),1,10)>=?"
            params.append(start_date)
        if end_date:
            sql += " AND substr(COALESCE(o.order_date,''),1,10)<=?"
            params.append(end_date)
        if status_filter == "Active":
            sql += " AND COALESCE(o.status,'') NOT IN ('Delivered','Picked Up','Canceled','Refunded','Returned to Sender')"
        elif status_filter == "Pickup Processing":
            sql += " AND lower(COALESCE(o.order_type,''))='pickup' AND COALESCE(o.status,'') NOT IN ('Picked Up','Delivered','Canceled','Refunded','Returned to Sender')"
        elif status_filter != "All Orders":
            sql += " AND o.status=?"
            params.append(status_filter)
        if search.strip():
            needle = "%" + search.strip().lower() + "%"
            sql += """ AND (
                lower(o.order_number) LIKE ? OR lower(o.item_summary) LIKE ? OR lower(o.address) LIKE ? OR
                lower(o.tracking_number) LIKE ? OR lower(o.alias_emails) LIKE ? OR lower(a.email) LIKE ? OR
                lower(o.status) LIKE ? OR lower(o.order_type) LIKE ? OR lower(COALESCE(o.pickup_store,'')) LIKE ?
            )"""
            params.extend([needle] * 9)
        sql += " ORDER BY COALESCE(o.order_date, '') DESC, o.id DESC"
        return self.conn.execute(sql, params).fetchall()

    def order_by_id(self, order_id: int):
        return self.conn.execute(
            "SELECT o.*, a.email AS source_email FROM orders o JOIN accounts a ON a.id=o.account_id WHERE o.id=?",
            (order_id,),
        ).fetchone()

    def tab_counts(self, start_date: str = "", end_date: str = "") -> dict[str, int]:
        sql = "SELECT COALESCE(status,'Unknown') AS status, COUNT(*) AS c FROM visible_orders WHERE 1=1"
        params: list[object] = []
        if start_date:
            sql += " AND substr(COALESCE(order_date,''),1,10)>=?"
            params.append(start_date)
        if end_date:
            sql += " AND substr(COALESCE(order_date,''),1,10)<=?"
            params.append(end_date)
        sql += " GROUP BY status"
        rows = self.conn.execute(sql, params).fetchall()
        d = {r["status"]: int(r["c"]) for r in rows}
        total = sum(d.values())
        active = total - sum(d.get(st, 0) for st in ("Delivered", "Picked Up", "Canceled", "Refunded", "Returned to Sender"))
        result = {"All Orders": total, "Active": active}
        for status in STATUS_ORDER:
            result[status] = d.get(status, 0)
        pickup_sql = "SELECT COUNT(*) FROM visible_orders WHERE lower(COALESCE(order_type,''))='pickup' AND COALESCE(status,'') NOT IN ('Picked Up','Delivered','Canceled','Refunded','Returned to Sender')"
        pickup_params: list[object] = []
        if start_date:
            pickup_sql += " AND substr(COALESCE(order_date,''),1,10)>=?"
            pickup_params.append(start_date)
        if end_date:
            pickup_sql += " AND substr(COALESCE(order_date,''),1,10)<=?"
            pickup_params.append(end_date)
        result["Pickup Processing"] = int(self.conn.execute(pickup_sql, pickup_params).fetchone()[0])
        return result

    def counts(self, start_date: str = "", end_date: str = "") -> dict[str, int]:
        d = self.tab_counts(start_date, end_date)
        today = date.today().isoformat()
        sql = """SELECT COUNT(*) FROM visible_orders WHERE eta_date=?
                 AND COALESCE(status,'') NOT IN ('Delivered','Picked Up','Canceled','Refunded','Returned to Sender','Returning to Sender','Mixed Shipments')"""
        params: list[object] = [today]
        if start_date:
            sql += " AND substr(COALESCE(order_date,''),1,10)>=?"
            params.append(start_date)
        if end_date:
            sql += " AND substr(COALESCE(order_date,''),1,10)<=?"
            params.append(end_date)
        arriving_today = self.conn.execute(sql, params).fetchone()[0]
        return {
            "All": d.get("All Orders", 0),
            "Active": d.get("Active", 0),
            "Processing": d.get("Processing", 0),
            "Action Required": d.get("Action Required", 0),
            "Shipped": d.get("Shipped", 0),
            "Pickup Ready": d.get("Ready for Pickup", 0),
            "Delivered": d.get("Delivered", 0),
            "Arriving Today": int(arriving_today),
        }

    def upcoming_deliveries(self, days: int = 45, start_date: str = "", end_date: str = ""):
        today = date.today()
        future_end = (today + timedelta(days=days)).isoformat()
        sql = """
            SELECT eta_date, COALESCE(order_type,'Unknown') AS order_type,
                   COUNT(*) AS order_count, COALESCE(SUM(qty),0) AS item_count
            FROM visible_orders
            WHERE eta_date>=? AND eta_date<=?
              AND COALESCE(status,'') NOT IN ('Delivered','Picked Up','Canceled','Refunded','Returned to Sender','Returning to Sender','Mixed Shipments')
        """
        params: list[object] = [today.isoformat(), future_end]
        if start_date:
            sql += " AND substr(COALESCE(order_date,''),1,10)>=?"
            params.append(start_date)
        if end_date:
            sql += " AND substr(COALESCE(order_date,''),1,10)<=?"
            params.append(end_date)
        sql += " GROUP BY eta_date, COALESCE(order_type,'Unknown') ORDER BY eta_date, order_type"
        return self.conn.execute(sql, params).fetchall()

    def activity_days(self, start_date: str, end_date: str):
        return self.conn.execute("""SELECT activity_date,
            CASE WHEN activity_label='Scheduled Pickup' THEN 'Pickup'
                 WHEN activity_label='Scheduled Delivery' THEN 'Shipping' ELSE activity_label END AS kind,
            COUNT(*) AS order_count,COALESCE(SUM(qty),0) AS item_count
            FROM tracker_calendar_activity WHERE activity_date BETWEEN ? AND ?
            GROUP BY activity_date,activity_label ORDER BY activity_date,kind""",(start_date,end_date)).fetchall()

    def orders_for_activity_date(self, selected_date: str):
        return self.conn.execute("""SELECT c.*,a.email AS source_email FROM tracker_calendar_activity c
            JOIN accounts a ON a.id=c.account_id WHERE c.activity_date=?
            ORDER BY CASE WHEN lower(c.order_type)='pickup' THEN 0 ELSE 1 END,c.eta_date,c.order_date,c.id""",(selected_date,)).fetchall()

    def orders_by_ids(self, order_ids: Iterable[int]):
        ids = [int(x) for x in order_ids]
        if not ids:
            return []
        marks = ",".join("?" for _ in ids)
        return self.conn.execute(
            f"SELECT o.*, a.email AS source_email FROM visible_orders o JOIN accounts a ON a.id=o.account_id WHERE o.id IN ({marks}) ORDER BY COALESCE(o.order_date,'') DESC, o.id DESC",
            ids,
        ).fetchall()

    def orders_for_order_date(self, selected_date: str, start_date: str = "", end_date: str = ""):
        sql = """SELECT o.*, a.email AS source_email FROM visible_orders o JOIN accounts a ON a.id=o.account_id
                 WHERE substr(COALESCE(o.order_date,''),1,10)=?"""
        params: list[object] = [selected_date]
        if start_date:
            sql += " AND substr(COALESCE(o.order_date,''),1,10)>=?"; params.append(start_date)
        if end_date:
            sql += " AND substr(COALESCE(o.order_date,''),1,10)<=?"; params.append(end_date)
        sql += " ORDER BY o.id DESC"
        return self.conn.execute(sql, params).fetchall()

    def release_summaries(self, start_date: str = "", end_date: str = "", include_archived: bool = False):
        sql = """SELECT substr(COALESCE(order_date,''),1,10) AS order_day,
                        COUNT(*) AS order_count,
                        COALESCE(SUM(qty),0) AS item_count,
                        COALESCE(SUM(CASE WHEN status IN ('Delivered','Picked Up') THEN 1 ELSE 0 END),0) AS completed_count,
                        COALESCE(SUM(CAST(REPLACE(REPLACE(REPLACE(COALESCE(total,'0'),'$',''),',',''),' ','') AS REAL)),0) AS spent,
                        GROUP_CONCAT(DISTINCT CASE WHEN COALESCE(image_url,'')<>'' THEN image_url END) AS images
                 FROM orders WHERE substr(COALESCE(order_date,''),1,10)<>''"""
        params: list[object] = []
        if start_date:
            sql += " AND substr(COALESCE(order_date,''),1,10)>=?"; params.append(start_date)
        if end_date:
            sql += " AND substr(COALESCE(order_date,''),1,10)<=?"; params.append(end_date)
        sql += " GROUP BY order_day ORDER BY order_day DESC"
        archived = self.archived_order_days()
        out = []
        for raw in self.conn.execute(sql, params).fetchall():
            item = dict(raw)
            item["archived"] = 1 if item.get("order_day") in archived else 0
            if include_archived or not item["archived"]:
                out.append(item)
        return out

    def tracking_rows(self, search: str = "", carrier: str = "", status: str = "", start_date: str = "", end_date: str = ""):
        sql = """SELECT o.*, a.email AS source_email FROM visible_orders o JOIN accounts a ON a.id=o.account_id
                 WHERE COALESCE(o.tracking_number,'')<>''
                   AND lower(COALESCE(o.order_type,''))='shipping'
                   AND COALESCE(o.status,'') NOT IN ('Delivered','Picked Up','Canceled','Refunded','Returned to Sender')"""
        params: list[object] = []
        if start_date:
            sql += " AND substr(COALESCE(o.order_date,''),1,10)>=?"; params.append(start_date)
        if end_date:
            sql += " AND substr(COALESCE(o.order_date,''),1,10)<=?"; params.append(end_date)
        if carrier and carrier != "All Carriers":
            sql += " AND lower(COALESCE(o.carrier,''))=?"; params.append(carrier.lower())
        if status and status != "All Statuses":
            if status == "Active":
                pass
            else:
                sql += " AND o.status=?"; params.append(status)
        if search.strip():
            needle = "%" + search.strip().lower() + "%"
            sql += """ AND (lower(o.order_number) LIKE ? OR lower(o.tracking_number) LIKE ? OR lower(COALESCE(o.carrier,'')) LIKE ? OR lower(COALESCE(o.item_summary,'')) LIKE ? OR lower(COALESCE(o.address,'')) LIKE ?)"""
            params.extend([needle, needle, needle, needle, needle])
        sql += " ORDER BY COALESCE(o.eta_date,'') DESC, COALESCE(o.order_date,'') DESC, o.id DESC"
        return self.conn.execute(sql, params).fetchall()

    def pickup_tracking_rows(self, search: str = "", start_date: str = "", end_date: str = ""):
        sql = """SELECT o.*, a.email AS source_email FROM visible_orders o JOIN accounts a ON a.id=o.account_id
                 WHERE lower(COALESCE(o.order_type,''))='pickup'
                   AND COALESCE(o.status,'') NOT IN ('Picked Up','Delivered','Canceled','Refunded','Returned to Sender')"""
        params: list[object] = []
        if start_date:
            sql += " AND substr(COALESCE(o.order_date,''),1,10)>=?"; params.append(start_date)
        if end_date:
            sql += " AND substr(COALESCE(o.order_date,''),1,10)<=?"; params.append(end_date)
        if search.strip():
            needle = "%" + search.strip().lower() + "%"
            sql += """ AND (lower(o.order_number) LIKE ? OR lower(COALESCE(o.item_summary,'')) LIKE ? OR
                       lower(COALESCE(o.pickup_store,'')) LIKE ? OR lower(COALESCE(o.alias_emails,'')) LIKE ?)"""
            params.extend([needle, needle, needle, needle])
        sql += " ORDER BY COALESCE(o.eta_date,'') ASC, COALESCE(o.order_date,'') DESC, o.id DESC"
        return self.conn.execute(sql, params).fetchall()

    def archived_order_days(self) -> set[str]:
        return {str(r[0]) for r in self.conn.execute("SELECT order_day FROM archived_order_dates").fetchall()}

    def archive_order_day(self, order_day: str):
        value = clean_text(order_day)
        if not value:
            return
        self.conn.execute("INSERT OR REPLACE INTO archived_order_dates(order_day, archived_at) VALUES(?,?)",
                          (value, datetime.now().astimezone().isoformat()))
        self.conn.commit()

    def restore_order_day(self, order_day: str):
        self.conn.execute("DELETE FROM archived_order_dates WHERE order_day=?", (clean_text(order_day),))
        self.conn.commit()

    def order_cache_rebuild_block_reason(self) -> str:
        has_apple_state = self.conn.execute("""
            SELECT EXISTS(SELECT 1 FROM apple_tasks)
                OR EXISTS(SELECT 1 FROM apple_phone_verification)
                OR EXISTS(SELECT 1 FROM apple_observations)
                OR EXISTS(SELECT 1 FROM apple_audit a JOIN orders o ON o.id=a.order_id)
                OR EXISTS(SELECT 1 FROM orders WHERE COALESCE(account_status_seq,0)>0
                    OR COALESCE(account_status,'')<>'' OR COALESCE(account_status_attempt_at,'')<>''
                    OR COALESCE(association_state,'')<>'' OR COALESCE(linked_apple_connection,'')<>'')
            """).fetchone()[0]
        if has_apple_state:
            return ("Rebuild Cache is unavailable because these orders have saved Apple jobs, "
                    "phone verification, or account history. Rebuilding would erase that history, "
                    "including actions whose outcome still needs verification.\n\n"
                    "Use Full Account Sync or Refresh Details to refresh orders while preserving saved data.")
        return ""

    def reset_order_cache(self):
        with self.conn:
            # Reserve the writer before checking. Another connection must not add
            # durable Apple state between this check and the cascading deletes.
            if not self.conn.in_transaction:
                self.conn.execute("BEGIN IMMEDIATE")
            reason = self.order_cache_rebuild_block_reason()
            if reason:
                raise ValueError(reason)
            self.conn.execute("DELETE FROM email_events")
            self.conn.execute("DELETE FROM orders")
            self.conn.execute("DELETE FROM sync_failures")
            self.conn.execute("UPDATE accounts SET last_uid=0, spam_last_uid=0, trash_last_uid=0, cancel_recovery_done=0, cancel_recovery_version=0")

    def history(self, account_id: int, order_number: str):
        return self.conn.execute(
            """SELECT * FROM email_events WHERE account_id=? AND order_number=?
               ORDER BY email_date DESC, id DESC""",
            (account_id, order_number),
        ).fetchall()

    def is_order_visible(self, order_id: int) -> bool:
        return self.conn.execute("SELECT 1 FROM visible_orders WHERE id=?", (int(order_id),)).fetchone() is not None

    def save_ups_package(self, order_id: int, tracking: str, result=None, error: str = ""):
        if not self.is_order_visible(order_id):
            return
        now = datetime.now(timezone.utc).isoformat()
        if result is not None:
            payload = result.as_dict() if isinstance(result, UPSResult) else dict(result)
            checked = payload.get("checked_at") or now
            self.conn.execute("""INSERT INTO ups_package_state(order_id,tracking_number,payload_json,checked_at,success_at,error)
                VALUES(?,?,?,?,?,'') ON CONFLICT(order_id,tracking_number) DO UPDATE SET
                payload_json=excluded.payload_json,checked_at=excluded.checked_at,success_at=excluded.success_at,error=''""",
                (int(order_id), tracking.upper(), json.dumps(payload, ensure_ascii=False), checked, checked))
        else:
            self.conn.execute("""INSERT INTO ups_package_state(order_id,tracking_number,checked_at,error)
                VALUES(?,?,?,?) ON CONFLICT(order_id,tracking_number) DO UPDATE SET
                checked_at=excluded.checked_at,error=excluded.error""", (int(order_id),tracking.upper(),now,str(error)))
        self.conn.commit()

    def ups_package_results(self, order_id: int):
        out = {}
        for row in self.conn.execute("SELECT * FROM ups_package_state WHERE order_id=? ORDER BY tracking_number", (int(order_id),)):
            try: value = json.loads(row["payload_json"] or "{}")
            except (ValueError, TypeError): value = {}
            value.update(error=row["error"], success_at=row["success_at"], last_attempt=row["checked_at"])
            out[row["tracking_number"]] = value
        return out

    def refresh_ups_aggregate(self, order_id: int):
        row = self.order_by_id(order_id)
        if not row or not self.is_order_visible(order_id): return False
        expected = split_tracking_numbers(row["tracking_number"] or "")
        results = self.ups_package_results(order_id)
        state, details, delivered, eta, window = aggregate_results(expected, results)
        latest = max((r.get("last_attempt", "") for r in results.values()), default="")
        successful = max((r.get("success_at", "") for r in results.values() if r.get("status")), default="")
        errors = "\n".join(f"{n}: {r['error']}" for n,r in results.items() if r.get("error"))
        event_at = max((r.get("event_at", "") for r in results.values()), default="")
        returned = max((r.get("returned_at", "") for r in results.values()), default="")
        new_state = state or row["tracking_status"] or ""
        prior = row["status"]
        old_delivered = row["tracking_delivered_at"] or ""
        if new_state in RETURN_STATES or new_state == "Mixed Shipments": old_delivered = ""
        self.conn.execute("""UPDATE orders SET tracking_status=?,tracking_detail=?,tracking_checked_at=?,
            tracking_success_at=?,tracking_error=?,tracking_event_at=?,tracking_delivered_at=?,tracking_returned_at=?,
            eta_date=?,delivery_time=?,updated_at=? WHERE id=?""",
            (new_state, details or row["tracking_detail"] or "", latest, successful, errors, event_at,
             delivered or old_delivered, returned, eta or row["eta_date"] or "", window or row["delivery_time"] or "", latest, int(order_id)))
        self.recompute_order_status(int(row["account_id"]),row["order_number"],commit=False)
        self.conn.commit()
        return self.order_by_id(order_id)["status"] != prior


class GmailIMAPClient:
    """Gmail IMAP helper optimized for long, resumable syncs.

    The client deliberately keeps server operations narrow: one Gmail sender search
    is attempted first, and plain IMAP sender searches are used only as a fallback.
    Network/protocol failures are surfaced to SyncWorker so it can reconnect and
    continue instead of aborting the whole account.
    """

    SOCKET_TIMEOUT = 90

    def __init__(self, email: str, password: str, server: str, port: int):
        self.email = email
        self.password = password.replace(" ", "")
        self.server = server
        self.port = port
        self.imap: Optional[imaplib.IMAP4_SSL] = None
        self.primary_mailbox = "INBOX"
        self._mailboxes: dict[str, str] = {}

    @staticmethod
    def _server_text(data) -> str:
        parts: list[str] = []
        for item in data or []:
            if isinstance(item, bytes):
                parts.append(item.decode(errors="ignore"))
            elif isinstance(item, tuple):
                parts.extend(GmailIMAPClient._server_text(item))
            elif item is not None:
                parts.append(str(item))
        return " ".join(parts).strip()

    def connect(self):
        self.close()
        self.imap = imaplib.IMAP4_SSL(self.server, self.port, timeout=self.SOCKET_TIMEOUT)
        self.imap.login(self.email, self.password)
        self._mailboxes = self._discover_mailboxes()
        mailbox = self._mailboxes.get("All Mail") or "INBOX"
        status, data = self.imap.select(mailbox, readonly=True)
        if status != "OK" and mailbox != "INBOX":
            status, data = self.imap.select("INBOX", readonly=True)
            mailbox = "INBOX"
        if status != "OK":
            raise RuntimeError("Could not open Gmail All Mail or INBOX via IMAP: " + self._server_text(data))
        self.primary_mailbox = mailbox

    @staticmethod
    def _mailbox_name_from_list_line(text: str) -> str:
        m = re.search(r'"([^"]+)"\s*$', text)
        if m:
            return f'"{m.group(1)}"'
        return text.rsplit(" ", 1)[-1]

    def _discover_mailboxes(self) -> dict[str, str]:
        """Find Gmail's All Mail, Spam and Trash folders."""
        assert self.imap is not None
        found: dict[str, str] = {}
        status, boxes = self.imap.list()
        if status == "OK":
            for raw in boxes or []:
                text = raw.decode(errors="ignore") if isinstance(raw, bytes) else str(raw)
                name = self._mailbox_name_from_list_line(text)
                low = text.lower()
                if "\\all" in low:
                    found["All Mail"] = name
                elif "\\junk" in low or "\\spam" in low or "/spam" in low:
                    found["Spam"] = name
                elif "\\trash" in low or "/trash" in low:
                    found["Trash"] = name
        found.setdefault("All Mail", '"[Gmail]/All Mail"')
        found.setdefault("Spam", '"[Gmail]/Spam"')
        found.setdefault("Trash", '"[Gmail]/Trash"')
        return found

    def mailboxes_to_scan(self) -> list[tuple[str, str]]:
        boxes = getattr(self, "_mailboxes", {}) or {}
        out: list[tuple[str, str]] = []
        primary = boxes.get("All Mail") or getattr(self, "primary_mailbox", "INBOX")
        out.append(("All Mail" if primary != "INBOX" else "INBOX", primary))
        for label in ("Spam", "Trash"):
            mailbox = boxes.get(label)
            if mailbox and mailbox != primary:
                out.append((label, mailbox))
        return out

    def select_mailbox(self, mailbox: str) -> bool:
        assert self.imap is not None
        status, data = self.imap.select(mailbox, readonly=True)
        if status != "OK":
            raise RuntimeError(f"Could not select Gmail mailbox {mailbox}: {self._server_text(data)}")
        return True

    def _search_args(self, last_uid: int = 0, start_date: str = "", end_date: str = "") -> list[str]:
        args: list[str] = []
        if last_uid > 0:
            args += ["UID", f"{last_uid + 1}:*"]
        if start_date:
            try:
                args += ["SINCE", date.fromisoformat(start_date).strftime("%d-%b-%Y")]
            except Exception:
                pass
        if end_date:
            try:
                args += ["BEFORE", (date.fromisoformat(end_date) + timedelta(days=1)).strftime("%d-%b-%Y")]
            except Exception:
                pass
        return args

    def _gmail_raw_search(self, raw_query: str, last_uid: int = 0, start_date: str = "", end_date: str = "") -> tuple[bool, set[int]]:
        assert self.imap is not None
        args = self._search_args(last_uid, start_date, end_date)
        escaped = raw_query.replace("\\", "\\\\").replace('"', '\\"')
        args += ["X-GM-RAW", f'"{escaped}"']
        status, data = self.imap.uid("SEARCH", None, *args)
        if status != "OK":
            detail = self._server_text(data)
            low = detail.lower()
            if any(x in low for x in ("overquota", "bandwidth limit", "rate limit", "temporarily unavailable")):
                raise RuntimeError("Gmail SEARCH failed: " + detail)
            return False, set()
        return True, {int(x) for x in (data[0] or b"").split() if x.isdigit()}

    def search_apple_uids_checked(self, last_uid: int = 0, start_date: str = "", end_date: str = "") -> tuple[bool, list[int]]:
        """Find Apple transactional mail with very few IMAP commands.

        Gmail X-GM-RAW is the fast path. A plain IMAP sender fallback is used only
        when the Gmail search returns no results. The parser remains responsible for
        rejecting Apple marketing/non-order messages.
        """
        assert self.imap is not None
        query = "from:(orders.apple.com OR email.apple.com)"
        ok, found = self._gmail_raw_search(query, last_uid, start_date, end_date)
        if ok and found:
            return True, sorted(found)

        # Fallback only on an empty result. Three narrow searches are much cheaper
        # than running every search dialect for every mailbox on every sync.
        fallback: set[int] = set()
        any_ok = False
        for sender in ("orders.apple.com", "email.apple.com"):
            args = self._search_args(last_uid, start_date, end_date) + ["FROM", f'"{sender}"']
            status, data = self.imap.uid("SEARCH", None, *args)
            if status == "OK":
                any_ok = True
                fallback.update(int(x) for x in (data[0] or b"").split() if x.isdigit())
            else:
                detail = self._server_text(data)
                low = detail.lower()
                if any(x in low for x in ("overquota", "bandwidth limit", "rate limit", "temporarily unavailable")):
                    raise RuntimeError("Gmail sender SEARCH failed: " + detail)
                # Keep trying the other sender fallback. If none work, surface it.
                continue
        if not any_ok:
            raise RuntimeError("Gmail Apple-order sender search failed.")
        return True, sorted(fallback)

    def search_apple_uids(self, last_uid: int = 0, start_date: str = "", end_date: str = "") -> list[int]:
        ok, uids = self.search_apple_uids_checked(last_uid, start_date, end_date)
        if not ok:
            raise RuntimeError("Gmail IMAP Apple-order search failed; sync checkpoint was not advanced.")
        return uids

    def search_cancellation_uids(self) -> tuple[bool, list[int]]:
        """Compatibility helper retained for manual historical repair tools."""
        assert self.imap is not None
        found: set[int] = set()
        any_ok = False
        for query in (
            'from:noreply@email.apple.com subject:"Information about your order"',
            'from:email.apple.com subject:"Information about your order"',
        ):
            ok, uids = self._gmail_raw_search(query)
            any_ok = any_ok or ok
            found.update(uids)
        return any_ok, sorted(found) if any_ok else []

    def highest_uid(self, mailbox: str) -> int:
        """Return current highest UID without downloading bodies."""
        assert self.imap is not None
        status, data = self.imap.status(mailbox, "(UIDNEXT)")
        if status == "OK" and data:
            m = re.search(rb"UIDNEXT\s+(\d+)", data[0] or b"", re.I)
            if m:
                return max(0, int(m.group(1)) - 1)
        # STATUS is normally supported by Gmail. If unavailable, a UID SEARCH ALL
        # is a safe metadata-only fallback.
        status, data = self.imap.uid("SEARCH", None, "ALL")
        if status != "OK":
            raise RuntimeError("Could not read Gmail UID high-water mark: " + self._server_text(data))
        vals = [int(x) for x in (data[0] or b"").split() if x.isdigit()]
        return max(vals) if vals else 0

    @staticmethod
    def _uid_set(uids: list[int]) -> str:
        if not uids:
            return ""
        values = sorted(set(int(x) for x in uids if int(x) > 0))
        if not values:
            return ""
        pieces: list[str] = []
        start = prev = values[0]
        for uid in values[1:]:
            if uid == prev + 1:
                prev = uid
                continue
            pieces.append(str(start) if start == prev else f"{start}:{prev}")
            start = prev = uid
        pieces.append(str(start) if start == prev else f"{start}:{prev}")
        return ",".join(pieces)

    def fetch_many(self, uids: list[int]) -> dict[int, bytes]:
        """Batch-fetch messages.

        Missing/deleted UIDs are simply absent from the returned dict. SyncWorker
        records them for a later retry instead of letting one bad UID abort a 20k run.
        """
        assert self.imap is not None
        if not uids:
            return {}
        uid_set = self._uid_set(uids)
        status, data = self.imap.uid("FETCH", uid_set, "(UID BODY.PEEK[])")
        if status != "OK":
            raise RuntimeError("Gmail batch FETCH failed: " + self._server_text(data))
        results: dict[int, bytes] = {}
        requested = set(int(x) for x in uids)
        for part in data or []:
            if not (isinstance(part, tuple) and len(part) >= 2 and isinstance(part[1], (bytes, bytearray))):
                continue
            head = part[0] if isinstance(part[0], (bytes, bytearray)) else str(part[0]).encode()
            m = re.search(rb"\bUID\s+(\d+)\b", head)
            if not m:
                # Do not guess which message this belongs to. The missing UID will
                # be retried individually/queued by SyncWorker.
                continue
            uid = int(m.group(1))
            if uid in requested:
                results[uid] = bytes(part[1])
        return results

    def fetch(self, uid: int) -> bytes:
        assert self.imap is not None
        status, data = self.imap.uid("FETCH", str(int(uid)), "(UID BODY.PEEK[])")
        if status != "OK" or not data:
            raise RuntimeError(f"Could not fetch email UID {uid}: {self._server_text(data)}")
        for part in data:
            if isinstance(part, tuple) and isinstance(part[1], (bytes, bytearray)):
                head = part[0] if isinstance(part[0], (bytes, bytearray)) else str(part[0]).encode()
                m = re.search(rb"\bUID\s+(\d+)\b", head)
                if m and int(m.group(1)) != int(uid):
                    continue
                return bytes(part[1])
        raise RuntimeError(f"Email UID {uid} had no usable message body.")

    def close(self):
        if self.imap is not None:
            try:
                self.imap.logout()
            except Exception:
                pass
            self.imap = None


class SyncWorker(QThread):
    progress = Signal(int, int, str)
    failed = Signal(str)       # fatal startup/configuration error only
    notice = Signal(str)       # recoverable/non-fatal information
    all_done = Signal(int, int)

    BATCH_SIZE = 100
    INITIAL_RETRY_SECONDS = 15
    MAX_RETRY_SECONDS = 300

    def __init__(self, database_path: Path, refresh_all: bool = False, start_date: str = "", end_date: str = "", account_ids: Optional[list[int]] = None):
        super().__init__()
        self.database_path = database_path
        self.refresh_all = refresh_all
        self.start_date = clean_text(start_date)
        self.end_date = clean_text(end_date)
        self.account_ids = set(int(x) for x in (account_ids or []))
        self._stop_requested = False
        self.cancel_count = 0
        self.error_count = 0
        self.deferred_count = 0
        self.skipped_accounts: list[str] = []
        self.retry_count = 0

    def request_stop(self):
        self._stop_requested = True

    @staticmethod
    def _err_text(exc: BaseException) -> str:
        return clean_text(str(exc)) or exc.__class__.__name__

    @classmethod
    def _is_auth_error(cls, exc: BaseException) -> bool:
        low = cls._err_text(exc).lower()
        return any(x in low for x in (
            "authenticationfailed", "invalid credentials", "application-specific password required",
            "web login required", "invalid login", "login failed", "authentication failed",
        ))

    @classmethod
    def _is_quota_error(cls, exc: BaseException) -> bool:
        low = cls._err_text(exc).lower()
        return any(x in low for x in (
            "overquota", "bandwidth limits", "bandwidth limit", "too many commands",
            "rate limit", "rate-limit", "too many simultaneous", "temporarily unavailable",
        ))

    @classmethod
    def _is_permanent_message_error(cls, exc: BaseException) -> bool:
        low = cls._err_text(exc).lower()
        return any(x in low for x in (
            "had no usable message body", "had no message body", "message no longer exists",
            "no such message", "invalid uid", "uid not found",
        ))

    @classmethod
    def _is_retryable_network_error(cls, exc: BaseException) -> bool:
        if cls._is_quota_error(exc):
            return True
        if isinstance(exc, (imaplib.IMAP4.abort, socket.timeout, TimeoutError, ConnectionError, OSError, EOFError)):
            return True
        low = cls._err_text(exc).lower()
        return any(x in low for x in (
            "timed out", "timeout", "connection reset", "connection aborted", "connection closed",
            "socket error", "broken pipe", "eof", "server unexpectedly", "try again", "unavailable",
            "cannot read from timed out object", "imap4.abort",
        ))

    def _sleep_interruptible(self, seconds: int) -> bool:
        remaining = max(0, int(seconds))
        while remaining > 0 and not self._stop_requested:
            time.sleep(min(1, remaining))
            remaining -= 1
        return not self._stop_requested

    def _retry_delay(self, attempt: int, quota: bool = False) -> int:
        base = 60 if quota else self.INITIAL_RETRY_SECONDS
        return min(self.MAX_RETRY_SECONDS, base * (2 ** min(max(0, attempt - 1), 4)))

    def _reconnect(self, client: GmailIMAPClient, mailbox: str, email: str, reason: str, completed: int = 0, total: int = 0) -> bool:
        attempt = 0
        while not self._stop_requested:
            attempt += 1
            try:
                client.connect()
                if mailbox:
                    client.select_mailbox(mailbox)
                return True
            except Exception as exc:
                if self._is_auth_error(exc):
                    raise
                delay = self._retry_delay(attempt, self._is_quota_error(exc))
                self.retry_count += 1
                self.progress.emit(completed, total, f"{email}: Gmail connection interrupted ({self._err_text(exc)}). Waiting {delay}s, then continuing automatically…")
                if not self._sleep_interruptible(delay):
                    return False
        return False

    def _network_call(self, client: GmailIMAPClient, mailbox: str, email: str, description: str, func, completed: int = 0, total: int = 0):
        """Retry quota/timeouts forever (until user closes the app).

        This is intentionally resumable rather than fail-fast: Gmail OVERQUOTA and
        network timeouts pause the sync, reconnect, and continue at the same batch.
        """
        attempt = 0
        while not self._stop_requested:
            try:
                return func()
            except Exception as exc:
                if self._is_auth_error(exc):
                    raise
                if description.startswith("retrieving UID ") and self._is_permanent_message_error(exc):
                    raise
                retryable = self._is_retryable_network_error(exc) or isinstance(exc, imaplib.IMAP4.error)
                if not retryable:
                    # Unknown protocol/server errors still get a few reconnect attempts
                    # before being surfaced to the caller, which can skip just this item.
                    attempt += 1
                    if attempt > 3:
                        raise
                else:
                    attempt += 1
                quota = self._is_quota_error(exc)
                delay = self._retry_delay(attempt, quota)
                self.retry_count += 1
                kind = "Gmail command/bandwidth limit" if quota else "temporary Gmail/network error"
                self.progress.emit(completed, total, f"{email}: {kind} during {description}: {self._err_text(exc)}. Waiting {delay}s and continuing automatically…")
                if not self._sleep_interruptible(delay):
                    raise RuntimeError("Sync stopped by user")
                try:
                    client.close()
                except Exception:
                    pass
                if not self._reconnect(client, mailbox, email, description, completed, total):
                    raise RuntimeError("Sync stopped by user")
        raise RuntimeError("Sync stopped by user")

    def _baseline_new_only_account(self, db: Database, client: GmailIMAPClient, account, checkpoints: dict[str, int], email: str) -> dict[str, int]:
        """For a never-synced account, New Emails Only starts *now*.

        Historical import is explicit through Full Account Sync. This prevents a
        zero checkpoint from accidentally turning every normal Sync into a 20k rescan.
        """
        if any(int(v or 0) > 0 for v in checkpoints.values()):
            return checkpoints
        event_count = int(db.conn.execute("SELECT COUNT(*) FROM email_events WHERE account_id=?", (int(account["id"]),)).fetchone()[0] or 0)
        if event_count:
            # Legacy database with events but no checkpoint: use the largest known UID
            # as a conservative All Mail baseline, then establish Spam/Trash below.
            max_uid = int(db.conn.execute("SELECT MAX(uid) FROM email_events WHERE account_id=?", (int(account["id"]),)).fetchone()[0] or 0)
            checkpoints["All Mail"] = max_uid
            checkpoints["INBOX"] = max_uid
            return checkpoints

        self.progress.emit(0, 0, f"{email}: New Emails Only selected on a never-synced account — establishing a baseline now. Use Full Account Sync to import older orders.")
        for label, mailbox in client.mailboxes_to_scan():
            if self._stop_requested:
                break
            try:
                self._network_call(client, mailbox, email, f"selecting {label}", lambda m=mailbox: client.select_mailbox(m))
                high = int(self._network_call(client, mailbox, email, f"reading {label} UID baseline", lambda m=mailbox: client.highest_uid(m)) or 0)
            except Exception as exc:
                if self._is_auth_error(exc):
                    raise
                self.error_count += 1
                self.notice.emit(f"{email}: could not establish {label} baseline yet: {self._err_text(exc)}")
                continue
            checkpoints[label] = high
            db.set_mailbox_last_uid(int(account["id"]), label, high, commit=False)
        db.conn.commit()
        return checkpoints

    def run(self):
        db = Database(self.database_path)
        parser = AppleMailParser()
        total_processed = 0
        total_orders = 0
        try:
            accounts = [a for a in db.list_accounts() if a["enabled"]]
            if self.account_ids:
                accounts = [a for a in accounts if int(a["id"]) in self.account_ids]
            if not accounts:
                self.failed.emit("No selected Gmail IMAP account is configured.")
                return

            for account in accounts:
                if self._stop_requested:
                    break
                email = account["email"]
                try:
                    password = keyring.get_password(APP_KEYRING_SERVICE, email)
                except Exception:
                    password = None
                if not password:
                    self.error_count += 1
                    self.skipped_accounts.append(email)
                    self.notice.emit(f"{email}: no saved Gmail App Password; account skipped while other accounts continue.")
                    continue

                client = GmailIMAPClient(email, password, account["server"], int(account["port"]))
                processed = 0
                orders = 0
                checkpoints = {
                    "All Mail": int(account["last_uid"] or 0),
                    "INBOX": int(account["last_uid"] or 0),
                    "Spam": int(account["spam_last_uid"] or 0),
                    "Trash": int(account["trash_last_uid"] or 0),
                }

                try:
                    scope = ""
                    if self.start_date or self.end_date:
                        scope = f" ({self.start_date or 'beginning'} through {self.end_date or 'today'})"
                    mode_text = "Full Account Sync" if self.refresh_all and not (self.start_date or self.end_date) else ("historical range refresh" if self.refresh_all else "New Emails Only")
                    self.progress.emit(0, 0, f"{email}: connecting for {mode_text}{scope}…")
                    self._network_call(client, "", email, "login", client.connect)

                    # Never silently reset checkpoints on normal sync. A zero checkpoint
                    # has explicit semantics: New Emails Only establishes a baseline;
                    # Full Account Sync scans history from UID 0.
                    if not self.refresh_all and not (self.start_date or self.end_date):
                        checkpoints = self._baseline_new_only_account(db, client, account, checkpoints, email)

                    mailbox_jobs: list[tuple[str, str, list[int], int, int]] = []
                    for label, mailbox in client.mailboxes_to_scan():
                        if self._stop_requested:
                            break
                        self._network_call(client, mailbox, email, f"selecting {label}", lambda m=mailbox: client.select_mailbox(m))
                        high = int(self._network_call(client, mailbox, email, f"reading {label} UID high-water mark", lambda m=mailbox: client.highest_uid(m)) or 0)
                        use_last_uid = 0 if self.refresh_all else int(checkpoints.get(label, 0) or 0)

                        # New Emails Only must never silently turn a zero per-mailbox
                        # checkpoint into a historical scan. Baseline that mailbox now.
                        if not self.refresh_all and use_last_uid == 0:
                            checkpoints[label] = high
                            db.set_mailbox_last_uid(int(account["id"]), label, high, commit=False)
                            db.conn.commit()
                            found_uids: list[int] = []
                        elif not self.refresh_all and use_last_uid >= high > 0:
                            found_uids = []
                        else:
                            result = self._network_call(
                                client, mailbox, email, f"searching {label}",
                                lambda last=use_last_uid: client.search_apple_uids_checked(last, self.start_date if self.refresh_all else "", self.end_date if self.refresh_all else ""),
                            )
                            search_ok, found_uids = result
                            if not search_ok:
                                raise RuntimeError(f"{label}: Gmail could not complete the Apple-order search")

                        # Retry deferred UIDs on normal/full syncs. A date-range Refresh
                        # Details stays scoped to the requested historical dates.
                        pending = [] if (self.refresh_all and (self.start_date or self.end_date)) else db.pending_sync_uids(int(account["id"]), label)
                        merged = sorted(set(int(x) for x in found_uids + pending if int(x) > 0))
                        mailbox_jobs.append((label, mailbox, merged, use_last_uid, high))

                    total = sum(len(job[2]) for job in mailbox_jobs)
                    completed = 0
                    if total == 0:
                        self.progress.emit(1, 1, f"{email}: no new Apple order emails to download")

                    for label, mailbox, uids, _use_last_uid, high in mailbox_jobs:
                        if self._stop_requested:
                            break
                        self._network_call(client, mailbox, email, f"selecting {label}", lambda m=mailbox: client.select_mailbox(m), completed, total)

                        for batch_start in range(0, len(uids), self.BATCH_SIZE):
                            if self._stop_requested:
                                break
                            batch = uids[batch_start: batch_start + self.BATCH_SIZE]
                            self.progress.emit(completed, total, f"{email}: {label} — downloading {completed + 1:,}-{min(total, completed + len(batch)):,} of {total:,}")

                            try:
                                messages = self._network_call(
                                    client, mailbox, email, f"downloading {label} batch",
                                    lambda b=batch: client.fetch_many(b), completed, total,
                                )
                            except Exception as exc:
                                if self._is_auth_error(exc):
                                    raise
                                # A weird non-retryable batch response should not kill the
                                # account. Fall back to individual UID fetches below.
                                self.error_count += 1
                                self.notice.emit(f"{email}: batch fetch problem in {label}; isolating messages individually: {self._err_text(exc)}")
                                messages = {}

                            db.conn.execute("BEGIN")
                            try:
                                for uid in batch:
                                    if self._stop_requested:
                                        break
                                    raw = messages.get(uid)
                                    if raw is None:
                                        # Isolate a missing/wrong UID. Temporary network or
                                        # quota failures keep retrying; truly missing messages
                                        # are queued and the rest of the sync continues.
                                        try:
                                            raw = self._network_call(
                                                client, mailbox, email, f"retrieving UID {uid}",
                                                lambda u=uid: client.fetch(u), completed, total,
                                            )
                                        except Exception as exc:
                                            if self._is_auth_error(exc):
                                                raise
                                            self.error_count += 1
                                            self.deferred_count += 1
                                            db.record_sync_failure(int(account["id"]), label, uid, self._err_text(exc), commit=False)
                                            continue

                                    processed += 1
                                    try:
                                        parsed = parser.parse(raw, email)
                                        # A sender-search candidate that is not actually an
                                        # Apple order is a successful scan, not an error.
                                        if not parsed:
                                            db.clear_sync_failure(int(account["id"]), label, uid, commit=False)
                                            continue
                                        if parsed.status == "Canceled":
                                            self.cancel_count += 1
                                        if self.refresh_all or self.start_date or self.end_date or label in ("Spam", "Trash"):
                                            if db.refresh_from_parsed(int(account["id"]), uid, parsed, commit=False):
                                                orders += 1
                                        elif db.save_update(int(account["id"]), uid, parsed, commit=False):
                                            orders += 1
                                        db.clear_sync_failure(int(account["id"]), label, uid, commit=False)
                                    except Exception as exc:
                                        self.error_count += 1
                                        self.deferred_count += 1
                                        db.record_sync_failure(int(account["id"]), label, uid, f"Parser/database: {self._err_text(exc)}", commit=False)

                                # Persist every completed batch immediately. If Gmail later
                                # throttles the connection or the app is closed, the next
                                # New Emails Only run resumes after this batch instead of
                                # starting again at message 1.
                                advance_checkpoint = not (self.refresh_all and (self.start_date or self.end_date))
                                if advance_checkpoint:
                                    batch_high = max(batch) if batch else int(checkpoints.get(label, 0) or 0)
                                    checkpoints[label] = max(int(checkpoints.get(label, 0) or 0), batch_high)
                                    db.set_mailbox_last_uid(int(account["id"]), label, checkpoints[label], commit=False)
                                db.conn.commit()
                            except Exception:
                                db.conn.rollback()
                                raise

                            completed += len(batch)
                            self.progress.emit(completed, total, f"{email}: scanned {completed:,}/{total:,} Apple email candidates; {orders:,} order updates imported")

                            # Tiny cooperative pause helps Gmail sustain very large runs
                            # without materially slowing normal incremental syncs.
                            if len(batch) >= self.BATCH_SIZE and not self._stop_requested:
                                time.sleep(0.05)

                        # Search covered the mailbox through `high`. Failed individual
                        # UIDs are in sync_failures, so advancing the checkpoint is safe:
                        # future New-only syncs fetch only newer mail plus that retry queue.
                        if not self._stop_requested and high > 0 and not (self.refresh_all and (self.start_date or self.end_date)):
                            checkpoints[label] = max(int(checkpoints.get(label, 0) or 0), high)
                            db.set_mailbox_last_uid(int(account["id"]), label, checkpoints[label], commit=False)
                            db.conn.commit()

                    total_processed += processed
                    total_orders += orders
                except Exception as exc:
                    if self._stop_requested:
                        break
                    self.error_count += 1
                    self.skipped_accounts.append(email)
                    if self._is_auth_error(exc):
                        self.notice.emit(f"{email}: Gmail authentication failed; this account was skipped while other accounts continue. Check its Google App Password.")
                    else:
                        # Only an unrecoverable account-level condition reaches here.
                        # Do not stop the global sync; continue with the next account.
                        self.notice.emit(f"{email}: account-level sync problem was isolated; other accounts continue: {self._err_text(exc)}")
                finally:
                    client.close()
        finally:
            try:
                selected_ids = [int(a["id"]) for a in accounts] if 'accounts' in locals() else []
                self.deferred_count = sum(db.sync_failure_count(aid) for aid in selected_ids)
            except Exception:
                pass
            db.close()
            self.all_done.emit(total_processed, total_orders)


class CarrierTracker:
    """Live status resolver.

    Preferred path: official carrier APIs when the user provides credentials.
    Fallback path: a normal public tracking-page request, then a local Chrome/Edge
    rendered-page read when available. The fallback deliberately does not rotate
    proxies or attempt to evade rate limits or anti-bot controls.
    """

    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36",
            "Accept-Language": "en-US,en;q=0.9",
        })
        retry = Retry(
            total=2,
            connect=2,
            read=2,
            status=2,
            backoff_factor=0.8,
            status_forcelist=(429, 500, 502, 503, 504),
            allowed_methods=frozenset({"GET", "POST"}),
            respect_retry_after_header=True,
        )
        adapter = HTTPAdapter(max_retries=retry, pool_connections=8, pool_maxsize=8)
        self.session.mount("https://", adapter)
        self.session.mount("http://", adapter)
        self._tokens: dict[str, tuple[str, float]] = {}
        self._last_host_request: dict[str, float] = {}
        self.browser_path = self._find_browser()

    @staticmethod
    def _credentials(prefix: str) -> tuple[str, str]:
        try:
            return (
                keyring.get_password(APP_KEYRING_SERVICE, f"{prefix}_client_id") or "",
                keyring.get_password(APP_KEYRING_SERVICE, f"{prefix}_client_secret") or "",
            )
        except Exception:
            return "", ""

    @staticmethod
    def _find_browser() -> str:
        candidates: list[str] = []
        for name in ("chrome", "chrome.exe", "msedge", "msedge.exe", "chromium", "chromium-browser"):
            found = shutil.which(name)
            if found:
                candidates.append(found)
        if sys.platform.startswith("win"):
            for base in (os.environ.get("PROGRAMFILES"), os.environ.get("PROGRAMFILES(X86)"), os.environ.get("LOCALAPPDATA")):
                if not base:
                    continue
                candidates.extend([
                    str(Path(base) / "Google/Chrome/Application/chrome.exe"),
                    str(Path(base) / "Microsoft/Edge/Application/msedge.exe"),
                ])
        for candidate in candidates:
            if candidate and Path(candidate).exists():
                return candidate
        return ""

    def _throttle(self, url: str, minimum_gap: float = 0.65):
        host = (urlparse(url).hostname or "").lower()
        if not host:
            return
        last = self._last_host_request.get(host, 0.0)
        wait = minimum_gap - (time.monotonic() - last)
        if wait > 0:
            time.sleep(wait)
        self._last_host_request[host] = time.monotonic()

    def _request(self, method: str, url: str, **kwargs):
        self._throttle(url)
        kwargs.setdefault("timeout", 22)
        return self.session.request(method, url, **kwargs)

    def _browser_text(self, url: str, timeout: int = 40) -> str:
        if not self.browser_path or not url.lower().startswith(("https://", "http://")):
            return ""
        profile_dir = app_data_dir() / "status_browser_profile"
        profile_dir.mkdir(parents=True, exist_ok=True)
        base_args = [
            "--disable-gpu",
            "--no-first-run",
            "--no-default-browser-check",
            "--disable-background-networking",
            "--disable-blink-features=AutomationControlled",
            "--window-size=1365,900",
            "--lang=en-US",
            f"--user-data-dir={profile_dir}",
            "--virtual-time-budget=18000",
            "--dump-dom",
            url,
        ]
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if sys.platform.startswith("win") else 0
        # Current Chrome/Edge use --headless=new. Keep the legacy switch as a
        # fallback so older installed browsers can still render Apple Order Status.
        for headless_flag in ("--headless=new", "--headless"):
            cmd = [self.browser_path, headless_flag, *base_args]
            try:
                proc = subprocess.run(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.DEVNULL,
                    text=True,
                    encoding="utf-8",
                    errors="ignore",
                    timeout=timeout,
                    creationflags=flags,
                )
                if proc.returncode == 0 and proc.stdout:
                    visible = clean_text(BeautifulSoup(proc.stdout, "html.parser").get_text(" "))
                    if visible:
                        return visible
            except Exception:
                continue
        return ""

    def _cached_token(self, key: str) -> str:
        token, expires = self._tokens.get(key, ("", 0.0))
        return token if token and time.time() < expires - 60 else ""

    def _store_token(self, key: str, token: str, ttl: int):
        self._tokens[key] = (token, time.time() + max(120, ttl))

    def _ups_access_token(self) -> str:
        cached = self._cached_token("ups")
        if cached:
            return cached
        client_id, client_secret = self._credentials("ups")
        if not client_id or not client_secret:
            return ""
        r = self._request(
            "POST", "https://onlinetools.ups.com/security/v1/oauth/token",
            auth=(client_id, client_secret), data={"grant_type": "client_credentials"},
        )
        r.raise_for_status()
        data = r.json(); token = str(data.get("access_token", "")); ttl = int(data.get("expires_in", 3600) or 3600)
        if token:
            self._store_token("ups", token, ttl)
        return token

    def _fedex_access_token(self) -> str:
        cached = self._cached_token("fedex")
        if cached:
            return cached
        client_id, client_secret = self._credentials("fedex")
        if not client_id or not client_secret:
            return ""
        r = self._request(
            "POST", "https://apis.fedex.com/oauth/token",
            data={"grant_type": "client_credentials", "client_id": client_id, "client_secret": client_secret},
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        r.raise_for_status()
        data = r.json(); token = str(data.get("access_token", "")); ttl = int(data.get("expires_in", 3600) or 3600)
        if token:
            self._store_token("fedex", token, ttl)
        return token

    def _usps_access_token(self) -> str:
        cached = self._cached_token("usps")
        if cached:
            return cached
        client_id, client_secret = self._credentials("usps")
        if not client_id or not client_secret:
            return ""
        r = self._request(
            "POST", "https://apis.usps.com/oauth2/v3/token",
            json={"grant_type": "client_credentials", "client_id": client_id, "client_secret": client_secret},
            headers={"Content-Type": "application/json", "Accept": "application/json"},
        )
        r.raise_for_status()
        data = r.json(); token = str(data.get("access_token", "")); ttl = int(data.get("expires_in", 28800) or 28800)
        if token:
            self._store_token("usps", token, ttl)
        return token

    @staticmethod
    def _classify_status(text: str) -> str:
        t = clean_text(text).lower()
        if not t:
            return ""
        if any(x in t for x in ("delivery attempted", "attempted delivery", "we missed you", "unable to deliver", "exception")):
            return "Exception"
        if any(x in t for x in ("delivered", "proof of delivery", "delivery complete", "package was delivered")):
            return "Delivered"
        if "out for delivery" in t or "on vehicle for delivery" in t:
            return "Out for Delivery"
        if any(x in t for x in ("on the way", "in transit", "departed", "arrived at facility", "shipped", "moving through network")):
            return "In Transit"
        if any(x in t for x in ("label created", "shipment ready", "information received", "pre-shipment")):
            return "Label Created"
        if any(x in t for x in ("delay", "delayed", "weather delay")):
            return "Delayed"
        return ""

    @staticmethod
    def _date_from_iso(value: str) -> str:
        value = clean_text(value)
        if not value:
            return ""
        try:
            return date_parser.parse(value).date().isoformat()
        except Exception:
            if re.fullmatch(r"\d{8}", value):
                return f"{value[:4]}-{value[4:6]}-{value[6:8]}"
            return ""

    @staticmethod
    def _time_window(begin: str, end: str) -> str:
        def fmt(v: str) -> str:
            if not v:
                return ""
            try:
                dt = date_parser.parse(v)
                return dt.strftime("%#I:%M %p") if os.name == "nt" else dt.strftime("%-I:%M %p")
            except Exception:
                return clean_text(v)
        a, b = fmt(begin), fmt(end)
        return f"{a} - {b}" if a and b else (a or b)

    def verify_ups(self, tracking: str):
        client_id,secret=load_ups_pair(keyring,APP_KEYRING_SERVICE)
        client=UPSClient(client_id,secret)
        try:
            result=client.track(tracking)
            return result.status,result.detail,result.delivered_at,result.eta_date,result.delivery_window
        finally:
            client.close()

    def verify_fedex(self, tracking: str) -> tuple[str, str, str, str, str]:
        try:
            token = self._fedex_access_token()
        except Exception:
            token = ""
        if token:
            try:
                r = self._request(
                    "POST", "https://apis.fedex.com/track/v1/trackingnumbers",
                    json={"includeDetailedScans": True, "trackingInfo": [{"trackingNumberInfo": {"trackingNumber": tracking}}]},
                    headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json", "X-locale": "en_US"},
                )
                r.raise_for_status(); data = r.json()
                complete = (((data or {}).get("output") or {}).get("completeTrackResults") or [])
                track_results = (complete[0].get("trackResults") or []) if complete else []
                if track_results:
                    tr = track_results[0]; latest = tr.get("latestStatusDetail") or {}
                    detail = clean_text(latest.get("statusByLocale") or latest.get("description") or latest.get("code") or "")
                    status = self._classify_status(detail); delivered_at = ""; eta_date = ""; eta_time = ""
                    for dtv in tr.get("dateAndTimes") or []:
                        dtype = str(dtv.get("type", "")).upper(); stamp = str(dtv.get("dateTime", ""))
                        if dtype == "ACTUAL_DELIVERY":
                            delivered_at = stamp
                        if not eta_date and dtype in ("ESTIMATED_DELIVERY", "COMMITMENT", "ACTUAL_DELIVERY"):
                            eta_date = self._date_from_iso(stamp)
                    win = ((tr.get("estimatedDeliveryTimeWindow") or {}).get("window") or {})
                    eta_time = self._time_window(str(win.get("begins", "")), str(win.get("ends", "")))
                    if status:
                        return status, detail, delivered_at, eta_date, eta_time
            except Exception:
                pass
        return self._verify_public(tracking, "FedEx")

    def verify_usps(self, tracking: str) -> tuple[str, str, str, str, str]:
        try:
            token = self._usps_access_token()
        except Exception:
            token = ""
        if token:
            for version in ("v3r2", "v3"):
                try:
                    if version == "v3r2":
                        r = self._request(
                            "GET", "https://apis.usps.com/tracking/v3r2/tracking/",
                            json=[{"trackingNumber": tracking}],
                            headers={"Authorization": f"Bearer {token}", "Accept": "application/json", "Content-Type": "application/json"},
                        )
                    else:
                        r = self._request(
                            "GET", f"https://apis.usps.com/tracking/v3/tracking/{tracking}",
                            params={"expand": "DETAIL"},
                            headers={"Authorization": f"Bearer {token}", "Accept": "application/json"},
                        )
                    r.raise_for_status(); data = r.json()
                    obj = data[0] if isinstance(data, list) and data else data
                    if isinstance(obj, dict) and "TrackResults" in obj:
                        obj = (obj.get("TrackResults") or {}).get("TrackInfo") or obj
                    if not isinstance(obj, dict):
                        continue
                    detail = clean_text(obj.get("statusSummary") or obj.get("TrackSummary") or obj.get("status") or obj.get("statusCategory") or "")
                    status = self._classify_status(detail); delivered_at = ""
                    events = obj.get("trackingEvents") or obj.get("TrackDetail") or []
                    if isinstance(events, dict):
                        events = [events]
                    for ev in events:
                        if not isinstance(ev, dict):
                            continue
                        txt = clean_text(str(ev.get("eventType") or ev.get("Event") or ev.get("eventDescription") or ""))
                        if self._classify_status(txt) == "Delivered":
                            delivered_at = str(ev.get("eventTimestamp") or ev.get("EventDate") or "")
                            break
                    exp = obj.get("deliveryDateExpectation") or {}
                    if not isinstance(exp, dict):
                        exp = {}
                    eta_date = clean_text(exp.get("predictedDeliveryDate") or exp.get("expectedDeliveryDate") or exp.get("guaranteedDeliveryDate") or "")
                    eta_time = self._time_window(str(exp.get("predictedDeliveryWindowStartTime", "")), str(exp.get("predictedDeliveryWindowEndTime", "")))
                    if status:
                        return status, detail, delivered_at, self._date_from_iso(eta_date), eta_time
                except Exception:
                    continue
        return self._verify_public(tracking, "USPS")

    def _verify_public(self, tracking: str, carrier: str) -> tuple[str, str, str, str, str]:
        url = direct_tracking_url(tracking, carrier)
        if not url:
            return "", "", "", "", ""
        texts: list[str] = []
        try:
            r = self._request("GET", url, allow_redirects=True)
            if r.ok and r.text:
                texts.append(clean_text(BeautifulSoup(r.text, "html.parser").get_text(" ")))
        except Exception:
            pass
        rendered = self._browser_text(url)
        if rendered:
            texts.append(rendered)
        compact_tracking = re.sub(r"\W", "", tracking).upper()
        for text in texts:
            if not text:
                continue
            compact_text = re.sub(r"\W", "", text).upper()
            if compact_tracking and compact_tracking not in compact_text:
                continue
            # Prefer a tracking-number-local window so generic carrier help text such as
            # "what does delivered mean?" cannot promote an unrelated shipment.
            upper_text = text.upper()
            pos = upper_text.find(clean_text(tracking).upper())
            window = text[max(0, pos - 1600):pos + 4200] if pos >= 0 else text[:6500]
            status = self._classify_status(window)
            if status:
                return status, window[:700], "", "", ""
        return "", "", "", "", ""

    def verify(self, tracking: str, carrier_hint: str = "") -> tuple[str, str, str, str, str]:
        carrier = normalize_carrier_name(carrier_hint) or infer_carrier(tracking)
        if carrier == "UPS":
            return self.verify_ups(tracking)
        if carrier == "FedEx":
            return self.verify_fedex(tracking)
        if carrier == "USPS":
            return self.verify_usps(tracking)
        return self._verify_public(tracking, carrier)

    @staticmethod
    def _apple_status_from_text(text: str, url: str, expected_order_number: str = "") -> tuple[str, str]:
        text = clean_text(text)
        if not text:
            return "", ""
        low = text.lower()
        expected = clean_text(expected_order_number).lower()
        if not expected:
            m = re.search(r"\bW\d{8,12}\b", url, re.I)
            expected = m.group(0).lower() if m else ""
        if expected and expected not in low and expected not in url.lower():
            return "", ""

        strong = [
            (r"your (?:item|items|order) (?:has|have) been picked up", "Picked Up"),
            (r"\bpicked up\s+(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)\w*\s+\d{1,2}\b", "Picked Up"),
            (r"your (?:item|items|order) (?:has|have|was|were) been delivered", "Delivered"),
            (r"\bdelivered\s+(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)\w*\s+\d{1,2}\b", "Delivered"),
            (r"your (?:item|items|order) (?:is|are) ready for pickup", "Ready for Pickup"),
            (r"\bready for pickup\s+(?:today|(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)\w*\s+\d{1,2})\b", "Ready for Pickup"),
            (r"your order (?:has been |was )?cancel(?:ed|led)", "Canceled"),
            (r"your (?:refund|order refund) (?:has been |was )?(?:issued|processed|completed)", "Refunded"),
        ]
        for pattern, status in strong:
            if re.search(pattern, low, re.I):
                return status, text[:900]
        for phrase, status in [
            ("preparing to ship", "Preparing to Ship"),
            ("your order has shipped", "Shipped"),
            ("your items have shipped", "Shipped"),
            ("we're processing your order", "Processing"),
            ("we are processing your order", "Processing"),
        ]:
            if phrase in low:
                return status, text[:900]
        return "", ""

    def verify_apple_order(self, url: str, order_number: str = "", alias_emails: str = "", source_email: str = "") -> tuple[str, str, str]:
        order_number = clean_text(order_number).upper()
        candidates: list[str] = []
        stored = safe_apple_url(url)
        if stored and apple_order_url_rank(stored, order_number) >= 90:
            candidates.append(stored)
        # Exact secure6 guest URLs from Chrome/Edge history are the most reliable
        # fallback when Apple's legacy redirect refuses a background HTTP client.
        candidates.extend(browser_history_guest_urls(order_number))
        candidates.extend(apple_vieworder_urls(order_number, alias_emails, source_email))
        seen: set[str] = set()
        unique: list[str] = []
        for candidate in candidates:
            if candidate and candidate not in seen:
                seen.add(candidate); unique.append(candidate)
        candidates = unique
        if not candidates:
            return "", "", ""

        best_resolved = stored or ""
        for candidate in candidates:
            resolved = candidate
            try:
                r = self._request("GET", candidate, allow_redirects=True, headers={
                    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
                    "Referer": "https://www.apple.com/",
                })
                if r.url:
                    final = safe_apple_url(r.url)
                    if final:
                        resolved = final
                        if apple_order_url_rank(final, order_number) > apple_order_url_rank(best_resolved, order_number):
                            best_resolved = final
                if r.ok and r.text:
                    visible = BeautifulSoup(r.text, "html.parser").get_text(" ")
                    status, detail = self._apple_status_from_text(visible, resolved, order_number)
                    if status:
                        return status, detail, best_resolved or resolved
            except Exception:
                pass
            browser_targets = []
            for target in (resolved, candidate, best_resolved):
                target = safe_apple_url(target)
                if target and target not in browser_targets:
                    browser_targets.append(target)
            # Rendering the original legacy vieworder URL is important: Apple may
            # set a cookie while redirecting it to the secure6 guest page. Rendering
            # that URL directly lets Chrome/Edge complete the redirect itself.
            for browser_url in browser_targets:
                rendered = self._browser_text(browser_url, timeout=45)
                if not rendered:
                    continue
                status, detail = self._apple_status_from_text(rendered, browser_url, order_number)
                if status:
                    return status, detail, best_resolved or resolved or browser_url
        return "", "", best_resolved

class ApplePickupWebEngineChecker(QObject):
    """Render Apple guest-order pages with Qt's Chromium engine on the GUI thread.

    Requests/headless --dump-dom can miss Apple's JavaScript-rendered status page.
    This checker loads the same legacy order link a user clicks, follows Apple's
    redirect to secure6.store.apple.com, waits for the page to settle, and then
    reads document.body.innerText. It runs only for Ready for Pickup orders.
    """
    progress = Signal(int, int, str)
    finished = Signal(int, int)
    failed = Signal(str)

    def __init__(self, db: Database, order_ids: list[int], parent=None):
        super().__init__(parent)
        self.db = db
        self.order_ids = [int(x) for x in order_ids]
        self.index = 0
        self.checked = 0
        self.updated = 0
        self.row = None
        self.candidates: list[str] = []
        self.candidate_index = 0
        self.poll_index = 0
        self.best_url = ""
        self.page = None
        self.profile = None
        if WEBENGINE_AVAILABLE:
            try:
                profile_root = app_data_dir() / "apple_web_profile"
                profile_root.mkdir(parents=True, exist_ok=True)
                self.profile = QWebEngineProfile("AppleOrderTrackerPickup", self)
                self.profile.setPersistentStoragePath(str(profile_root / "storage"))
                self.profile.setCachePath(str(profile_root / "cache"))
                self.profile.setHttpUserAgent(
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36"
                )
                self.page = QWebEnginePage(self.profile, self)
                self.page.loadFinished.connect(self._load_finished)
                self.page.urlChanged.connect(self._url_changed)
            except Exception as exc:
                self.page = None
                self.failed.emit(f"Apple browser checker could not start: {exc}")

    def start(self):
        if not WEBENGINE_AVAILABLE or self.page is None:
            self.finished.emit(0, 0)
            return
        QTimer.singleShot(0, self._next_order)

    def _url_changed(self, qurl):
        try:
            url = safe_apple_url(qurl.toString())
            if url and self.row is not None:
                order = clean_text(self.row["order_number"] or "")
                if apple_order_url_rank(url, order) > apple_order_url_rank(self.best_url, order):
                    self.best_url = url
        except Exception:
            pass

    def _next_order(self):
        while self.index < len(self.order_ids):
            order_id = self.order_ids[self.index]
            self.index += 1
            row = self.db.order_by_id(order_id)
            if not row or (row["status"] or "") != "Ready for Pickup" or (row["order_type"] or "").lower() != "pickup":
                continue
            self.row = row
            self.checked += 1
            order = clean_text(row["order_number"] or "")
            self.progress.emit(self.checked, len(self.order_ids), f"Opening Apple Order Status for Ready for Pickup order {self.checked}/{len(self.order_ids)} — {order}…")
            candidates: list[str] = []
            stored = safe_apple_url(row["order_url"] or "")
            if stored and apple_order_url_rank(stored, order) >= 90:
                candidates.append(stored)
            candidates.extend(browser_history_guest_urls(order))
            try:
                source_email = self.db.conn.execute(
                    "SELECT email FROM accounts WHERE id=?", (int(row["account_id"]),)
                ).fetchone()
                source_email = source_email[0] if source_email else ""
            except Exception:
                source_email = ""
            candidates.extend(apple_vieworder_urls(order, row["alias_emails"] or "", source_email))
            seen = set(); self.candidates = []
            for url in candidates:
                url = safe_apple_url(url)
                if url and url not in seen:
                    seen.add(url); self.candidates.append(url)
            self.candidate_index = 0
            self.poll_index = 0
            self.best_url = stored or ""
            if self.candidates:
                self._load_candidate()
                return
            self.db.mark_apple_web_checked(order_id, "", "No order-specific Apple guest URL was available.", self.best_url)
        self.finished.emit(self.checked, self.updated)

    def _load_candidate(self):
        if self.row is None:
            self._next_order(); return
        if self.candidate_index >= len(self.candidates):
            self.db.mark_apple_web_checked(
                int(self.row["id"]), "",
                "Apple page loaded, but no package-specific Picked Up text was found.",
                self.best_url,
            )
            self._next_order(); return
        url = self.candidates[self.candidate_index]
        self.candidate_index += 1
        self.poll_index = 0
        try:
            self.page.load(QUrl(url))
        except Exception:
            QTimer.singleShot(0, self._load_candidate)

    def _load_finished(self, ok: bool):
        # Apple fills the guest-order timeline after the initial document load.
        # Poll several times rather than reading the DOM immediately.
        self.poll_index = 0
        QTimer.singleShot(1200, self._poll_text)

    def _poll_text(self):
        if self.page is None or self.row is None:
            self._next_order(); return
        try:
            self.page.runJavaScript(
                "document.body ? document.body.innerText : ''",
                self._handle_text,
            )
        except Exception:
            self._load_candidate()

    def _handle_text(self, value):
        if self.row is None:
            self._next_order(); return
        text = clean_text(str(value or ""))
        order = clean_text(self.row["order_number"] or "")
        current_url = ""
        try:
            current_url = safe_apple_url(self.page.url().toString())
        except Exception:
            pass
        if current_url and apple_order_url_rank(current_url, order) > apple_order_url_rank(self.best_url, order):
            self.best_url = current_url
        status, detail = CarrierTracker._apple_status_from_text(text, current_url or self.best_url, order)
        if status:
            before = self.row["status"] or "Unknown"
            self.db.mark_apple_web_checked(int(self.row["id"]), status, detail, self.best_url or current_url)
            after_row = self.db.order_by_id(int(self.row["id"]))
            after = (after_row["status"] if after_row else before) or before
            if after != before:
                self.updated += 1
            self.progress.emit(self.checked, len(self.order_ids), f"Apple confirmed {order}: {after}.")
            self._next_order(); return
        self.poll_index += 1
        # Give dynamic Apple pages up to ~10 seconds to populate the timeline.
        if self.poll_index < 4:
            QTimer.singleShot(2200, self._poll_text)
            return
        self._load_candidate()


class VerificationWorker(QThread):
    progress = Signal(int, int, str)
    all_done = Signal(int, int)
    failed = Signal(str)
    package_started = Signal(list, str)
    order_updated = Signal(int)

    def __init__(self, database_path: Path, start_date="", end_date="", force=False,
                 order_ids=None, skip_apple=True, ups_only=True):
        super().__init__()
        self.database_path = database_path
        self.start_date, self.end_date, self.force = start_date, end_date, bool(force)
        self.order_ids = None if order_ids is None else set(map(int,order_ids))
        self._stop_requested = False
        self.stats = {"checked":0,"success":0,"errors":0,"changed":0,"skipped":0,"canceled":False}
        self.report_lines = []

    def request_stop(self):
        self._stop_requested = True

    def run(self):
        db = None
        client = None
        changed = set()
        try:
            db = Database(self.database_path)
            rows = list(db.tracking_candidates(start_date=self.start_date,end_date=self.end_date,force=self.force))
            if self.order_ids is not None:
                rows = [r for r in rows if int(r["id"]) in self.order_ids]
            assignments = {}
            for row in rows:
                for n in ups_numbers_for_order(row):
                    assignments.setdefault(n,[]).append((int(row["id"]),row["order_number"]))
            total = len(assignments)
            self.stats["skipped"] = total
            if not total:
                self.report_lines.append("No eligible, unarchived UPS packages in this selection.")
                return
            cid, secret = load_ups_pair(keyring, APP_KEYRING_SERVICE)
            client = UPSClient(cid,secret)
            self.progress.emit(0,total,f"Starting UPS API checks for {total} unique packages...")
            for n,targets in assignments.items():
                if self._stop_requested:
                    self.stats["canceled"] = True
                    break
                targets = [(oid,order) for oid,order in targets if db.is_order_visible(oid)]
                if not targets: continue
                self.package_started.emit([oid for oid,_ in targets], n)
                self.progress.emit(self.stats["checked"],total,f"Checking UPS {self.stats['checked']+1}/{total} - {n}")
                stop = False
                try:
                    result = client.track(n)
                    self.stats["success"] += 1
                    self.report_lines.append(f"{n}: {result.status} | {result.detail}")
                    for oid,_ in targets: db.save_ups_package(oid,n,result=result)
                except UPSCheckError as exc:
                    self.stats["errors"] += 1
                    self.report_lines.append(f"{n}: CHECK FAILED [{exc.kind}] {exc}")
                    self.report_lines.extend(line for line in client.diagnostics if line not in self.report_lines)
                    for oid,_ in targets: db.save_ups_package(oid,n,error=str(exc))
                    stop = exc.kind in ("auth","access","rate_limited","redirect")
                self.stats["checked"] += 1
                self.stats["skipped"] = total-self.stats["checked"]
                for oid,order in targets:
                    if db.refresh_ups_aggregate(oid): changed.add(oid)
                    self.order_updated.emit(oid)
                self.progress.emit(self.stats["checked"],total,self.report_lines[-1])
                if stop:
                    self.report_lines.append("Remaining requests were stopped to respect UPS authentication/access/rate-limit controls.")
                    break
        except Exception as exc:
            message = ("UPS check could not finish: " + str(exc) if isinstance(exc, UPSCredentialError)
                       else f"UPS check could not finish ({type(exc).__name__}). Open Settings and test the saved UPS credentials.")
            self.report_lines.append(message)
            self.stats["errors"] += 1
            self.stats["fatal"] = message
            self.failed.emit(message)
        finally:
            self.stats["changed"] = len(changed)
            if client is not None: client.close()
            if db is not None: db.close()
            self.all_done.emit(self.stats["checked"],len(changed))


class UPSConnectionTestWorker(QThread):
    """Runs a read-only OAuth/Tracking diagnosis without blocking the GUI."""
    progress = Signal(str)

    def __init__(self, client_id, client_secret, tracking_number='', parent=None):
        super().__init__(parent)
        self.client_id, self.client_secret = client_id, client_secret
        self.tracking_number = tracking_number
        self.report = {}

    def run(self):
        client = None
        try:
            self.progress.emit("Testing production OAuth" + (" and one Tracking request..." if self.tracking_number else " only..."))
            client = UPSClient(self.client_id, self.client_secret)
            self.report = client.diagnose(self.tracking_number)
        except Exception as exc:
            # Never print arbitrary exceptions which could echo request credentials.
            self.report = {'oauth_ok': False, 'tracking_ok': False if self.tracking_number else None,
                           'error_kind': 'test_error', 'lines': [f'The connection test stopped ({type(exc).__name__}). No order data was changed.']}
        finally:
            if client is not None:
                client.close()
            self.client_id = self.client_secret = ''


class AppUpdateCheckWorker(QThread):
    result_ready = Signal(object)
    failed = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)

    def run(self):
        try:
            self.result_ready.emit(check_latest_release(APP_VERSION))
        except UpdateError as exc:
            self.failed.emit(str(exc))
        except Exception as exc:
            self.failed.emit(f"Update check could not finish ({type(exc).__name__}).")


class AppUpdateDownloadWorker(QThread):
    progress = Signal(int, int)
    downloaded = Signal(str)
    failed = Signal(str)

    def __init__(self, info: UpdateInfo, parent=None):
        super().__init__(parent)
        self.info = info

    def run(self):
        try:
            destination = update_download_path(self.info.version)
            path = download_and_verify(
                self.info,
                destination,
                progress=lambda current, total: self.progress.emit(int(current), int(total)),
            )
            self.downloaded.emit(str(path))
        except UpdateError as exc:
            self.failed.emit(str(exc))
        except Exception as exc:
            self.failed.emit(f"Update download could not finish ({type(exc).__name__}).")


class SettingsDialog(QDialog):
    def __init__(self, settings: QSettings, parent=None):
        super().__init__(parent)
        self.settings = settings
        self.ups_test_worker = None
        self.setWindowTitle("Settings")
        self.resize(780, 720)
        lay = QVBoxLayout(self); lay.setContentsMargins(26, 24, 26, 22); lay.setSpacing(14)
        title = QLabel("Settings"); title.setObjectName("dialogTitle"); lay.addWidget(title)
        desc = QLabel("Apple email remains the normal status source. Saved manual status and quantity overrides always have highest priority.")
        desc.setObjectName("muted"); desc.setWordWrap(True); lay.addWidget(desc)

        scroll = QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QFrame.NoFrame)
        body_widget = QWidget(); content = QVBoxLayout(body_widget); content.setContentsMargins(0,0,0,0); content.setSpacing(14)
        scroll.setWidget(body_widget); lay.addWidget(scroll,1)
        ups = QFrame(); ups.setObjectName("detailCard")
        ups_lay = QVBoxLayout(ups); ups_lay.setContentsMargins(18,16,18,16); ups_lay.setSpacing(10)
        uh = QLabel("UPS API tracking"); uh.setObjectName("sectionTitle"); ups_lay.addWidget(uh)
        ub = QLabel("Production: onlinetools.ups.com. Use the Client ID and Client Secret from the SAME UPS Developer Portal app, with Tracking added to its API products. Credentials stay in Windows Credential Manager, not in orders.db.")
        ub.setObjectName("muted"); ub.setWordWrap(True); ups_lay.addWidget(ub)
        form = QGridLayout(); form.setHorizontalSpacing(10); form.setVerticalSpacing(8)
        self.ups_client_id = QLineEdit(); self.ups_client_id.setPlaceholderText("UPS application Client ID")
        self.ups_client_secret = QLineEdit(); self.ups_client_secret.setEchoMode(QLineEdit.Password); self.ups_client_secret.setPlaceholderText("Matching UPS Client Secret")
        try:
            saved_id, saved_secret = load_ups_pair(keyring,APP_KEYRING_SERVICE)
        except UPSCredentialError:
            saved_id = saved_secret = ''
        self.ups_client_id.setText(saved_id)
        if saved_secret:
            self.ups_client_secret.setPlaceholderText("Saved securely - a new Client ID also requires its matching secret")
        form.addWidget(QLabel("Client ID"),0,0); form.addWidget(self.ups_client_id,0,1)
        form.addWidget(QLabel("Client Secret"),1,0); form.addWidget(self.ups_client_secret,1,1)
        ups_lay.addLayout(form)
        self.ups_auto = QCheckBox("Automatically refresh eligible UPS shipments after Gmail Sync")
        self.ups_auto.setChecked(str(self.settings.value("ups_auto_refresh","true")).lower()!='false'); ups_lay.addWidget(self.ups_auto)
        btns = QHBoxLayout()
        self.save_ups_button = QPushButton("Save UPS Credentials"); self.save_ups_button.setObjectName("primaryButton")
        self.test_oauth_button = QPushButton("Test OAuth Only"); self.test_oauth_button.setObjectName("secondaryAccent")
        self.clear_ups_button = QPushButton("Remove UPS Credentials"); self.clear_ups_button.setObjectName("dangerButton")
        btns.addWidget(self.save_ups_button); btns.addWidget(self.test_oauth_button); btns.addWidget(self.clear_ups_button)
        ups_lay.addLayout(btns)
        self.ups_test_number = QLineEdit(); self.ups_test_number.setPlaceholderText("Paste one real UPS tracking number here (1Z...)")
        try:
            if parent and hasattr(parent,'tracking_model'):
                candidates = [n for row in parent.tracking_model.rows for n in ups_numbers_for_order(row)]
                if candidates: self.ups_test_number.setText(candidates[0])
        except Exception:
            pass
        tracking_test = QHBoxLayout()
        tracking_test.addWidget(self.ups_test_number,1)
        self.test_tracking_button = QPushButton("Test UPS Tracking"); self.test_tracking_button.setObjectName("primaryButton")
        tracking_test.addWidget(self.test_tracking_button); ups_lay.addLayout(tracking_test)
        self.ups_status = QLabel("Credentials found. Test UPS Tracking checks BOTH token creation and one real package; Test OAuth Only does not prove Tracking access." if saved_id and saved_secret else "No complete credential pair found. Paste both values from the same UPS app, save, then test one real UPS tracking number.")
        self.ups_status.setObjectName("mutedSmall"); self.ups_status.setWordWrap(True); ups_lay.addWidget(self.ups_status)
        content.addWidget(ups)
        self.save_ups_button.clicked.connect(self._save_ups)
        self.test_oauth_button.clicked.connect(self._test_ups)
        self.test_tracking_button.clicked.connect(self._test_tracking)
        self.clear_ups_button.clicked.connect(self._clear_ups)

        updates = QFrame(); updates.setObjectName("detailCard")
        updates_lay = QVBoxLayout(updates); updates_lay.setContentsMargins(18,16,18,16); updates_lay.setSpacing(10)
        uph = QLabel(f"App updates — v{APP_VERSION}"); uph.setObjectName("sectionTitle"); updates_lay.addWidget(uph)
        upb = QLabel("Stable updates are downloaded from the official Ah Pa Ta Tracker GitHub release channel. The updater verifies SHA-256 before replacing the Windows EXE. Your local database and saved credentials are not replaced.")
        upb.setObjectName("muted"); upb.setWordWrap(True); updates_lay.addWidget(upb)
        self.auto_updates = QCheckBox("Automatically check for stable updates when Ah Pa Ta Tracker starts")
        self.auto_updates.setChecked(str(self.settings.value("updates_auto_check","true")).lower() != "false")
        self.auto_updates.toggled.connect(lambda checked: (self.settings.setValue("updates_auto_check", "true" if checked else "false"), self.settings.sync()))
        updates_lay.addWidget(self.auto_updates)
        update_buttons = QHBoxLayout()
        self.check_update_button = QPushButton("Check for Updates"); self.check_update_button.setObjectName("primaryButton")
        self.check_update_button.clicked.connect(lambda: self.parent().check_for_updates(True) if self.parent() and hasattr(self.parent(), "check_for_updates") else None)
        update_buttons.addWidget(self.check_update_button); update_buttons.addStretch(1); updates_lay.addLayout(update_buttons)
        content.addWidget(updates)

        info = QFrame(); info.setObjectName("detailCard"); info_lay = QVBoxLayout(info)
        h = QLabel("Manual override mode"); h.setObjectName("sectionTitle"); info_lay.addWidget(h)
        b = QLabel("Use Save Changes on the Orders page to commit status and quantity edits. Choose Automatic to let Apple email/UPS evidence control a manually overridden order again.")
        b.setObjectName("muted"); b.setWordWrap(True); info_lay.addWidget(b); content.addWidget(info); content.addStretch(1)
        self.rebuild_button = QPushButton("Advanced: Rebuild Local Cache"); self.rebuild_button.setObjectName("dangerButton"); self.rebuild_button.clicked.connect(self._rebuild); content.addWidget(self.rebuild_button)
        self.close_buttons = QDialogButtonBox(QDialogButtonBox.Close); self.close_buttons.rejected.connect(self.reject); lay.addWidget(self.close_buttons)

    def _batch_busy(self):
        return bool(self.parent() and getattr(self.parent(), '_ups_busy', False))

    def _test_busy(self):
        return bool(self.ups_test_worker and self.ups_test_worker.isRunning())

    def _save_ups(self):
        if self._batch_busy() or self._test_busy():
            QMessageBox.information(self, APP_NAME, "Wait for the current UPS check to finish before changing credentials.")
            return False
        try:
            cid, secret = save_ups_pair(keyring, APP_KEYRING_SERVICE, self.ups_client_id.text(), self.ups_client_secret.text())
            self.settings.setValue("ups_auto_refresh", "true" if self.ups_auto.isChecked() else "false"); self.settings.sync()
            self.ups_client_id.setText(cid); self.ups_client_secret.clear()
            self.ups_client_secret.setPlaceholderText("Saved securely - a new Client ID also requires its matching secret")
            self.ups_status.setText("Credential pair saved. Enter one UPS number and use Test UPS Tracking to test actual Tracking access.")
            return True
        except UPSCredentialError as exc:
            QMessageBox.warning(self, APP_NAME, str(exc))
            return False
        except Exception:
            QMessageBox.warning(self, APP_NAME, "Could not confirm saving the UPS settings. No test was started.")
            return False

    def _test_ups(self):
        self._start_ups_test('')

    def _test_tracking(self):
        tracking = re.sub(r'\s+', '', self.ups_test_number.text()).upper()
        if not re.fullmatch(r'[A-Z0-9]{7,34}',tracking) or re.fullmatch(r'W\d{8,}',tracking):
            QMessageBox.warning(self, APP_NAME, "Enter one UPS tracking number, not an Apple order number or a URL.")
            return
        self._start_ups_test(tracking)

    def _start_ups_test(self, tracking):
        # A failed save must NEVER fall through and test an old credential pair.
        if not self._save_ups(): return
        try:
            cid, secret = load_ups_pair(keyring, APP_KEYRING_SERVICE)
        except UPSCredentialError as exc:
            QMessageBox.warning(self, APP_NAME, str(exc)); return
        self.ups_status.setText("Testing UPS production OAuth" + (" and Tracking..." if tracking else " only..."))
        self._set_ups_test_enabled(False)
        worker = UPSConnectionTestWorker(cid,secret,tracking,self)
        self.ups_test_worker = worker
        worker.progress.connect(self.ups_status.setText)
        worker.finished.connect(self._ups_test_finished)
        worker.start()

    def _set_ups_test_enabled(self, enabled):
        for widget in (self.save_ups_button,self.test_oauth_button,self.test_tracking_button,self.clear_ups_button,
                       self.ups_client_id,self.ups_client_secret,self.ups_test_number,self.ups_auto,self.rebuild_button,self.close_buttons):
            widget.setEnabled(enabled)

    def _ups_test_finished(self):
        worker = self.ups_test_worker
        if worker is None: return
        report = worker.report
        self.ups_test_worker = None
        worker.deleteLater()
        self._set_ups_test_enabled(True)
        if report.get('tracking_ok'):
            summary = "OAuth and Tracking passed. Close Settings and use Shipping Tracking > Refresh UPS to update orders."
        elif report.get('oauth_ok') and report.get('tracking_ok') is None:
            summary = "OAuth passed. Tracking was NOT tested; enter a UPS number and click Test UPS Tracking."
        elif report.get('oauth_ok'):
            summary = "OAuth passed, but the Tracking request did not succeed. See the exact error and next steps below."
        else:
            summary = "UPS connection test failed before a usable OAuth token was available. See the exact error below."
        self.ups_status.setText(summary)
        dialog = QDialog(self); dialog.setWindowTitle("UPS connection diagnosis"); dialog.resize(850,520)
        layout = QVBoxLayout(dialog)
        label = QLabel(summary); label.setWordWrap(True); layout.addWidget(label)
        result = QPlainTextEdit(); result.setReadOnly(True)
        result.setPlainText('\n\n'.join(report.get('lines',[]))); layout.addWidget(result,1)
        note = QLabel("The test does not update orders. This report excludes the Client ID, Client Secret, token and Authorization header.")
        note.setWordWrap(True); note.setObjectName("mutedSmall"); layout.addWidget(note)
        row = QHBoxLayout(); copy = QPushButton("Copy Diagnostic Report")
        copy.clicked.connect(lambda: QApplication.clipboard().setText(result.toPlainText())); row.addWidget(copy); row.addStretch(1)
        buttons = QDialogButtonBox(QDialogButtonBox.Close); buttons.rejected.connect(dialog.reject); row.addWidget(buttons); layout.addLayout(row)
        dialog.exec()

    def _clear_ups(self):
        if self._batch_busy() or self._test_busy():
            QMessageBox.information(self, APP_NAME, "Wait for the current UPS check to finish before removing credentials."); return
        try:
            clear_ups_pair(keyring, APP_KEYRING_SERVICE)
            self.ups_client_id.clear(); self.ups_client_secret.clear()
            self.ups_client_secret.setPlaceholderText("Matching UPS Client Secret")
            self.ups_status.setText("UPS credentials removed. Paste BOTH values from the same UPS app to reconnect.")
        except UPSCredentialError as exc:
            QMessageBox.warning(self, APP_NAME, str(exc))

    def reject(self):
        if self._test_busy():
            self.ups_status.setText("Please wait for the bounded UPS connection test to finish before closing Settings.")
            return
        super().reject()

    def closeEvent(self, event):
        if self._test_busy():
            event.ignore()
            self.ups_status.setText("Please wait for the UPS connection test to finish before closing Settings.")
        else:
            super().closeEvent(event)

    def _rebuild(self):
        if self._test_busy(): return
        self.reject()
        if self.parent() and hasattr(self.parent(), "full_rescan"):
            QTimer.singleShot(0,self.parent().full_rescan)

class AccountDialog(QDialog):
    def __init__(self, db: Database, parent=None):
        super().__init__(parent)
        self.db = db
        self.setWindowTitle("Gmail Accounts")
        self.resize(650, 430)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(22, 20, 22, 20)
        layout.setSpacing(14)

        title = QLabel("Gmail IMAP accounts")
        title.setObjectName("dialogTitle")
        layout.addWidget(title)
        info = QLabel(
            "Use your Gmail address and a Google App Password. The password stays in Windows Credential Manager; it is not written into the order database."
        )
        info.setWordWrap(True)
        info.setObjectName("muted")
        layout.addWidget(info)

        self.list = QListWidget()
        self.list.setSelectionMode(QAbstractItemView.SingleSelection)
        layout.addWidget(self.list, 1)

        form = QGridLayout()
        self.email_edit = QLineEdit()
        self.email_edit.setPlaceholderText("you@gmail.com")
        self.password_edit = QLineEdit()
        self.password_edit.setEchoMode(QLineEdit.Password)
        self.password_edit.setPlaceholderText("16-character Google App Password")
        self.server_edit = QLineEdit(DEFAULT_IMAP_SERVER)
        self.port_edit = QLineEdit(str(DEFAULT_IMAP_PORT))
        form.addWidget(QLabel("Gmail"), 0, 0)
        form.addWidget(self.email_edit, 0, 1)
        form.addWidget(QLabel("App Password"), 1, 0)
        form.addWidget(self.password_edit, 1, 1)
        form.addWidget(QLabel("IMAP server"), 2, 0)
        form.addWidget(self.server_edit, 2, 1)
        form.addWidget(QLabel("Port"), 3, 0)
        form.addWidget(self.port_edit, 3, 1)
        layout.addLayout(form)

        actions = QHBoxLayout()
        save = QPushButton("Save / Update")
        save.setObjectName("primaryButton")
        remove = QPushButton("Remove Selected")
        close = QPushButton("Close")
        actions.addWidget(save)
        actions.addWidget(remove)
        actions.addStretch(1)
        actions.addWidget(close)
        layout.addLayout(actions)

        save.clicked.connect(self.save_account)
        remove.clicked.connect(self.remove_selected)
        close.clicked.connect(self.accept)
        self.refresh()

    def refresh(self):
        self.list.clear()
        for row in self.db.list_accounts():
            item = QListWidgetItem(f"{row['email']}    •    Last IMAP UID: {int(row['last_uid'] or 0):,}")
            item.setData(Qt.UserRole, int(row["id"]))
            item.setData(Qt.UserRole + 1, row["email"])
            self.list.addItem(item)

    def save_account(self):
        email = self.email_edit.text().strip().lower()
        password = self.password_edit.text().strip().replace(" ", "")
        server = self.server_edit.text().strip() or DEFAULT_IMAP_SERVER
        try:
            port = int(self.port_edit.text().strip() or DEFAULT_IMAP_PORT)
        except ValueError:
            QMessageBox.warning(self, APP_NAME, "Port must be a number.")
            return
        if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
            QMessageBox.warning(self, APP_NAME, "Enter a valid Gmail address.")
            return
        if not password:
            QMessageBox.warning(self, APP_NAME, "Enter the Google App Password.")
            return
        self.db.add_account(email, server, port)
        try:
            keyring.set_password(APP_KEYRING_SERVICE, email, password)
        except Exception as exc:
            QMessageBox.critical(self, APP_NAME, f"Could not save the app password in Windows Credential Manager:\n\n{exc}")
            return
        self.password_edit.clear()
        self.refresh()
        QMessageBox.information(self, APP_NAME, "Account saved. Use Sync Now on the Orders page.")

    def remove_selected(self):
        item = self.list.currentItem()
        if not item:
            return
        email = item.data(Qt.UserRole + 1)
        if QMessageBox.question(self, APP_NAME, f"Remove {email} and its locally cached orders?") != QMessageBox.Yes:
            return
        self.db.remove_account(int(item.data(Qt.UserRole)))
        self.refresh()


class ProductImageCache(QObject):
    ready = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.net = QNetworkAccessManager(self)
        self.cache: dict[str, QPixmap] = {}
        self.pending: set[str] = set()
        self.queue: list[str] = []
        self.max_parallel = 6

    def icon_for(self, url: str) -> QIcon:
        url = safe_product_image_url(url)
        if not url:
            return QIcon()
        pix = self.cache.get(url)
        if pix and not pix.isNull():
            return QIcon(pix)
        if url not in self.pending and url not in self.queue:
            self.queue.append(url)
            self._pump()
        return QIcon()

    def _pump(self):
        while self.queue and len(self.pending) < self.max_parallel:
            url = self.queue.pop(0)
            self.pending.add(url)
            req = QNetworkRequest(QUrl(url))
            req.setRawHeader(b"User-Agent", f"AhPaTaTracker/{APP_VERSION}".encode("ascii"))
            reply = self.net.get(req)
            reply.finished.connect(lambda u=url, r=reply: self._finished(u, r))

    def _finished(self, url: str, reply):
        try:
            data = bytes(reply.readAll())
            pix = QPixmap()
            if data and pix.loadFromData(data):
                self.cache[url] = pix
                self.ready.emit(url)
        finally:
            self.pending.discard(url)
            reply.deleteLater()
            self._pump()



class StatusDelegate(RowHoverDelegate):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.dark = False

    def set_dark(self, dark: bool):
        self.dark = dark

    def paint(self,painter: QPainter,option,index):
        status=str(index.data(Qt.DisplayRole) or "Unknown")
        fg,bg=STATUS_COLORS.get(status,STATUS_COLORS["Unknown"])
        if self.dark:
            if status in ("Returning to Sender","Returned to Sender","Exception","Canceled","Refunded"):
                fg,bg="#fda4af","#3a2029"
            elif status in ("Delayed","Mixed Shipments"):
                fg,bg="#fcd34d","#392d18"
            elif status in ("Delivered","Picked Up","Out for Delivery","Partially Delivered"):
                fg,bg="#86efac","#153324"
            elif status in ("Ready for Pickup","Shipping to Store","Check in Today"):
                fg,bg="#c4b5fd","#2a203d"
            else:
                fg,bg="#93c5fd","#172b47"
        painter.save()
        opt=paint_cell_background(self,painter,option,index)
        row=index.model().row_at(index.row()) if hasattr(index.model(),"row_at") else None
        window=option.widget.window() if option.widget else None
        active=row is not None and int(row["id"]) in getattr(window,"_ups_active_ids",set())
        dot=None
        if active:
            dot=QColor("#22c55e")
            dot.setAlpha(int(125+130*(math.sin(getattr(window,"_ups_phase",0)*math.pi/15)+1)/2))
        elif row is not None and row_value(row,"tracking_error"):
            dot=QColor("#f59e0b")
        elif row is not None and row_value(row,"tracking_success_at"):
            try:
                dt=datetime.fromisoformat(row_value(row,"tracking_success_at").replace("Z","+00:00"))
                if dt.tzinfo is None: dt=dt.replace(tzinfo=timezone.utc)
                fresh=(datetime.now(timezone.utc)-dt).total_seconds() <= 1200
            except ValueError: fresh=False
            dot=QColor("#22c55e" if fresh else "#94a3b8")
        font=QFont(option.font); font.setBold(True); painter.setFont(font)
        fm=painter.fontMetrics(); label=f"{STATUS_GLYPHS.get(status,'-')}  {status}"
        room=max(35,option.rect.width()-(36 if dot is not None else 18))
        label=fm.elidedText(label,Qt.ElideRight,room-18)
        width=min(room,fm.horizontalAdvance(label)+22); height=min(30,option.rect.height()-12)
        x=option.rect.x()+(option.rect.width()-width-(18 if dot is not None else 0))//2
        y=option.rect.y()+(option.rect.height()-height)//2
        painter.setRenderHint(QPainter.Antialiasing); painter.setPen(Qt.NoPen); painter.setBrush(QColor(bg))
        painter.drawRoundedRect(int(x),int(y),int(width),int(height),10,10)
        painter.setPen(QColor(fg)); painter.drawText(int(x+9),int(y),int(width-16),int(height),Qt.AlignVCenter|Qt.AlignLeft,label)
        if dot is not None:
            painter.setPen(Qt.NoPen); painter.setBrush(dot)
            painter.drawEllipse(int(x+width+7),int(y+height//2-4),8,8)
        painter.restore()

class StatusEditDelegate(StatusDelegate):
    """Status pill that becomes a dropdown when the user clicks the cell."""
    def createEditor(self, parent, option, index):
        editor = QComboBox(parent)
        editor.addItem(MANUAL_STATUS_AUTOMATIC, "")
        for status in MANUAL_STATUS_OPTIONS:
            editor.addItem(status, status)
        editor.activated.connect(lambda *_: self.commitData.emit(editor))
        return editor

    def setEditorData(self, editor, index):
        model = index.model()
        row = model.row_at(index.row()) if hasattr(model, "row_at") else None
        order_id = int(row["id"]) if row else -1
        pending = getattr(model, "pending_status", {})
        if order_id in pending:
            value = pending[order_id]
        else:
            value = clean_text(row["manual_status"] or "") if row and "manual_status" in row.keys() else ""
        target = value or ""
        found = editor.findData(target)
        editor.setCurrentIndex(found if found >= 0 else 0)

    def setModelData(self, editor, model, index):
        model.setData(index, editor.currentData(), Qt.EditRole)


class QtyEditDelegate(RowHoverDelegate):
    def createEditor(self, parent, option, index):
        editor = QSpinBox(parent)
        editor.setRange(1, 9999)
        editor.setAlignment(Qt.AlignCenter)
        editor.setFrame(True)
        return editor

    def setEditorData(self, editor, index):
        try:
            editor.setValue(int(index.data(Qt.DisplayRole) or 1))
        except Exception:
            editor.setValue(1)

    def setModelData(self, editor, model, index):
        model.setData(index, int(editor.value()), Qt.EditRole)


class OrderTableModel(QAbstractTableModel):
    checkedChanged = Signal()
    pendingChanged = Signal()
    COLUMNS = [
        ("select", "Select"),
        ("image", "Image"),
        ("order_type", "Type"),
        ("item_summary", "Item"),
        ("qty", "Qty"),
        ("status", "Status"),
        ("order_number", "Order #"),
        ("tracking_number", "Tracking #"),
        ("schedule", "Delivery / Pickup Date"),
        ("destination", "Destination"),
        ("total", "Total"),
        ("order_date", "Order Date"),
        ("source_email", "IMAP Source"),
    ]

    def __init__(self, image_cache: ProductImageCache, parent=None):
        super().__init__(parent)
        self.rows: list[sqlite3.Row] = []
        self.image_cache = image_cache
        self.image_rows: dict[str, list[int]] = {}
        self.dark = False
        self.checked_ids: set[int] = set()
        self.pending_status: dict[int, str] = {}
        self.pending_qty: dict[int, int] = {}
        self.image_cache.ready.connect(self._image_ready)

    def set_rows(self, rows):
        old_checked = set(self.checked_ids)
        self.beginResetModel()
        self.rows = list(rows)
        visible_ids = {int(r["id"]) for r in self.rows}
        self.checked_ids = old_checked & visible_ids
        self.image_rows = {}
        for i, row in enumerate(self.rows):
            url = safe_product_image_url(row["image_url"] or "")
            if url:
                self.image_rows.setdefault(url, []).append(i)
        self.endResetModel()

    def set_dark(self, dark: bool):
        self.dark = dark
        if self.rows:
            self.dataChanged.emit(self.index(0, 0), self.index(len(self.rows) - 1, len(self.COLUMNS) - 1))

    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.rows)

    def columnCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.COLUMNS)

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if orientation == Qt.Horizontal and 0 <= section < len(self.COLUMNS):
            if role == Qt.DisplayRole:
                return self.COLUMNS[section][1]
            if role == Qt.TextAlignmentRole:
                return int(Qt.AlignCenter)
            if role == Qt.ToolTipRole and self.COLUMNS[section][0] == "select":
                return "Select orders to export"
        return None

    def flags(self, index: QModelIndex):
        if not index.isValid():
            return Qt.NoItemFlags
        flags = Qt.ItemIsEnabled | Qt.ItemIsSelectable
        key = self.COLUMNS[index.column()][0]
        if key == "select":
            flags |= Qt.ItemIsUserCheckable
        if key in ("status", "qty"):
            flags |= Qt.ItemIsEditable
        return flags

    def setData(self, index: QModelIndex, value, role=Qt.EditRole):
        if not index.isValid():
            return False
        row = self.row_at(index.row())
        if not row:
            return False
        order_id = int(row["id"])
        key = self.COLUMNS[index.column()][0]
        if key == "select" and role == Qt.CheckStateRole:
            if check_state_is_checked(value):
                self.checked_ids.add(order_id)
            else:
                self.checked_ids.discard(order_id)
            self.dataChanged.emit(index, index, [Qt.CheckStateRole])
            self.checkedChanged.emit()
            return True
        if key == "status" and role == Qt.EditRole:
            status = clean_text(str(value or ""))
            if status and status not in MANUAL_STATUS_OPTIONS:
                return False
            self.pending_status[order_id] = status
            self.dataChanged.emit(index, index, [Qt.DisplayRole, Qt.ToolTipRole])
            self.pendingChanged.emit()
            return True
        if key == "qty" and role == Qt.EditRole:
            try:
                qty = max(1, min(9999, int(value)))
            except Exception:
                return False
            self.pending_qty[order_id] = qty
            self.dataChanged.emit(index, index, [Qt.DisplayRole, Qt.FontRole, Qt.ToolTipRole])
            self.pendingChanged.emit()
            return True
        return False

    def pending_changes(self) -> dict[int, dict]:
        ids = set(self.pending_status) | set(self.pending_qty)
        out: dict[int, dict] = {}
        for order_id in ids:
            change: dict = {}
            if order_id in self.pending_status:
                change["status"] = self.pending_status[order_id]
            if order_id in self.pending_qty:
                change["qty"] = self.pending_qty[order_id]
            out[int(order_id)] = change
        return out

    def pending_order_count(self) -> int:
        return len(set(self.pending_status) | set(self.pending_qty))

    def clear_pending(self):
        if not self.pending_status and not self.pending_qty:
            return
        self.pending_status.clear(); self.pending_qty.clear()
        if self.rows:
            self.dataChanged.emit(self.index(0, 0), self.index(len(self.rows)-1, len(self.COLUMNS)-1))
        self.pendingChanged.emit()

    def checked_order_ids(self) -> list[int]:
        return [int(r["id"]) for r in self.rows if int(r["id"]) in self.checked_ids]

    def clear_checked(self):
        if not self.checked_ids:
            return
        self.checked_ids.clear()
        if self.rows:
            self.dataChanged.emit(self.index(0, 0), self.index(len(self.rows)-1, 0), [Qt.CheckStateRole])
        self.checkedChanged.emit()

    def set_all_checked(self, checked: bool = True):
        self.checked_ids = {int(r["id"]) for r in self.rows} if checked else set()
        if self.rows:
            self.dataChanged.emit(self.index(0, 0), self.index(len(self.rows)-1, 0), [Qt.CheckStateRole])
        self.checkedChanged.emit()

    def data(self, index: QModelIndex, role=Qt.DisplayRole):
        if not index.isValid() or not (0 <= index.row() < len(self.rows)):
            return None
        row = self.rows[index.row()]
        key = self.COLUMNS[index.column()][0]

        if role == Qt.ToolTipRole and key in ("status", "display_status"):
            return tracking_status_tip(row) + "\nManual overrides remain highest priority."
        order_id = int(row["id"])
        if role == Qt.UserRole:
            return order_id
        if role == Qt.EditRole:
            if key == "status":
                return self.pending_status.get(order_id, clean_text(row["manual_status"] or "") if "manual_status" in row.keys() else "")
            if key == "qty":
                return self.pending_qty.get(order_id, int(row["qty"] or 1))
        if key == "select" and role == Qt.CheckStateRole:
            return Qt.CheckState.Checked if int(row["id"]) in self.checked_ids else Qt.CheckState.Unchecked
        if key == "image" and role == Qt.DecorationRole:
            return self.image_cache.icon_for(row["image_url"] or "")
        if role == Qt.DisplayRole:
            if key in ("select", "image"):
                return ""
            if key == "order_type":
                return "Pickup" if (row["order_type"] or "").lower() == "pickup" else "Shipping"
            if key == "status":
                if order_id in self.pending_status:
                    pending = self.pending_status[order_id]
                    if pending:
                        return pending
                    return clean_text(row["detected_status"] or "") if "detected_status" in row.keys() else (row["status"] or "Unknown")
                return row["status"] or "Unknown"
            if key == "qty":
                return str(self.pending_qty.get(order_id, int(row["qty"] or 1)))
            if key == "destination":
                if (row["order_type"] or "").lower() == "pickup":
                    return row["pickup_store"] or pickup_store_from_address(row["address"] or "")
                return row["address"] or ""
            if key == "schedule":
                base = display_eta_value(row["eta_date"] or "", row["eta_text"] or "")
                if (row["order_type"] or "").lower() == "pickup" and row["pickup_time"]:
                    return f"{base} • {row['pickup_time']}" if base else row["pickup_time"]
                if (row["order_type"] or "").lower() == "shipping" and row["delivery_time"]:
                    return f"{base} • {row['delivery_time']}" if base else row["delivery_time"]
                return base
            value = row[key] if key in row.keys() else ""
            return str(value if value is not None else "")
        if role == Qt.TextAlignmentRole:
            return int(Qt.AlignCenter | Qt.AlignVCenter)
        if role == Qt.FontRole:
            if key in ("order_number", "tracking_number") and row[key]:
                f = QFont(); f.setUnderline(True); return f
            if key == "qty" and (order_id in self.pending_qty or ("manual_qty" in row.keys() and row["manual_qty"] is not None)):
                f = QFont(); f.setBold(True); return f
        if role == Qt.ForegroundRole:
            if key in ("order_number", "tracking_number") and row[key]:
                return QBrush(QColor("#60a5fa" if self.dark else "#2563eb"))
            if key == "status":
                status = row["status"] or "Unknown"
                palette = {
                    "Delivered": "#16a34a",
                    "Picked Up": "#16a34a",
                    "Canceled": "#ef4444",
                    "Refunded": "#ef4444",
                    "Action Required": "#f59e0b",
                    "Shipped": "#0891b2" if not self.dark else "#22d3ee",
                    "Ready for Pickup": "#7c3aed" if not self.dark else "#c4b5fd",
                    "Processing": "#2563eb" if not self.dark else "#60a5fa",
                }
                if status in palette:
                    return QBrush(QColor(palette[status]))
        if role == Qt.ToolTipRole:
            if key == "destination":
                if (row["order_type"] or "").lower() == "pickup":
                    return row["pickup_store"] or row["address"] or ""
                return row["address"] or ""
            if key == "alias_emails":
                return row["alias_emails"] or ""
            if key == "source_email":
                return "Gmail IMAP account used to fetch this message"
            if key == "order_number" and row["order_number"]:
                return "Click the order number to open Apple Order Status. Hover and click ⧉ to copy."
            if key == "status":
                if order_id in self.pending_status:
                    return "Unsaved status change. Click Save Changes to make it permanent."
                if "manual_status" in row.keys() and clean_text(row["manual_status"] or ""):
                    return "Manual override — highest priority. Click to choose a different status or Automatic."
                return ("Apple Account: " + row_value(row,"account_raw_status") + " | Last success: " + row_value(row,"account_status_success_at") + " | Error: " + (row_value(row,"account_status_error") or "None")) if row_value(row,"account_status") else "Click to manually override this order status."
            if key == "qty":
                if order_id in self.pending_qty:
                    return "Unsaved quantity change. Click Save Changes to make it permanent."
                if "manual_qty" in row.keys() and row["manual_qty"] is not None:
                    return "Manual quantity override — highest priority. Click to change it."
                return "Click to manually override the quantity."
        return None

    def sort(self, column: int, order=Qt.AscendingOrder):
        if not (0 <= column < len(self.COLUMNS)):
            return
        key = self.COLUMNS[column][0]
        if key in ("select", "image"):
            return
        self.layoutAboutToBeChanged.emit()
        reverse = order == Qt.DescendingOrder

        def sort_key(row):
            oid = int(row["id"])
            if key == "schedule":
                value = row["eta_date"] or row["eta_text"] or ""
            elif key == "status" and oid in self.pending_status:
                value = self.pending_status[oid] or (row["detected_status"] if "detected_status" in row.keys() else row["status"])
            elif key == "qty" and oid in self.pending_qty:
                value = self.pending_qty[oid]
            else:
                value = row[key] if key in row.keys() else ""
            if key == "qty":
                try:
                    return int(value or 0)
                except Exception:
                    return 0
            return str(value or "").lower()

        self.rows.sort(key=sort_key, reverse=reverse)
        self.image_rows = {}
        for i, row in enumerate(self.rows):
            url = safe_product_image_url(row["image_url"] or "")
            if url:
                self.image_rows.setdefault(url, []).append(i)
        self.layoutChanged.emit()

    def _image_ready(self, url: str):
        for row_idx in self.image_rows.get(url, []):
            idx = self.index(row_idx, 1)
            self.dataChanged.emit(idx, idx, [Qt.DecorationRole])

    def row_at(self, row_idx: int):
        if 0 <= row_idx < len(self.rows):
            return self.rows[row_idx]
        return None


class SyncRangeDialog(QDialog):
    """Choose which Gmail accounts and order-email date range to scan."""
    def __init__(self, db: Database, settings: QSettings, parent=None):
        super().__init__(parent)
        self.db = db
        self.settings = settings
        self.account_checks: dict[int, QCheckBox] = {}
        self.setWindowTitle(f"{APP_NAME} — Gmail Sync")
        self.resize(560, 540)
        self.setMinimumWidth(520)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(24, 22, 24, 22)
        lay.setSpacing(14)

        title = QLabel("Gmail Sync")
        title.setObjectName("dialogTitle")
        desc = QLabel("Choose exactly how Gmail should sync. New Emails Only is the fast everyday mode. Full Account Sync scans all historical Apple order mail and can run for a long time on large accounts.")
        desc.setObjectName("muted")
        desc.setWordWrap(True)
        lay.addWidget(title)
        lay.addWidget(desc)

        account_label = QLabel("Email Accounts")
        account_label.setObjectName("sectionTitle")
        lay.addWidget(account_label)
        account_box = QFrame(); account_box.setObjectName("detailCard")
        account_lay = QVBoxLayout(account_box); account_lay.setContentsMargins(14, 12, 14, 12); account_lay.setSpacing(8)
        accounts = [a for a in db.list_accounts() if a["enabled"]]
        for row in accounts:
            cb = QCheckBox(row["email"])
            cb.setChecked(True)
            self.account_checks[int(row["id"])] = cb
            account_lay.addWidget(cb)
        if not accounts:
            empty = QLabel("No enabled Gmail accounts. Close this window and add one under Gmail Accounts.")
            empty.setObjectName("muted"); empty.setWordWrap(True); account_lay.addWidget(empty)
        lay.addWidget(account_box)

        dates_title = QLabel("Date Range")
        dates_title.setObjectName("sectionTitle")
        lay.addWidget(dates_title)
        dates = QFrame(); dates.setObjectName("detailCard")
        form = QFormLayout(dates); form.setContentsMargins(14, 12, 14, 12); form.setSpacing(10)
        today = date.today()
        start_saved = clean_text(str(settings.value("sync_start_date", "") or ""))
        end_saved = clean_text(str(settings.value("sync_end_date", "") or ""))
        try: start_default = date.fromisoformat(start_saved)
        except Exception: start_default = today - timedelta(days=30)
        try: end_default = date.fromisoformat(end_saved)
        except Exception: end_default = today
        self.start_date = QDateEdit(QDate(start_default.year, start_default.month, start_default.day))
        self.end_date = QDateEdit(QDate(end_default.year, end_default.month, end_default.day))
        for w in (self.start_date, self.end_date):
            configure_date_edit(w)
            w.setDisplayFormat("MMM d, yyyy")
            w.setMinimumDate(QDate(2000, 1, 1))
            w.setMaximumDate(QDate.currentDate().addDays(1))
        form.addRow("Start date", self.start_date)
        form.addRow("End date", self.end_date)
        lay.addWidget(dates)

        mode_title = QLabel("Sync Mode")
        mode_title.setObjectName("sectionTitle")
        lay.addWidget(mode_title)
        self.mode_combo = QComboBox()
        self.mode_combo.addItem("New Emails Only — fastest (recommended)", "new")
        self.mode_combo.addItem("Full Account Sync — scan all historical Apple order emails", "full")
        # Always default to the safe/fast everyday mode. Full Account Sync must be
        # deliberately selected each time so a prior full scan cannot repeat by accident.
        self.mode_combo.setCurrentIndex(0)
        lay.addWidget(self.mode_combo)
        note = QLabel("New Emails Only uses the saved Gmail UID checkpoint and will not reread old mail. On a brand-new account it starts from the current mailbox position; run Full Account Sync once if you want existing historical orders. Full Account Sync ignores the checkpoint and scans all Apple order mail. The date range below only controls what the dashboard displays.")
        note.setObjectName("mutedSmall"); note.setWordWrap(True); lay.addWidget(note)
        lay.addStretch(1)

        actions = QHBoxLayout()
        cancel = QPushButton("Cancel")
        start = QPushButton("Start Sync")
        start.setObjectName("primaryButton")
        actions.addStretch(1); actions.addWidget(cancel); actions.addWidget(start)
        lay.addLayout(actions)
        cancel.clicked.connect(self.reject)
        start.clicked.connect(self._accept_valid)

    def _accept_valid(self):
        if not self.selected_account_ids():
            QMessageBox.warning(self, APP_NAME, "Select at least one Gmail account.")
            return
        if self.start_iso() > self.end_iso():
            QMessageBox.warning(self, APP_NAME, "The start date must be on or before the end date.")
            return
        self.settings.setValue("sync_start_date", self.start_iso())
        self.settings.setValue("sync_end_date", self.end_iso())
        self.accept()

    def sync_mode(self) -> str:
        return clean_text(str(self.mode_combo.currentData() or "new")).lower() or "new"

    def selected_account_ids(self) -> list[int]:
        return [account_id for account_id, cb in self.account_checks.items() if cb.isChecked()]

    def start_iso(self) -> str:
        qd = self.start_date.date()
        return date(qd.year(), qd.month(), qd.day()).isoformat()

    def end_iso(self) -> str:
        qd = self.end_date.date()
        return date(qd.year(), qd.month(), qd.day()).isoformat()


class OrderNumberDelegate(RowHoverDelegate):
    copyRequested = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.dark = False

    def set_dark(self, dark: bool):
        self.dark = dark

    def paint(self, painter: QPainter, option, index: QModelIndex):
        super().paint(painter, option, index)
        value = clean_text(str(index.data(Qt.DisplayRole) or ""))
        if not value or not (option.state & QStyle.State_MouseOver):
            return
        painter.save()
        rect = option.rect.adjusted(option.rect.width() - 34, 7, -7, -7)
        painter.setRenderHint(QPainter.Antialiasing, True)
        painter.setPen(QPen(QColor("#334155" if self.dark else "#bfdbfe"), 1))
        painter.setBrush(QColor("#172033" if self.dark else "#eff6ff"))
        painter.drawRoundedRect(rect, 7, 7)
        painter.setPen(QColor("#60a5fa" if self.dark else "#2563eb"))
        font = painter.font(); font.setBold(True); font.setPointSize(max(9, font.pointSize() - 1)); painter.setFont(font)
        painter.drawText(rect, Qt.AlignCenter, "⧉")
        painter.restore()

    def editorEvent(self, event, model, option, index: QModelIndex):
        if event.type() == QEvent.MouseButtonRelease and getattr(event, "button", lambda: None)() == Qt.LeftButton:
            value = clean_text(str(index.data(Qt.DisplayRole) or ""))
            if value:
                copy_rect = option.rect.adjusted(option.rect.width() - 38, 2, -2, -2)
                if copy_rect.contains(event.position().toPoint() if hasattr(event, "position") else event.pos()):
                    self.copyRequested.emit(value)
                    return True
        return super().editorEvent(event, model, option, index)


class CheckBoxDelegate(RowHoverDelegate):
    """Large centered checkbox for row-selection tables."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.dark = False

    def set_dark(self, dark: bool):
        self.dark = dark

    def paint(self, painter: QPainter, option, index: QModelIndex):
        painter.save()
        paint_cell_background(self, painter, option, index)
        checked = check_state_is_checked(index.data(Qt.CheckStateRole))
        size = 20
        x = option.rect.x() + (option.rect.width() - size) // 2
        y = option.rect.y() + (option.rect.height() - size) // 2
        rect = option.rect.__class__(x, y, size, size)
        painter.setRenderHint(QPainter.Antialiasing, True)
        border = QColor("#4f83ff" if checked else ("#64748b" if self.dark else "#94a3b8"))
        fill = QColor("#2563eb" if checked else ("#111b2d" if self.dark else "#ffffff"))
        painter.setPen(QPen(border, 1.6)); painter.setBrush(fill); painter.drawRoundedRect(rect, 5, 5)
        if checked:
            painter.setPen(QPen(QColor("#ffffff"), 2.2))
            painter.drawLine(x + 5, y + 10, x + 9, y + 14)
            painter.drawLine(x + 9, y + 14, x + 16, y + 6)
        painter.restore()

    def editorEvent(self, event, model, option, index: QModelIndex):
        if not index.isValid():
            return False
        activate = False
        if event.type() == QEvent.MouseButtonRelease and getattr(event, "button", lambda: None)() == Qt.LeftButton:
            activate = True
        elif event.type() == QEvent.KeyPress and getattr(event, "key", lambda: None)() in (Qt.Key_Space, Qt.Key_Return, Qt.Key_Enter):
            activate = True
        if activate:
            current = index.data(Qt.CheckStateRole)
            new_value = Qt.CheckState.Unchecked if check_state_is_checked(current) else Qt.CheckState.Checked
            return bool(model.setData(index, new_value, Qt.CheckStateRole))
        return False


class OrderSelectionTableView(HoverTableView):
    """Order table that makes the left selection checkbox unambiguously clickable.

    QTableView can suppress a checkable delegate's editorEvent when editing is
    disabled by the view. Handle the selection cell at the view level so a
    normal left-click always toggles it, while the rest of the row keeps the
    existing click/double-click behavior.
    """
    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            index = self.indexAt(event.position().toPoint() if hasattr(event, "position") else event.pos())
            if index.isValid() and index.data(Qt.CheckStateRole) is not None:
                current = index.data(Qt.CheckStateRole)
                new_value = Qt.CheckState.Unchecked if check_state_is_checked(current) else Qt.CheckState.Checked
                if self.model() and self.model().setData(index, new_value, Qt.CheckStateRole):
                    self.setCurrentIndex(index)
                    event.accept()
                    return
        super().mouseReleaseEvent(event)

    def keyPressEvent(self, event):
        index = self.currentIndex()
        if index.isValid() and index.data(Qt.CheckStateRole) is not None and event.key() in (Qt.Key_Space, Qt.Key_Return, Qt.Key_Enter):
            current = index.data(Qt.CheckStateRole)
            new_value = Qt.CheckState.Unchecked if check_state_is_checked(current) else Qt.CheckState.Checked
            if self.model() and self.model().setData(index, new_value, Qt.CheckStateRole):
                event.accept()
                return
        super().keyPressEvent(event)


class StatCard(QFrame):
    def __init__(self, title: str, icon: str = "•", parent=None):
        super().__init__(parent)
        self.setObjectName("statCard")
        lay = QHBoxLayout(self)
        lay.setContentsMargins(12, 8, 12, 8)
        lay.setSpacing(8)
        bubble = QLabel(icon)
        bubble.setObjectName("statIcon")
        bubble.setAlignment(Qt.AlignCenter)
        bubble.setFixedSize(28, 28)
        text = QVBoxLayout(); text.setSpacing(1)
        self.title = QLabel(title); self.title.setObjectName("statTitle")
        self.value = QLabel("0"); self.value.setObjectName("statValue")
        text.addWidget(self.title); text.addWidget(self.value)
        lay.addWidget(bubble); lay.addLayout(text); lay.addStretch(1)

    def set_value(self, value: int):
        self.value.setText(f"{value:,}")


class OrderDetailDialog(QDialog):
    def __init__(self, db: Database, row, parent=None):
        super().__init__(parent)
        self.db = db
        self.row = row
        self.setWindowTitle(f"Order {row['order_number']}")
        self.resize(900, 680)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 22, 24, 22)
        layout.setSpacing(14)

        top = QHBoxLayout()
        title_wrap = QVBoxLayout()
        title = QLabel(row["item_summary"] or "Apple order")
        title.setObjectName("dialogTitle")
        subtitle = QPushButton(f"Order {row['order_number']}  •  Qty {row['qty'] or 1}")
        subtitle.setObjectName("linkButton")
        subtitle.setCursor(Qt.PointingHandCursor)
        subtitle.setToolTip("Open this order on Apple Order Status")
        subtitle.clicked.connect(lambda: QDesktopServices.openUrl(QUrl(effective_apple_order_url(row))))
        title_wrap.addWidget(title)
        title_wrap.addWidget(subtitle, 0, Qt.AlignLeft)
        top.addLayout(title_wrap, 1)
        if row["order_url"]:
            apple_btn = QPushButton("View on Apple")
            apple_btn.clicked.connect(lambda: QDesktopServices.openUrl(QUrl(effective_apple_order_url(row))))
            top.addWidget(apple_btn)
        if row["tracking_number"]:
            track_btn = QPushButton("Track Package")
            track_btn.setObjectName("primaryButton")
            track_btn.clicked.connect(self._open_tracking)
            top.addWidget(track_btn)
        layout.addLayout(top)

        details = QFrame()
        details.setObjectName("detailCard")
        grid = QGridLayout(details)
        grid.setContentsMargins(18, 16, 18, 16)
        grid.setHorizontalSpacing(24)
        grid.setVerticalSpacing(9)
        fields = [
            ("Status", row["status"] or "Unknown"),
            ("Status source", row["status_source"] or "Apple Email"),
            ("Type", row["order_type"] or ""),
            ("Total", row["total"] or ""),
            ("Order date", row["order_date"] or ""),
            ("Pickup / delivery date", display_eta_value(row["eta_date"] or "", row["eta_text"] or "")),
            ("Arrival / check-in time", row["pickup_time"] or ""),
            ("Delivery time / window", row["delivery_time"] or ""),
            ("Apple Store", row["pickup_store"] or ""),
            ("Carrier", row["carrier"] or infer_carrier(row["tracking_number"] or "")),
            ("Tracking", row["tracking_number"] or ""),
            ("Carrier status", row["tracking_status"] or ""),
            ("Last UPS success", row_value(row,"tracking_success_at") or "Never"),
            ("Last UPS attempt", row_value(row,"tracking_checked_at") or "Never"),
            ("UPS check error", row_value(row,"tracking_error") or "None"),
            ("Alias email", row["alias_emails"] or ""),
            ("", ""),
            ("Phone number(s)", __import__('apple_account_ui').phone_summary(db,row)),
            ("Address", row["address"] or ""),
            ("Latest Apple email", row["subject"] or ""),
            ("IMAP source", row["source_email"] or ""),
        ]
        for i, (name, value) in enumerate(fields):
            r = i // 2
            c = (i % 2) * 2
            lbl = QLabel(name)
            lbl.setObjectName("fieldLabel")
            val = QLabel(str(value))
            val.setWordWrap(True)
            val.setTextInteractionFlags(Qt.TextSelectableByMouse)
            grid.addWidget(lbl, r, c)
            grid.addWidget(val, r, c + 1)
            if name == 'Phone number(s)':self._phone_value_label=val
        self._phone_refresh_timer=QTimer(self)
        self._phone_refresh_timer.setInterval(1800)
        self._phone_refresh_timer.timeout.connect(self._refresh_phone_values)
        self.finished.connect(lambda *_:self._phone_refresh_timer.stop())
        details_scroll = QScrollArea()
        details_scroll.setWidgetResizable(True)
        details_scroll.setWidget(details)
        details_scroll.setMinimumHeight(200)
        layout.addWidget(details_scroll, 2)
        from apple_account_ui import AppleDetailSection
        layout.addWidget(AppleDetailSection(db,int(row['id']),self))
        main_host = parent.window() if parent else None
        if main_host and hasattr(main_host,'apple_page'):
            refresh_apple=QPushButton('Refresh this order from Apple')
            refresh_apple.clicked.connect(lambda: main_host.apple_page.queue_batch([int(row['id'])],'refresh'))
            layout.addWidget(refresh_apple,0,Qt.AlignLeft)
        if row_value(row,"tracking_detail"):
            ups_text = QPlainTextEdit(); ups_text.setReadOnly(True); ups_text.setMaximumHeight(145)
            ups_text.setPlainText(row_value(row,"tracking_detail")); layout.addWidget(ups_text)

        history_title = QLabel("Order timeline")
        history_title.setObjectName("sectionTitle")
        layout.addWidget(history_title)
        history = QTableWidget(0, 3)
        history.setHorizontalHeaderLabels(["Date", "Status", "Source / event"])
        history.setEditTriggers(QAbstractItemView.NoEditTriggers)
        history.setSelectionBehavior(QAbstractItemView.SelectRows)
        history.verticalHeader().setVisible(False)
        history.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        history.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeToContents)
        history.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        events=[{'when':e['email_date'] or '', 'status':e['event_status'] or '', 'note':e['subject'] or ''}
                for e in db.history(int(row['account_id']),row['order_number'])]
        for e in db.conn.execute('SELECT observed_at,normalized_status,raw_status FROM apple_observations WHERE order_id=? ORDER BY sequence DESC LIMIT 100',(int(row['id']),)):
            events.append({'when':e['observed_at'],'status':e['normalized_status'],'note':'Apple Account: '+e['raw_status']})
        for e in sorted(events,key=lambda e:e['when'],reverse=True):
            n=history.rowCount();history.insertRow(n)
            history.setItem(n,0,QTableWidgetItem(e['when'][:19].replace('T',' ')))
            history.setItem(n,1,QTableWidgetItem(e['status']))
            history.setItem(n,2,QTableWidgetItem(e['note']))
        layout.addWidget(history, 1)

        close = QDialogButtonBox(QDialogButtonBox.Close)
        close.rejected.connect(self.reject)
        layout.addWidget(close)

    def showEvent(self, event):
        super().showEvent(event)
        self._refresh_phone_values()
        self._phone_refresh_timer.start()

    def hideEvent(self, event):
        self._phone_refresh_timer.stop()
        super().hideEvent(event)

    def _refresh_phone_values(self):
        row=self.db.order_by_id(int(self.row['id']))
        if row and hasattr(self,'_phone_value_label'):
            from apple_account_ui import phone_summary
            self._phone_value_label.setText(phone_summary(self.db,row))

    def _open_tracking(self):
        url = safe_tracking_url(self.row["tracking_url"] or "") or direct_tracking_url(self.row["tracking_number"] or "", self.row["carrier"] or "")
        if url:
            QDesktopServices.openUrl(QUrl(url))


class ScheduleOrderCard(QFrame):
    def __init__(self, db: Database, image_cache: ProductImageCache, row, parent=None):
        super().__init__(parent)
        self.db = db; self.image_cache = image_cache; self.row = row
        self.setObjectName("scheduleCard")
        self.setMinimumHeight(138)
        outer = QHBoxLayout(self); outer.setContentsMargins(18, 16, 18, 16); outer.setSpacing(16)

        self.image = QLabel(""); self.image.setObjectName("productThumb"); self.image.setAlignment(Qt.AlignCenter); self.image.setFixedSize(78, 78)
        outer.addWidget(self.image, 0, Qt.AlignTop)
        self.image_url = safe_product_image_url(row["image_url"] or "")
        if self.image_url:
            icon = image_cache.icon_for(self.image_url)
            if not icon.isNull(): self.image.setPixmap(icon.pixmap(72, 72))
            image_cache.ready.connect(self._image_ready)

        body = QVBoxLayout(); body.setSpacing(8); outer.addLayout(body, 1)
        top = QHBoxLayout(); top.setSpacing(10)
        type_lbl = QLabel((row["order_type"] or "Order").title()); type_lbl.setObjectName("typeBadge")
        item = QLabel(row["item_summary"] or "Apple order"); item.setObjectName("cardItem"); item.setWordWrap(True); item.setMaximumHeight(44)
        qty = QLabel(f"Qty {int(row['qty'] or 1)}"); qty.setObjectName("qtyBadge")
        top.addWidget(type_lbl); top.addWidget(item, 1); top.addWidget(qty); body.addLayout(top)

        mid = QHBoxLayout(); mid.setSpacing(12)
        status = row["status"] or "Unknown"
        pill = QLabel(f"{STATUS_GLYPHS.get(status, '•')}  {status}"); pill.setObjectName("statusBadge")
        fg, bg = STATUS_COLORS.get(status, STATUS_COLORS["Unknown"])
        if getattr(self.window(), "theme", "light") == "dark":
            bg = "#172554" if status in ("Processing", "Shipped") else "#2a203d" if status in ("Ready for Pickup", "Shipping to Store", "Check in Today") else "#153324" if status in ("Delivered", "Picked Up") else "#3a2613" if status == "Action Required" else "#1e293b"
            fg = "#93c5fd" if status in ("Processing", "Shipped") else "#c4b5fd" if status in ("Ready for Pickup", "Shipping to Store", "Check in Today") else "#86efac" if status in ("Delivered", "Picked Up") else "#fbbf24" if status == "Action Required" else "#cbd5e1"
        pill.setStyleSheet(f"color:{fg}; background:{bg}; border-radius:10px; padding:5px 9px; font-weight:700;")
        mid.addWidget(pill)
        order_btn = QPushButton(row["order_number"] or "Order"); order_btn.setObjectName("linkButton"); order_btn.setCursor(Qt.PointingHandCursor)
        order_btn.setToolTip("Open this order on Apple Order Status")
        order_btn.clicked.connect(self._open_order_status)
        mid.addWidget(order_btn)
        if row["tracking_number"]:
            carrier = row["carrier"] or infer_carrier(row["tracking_number"] or "") or "Carrier"
            track_btn = QPushButton(f"{carrier}: {row['tracking_number']}"); track_btn.setObjectName("linkButton"); track_btn.setCursor(Qt.PointingHandCursor)
            track_btn.clicked.connect(self._open_tracking); mid.addWidget(track_btn)
        mid.addStretch(1); body.addLayout(mid)

        fulfill = QHBoxLayout(); fulfill.setSpacing(22)
        kind = (row["order_type"] or "").lower()
        if kind == "pickup":
            store = row["pickup_store"] or pickup_store_from_address(row["address"] or "") or "Apple Store"
            where = QLabel(f"⌂  {store}"); where.setObjectName("fulfillmentPrimary")
            when = display_eta_value(row["eta_date"] or "", row["eta_text"] or "") or "Date not found"
            if row["pickup_time"]: when += f"  •  {row['pickup_time']}"
            timing = QLabel(f"◷  {when}"); timing.setObjectName("muted")
        else:
            carrier = row["carrier"] or infer_carrier(row["tracking_number"] or "") or "Shipping"
            where = QLabel(f"▰  {carrier} delivery"); where.setObjectName("fulfillmentPrimary")
            if row["status"] == "Delivered" and row["tracking_delivered_at"]:
                when = clean_text(row["tracking_delivered_at"]).replace("T", " ")
            else:
                when = display_eta_value(row["eta_date"] or "", row["eta_text"] or "") or "Delivery date not found"
                if row["delivery_time"]: when += f"  •  {row['delivery_time']}"
            timing = QLabel(f"◷  {when}"); timing.setObjectName("muted")
        where.setWordWrap(True); timing.setWordWrap(True)
        fulfill.addWidget(where, 0); fulfill.addWidget(timing, 1); body.addLayout(fulfill)

        details = QPushButton("View Details  ›"); details.setObjectName("secondaryAccent"); details.setFixedWidth(112); details.clicked.connect(self._details)
        outer.addWidget(details, 0, Qt.AlignVCenter)

    def _image_ready(self, url: str):
        if url != self.image_url: return
        icon = self.image_cache.icon_for(url)
        if not icon.isNull(): self.image.setPixmap(icon.pixmap(72, 72))

    def _open_order_status(self):
        url = effective_apple_order_url(self.row)
        if url: QDesktopServices.openUrl(QUrl(url))

    def _open_tracking(self):
        url = safe_tracking_url(self.row["tracking_url"] or "") or direct_tracking_url(self.row["tracking_number"] or "", self.row["carrier"] or "")
        if url: QDesktopServices.openUrl(QUrl(url))

    def _details(self):
        OrderDetailDialog(self.db, self.row, self).exec()


class ScheduleDialog(QDialog):
    def __init__(self, db: Database, image_cache: ProductImageCache, initial_date: date | None = None, parent=None):
        super().__init__(parent)
        self.db = db; self.image_cache = image_cache
        self.setWindowTitle("Delivery & Pickup Calendar")
        self.resize(1320, 820); self.setMinimumSize(1060, 680)
        outer = QVBoxLayout(self); outer.setContentsMargins(28, 24, 28, 22); outer.setSpacing(14)
        title = QLabel("Delivery & Pickup Calendar"); title.setObjectName("dialogTitle")
        desc = QLabel("Select a date. Orders are shown as spacious cards with only the details that matter for that day.")
        desc.setObjectName("muted"); desc.setWordWrap(True); outer.addWidget(title); outer.addWidget(desc)

        splitter = QSplitter(Qt.Horizontal); splitter.setChildrenCollapsible(False)
        left = QFrame(); left.setObjectName("calendarPanel"); left.setMinimumWidth(360); left.setMaximumWidth(430)
        left_lay = QVBoxLayout(left); left_lay.setContentsMargins(16, 16, 16, 16); left_lay.setSpacing(12)
        self.calendar = OrderActivityCalendar()
        left_lay.addWidget(self.calendar, 1)
        today_btn = QPushButton("Jump to Today"); today_btn.clicked.connect(lambda: self.calendar.setSelectedDate(QDate.currentDate())); left_lay.addWidget(today_btn)
        splitter.addWidget(left)

        right = QFrame(); right.setObjectName("schedulePanel")
        right_lay = QVBoxLayout(right); right_lay.setContentsMargins(20, 18, 20, 18); right_lay.setSpacing(10)
        self.day_title = QLabel(""); self.day_title.setObjectName("sectionTitle")
        self.day_summary = QLabel(""); self.day_summary.setObjectName("muted")
        day_head = QHBoxLayout(); day_head.setSpacing(8)
        day_head.addWidget(self.day_title, 1)
        self.bulk_btn = QPushButton("Bulk Tracking")
        self.bulk_btn.setObjectName("secondaryAccent")
        self.export_day_btn = QPushButton("Export Day")
        self.export_day_btn.setObjectName("primaryButton")
        day_head.addWidget(self.bulk_btn); day_head.addWidget(self.export_day_btn)
        right_lay.addLayout(day_head); right_lay.addWidget(self.day_summary)
        self.order_scroll = QScrollArea(); self.order_scroll.setWidgetResizable(True); self.order_scroll.setFrameShape(QFrame.NoFrame)
        self.order_host = QWidget(); self.order_layout = QVBoxLayout(self.order_host); self.order_layout.setContentsMargins(0, 6, 8, 6); self.order_layout.setSpacing(12); self.order_layout.addStretch(1)
        self.order_scroll.setWidget(self.order_host); right_lay.addWidget(self.order_scroll, 1)
        splitter.addWidget(right); splitter.setStretchFactor(0, 0); splitter.setStretchFactor(1, 1); splitter.setSizes([390, 900])
        outer.addWidget(splitter, 1)
        buttons = QDialogButtonBox(QDialogButtonBox.Close); buttons.rejected.connect(self.reject); outer.addWidget(buttons)

        self.current_rows = []
        self.current_date = initial_date or date.today()
        self.calendar.selectionChanged.connect(self._load_selected)
        self.export_day_btn.clicked.connect(self._export_selected_day)
        self.bulk_btn.clicked.connect(self._open_bulk_tracking)
        start = date.today() - timedelta(days=365); end = date.today() + timedelta(days=365)
        self._apply_activity_marks(start, end)
        chosen = initial_date or date.today(); self.calendar.setSelectedDate(QDate(chosen.year, chosen.month, chosen.day)); self._load_selected()

    def _clear_cards(self):
        while self.order_layout.count():
            item = self.order_layout.takeAt(0); w = item.widget()
            if w: w.deleteLater()

    def _apply_activity_marks(self, start: date, end: date):
        rows = self.db.activity_days(start.isoformat(), end.isoformat()); counts: dict[str, int] = {}
        for row in rows: counts[row["activity_date"]] = counts.get(row["activity_date"], 0) + int(row["order_count"] or 0)
        for iso, count in counts.items():
            try: d = date.fromisoformat(iso)
            except Exception: continue
            fmt = QTextCharFormat(); fmt.setFontWeight(QFont.Bold); fmt.setToolTip(f"{count} order{'s' if count != 1 else ''} with activity")
            fmt.setBackground(QColor("#dbeafe")); fmt.setForeground(QColor("#1d4ed8")); self.calendar.setDateTextFormat(QDate(d.year, d.month, d.day), fmt)

    def _load_selected(self):
        qd = self.calendar.selectedDate(); selected = date(qd.year(), qd.month(), qd.day())
        rows = self.db.orders_for_activity_date(selected.isoformat()); self._clear_cards()
        self.current_date = selected
        self.current_rows = list(rows)
        items = sum(int(r["qty"] or 1) for r in rows); labels: dict[str, int] = {}
        for r in rows:
            label = r["activity_label"] or r["status"] or "Order"; labels[label] = labels.get(label, 0) + 1
            self.order_layout.addWidget(ScheduleOrderCard(self.db, self.image_cache, r, self.order_host))
        if not rows:
            empty = QFrame(); empty.setObjectName("emptyState"); el = QVBoxLayout(empty); el.setContentsMargins(26, 40, 26, 40)
            icon = QLabel("◷"); icon.setObjectName("emptyIcon"); icon.setAlignment(Qt.AlignCenter)
            msg = QLabel("No pickup, delivery, delivered, or picked-up activity for this date."); msg.setObjectName("muted"); msg.setAlignment(Qt.AlignCenter); msg.setWordWrap(True)
            el.addWidget(icon); el.addWidget(msg); self.order_layout.addWidget(empty)
        self.order_layout.addStretch(1)
        self.day_title.setText(selected.strftime("%A, %B %d, %Y"))
        breakdown = "   •   ".join(f"{k}: {v}" for k, v in labels.items())
        self.day_summary.setText(f"{len(rows):,} order{'s' if len(rows) != 1 else ''}   •   {items:,} item{'s' if items != 1 else ''}" + (f"   •   {breakdown}" if breakdown else ""))
        self.export_day_btn.setEnabled(bool(rows))
        has_tracking = any(split_tracking_numbers(r["tracking_number"] or "") for r in rows)
        self.bulk_btn.setEnabled(has_tracking)
        self.bulk_btn.setToolTip("Copy/open all tracking numbers for this day" if has_tracking else "Bulk tracking is unavailable because this day has no shipment tracking numbers")

    def _export_selected_day(self):
        if not self.current_rows:
            return
        settings = QSettings("Local", "AppleOrderTracker")
        label = self.current_date.strftime("%A, %B %d, %Y")
        save_rows_csv(self, settings, self.current_rows, f"apple_orders_{self.current_date.isoformat()}", f"Selected day — {label}")

    def _open_bulk_tracking(self):
        if not self.current_rows:
            return
        BulkTrackingDialog(self.current_rows, self.current_date, self).exec()


class OrderActivityCalendar(ReadableCalendar):
    """Shared full-page/calendar-popup renderer, with no inherited table padding."""
    pass


class SchedulePage(QWidget):
    """Full-page Delivery & Pickup Calendar used inside the main navigation stack."""
    def __init__(self, db: Database, image_cache: ProductImageCache, parent=None):
        super().__init__(parent)
        self.db = db
        self.image_cache = image_cache
        self.current_rows = []
        self.current_date = date.today()
        outer = QVBoxLayout(self)
        outer.setContentsMargins(30, 24, 30, 20)
        outer.setSpacing(14)

        title = QLabel("Delivery & Pickup Calendar")
        title.setObjectName("pageTitle")
        desc = QLabel("Select a date to review scheduled deliveries and pickups, plus completed Delivered or Picked Up activity.")
        desc.setObjectName("muted")
        desc.setWordWrap(True)
        outer.addWidget(title)
        outer.addWidget(desc)

        splitter = QSplitter(Qt.Horizontal)
        splitter.setChildrenCollapsible(False)
        left = QFrame(); left.setObjectName("calendarPanel"); left.setMinimumWidth(360); left.setMaximumWidth(440)
        left_lay = QVBoxLayout(left); left_lay.setContentsMargins(16,16,16,16); left_lay.setSpacing(12)
        self.calendar = OrderActivityCalendar()
        left_lay.addWidget(self.calendar, 1)
        today_btn = QPushButton("Jump to Today"); today_btn.clicked.connect(lambda: self.set_date(date.today())); left_lay.addWidget(today_btn)
        splitter.addWidget(left)

        right = QFrame(); right.setObjectName("schedulePanel")
        right_lay = QVBoxLayout(right); right_lay.setContentsMargins(20,18,20,18); right_lay.setSpacing(10)
        day_head = QHBoxLayout(); day_head.setSpacing(8)
        self.day_title = QLabel(""); self.day_title.setObjectName("sectionTitle"); day_head.addWidget(self.day_title,1)
        self.bulk_btn = QPushButton("Bulk Tracking"); self.bulk_btn.setObjectName("secondaryAccent")
        self.export_day_btn = QPushButton("Export Day"); self.export_day_btn.setObjectName("primaryButton")
        day_head.addWidget(self.bulk_btn); day_head.addWidget(self.export_day_btn)
        right_lay.addLayout(day_head)
        self.day_summary = QLabel(""); self.day_summary.setObjectName("muted"); self.day_summary.setWordWrap(True); right_lay.addWidget(self.day_summary)
        self.order_scroll = QScrollArea(); self.order_scroll.setWidgetResizable(True); self.order_scroll.setFrameShape(QFrame.NoFrame)
        self.order_host = QWidget(); self.order_layout = QVBoxLayout(self.order_host); self.order_layout.setContentsMargins(0,6,8,6); self.order_layout.setSpacing(12)
        self.order_scroll.setWidget(self.order_host); right_lay.addWidget(self.order_scroll,1)
        splitter.addWidget(right); splitter.setStretchFactor(0,0); splitter.setStretchFactor(1,1); splitter.setSizes([400,900])
        outer.addWidget(splitter,1)

        self.calendar.selectionChanged.connect(self._load_selected)
        self.export_day_btn.clicked.connect(self._export_selected_day)
        self.bulk_btn.clicked.connect(self._open_bulk_tracking)
        self.refresh_activity_marks()
        self.set_date(date.today())

    def refresh_activity_marks(self):
        start = date.today() - timedelta(days=365)
        end = date.today() + timedelta(days=365)
        rows = self.db.activity_days(start.isoformat(), end.isoformat())
        counts: dict[str, int] = {}
        for row in rows:
            counts[row["activity_date"]] = counts.get(row["activity_date"], 0) + int(row["order_count"] or 0)
        self.calendar.set_activity_counts(counts)
        # Keep a tooltip/bold cue, but avoid the old blue block that hid the date.
        self.calendar.setDateTextFormat(QDate(), QTextCharFormat())
        for iso, count in counts.items():
            try: d = date.fromisoformat(iso)
            except Exception: continue
            fmt = QTextCharFormat(); fmt.setFontWeight(QFont.Bold); fmt.setToolTip(f"{count} order{'s' if count != 1 else ''} on this date")
            self.calendar.setDateTextFormat(QDate(d.year,d.month,d.day), fmt)

    def set_dark(self, dark: bool):
        self.calendar.set_dark(dark)

    def set_date(self, selected: date | None = None):
        selected = selected or date.today()
        self.current_date = selected
        target = QDate(selected.year, selected.month, selected.day)
        if self.calendar.selectedDate() != target:
            self.calendar.setSelectedDate(target)
        self._load_selected()

    def refresh_current(self):
        self.refresh_activity_marks()
        self._load_selected()

    def _clear_cards(self):
        while self.order_layout.count():
            item = self.order_layout.takeAt(0); w = item.widget()
            if w: w.deleteLater()

    def _load_selected(self):
        qd = self.calendar.selectedDate(); selected = date(qd.year(), qd.month(), qd.day())
        rows = self.db.orders_for_activity_date(selected.isoformat())
        self._clear_cards(); self.current_date = selected; self.current_rows = list(rows)
        items = sum(int(r["qty"] or 1) for r in rows); labels: dict[str,int] = {}
        for r in rows:
            label = r["activity_label"] or r["status"] or "Order"; labels[label] = labels.get(label,0)+1
            self.order_layout.addWidget(ScheduleOrderCard(self.db,self.image_cache,r,self.order_host))
        if not rows:
            empty = QFrame(); empty.setObjectName("emptyState"); el = QVBoxLayout(empty); el.setContentsMargins(26,40,26,40)
            icon = QLabel("◷"); icon.setObjectName("emptyIcon"); icon.setAlignment(Qt.AlignCenter)
            msg = QLabel("No pickup, delivery, delivered, or picked-up activity for this date."); msg.setObjectName("muted"); msg.setAlignment(Qt.AlignCenter); msg.setWordWrap(True)
            el.addWidget(icon); el.addWidget(msg); self.order_layout.addWidget(empty)
        self.order_layout.addStretch(1)
        self.day_title.setText(selected.strftime("%A, %B %d, %Y"))
        breakdown = "   •   ".join(f"{k}: {v}" for k,v in labels.items())
        self.day_summary.setText(f"{len(rows):,} order{'s' if len(rows) != 1 else ''}   •   {items:,} item{'s' if items != 1 else ''}" + (f"   •   {breakdown}" if breakdown else ""))
        self.export_day_btn.setEnabled(bool(rows))
        has_tracking = any(split_tracking_numbers(r["tracking_number"] or "") for r in rows)
        self.bulk_btn.setEnabled(has_tracking)
        self.bulk_btn.setToolTip("Copy/open all tracking numbers for this day" if has_tracking else "Bulk tracking is unavailable because this date contains only pickup orders or orders without tracking numbers")

    def _export_selected_day(self):
        if self.current_rows:
            save_rows_csv(self, QSettings("Local","AppleOrderTracker"), self.current_rows,
                          f"apple_orders_{self.current_date.isoformat()}",
                          f"Selected day — {self.current_date.strftime('%A, %B %d, %Y')}")

    def _open_bulk_tracking(self):
        if self.bulk_btn.isEnabled() and self.current_rows:
            BulkTrackingDialog(self.current_rows, self.current_date, self).exec()


EXPORT_FIELDS = [
    ("retailer", "Retailer"),
    ("order_number", "Order #"),
    ("item_summary", "Item"),
    ("storage", "Storage / Size"),
    ("color", "Color"),
    ("qty", "Qty"),
    ("order_type", "Type"),
    ("status", "Status"),
    ("status_source", "Status Source"),
    ("total", "Total"),
    ("tracking_number", "Tracking #"),
    ("carrier", "Carrier"),
    ("tracking_status", "Carrier Status"),
    ("tracking_detail", "UPS Package Details"),
    ("tracking_error", "UPS Last Check Error"),
    ("tracking_success_at", "UPS Last Successful Check"),
    ("address", "Shipping Address"),
    ("pickup_store", "Apple Store"),
    ("pickup_date", "Pickup Date"),
    ("pickup_time", "Arrival Time"),
    ("delivery_date", "Delivery Date"),
    ("delivery_time", "Delivery Time"),
    ("alias_emails", "Alias Email"),
    ("order_date", "Order Date"),
    ("source_email", "IMAP Source"),
    ("order_url", "Apple Order URL"),
    ("tracking_url", "Tracking URL"),
    ("last_email_date", "Last Email Update"),
]

DEFAULT_EXPORT_FIELDS = {
    "order_number", "item_summary", "qty", "status", "total", "tracking_number",
    "pickup_store", "pickup_date", "pickup_time", "delivery_date", "delivery_time", "address", "order_date"
}


class ExportDialog(QDialog):
    def __init__(self, settings: QSettings, visible_count: int, total_count: int, parent=None, fixed_scope_label: str = ""):
        super().__init__(parent)
        self.settings = settings
        self.checkboxes: dict[str, QCheckBox] = {}
        self.setWindowTitle("Export Orders")
        self.resize(620, 620)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(22, 20, 22, 20)
        layout.setSpacing(12)

        title = QLabel("Export Orders")
        title.setObjectName("dialogTitle")
        desc = QLabel("Choose exactly which columns you want in the CSV. Unchecked fields will not appear in the file.")
        desc.setWordWrap(True)
        desc.setObjectName("muted")
        layout.addWidget(title)
        layout.addWidget(desc)

        self.scope = QComboBox()
        if fixed_scope_label:
            self.scope.addItem(f"{fixed_scope_label} ({visible_count:,} orders)", "fixed")
            self.scope.setEnabled(False)
        else:
            self.scope.addItem(f"Current view ({visible_count:,} orders)", "current")
            self.scope.addItem(f"All orders ({total_count:,} orders)", "all")
        layout.addWidget(self.scope)

        tools = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search export fields…")
        select_all = QPushButton("Select All")
        clear = QPushButton("Clear")
        tools.addWidget(self.search, 1)
        tools.addWidget(select_all)
        tools.addWidget(clear)
        layout.addLayout(tools)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        host = QWidget()
        grid = QGridLayout(host)
        grid.setContentsMargins(2, 4, 10, 4)
        grid.setHorizontalSpacing(24)
        grid.setVerticalSpacing(6)
        saved = self.settings.value("export_fields", [])
        if isinstance(saved, str):
            saved = [x for x in saved.split(",") if x]
        selected = set(saved or DEFAULT_EXPORT_FIELDS)
        for i, (key, label) in enumerate(EXPORT_FIELDS):
            cb = QCheckBox(label)
            cb.setChecked(key in selected)
            cb.setProperty("exportKey", key)
            self.checkboxes[key] = cb
            grid.addWidget(cb, i // 2, i % 2)
        grid.setRowStretch((len(EXPORT_FIELDS) + 1) // 2, 1)
        scroll.setWidget(host)
        layout.addWidget(scroll, 1)

        self.selection_label = QLabel("")
        self.selection_label.setObjectName("muted")
        layout.addWidget(self.selection_label)

        buttons = QHBoxLayout()
        cancel = QPushButton("Cancel")
        export = QPushButton("Export CSV")
        export.setObjectName("primaryButton")
        buttons.addStretch(1)
        buttons.addWidget(cancel)
        buttons.addWidget(export)
        layout.addLayout(buttons)

        self.search.textChanged.connect(self._filter)
        select_all.clicked.connect(lambda: self._set_all(True))
        clear.clicked.connect(lambda: self._set_all(False))
        cancel.clicked.connect(self.reject)
        export.clicked.connect(self._accept_if_valid)
        for cb in self.checkboxes.values():
            cb.toggled.connect(self._update_count)
        self._update_count()

    def _filter(self, text: str):
        needle = text.strip().lower()
        for key, cb in self.checkboxes.items():
            label = dict(EXPORT_FIELDS)[key]
            cb.setVisible(not needle or needle in label.lower())

    def _set_all(self, checked: bool):
        for cb in self.checkboxes.values():
            if cb.isVisible():
                cb.setChecked(checked)

    def _update_count(self):
        count = sum(1 for cb in self.checkboxes.values() if cb.isChecked())
        self.selection_label.setText(f"{count} field{'s' if count != 1 else ''} selected")

    def _accept_if_valid(self):
        if not self.selected_fields():
            QMessageBox.warning(self, APP_NAME, "Select at least one export field.")
            return
        self.settings.setValue("export_fields", self.selected_fields())
        self.accept()

    def selected_fields(self) -> list[str]:
        return [key for key, _ in EXPORT_FIELDS if self.checkboxes[key].isChecked()]

    def scope_value(self) -> str:
        return str(self.scope.currentData())


def export_value_for_field(row, key: str):
    if key == "retailer":
        return "Apple"
    if key == "storage":
        return derive_storage(row["item_summary"] or "")
    if key == "color":
        return derive_color(row["item_summary"] or "")
    if key == "carrier":
        return row["carrier"] or infer_carrier(row["tracking_number"] or "")
    if key == "address":
        return (row["address"] or "") if (row["order_type"] or "").lower() == "shipping" else ""
    if key == "pickup_store":
        return (row["pickup_store"] or pickup_store_from_address(row["address"] or "")) if (row["order_type"] or "").lower() == "pickup" else ""
    if key == "pickup_date":
        return display_eta_value(row["eta_date"] or "", row["eta_text"] or "") if (row["order_type"] or "").lower() == "pickup" else ""
    if key == "delivery_date":
        return display_eta_value(row["eta_date"] or "", row["eta_text"] or "") if (row["order_type"] or "").lower() == "shipping" else ""
    if key == "delivery_time":
        return (row["delivery_time"] or "") if (row["order_type"] or "").lower() == "shipping" else ""
    value = row[key] if key in row.keys() else ""
    return value if value is not None else ""


def save_rows_csv(parent, settings: QSettings, rows, default_stem: str, fixed_scope_label: str = "") -> bool:
    rows = list(rows)
    if not rows:
        QMessageBox.information(parent, APP_NAME, "There are no orders to export for this selection.")
        return False
    dlg = ExportDialog(settings, len(rows), len(rows), parent, fixed_scope_label=fixed_scope_label)
    if dlg.exec() != QDialog.Accepted:
        return False
    fields = dlg.selected_fields()
    labels = dict(EXPORT_FIELDS)
    desktop = Path.home() / "Desktop"
    default_dir = desktop if desktop.exists() else Path.home()
    default_name = str(default_dir / f"{default_stem}.csv")
    path, _ = QFileDialog.getSaveFileName(parent, "Export Apple Orders", default_name, "CSV Files (*.csv)")
    if not path:
        return False
    if not path.lower().endswith(".csv"):
        path += ".csv"
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow([labels[key] for key in fields])
        for row in rows:
            writer.writerow([export_value_for_field(row, key) for key in fields])
    QMessageBox.information(parent, APP_NAME, f"Exported {len(rows):,} orders with {len(fields)} selected fields to:\n{path}")
    return True


class BulkTrackingDialog(QDialog):
    def __init__(self, rows, selected_date: date | None = None, parent=None, context_label: str = ""):
        super().__init__(parent)
        self.rows = list(rows)
        self.selected_date = selected_date
        self.context_label = context_label or (selected_date.strftime("%A, %B %d, %Y") if selected_date else "Selected orders")
        self.entries: list[tuple[str, str]] = []
        seen: set[str] = set()
        for row in self.rows:
            hint = row["carrier"] or ""
            for number in split_tracking_numbers(row["tracking_number"] or ""):
                if number in seen:
                    continue
                seen.add(number)
                self.entries.append((normalize_carrier_name(hint) or infer_carrier(number) or "Carrier", number))
        self.setWindowTitle("Bulk Tracking")
        self.resize(720, 620)
        lay = QVBoxLayout(self); lay.setContentsMargins(24, 22, 24, 22); lay.setSpacing(12)
        title = QLabel(f"Bulk Tracking — {self.context_label}")
        title.setObjectName("dialogTitle")
        desc = QLabel("All tracking numbers in this selection. Copy them as a batch or generate a local tracking page with direct carrier links.")
        desc.setObjectName("muted"); desc.setWordWrap(True)
        lay.addWidget(title); lay.addWidget(desc)
        grouped: dict[str, list[str]] = {}
        for carrier, number in self.entries:
            grouped.setdefault(carrier, []).append(number)
        summary = "   •   ".join(f"{carrier}: {len(nums)}" for carrier, nums in grouped.items()) or "No tracking numbers"
        sm = QLabel(summary); sm.setObjectName("muted"); lay.addWidget(sm)
        self.text = QPlainTextEdit(); self.text.setReadOnly(True); self.text.setPlainText("\n".join(n for _, n in self.entries)); self.text.setMinimumHeight(260)
        lay.addWidget(self.text, 1)
        tip = QLabel("UPS, FedEx and USPS public tracking pages accept multiple numbers in their web interfaces; where a carrier does not accept a shareable batch URL, the generated page provides one direct link per package.")
        tip.setObjectName("mutedSmall"); tip.setWordWrap(True); lay.addWidget(tip)
        row = QHBoxLayout()
        copy_btn = QPushButton("Copy All")
        page_btn = QPushButton("Generate Tracking Page")
        page_btn.setObjectName("primaryButton")
        open_btn = QPushButton("Open Carrier Tracking")
        row.addWidget(copy_btn); row.addStretch(1); row.addWidget(open_btn); row.addWidget(page_btn)
        lay.addLayout(row)
        close = QDialogButtonBox(QDialogButtonBox.Close); close.rejected.connect(self.reject); lay.addWidget(close)
        copy_btn.clicked.connect(self.copy_all)
        page_btn.clicked.connect(self.generate_page)
        open_btn.clicked.connect(self.open_carrier_pages)
        enabled = bool(self.entries)
        copy_btn.setEnabled(enabled); page_btn.setEnabled(enabled); open_btn.setEnabled(enabled)

    def copy_all(self):
        QApplication.clipboard().setText("\n".join(n for _, n in self.entries))

    def open_carrier_pages(self):
        self.copy_all()
        carriers = []
        for carrier, _ in self.entries:
            if carrier not in carriers:
                carriers.append(carrier)
        pages = {
            "UPS": "https://www.ups.com/track?loc=en_US&requester=ST/",
            "FedEx": "https://www.fedex.com/en-us/tracking.html",
            "USPS": "https://tools.usps.com/go/TrackConfirmAction_input",
            "DHL": "https://www.dhl.com/us-en/home/tracking.html",
            "OnTrac": "https://www.ontrac.com/tracking/",
            "Veho": "https://track.shipveho.com/",
        }
        opened = False
        for carrier in carriers:
            url = pages.get(carrier)
            if url:
                QDesktopServices.openUrl(QUrl(url)); opened = True
        if opened:
            QMessageBox.information(self, APP_NAME, "Tracking numbers were copied to the clipboard. Paste them into the carrier page when needed.")

    def generate_page(self):
        track_dir = app_data_dir() / "bulk_tracking"
        track_dir.mkdir(parents=True, exist_ok=True)
        stamp = self.selected_date.isoformat() if self.selected_date else date.today().isoformat()
        token = hashlib.sha256((self.context_label + "|" + "|".join(n for _, n in self.entries)).encode()).hexdigest()[:10]
        path = track_dir / f"tracking_{stamp}_{token}.html"
        groups: dict[str, list[str]] = {}
        for carrier, number in self.entries:
            groups.setdefault(carrier, []).append(number)
        blocks = []
        for carrier, numbers in groups.items():
            links = []
            for n in numbers:
                url = direct_tracking_url(n, carrier)
                links.append(f'<li><code>{html.escape(n)}</code> &nbsp; <a href="{html.escape(url)}">Open tracking</a></li>' if url else f'<li><code>{html.escape(n)}</code></li>')
            blocks.append(f'<section><h2>{html.escape(carrier)}</h2><textarea readonly>{html.escape(chr(10).join(numbers))}</textarea><ul>{"".join(links)}</ul></section>')
        doc = f"""<!doctype html><html><head><meta charset=\"utf-8\"><title>Ah Pa Ta Tracker - Bulk Tracking</title><style>body{{font-family:Segoe UI,Arial,sans-serif;max-width:900px;margin:40px auto;padding:0 24px;color:#172033}}section{{border:1px solid #dfe7f1;border-radius:14px;padding:18px;margin:16px 0;background:#f8fafc}}textarea{{width:100%;min-height:110px;padding:12px;box-sizing:border-box;border:1px solid #cbd5e1;border-radius:9px;font:14px Consolas,monospace}}li{{margin:9px 0}}a{{color:#2563eb}}.muted{{color:#64748b}}</style></head><body><h1>Bulk Tracking</h1><p class=\"muted\">{html.escape(self.context_label)} · {len(self.entries)} package(s)</p>{''.join(blocks)}</body></html>"""
        path.write_text(doc, encoding="utf-8")
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))
        QApplication.clipboard().setText(QUrl.fromLocalFile(str(path)).toString())



class TrackingTableModel(QAbstractTableModel):
    checkedChanged = Signal()
    COLUMNS = [
        ("select", "Select"),
        ("order_number", "Order #"),
        ("tracking_number", "Tracking #"),
        ("eta_date", "Delivery Date"),
        ("delivery_time", "Delivery Window"),
        ("address", "Address"),
        ("item_summary", "Item"),
        ("qty", "Qty"),
        ("carrier", "Carrier"),
        ("display_status", "Status"),
        ("order_date", "Order Date"),
    ]

    def __init__(self, parent=None):
        super().__init__(parent)
        self.rows=[]
        self.dark=False
        self.checked_ids: set[int] = set()

    def set_rows(self, rows):
        old_checked=set(self.checked_ids)
        self.beginResetModel(); self.rows=list(rows)
        visible={int(r["id"]) for r in self.rows}
        self.checked_ids=old_checked & visible
        self.endResetModel()
        self.checkedChanged.emit()

    def set_dark(self, dark: bool):
        self.dark=dark
        if self.rows: self.dataChanged.emit(self.index(0,0),self.index(len(self.rows)-1,len(self.COLUMNS)-1))

    def rowCount(self,parent=QModelIndex()): return 0 if parent.isValid() else len(self.rows)
    def columnCount(self,parent=QModelIndex()): return 0 if parent.isValid() else len(self.COLUMNS)

    def headerData(self,section,orientation,role=Qt.DisplayRole):
        if orientation==Qt.Horizontal and 0<=section<len(self.COLUMNS):
            if role==Qt.DisplayRole: return self.COLUMNS[section][1]
            if role==Qt.TextAlignmentRole: return int(Qt.AlignCenter)
            if role==Qt.ToolTipRole and self.COLUMNS[section][0]=="select": return "Select shipments to export"
        return None

    def flags(self,index):
        if not index.isValid(): return Qt.NoItemFlags
        flags=Qt.ItemIsEnabled|Qt.ItemIsSelectable
        if self.COLUMNS[index.column()][0]=="select": flags|=Qt.ItemIsUserCheckable
        return flags

    def setData(self,index,value,role=Qt.EditRole):
        if not index.isValid() or self.COLUMNS[index.column()][0]!="select" or role!=Qt.CheckStateRole: return False
        row=self.row_at(index.row())
        if not row: return False
        oid=int(row["id"])
        if check_state_is_checked(value): self.checked_ids.add(oid)
        else: self.checked_ids.discard(oid)
        self.dataChanged.emit(index,index,[Qt.CheckStateRole]); self.checkedChanged.emit(); return True

    def checked_order_ids(self):
        return [int(r["id"]) for r in self.rows if int(r["id"]) in self.checked_ids]

    def clear_checked(self):
        self.checked_ids.clear()
        if self.rows: self.dataChanged.emit(self.index(0,0),self.index(len(self.rows)-1,0),[Qt.CheckStateRole])
        self.checkedChanged.emit()

    def set_all_checked(self,checked=True):
        self.checked_ids={int(r["id"]) for r in self.rows} if checked else set()
        if self.rows: self.dataChanged.emit(self.index(0,0),self.index(len(self.rows)-1,0),[Qt.CheckStateRole])
        self.checkedChanged.emit()

    def _display_status(self,row):
        # The order status field is authoritative. Manual overrides are already
        # resolved into it by Database.recompute_order_status().
        return row["status"] or "Shipped"

    def data(self,index,role=Qt.DisplayRole):
        if not index.isValid() or not (0<=index.row()<len(self.rows)): return None
        row=self.rows[index.row()]; key=self.COLUMNS[index.column()][0]
        if role == Qt.ToolTipRole and key in ("status", "display_status"):
            return tracking_status_tip(row) + "\nManual overrides remain highest priority."
        if role==Qt.UserRole: return int(row["id"])
        if key=="select" and role==Qt.CheckStateRole:
            return Qt.CheckState.Checked if int(row["id"]) in self.checked_ids else Qt.CheckState.Unchecked
        if role==Qt.DisplayRole:
            if key=="select": return ""
            if key=="eta_date": return display_eta_value(row["eta_date"] or "", row["eta_text"] or "") or "—"
            if key=="delivery_time": return row["delivery_time"] or "—"
            if key=="address": return row["address"] or "—"
            if key=="carrier": return row["carrier"] or infer_carrier(row["tracking_number"] or "") or "—"
            if key=="display_status": return self._display_status(row)
            value=row[key] if key in row.keys() else ""; return str(value if value is not None else "")
        if role==Qt.TextAlignmentRole: return int(Qt.AlignCenter|Qt.AlignVCenter)
        if role==Qt.FontRole and key in ("order_number","tracking_number","display_status"):
            f=QFont(); f.setUnderline(key in ("order_number","tracking_number")); f.setBold(key=="display_status"); return f
        if role==Qt.ForegroundRole and key in ("order_number","tracking_number"):
            return QBrush(QColor("#8fb4ff" if self.dark else "#2563eb"))
        if role==Qt.ForegroundRole and key=="display_status":
            value=self._display_status(row)
            if "Delivered" in value: return QBrush(QColor("#22c55e" if self.dark else "#15803d"))
            if "Out for Delivery" in value: return QBrush(QColor("#fbbf24" if self.dark else "#b45309"))
            if "Exception" in value or "Delayed" in value: return QBrush(QColor("#fb7185" if self.dark else "#b91c1c"))
            return QBrush(QColor("#60a5fa" if self.dark else "#1d4ed8"))
        if role==Qt.ToolTipRole:
            if key=="order_number": return "Click to open Apple Order Status. Hover ⧉ to copy."
            if key=="address": return row["address"] or ""
            if key=="item_summary": return row["item_summary"] or ""
        return None

    def sort(self,column:int,order=Qt.AscendingOrder):
        if not (0<=column<len(self.COLUMNS)): return
        key=self.COLUMNS[column][0]
        if key=="select": return
        reverse=order==Qt.DescendingOrder
        def value(row):
            if key=="display_status": return self._display_status(row).lower()
            if key=="carrier": return (row["carrier"] or infer_carrier(row["tracking_number"] or "") or "").lower()
            if key in ("eta_date","order_date"): return clean_text(row[key] or "")
            if key=="delivery_time":
                raw=clean_text(row["delivery_time"] or ""); first=raw.split("-")[0].strip()
                try: return date_parser.parse(first).time().strftime("%H:%M:%S")
                except Exception: return raw.lower()
            if key=="qty": return int(row["qty"] or 0)
            return clean_text(str(row[key] if key in row.keys() else "")).lower()
        self.layoutAboutToBeChanged.emit(); self.rows.sort(key=value,reverse=reverse); self.layoutChanged.emit()

    def row_at(self,idx:int): return self.rows[idx] if 0<=idx<len(self.rows) else None


class PickupTrackingTableModel(TrackingTableModel):
    COLUMNS = [
        ("select", "Select"),
        ("order_number", "Order #"),
        ("status", "Status"),
        ("pickup_store", "Store"),
        ("eta_date", "Pickup Date"),
        ("pickup_time", "Time"),
        ("item_summary", "Item"),
        ("qty", "Qty"),
        ("order_date", "Order Date"),
        ("status_updated_at", "Last Checked"),
    ]

    def __init__(self, parent=None):
        super().__init__(parent)

    def set_rows(self, rows):
        super().set_rows(rows)

    def set_dark(self, dark: bool):
        self.dark = dark
        if self.rows:
            self.dataChanged.emit(self.index(0,0), self.index(len(self.rows)-1, len(self.COLUMNS)-1))

    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.rows)

    def columnCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.COLUMNS)

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if orientation == Qt.Horizontal and 0 <= section < len(self.COLUMNS):
            if role == Qt.DisplayRole:
                return self.COLUMNS[section][1]
            if role == Qt.TextAlignmentRole:
                return int(Qt.AlignCenter)
        return None

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid() or not (0 <= index.row() < len(self.rows)):
            return None
        row = self.rows[index.row()]
        key = self.COLUMNS[index.column()][0]
        if key == "select" and role == Qt.CheckStateRole:
            return Qt.CheckState.Checked if int(row["id"]) in self.checked_ids else Qt.CheckState.Unchecked
        if key == "select" and role == Qt.DisplayRole: return ""
        if role == Qt.UserRole:
            return int(row["id"])
        if role == Qt.DisplayRole:
            if key == "eta_date":
                return display_eta_value(row["eta_date"] or "", row["eta_text"] or "") or "—"
            if key == "pickup_store":
                return row["pickup_store"] or pickup_store_from_address(row["address"] or "") or "Apple Store"
            if key == "status_updated_at":
                value = clean_text(row["status_updated_at"] or row["last_email_date"] or "")
                return value[:19].replace("T", " ") if value else "Never"
            value = row[key] if key in row.keys() else ""
            return str(value if value is not None else "")
        if role == Qt.TextAlignmentRole:
            return int(Qt.AlignCenter | Qt.AlignVCenter)
        if role == Qt.FontRole and key in ("order_number", "status"):
            f = QFont(); f.setUnderline(key == "order_number"); f.setBold(key == "status"); return f
        if role == Qt.ForegroundRole and key == "order_number":
            return QBrush(QColor("#8fb4ff" if self.dark else "#2563eb"))
        if role == Qt.ForegroundRole and key == "status":
            status = row["status"] or "Processing"
            if status == "Ready for Pickup":
                color = "#a78bfa" if self.dark else "#6d28d9"
            elif status == "Processing":
                color = "#60a5fa" if self.dark else "#1d4ed8"
            else:
                color = "#cbd5e1" if self.dark else "#334155"
            return QBrush(QColor(color))
        if role == Qt.ToolTipRole and key == "order_number":
            return "Click to open Apple Order Status. Hover ⧉ to copy."
        return None

    def sort(self, column: int, order=Qt.AscendingOrder):
        if not (0 <= column < len(self.COLUMNS)):
            return
        key = self.COLUMNS[column][0]
        if key == "select": return
        reverse = order == Qt.DescendingOrder
        status_rank = {"Processing": 0, "Preparing to Ship": 1, "Ready for Pickup": 2, "Picked Up": 3}
        def value(row):
            if key in ("eta_date", "order_date", "status_updated_at"):
                return clean_text(row[key] or "")
            if key == "pickup_time":
                raw = clean_text(row["pickup_time"] or "")
                first = raw.split("-")[0].strip()
                try:
                    return date_parser.parse(first).time().strftime("%H:%M:%S")
                except Exception:
                    return raw.lower()
            if key == "pickup_store":
                return clean_text(row["pickup_store"] or pickup_store_from_address(row["address"] or "")).lower()
            if key == "status":
                return status_rank.get(clean_text(row["status"] or ""), 99)
            if key == "qty":
                return int(row["qty"] or 0)
            return clean_text(str(row[key] if key in row.keys() else "")).lower()
        self.layoutAboutToBeChanged.emit(); self.rows.sort(key=value, reverse=reverse); self.layoutChanged.emit()

    def row_at(self, idx: int):
        return self.rows[idx] if 0 <= idx < len(self.rows) else None


class ReleaseCard(QFrame):
    clicked = Signal(str)
    archiveRequested = Signal(str, bool)

    def __init__(self, summary, image_cache: ProductImageCache, parent=None):
        super().__init__(parent)
        self.summary = summary
        self.image_cache = image_cache
        self.setObjectName("releaseCard")
        self.setCursor(Qt.PointingHandCursor)
        self.setMinimumHeight(236)
        self._thumbs: list[tuple[str, QLabel]] = []
        lay = QVBoxLayout(self); lay.setContentsMargins(20, 18, 20, 16); lay.setSpacing(12)

        head = QHBoxLayout(); head.setSpacing(12)
        logo = QLabel(""); logo.setObjectName("releaseLogo"); logo.setAlignment(Qt.AlignCenter); logo.setFixedSize(48,48)
        title_wrap = QVBoxLayout(); title_wrap.setSpacing(1)
        title = QLabel("Apple Orders"); title.setObjectName("releaseTitle")
        try: day = date.fromisoformat(summary["order_day"]); day_text = day.strftime("%a, %B %d, %Y")
        except Exception: day_text = summary["order_day"] or "Unknown date"
        subtitle = QLabel(day_text); subtitle.setObjectName("muted")
        title_wrap.addWidget(title); title_wrap.addWidget(subtitle)
        head.addWidget(logo); head.addLayout(title_wrap); head.addStretch(1)
        self.archived = bool(summary.get("archived", 0) if isinstance(summary, dict) else summary["archived"])
        archive_btn = QPushButton("Restore" if self.archived else "Archive")
        archive_btn.setObjectName("miniAction")
        archive_btn.setToolTip("Restore these orders everywhere" if self.archived else "Hide this date and its orders across every page")
        archive_btn.clicked.connect(lambda: self.archiveRequested.emit(str(self.summary["order_day"] or ""), not self.archived))
        head.addWidget(archive_btn)
        arrow = QLabel("›"); arrow.setObjectName("releaseArrow"); head.addWidget(arrow)
        lay.addLayout(head)
        if self.archived:
            archived_label = QLabel("Archived")
            archived_label.setObjectName("archivedBadge")
            lay.addWidget(archived_label, 0, Qt.AlignLeft)

        thumbs = QHBoxLayout(); thumbs.setSpacing(8)
        urls = [safe_product_image_url(x) for x in clean_text(summary["images"] or "").split(",") if safe_product_image_url(x)]
        for url in urls[:5]:
            lbl = QLabel(""); lbl.setObjectName("releaseThumb"); lbl.setAlignment(Qt.AlignCenter); lbl.setFixedSize(54,54)
            icon = self.image_cache.icon_for(url)
            if not icon.isNull(): lbl.setPixmap(icon.pixmap(48,48))
            self._thumbs.append((url,lbl)); thumbs.addWidget(lbl)
        if len(urls) > 5:
            more = QLabel(f"+{len(urls)-5}"); more.setObjectName("releaseThumbMore"); more.setAlignment(Qt.AlignCenter); more.setFixedSize(54,54); thumbs.addWidget(more)
        thumbs.addStretch(1); lay.addLayout(thumbs)
        self.image_cache.ready.connect(self._image_ready)

        metrics = QHBoxLayout(); metrics.setSpacing(8)
        order_count = int(summary["order_count"] or 0); item_count = int(summary["item_count"] or 0)
        spent = float(summary["spent"] or 0.0); completed = int(summary["completed_count"] or 0)
        pct = (completed / order_count * 100.0) if order_count else 0.0
        for label, value in (("ORDERS", f"{order_count:,} / {item_count:,} items"), ("SPENT", f"${spent:,.2f}"), ("COMPLETED", f"{pct:.1f}%")):
            box = QFrame(); box.setObjectName("releaseMetric"); bl = QVBoxLayout(box); bl.setContentsMargins(10,8,10,8); bl.setSpacing(1)
            a=QLabel(label); a.setObjectName("metricLabel"); b=QLabel(value); b.setObjectName("metricValue")
            if label == "COMPLETED": b.setProperty("goodMetric", pct >= 95.0)
            bl.addWidget(a); bl.addWidget(b); metrics.addWidget(box,1)
        lay.addLayout(metrics)

    def _image_ready(self, url: str):
        for saved, lbl in self._thumbs:
            if saved == url:
                icon = self.image_cache.icon_for(url)
                if not icon.isNull(): lbl.setPixmap(icon.pixmap(48,48))

    def mouseReleaseEvent(self, event):
        if getattr(event, "button", lambda: None)() == Qt.LeftButton:
            self.clicked.emit(str(self.summary["order_day"] or ""))
        super().mouseReleaseEvent(event)


class ReleaseDetailDialog(QDialog):
    def __init__(self, db: Database, image_cache: ProductImageCache, order_day: str, parent=None):
        super().__init__(parent)
        self.db = db; self.image_cache = image_cache; self.order_day = order_day
        self.rows = list(db.orders_for_order_date(order_day))
        self.setWindowTitle(f"Apple Orders — {display_date_long(order_day)}")
        self.resize(1460, 900); self.setMinimumSize(1120, 720)
        outer = QVBoxLayout(self); outer.setContentsMargins(26,22,26,22); outer.setSpacing(16)

        head = QHBoxLayout()
        logo=QLabel(""); logo.setObjectName("releaseHeroLogo"); logo.setAlignment(Qt.AlignCenter); logo.setFixedSize(54,54)
        titles=QVBoxLayout(); titles.setSpacing(1)
        t=QLabel("Apple Orders"); t.setObjectName("dialogTitle")
        st=QLabel(display_date_long(order_day)); st.setObjectName("muted")
        titles.addWidget(t); titles.addWidget(st); head.addWidget(logo); head.addLayout(titles); head.addStretch(1)
        export_btn=QPushButton("⇩  Export Day"); export_btn.setObjectName("secondaryAccent"); export_btn.clicked.connect(self._export); head.addWidget(export_btn)
        outer.addLayout(head)

        status_counts={name:0 for name in ("Processing","Preparing to Ship","Action Required","Shipped","Delivered","Ready for Pickup","Picked Up","Canceled","Refunded")}
        spent=0.0
        for r in self.rows:
            status_counts[r["status"] or ""] = status_counts.get(r["status"] or "",0)+1
            try: spent += float(re.sub(r"[^0-9.]","", r["total"] or "0") or 0)
            except Exception: pass
        stats = QFrame(); stats.setObjectName("releaseStats"); grid=QGridLayout(stats); grid.setContentsMargins(12,12,12,12); grid.setSpacing(8)
        values=[("Orders",len(self.rows)),("Processing",status_counts.get("Processing",0)),("Shipped",status_counts.get("Shipped",0)),("Delivered",status_counts.get("Delivered",0)),("Ready for Pickup",status_counts.get("Ready for Pickup",0)),("Picked Up",status_counts.get("Picked Up",0)),("Canceled",status_counts.get("Canceled",0)),("Spent",f"${spent:,.2f}")]
        for i,(label,value) in enumerate(values):
            card=QFrame(); card.setObjectName("miniStat"); cl=QVBoxLayout(card); cl.setContentsMargins(12,8,12,8); cl.setSpacing(1)
            la=QLabel(label.upper()); la.setObjectName("metricLabel"); va=QLabel(str(value)); va.setObjectName("metricValue"); cl.addWidget(la); cl.addWidget(va); grid.addWidget(card,0,i)
        outer.addWidget(stats)

        items_title=QLabel("Items"); items_title.setObjectName("sectionTitle"); outer.addWidget(items_title)
        item_scroll=QScrollArea(); item_scroll.setWidgetResizable(True); item_scroll.setFrameShape(QFrame.NoFrame); item_scroll.setFixedHeight(265)
        item_host=QWidget(); item_grid=QGridLayout(item_host); item_grid.setContentsMargins(0,0,8,0); item_grid.setSpacing(10)
        grouped={}
        for r in self.rows:
            key=r["item_summary"] or "Apple order"; g=grouped.setdefault(key,{"rows":[],"qty":0,"image":r["image_url"] or ""}); g["rows"].append(r); g["qty"] += int(r["qty"] or 1)
        for i,(name,g) in enumerate(grouped.items()):
            card=QFrame(); card.setObjectName("itemSummaryCard"); il=QHBoxLayout(card); il.setContentsMargins(14,12,14,12); il.setSpacing(12)
            img=QLabel(""); img.setObjectName("releaseThumb"); img.setAlignment(Qt.AlignCenter); img.setFixedSize(60,60)
            url=safe_product_image_url(g["image"])
            if url:
                icon=image_cache.icon_for(url)
                if not icon.isNull(): img.setPixmap(icon.pixmap(54,54))
            il.addWidget(img)
            body=QVBoxLayout(); body.setSpacing(4); nm=QLabel(name); nm.setObjectName("cardItem"); nm.setWordWrap(True); body.addWidget(nm)
            counts={}
            for r in g["rows"]: counts[r["status"]]=counts.get(r["status"],0)+1
            status_text="  •  ".join(f"{k}: {v}" for k,v in counts.items() if k)
            meta=QLabel(f"{len(g['rows'])} order(s)  •  Qty {g['qty']}" + (f"  •  {status_text}" if status_text else "")); meta.setObjectName("mutedSmall"); meta.setWordWrap(True); body.addWidget(meta)
            il.addLayout(body,1); item_grid.addWidget(card,i//2,i%2)
        item_scroll.setWidget(item_host); outer.addWidget(item_scroll)

        order_title=QLabel("Orders"); order_title.setObjectName("sectionTitle"); outer.addWidget(order_title)
        self.model=OrderTableModel(image_cache,self); self.model.set_rows(self.rows); self.model.set_dark(getattr(parent, "theme", "light") == "dark")
        table=HoverTableView(); table.setModel(self.model); table.setSelectionBehavior(QAbstractItemView.SelectRows); table.setSelectionMode(QAbstractItemView.ExtendedSelection); table.setEditTriggers(QAbstractItemView.NoEditTriggers); table.setAlternatingRowColors(True); table.setSortingEnabled(True); table.verticalHeader().setVisible(False); table.verticalHeader().setDefaultSectionSize(56); table.setIconSize(QSize(42,42)); table.setShowGrid(False); table.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
        release_status_delegate = StatusDelegate(table); release_status_delegate.set_dark(getattr(parent, "theme", "light") == "dark"); table.setItemDelegateForColumn(5, release_status_delegate); table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        widths={0:70,1:90,2:320,3:60,4:170,5:135,6:190,7:220,8:300,9:100,10:120,11:210}
        for c,w in widths.items(): table.setColumnWidth(c,w)
        table.doubleClicked.connect(lambda idx: OrderDetailDialog(self.db,self.model.row_at(idx.row()),self).exec() if self.model.row_at(idx.row()) else None)
        outer.addWidget(table,1)
        close=QDialogButtonBox(QDialogButtonBox.Close); close.rejected.connect(self.reject); outer.addWidget(close)

    def _export(self):
        save_rows_csv(self, QSettings("Local","AppleOrderTracker"), self.rows, f"apple_orders_{self.order_day}", f"Order date — {display_date_long(self.order_day)}")


class MainWindow(QMainWindow):
    PAGE_ORDERS = 0
    PAGE_RELEASES = 1
    PAGE_TRACKING = 2
    PAGE_PICKUP_TRACKING = 3
    PAGE_SCHEDULE = 4
    PAGE_DAY_ORDERS = 5
    PAGE_APPLE = 6
    apple_order_url = staticmethod(effective_apple_order_url)
    apple_eta_parser = staticmethod(iso_date_from_text)

    TAB_FILTERS = [
        "All Orders", "Processing", "Pickup Processing", "Preparing to Ship", "Action Required", "Shipped",
        "Delivered", "Ready for Pickup", "Picked Up", "Canceled", "Refunded",
    ]

    TAB_FILTERS = TAB_FILTERS + list(UPS_STATES) + list(APPLE_EXTRA_STATUSES)

    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME} v{APP_VERSION}")
        self.resize(1720, 980)
        self.setMinimumSize(1240, 760)
        self.settings = QSettings("Local", "AppleOrderTracker")
        backup_before_ups_migration(db_path())
        backup_before_apple_migration(db_path())
        self.db = Database(db_path())
        self.sync_worker: Optional[SyncWorker] = None
        self.verify_worker: Optional[VerificationWorker] = None
        self.apple_web_checker: Optional[ApplePickupWebEngineChecker] = None
        self._verification_force = False
        self._verification_order_ids: set[int] = set()
        self._verify_worker_checked = 0
        self._verify_worker_updated = 0
        self.image_cache = ProductImageCache(self)
        self.table_model = OrderTableModel(self.image_cache, self)
        self.tracking_model = TrackingTableModel(self)
        self.pickup_tracking_model = PickupTrackingTableModel(self)
        self.day_model = OrderTableModel(self.image_cache, self)
        self.status_delegate = StatusEditDelegate(self)
        self.qty_edit_delegate = QtyEditDelegate(self)
        self.day_status_delegate = StatusDelegate(self)
        self.order_number_delegate = OrderNumberDelegate(self)
        self.day_order_number_delegate = OrderNumberDelegate(self)
        self.tracking_order_number_delegate = OrderNumberDelegate(self)
        self.pickup_order_number_delegate = OrderNumberDelegate(self)
        self.checkbox_delegate = CheckBoxDelegate(self)
        self.day_checkbox_delegate = CheckBoxDelegate(self)
        self.tracking_checkbox_delegate = CheckBoxDelegate(self)
        self.pickup_status_delegate = StatusDelegate(self)
        self.pickup_checkbox_delegate = CheckBoxDelegate(self)
        self.shipping_status_delegate = StatusDelegate(self)
        self._ups_busy = False
        self._ups_active_ids = set()
        self._ups_phase = 0
        self._ups_report = []
        self._ups_last_stats = {}
        self._update_check_worker: Optional[AppUpdateCheckWorker] = None
        self._update_download_worker: Optional[AppUpdateDownloadWorker] = None
        self._update_progress_dialog: Optional[QDialog] = None
        self._update_progress_bar: Optional[QProgressBar] = None
        self._update_progress_label: Optional[QLabel] = None
        self._update_pending_info: Optional[UpdateInfo] = None
        self._update_manual_request = False
        self._updating = False
        self._ups_repaint_timer = QTimer(self)
        self._ups_repaint_timer.setInterval(100)
        self._ups_repaint_timer.timeout.connect(self._animate_ups)
        self._ups_refresh_timer = QTimer(self)
        self._ups_refresh_timer.setSingleShot(True)
        self._ups_refresh_timer.setInterval(700)
        self._ups_refresh_timer.timeout.connect(self._refresh_ups_views)
        self.current_order_day = ""
        self.filter_start = clean_text(str(self.settings.value("dashboard_start_date", "") or ""))
        self.filter_end = clean_text(str(self.settings.value("dashboard_end_date", "") or ""))
        self._copy_guard_until = 0.0
        self.search_timer = QTimer(self); self.search_timer.setSingleShot(True); self.search_timer.setInterval(220)
        self.search_timer.timeout.connect(self.refresh_table)
        self.tracking_search_timer = QTimer(self); self.tracking_search_timer.setSingleShot(True); self.tracking_search_timer.setInterval(220)
        self.tracking_search_timer.timeout.connect(self.refresh_tracking)
        self.theme = str(self.settings.value("theme", "dark"))
        self._build_ui()
        self.apply_theme(self.theme)
        self.refresh_all()


        # Apple pickup website checking stays disabled. UPS shipment tracking can
        # use the official UPS Track API when the user saves OAuth credentials.
        self.live_verify_timer = None

        if not self.db.list_accounts():
            self.show_first_run_hint()

        QTimer.singleShot(2200, self._maybe_auto_check_update)

    def closeEvent(self, event):
        if hasattr(self,'apple_page') and self.apple_page.stopping():
            event.ignore()
            QTimer.singleShot(250,self.close)
            return
        if hasattr(self,'_apple_refresh_timer'):self._apple_refresh_timer.stop()
        # Owned dialogs are separate windows and can remain visible when this
        # window closes. End their refresh timers before closing the database.
        for dialog in self.findChildren(OrderDetailDialog):
            dialog.close()
        if self._updating:
            self._ups_repaint_timer.stop(); self._ups_refresh_timer.stop()
            try: self.db.close()
            except Exception: pass
            event.accept()
            return
        active = [w for w in (self.sync_worker,self.verify_worker) if w and w.isRunning()]
        if active:
            for worker in active: worker.request_stop()
            self.sync_status.setText("Finishing the current network request before closing...")
            event.ignore()
            QTimer.singleShot(250,self.close)
            return
        self._ups_repaint_timer.stop(); self._ups_refresh_timer.stop()
        self.db.close()
        super().closeEvent(event)

    def _build_ui(self):
        root = QWidget(); self.setCentralWidget(root)
        shell = QHBoxLayout(root); shell.setContentsMargins(0,0,0,0); shell.setSpacing(0)

        sidebar = QFrame(); sidebar.setObjectName("sidebar"); sidebar.setFixedWidth(238)
        side = QVBoxLayout(sidebar); side.setContentsMargins(16,18,16,18); side.setSpacing(7)
        brand = QHBoxLayout(); brand.setSpacing(10)
        icon_label = QLabel(); icon_path = resource_path("app_icon.ico")
        if icon_path.exists(): icon_label.setPixmap(QIcon(str(icon_path)).pixmap(36,36))
        icon_label.setFixedSize(40,40)
        bt = QVBoxLayout(); bt.setSpacing(0)
        bn=QLabel("Ah Pa Ta Tracker"); bn.setObjectName("brandName")
        bv=QLabel(f"v{APP_VERSION}"); bv.setObjectName("mutedSmall")
        bt.addWidget(bn); bt.addWidget(bv); brand.addWidget(icon_label); brand.addLayout(bt); brand.addStretch(1)
        side.addLayout(brand); side.addSpacing(16)

        # Primary pages stay together at the top.
        self.orders_nav = QPushButton("▣   Orders")
        self.releases_nav = QPushButton("◉   Order Dates")
        self.tracking_nav = QPushButton("▰   Shipping Tracking")
        self.pickup_nav = QPushButton("⌂   Pickup Tracking")
        self.schedule_nav = QPushButton("▦   Delivery Calendar")
        self.apple_nav = QPushButton("Apple Account")
        self._page_nav_buttons = [self.orders_nav,self.releases_nav,self.tracking_nav,self.pickup_nav,self.schedule_nav,self.apple_nav]
        for btn in self._page_nav_buttons:
            btn.setProperty("navButton", True); btn.setCursor(Qt.PointingHandCursor); side.addWidget(btn)

        # Utility actions live at the bottom, beside theme control, as requested.
        side.addStretch(1)
        self.export_nav = QPushButton("⇩   Export")
        self.accounts_nav = QPushButton("✉   Gmail Accounts")
        self.rescan_nav = QPushButton("↻   Refresh Details")
        self.settings_nav = QPushButton("⚙   Settings")
        self.updates_nav = QPushButton("⬆   Check for Updates")
        self.theme_btn = QPushButton()
        self._utility_buttons = [self.export_nav,self.accounts_nav,self.rescan_nav,self.settings_nav,self.updates_nav,self.theme_btn]
        for btn in self._utility_buttons:
            btn.setProperty("navButton", True); btn.setCursor(Qt.PointingHandCursor); side.addWidget(btn)
        shell.addWidget(sidebar)

        self.stack = QStackedWidget(); self.stack.setObjectName("pageStack")
        self.orders_page = self._build_orders_page()
        self.releases_page = self._build_releases_page()
        self.tracking_page = self._build_tracking_page()
        self.pickup_tracking_page = self._build_pickup_tracking_page()
        self.schedule_page = SchedulePage(self.db, self.image_cache, self)
        self.day_orders_page = self._build_day_orders_page()
        from apple_account_ui import AppleWorkspace
        self.apple_page = AppleWorkspace(self)
        self.apple_page.changed.connect(self._apple_data_changed)
        self._apple_refresh_timer = QTimer(self)
        self._apple_refresh_timer.setSingleShot(True)
        self._apple_refresh_timer.setInterval(700)
        self._apple_refresh_timer.timeout.connect(self.refresh_all)
        for page in (self.orders_page,self.releases_page,self.tracking_page,self.pickup_tracking_page,self.schedule_page,self.day_orders_page,self.apple_page):
            self.stack.addWidget(page)
        shell.addWidget(self.stack, 1)

        self.orders_nav.clicked.connect(lambda: self.show_page(self.PAGE_ORDERS, self.orders_nav))
        self.releases_nav.clicked.connect(lambda: self.show_page(self.PAGE_RELEASES, self.releases_nav))
        self.tracking_nav.clicked.connect(lambda: self.show_page(self.PAGE_TRACKING, self.tracking_nav))
        self.pickup_nav.clicked.connect(lambda: self.show_page(self.PAGE_PICKUP_TRACKING, self.pickup_nav))
        self.schedule_nav.clicked.connect(lambda: self.open_schedule())
        self.apple_nav.clicked.connect(lambda: self.show_page(self.PAGE_APPLE,self.apple_nav))
        self.export_nav.clicked.connect(self.export_csv)
        self.accounts_nav.clicked.connect(self.manage_accounts)
        self.rescan_nav.clicked.connect(self.refresh_details)
        self.settings_nav.clicked.connect(self.open_settings)
        self.updates_nav.clicked.connect(lambda: self.check_for_updates(True))
        self.theme_btn.clicked.connect(self.toggle_theme)
        self.show_page(self.PAGE_ORDERS, self.orders_nav)

    def _apple_data_changed(self):
        if not self._apple_refresh_timer.isActive():self._apple_refresh_timer.start()

    def _page_shell(self):
        page=QWidget(); page.setObjectName("content")
        lay=QVBoxLayout(page); lay.setContentsMargins(30,24,30,20); lay.setSpacing(12)
        return page, lay

    def _build_orders_page(self):
        page, outer = self._page_shell()
        header=QHBoxLayout(); titles=QVBoxLayout(); titles.setSpacing(2)
        title=QLabel("Apple Orders"); title.setObjectName("pageTitle")
        self.subtitle=QLabel("Track every Apple Store order from Gmail IMAP"); self.subtitle.setObjectName("muted")
        titles.addWidget(title); titles.addWidget(self.subtitle); header.addLayout(titles); header.addStretch(1)
        self.search_edit=QLineEdit(); self.search_edit.setPlaceholderText("Search orders, items, destination, tracking, email…"); self.search_edit.setClearButtonEnabled(True); self.search_edit.setMinimumWidth(380); header.addWidget(self.search_edit)
        # Kept as a hidden compatibility object for old internal callbacks; live web checks are disabled.
        self.verify_btn=QPushButton(); self.verify_btn.setVisible(False)
        self.sync_btn=QPushButton("↻  Sync Now"); self.sync_btn.setObjectName("secondaryAccent"); header.addWidget(self.sync_btn)
        self.save_overrides_btn=QPushButton("Save Changes"); self.save_overrides_btn.setObjectName("primaryButton"); self.save_overrides_btn.setEnabled(False); header.addWidget(self.save_overrides_btn)
        outer.addLayout(header)

        status=QHBoxLayout(); self.sync_status=QLabel("Ready"); self.sync_status.setObjectName("syncStatus"); status.addWidget(self.sync_status,1)
        self.range_label=QLabel(""); self.range_label.setObjectName("muted"); status.addWidget(self.range_label)
        self.result_label=QLabel("0 orders"); self.result_label.setObjectName("muted"); status.addWidget(self.result_label); outer.addLayout(status)
        self.progress=QProgressBar(); self.progress.setRange(0,100); self.progress.setValue(0); self.progress.setTextVisible(False); self.progress.setFixedHeight(3); outer.addWidget(self.progress)
        live_row = QHBoxLayout()
        self.ups_indicator = LiveIndicator(self); live_row.addWidget(self.ups_indicator)
        self.ups_card_host = QWidget(); self.ups_card_layout = QHBoxLayout(self.ups_card_host)
        self.ups_card_layout.setContentsMargins(0,0,0,0); self.ups_card_layout.setSpacing(6)
        card_scroll = QScrollArea(); card_scroll.setWidgetResizable(True); card_scroll.setFrameShape(QFrame.NoFrame)
        card_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff); card_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        card_scroll.setFixedHeight(47); card_scroll.setWidget(self.ups_card_host)
        live_row.addWidget(card_scroll,1)
        self.ups_results_btn = QPushButton("UPS Results"); self.ups_results_btn.setObjectName("miniAction")
        self.ups_results_btn.clicked.connect(self.show_ups_results); live_row.addWidget(self.ups_results_btn)
        outer.addLayout(live_row)

        upcoming=QFrame(); upcoming.setObjectName("upcomingFrame"); up=QHBoxLayout(upcoming); up.setContentsMargins(12,7,12,7); up.setSpacing(8)
        lab=QLabel("Upcoming"); lab.setObjectName("sectionLabel"); up.addWidget(lab)
        self.chip_scroll=QScrollArea(); self.chip_scroll.setWidgetResizable(True); self.chip_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff); self.chip_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff); self.chip_scroll.setFrameShape(QFrame.NoFrame); self.chip_scroll.setFixedHeight(54)
        self.chip_host=QWidget(); self.chip_layout=QHBoxLayout(self.chip_host); self.chip_layout.setContentsMargins(0,0,0,0); self.chip_layout.setSpacing(7); self.chip_scroll.setWidget(self.chip_host); up.addWidget(self.chip_scroll,1)
        self.date_picker=QDateEdit(QDate.currentDate()); configure_date_edit(self.date_picker); self.date_picker.setDisplayFormat("MMM d, yyyy"); self.date_picker.setMinimumWidth(130); up.addWidget(self.date_picker)
        view_day=QPushButton("View Day"); view_day.setObjectName("secondaryAccent"); up.addWidget(view_day); outer.addWidget(upcoming)

        self.tabs=QTabBar(); self.tabs.setExpanding(False); self.tabs.setDrawBase(False)
        for name in self.TAB_FILTERS: self.tabs.addTab(name)
        outer.addWidget(self.tabs)

        tools=QHBoxLayout(); tools.setSpacing(8)
        self.selected_label=QLabel("0 selected"); self.selected_label.setObjectName("mutedSmall"); tools.addWidget(self.selected_label)
        self.export_selected_btn=QPushButton("⇩  Export Selected"); self.export_selected_btn.setObjectName("secondaryAccent"); self.export_selected_btn.setEnabled(False); tools.addWidget(self.export_selected_btn)
        self.select_all_btn=QPushButton("☑  Select All"); self.select_all_btn.setObjectName("secondaryAccent"); tools.addWidget(self.select_all_btn)
        self.clear_selected_btn=QPushButton("Clear"); self.clear_selected_btn.setObjectName("secondaryAccent"); tools.addWidget(self.clear_selected_btn)
        self.bulk_status_btn = QPushButton("Bulk Status"); self.bulk_status_btn.setEnabled(False); tools.addWidget(self.bulk_status_btn)
        self.bulk_status_btn.clicked.connect(lambda: self.bulk_change_status(self.table_model))
        from apple_account_ui import actions_button
        tools.addWidget(actions_button(self,self.table_model))
        self.bulk_main_btn=QPushButton("▰  Bulk Tracking"); self.bulk_main_btn.setObjectName("secondaryAccent"); self.bulk_main_btn.setVisible(False); self.bulk_main_btn.setEnabled(False); tools.addWidget(self.bulk_main_btn)
        tools.addStretch(1)
        hint=QLabel("Use the checkboxes to select one or many orders for export"); hint.setObjectName("mutedSmall"); tools.addWidget(hint)
        outer.addLayout(tools)

        self.table=OrderSelectionTableView(); self.table.setModel(self.table_model); self.table.setAlternatingRowColors(True); self.table.setSelectionBehavior(QAbstractItemView.SelectRows); self.table.setSelectionMode(QAbstractItemView.ExtendedSelection); self.table.setEditTriggers(QAbstractItemView.NoEditTriggers); self.table.setSortingEnabled(True); self.table.setShowGrid(False); self.table.setWordWrap(False); self.table.setIconSize(QSize(44,44)); self.table.verticalHeader().setVisible(False); self.table.verticalHeader().setDefaultSectionSize(56); self.table.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded); self.table.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel); self.table.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel); self.table.setMouseTracking(True)
        self.table.setItemDelegateForColumn(0,self.checkbox_delegate); self.table.setItemDelegateForColumn(4,self.qty_edit_delegate); self.table.setItemDelegateForColumn(5,self.status_delegate); self.table.setItemDelegateForColumn(6,self.order_number_delegate)
        hv=self.table.horizontalHeader(); hv.setHighlightSections(False); hv.setStretchLastSection(False); hv.setSectionResizeMode(QHeaderView.Interactive); hv.setDefaultAlignment(Qt.AlignCenter)
        widths={0:64,1:72,2:96,3:330,4:64,5:225,6:138,7:210,8:240,9:330,10:108,11:126,12:220}
        for c,w in widths.items(): self.table.setColumnWidth(c,w)
        outer.addWidget(self.table,1)
        foot=QHBoxLayout(); f=QLabel("Click an Order # to open Apple Order Status. Hover ⧉ to copy. Click a Tracking # to open carrier tracking."); f.setObjectName("mutedSmall"); foot.addWidget(f); foot.addStretch(1); dbp=QLabel("Local database: %LOCALAPPDATA%\\AppleOrderTracker"); dbp.setObjectName("mutedSmall"); foot.addWidget(dbp); outer.addLayout(foot)

        self.sync_btn.clicked.connect(self.start_sync); self.save_overrides_btn.clicked.connect(self.save_manual_overrides); view_day.clicked.connect(self.open_selected_date)
        self.tabs.currentChanged.connect(self._tab_changed); self.search_edit.textChanged.connect(lambda: self.search_timer.start())
        self.table.clicked.connect(self.table_clicked); self.table.doubleClicked.connect(self.table_double_clicked); self.order_number_delegate.copyRequested.connect(self.copy_order_number)
        self.table_model.checkedChanged.connect(self._order_selection_changed)
        self.table_model.pendingChanged.connect(self._manual_edits_changed)
        self.export_selected_btn.clicked.connect(self.export_selected_orders); self.select_all_btn.clicked.connect(lambda: self.table_model.set_all_checked(True)); self.clear_selected_btn.clicked.connect(lambda: self.table_model.set_all_checked(False)); self.bulk_main_btn.clicked.connect(self.bulk_tracking_current_view)
        return page

    def _build_releases_page(self):
        page, outer=self._page_shell()
        header=QHBoxLayout(); titles=QVBoxLayout(); titles.setSpacing(2)
        t=QLabel("Order Dates"); t.setObjectName("pageTitle"); s=QLabel("Browse real Apple order activity grouped by the date the orders were placed"); s.setObjectName("muted"); titles.addWidget(t); titles.addWidget(s); header.addLayout(titles); header.addStretch(1)
        self.release_result=QLabel(""); self.release_result.setObjectName("muted"); header.addWidget(self.release_result); outer.addLayout(header)
        controls=QHBoxLayout(); self.release_search=QLineEdit(); self.release_search.setPlaceholderText("Search date, e.g. Sep 18 or 2026-09-18…"); self.release_search.setMaximumWidth(360); controls.addWidget(self.release_search); controls.addStretch(1); self.show_archived_dates=QCheckBox("Show archived dates"); controls.addWidget(self.show_archived_dates); range_hint=QLabel("Uses the active Sync date range"); range_hint.setObjectName("mutedSmall"); controls.addWidget(range_hint); outer.addLayout(controls)
        self.release_scroll=QScrollArea(); self.release_scroll.setWidgetResizable(True); self.release_scroll.setFrameShape(QFrame.NoFrame)
        self.release_host=QWidget(); self.release_grid=QGridLayout(self.release_host); self.release_grid.setContentsMargins(0,6,10,10); self.release_grid.setHorizontalSpacing(14); self.release_grid.setVerticalSpacing(14); self.release_scroll.setWidget(self.release_host); outer.addWidget(self.release_scroll,1)
        self.release_search.textChanged.connect(self.refresh_releases); self.show_archived_dates.toggled.connect(self.refresh_releases)
        return page

    def _build_tracking_page(self):
        page, outer=self._page_shell()
        header=QHBoxLayout(); titles=QVBoxLayout(); titles.setSpacing(2)
        t=QLabel("Shipping Tracking"); t.setObjectName("pageTitle")
        s=QLabel("Only shipping orders still in transit are shown here — delivered orders disappear automatically"); s.setObjectName("muted")
        titles.addWidget(t); titles.addWidget(s); header.addLayout(titles); header.addStretch(1)
        self.tracking_refresh_btn=QPushButton("↻  Refresh UPS"); self.tracking_refresh_btn.setObjectName("secondaryAccent"); header.addWidget(self.tracking_refresh_btn)
        self.tracking_indicator = LiveIndicator(self); header.addWidget(self.tracking_indicator)
        self.ups_cancel_btn = QPushButton("Stop UPS"); self.ups_cancel_btn.setVisible(False)
        self.ups_cancel_btn.clicked.connect(self.cancel_ups); header.addWidget(self.ups_cancel_btn)
        results_btn = QPushButton("UPS Results"); results_btn.clicked.connect(self.show_ups_results); header.addWidget(results_btn)
        outer.addLayout(header)

        controls=QHBoxLayout(); controls.setSpacing(8)
        self.tracking_search=QLineEdit(); self.tracking_search.setPlaceholderText("Search order, address, item, carrier, tracking…"); self.tracking_search.setMinimumWidth(340); controls.addWidget(self.tracking_search)
        self.tracking_count=QLabel("0 shipments"); self.tracking_count.setObjectName("muted"); controls.addWidget(self.tracking_count); controls.addStretch(1)
        self.tracking_carrier=QComboBox(); self.tracking_carrier.addItems(["All Carriers","UPS","FedEx","USPS","DHL","OnTrac","Veho"]); controls.addWidget(self.tracking_carrier)
        self.tracking_status_filter=QComboBox(); self.tracking_status_filter.addItems(["All Statuses","Order Placed","Processing","Preparing to Ship","Action Required","Shipped"]+list(UPS_STATES)); controls.addWidget(self.tracking_status_filter)
        self.tracking_check_selected=QPushButton("↻  Check Selected UPS"); self.tracking_check_selected.setObjectName("secondaryAccent"); self.tracking_check_selected.setEnabled(False); controls.addWidget(self.tracking_check_selected)
        self.tracking_bulk_btn=QPushButton("▰  Bulk Tracking"); self.tracking_bulk_btn.setObjectName("secondaryAccent"); controls.addWidget(self.tracking_bulk_btn)
        outer.addLayout(controls)

        tools=QHBoxLayout(); tools.setSpacing(8)
        self.tracking_selected_label=QLabel("0 selected"); self.tracking_selected_label.setObjectName("mutedSmall"); tools.addWidget(self.tracking_selected_label)
        self.tracking_export_selected=QPushButton("⇩  Export Selected"); self.tracking_export_selected.setObjectName("secondaryAccent"); self.tracking_export_selected.setEnabled(False); tools.addWidget(self.tracking_export_selected)
        self.tracking_select_all=QPushButton("☑  Select All"); self.tracking_select_all.setObjectName("secondaryAccent"); tools.addWidget(self.tracking_select_all)
        self.tracking_clear_selected=QPushButton("Clear"); self.tracking_clear_selected.setObjectName("secondaryAccent"); tools.addWidget(self.tracking_clear_selected)
        self.tracking_bulk_status = QPushButton("Bulk Status"); self.tracking_bulk_status.setEnabled(False); tools.addWidget(self.tracking_bulk_status)
        self.tracking_bulk_status.clicked.connect(lambda: self.bulk_change_status(self.tracking_model))
        from apple_account_ui import actions_button
        tools.addWidget(actions_button(self,self.tracking_model))
        tools.addStretch(1)
        self.tracking_feedback=QLabel("UPS API tracking is available for UPS packages when credentials are configured in Settings. Manual overrides still have highest priority."); self.tracking_feedback.setObjectName("mutedSmall"); self.tracking_feedback.setWordWrap(True)
        outer.addLayout(tools)
        outer.addWidget(self.tracking_feedback)

        self.tracking_table=OrderSelectionTableView(); self.tracking_table.setModel(self.tracking_model); self.tracking_table.setAlternatingRowColors(True); self.tracking_table.setSelectionBehavior(QAbstractItemView.SelectRows); self.tracking_table.setSelectionMode(QAbstractItemView.ExtendedSelection); self.tracking_table.setEditTriggers(QAbstractItemView.NoEditTriggers); self.tracking_table.setSortingEnabled(True); self.tracking_table.setShowGrid(False); self.tracking_table.verticalHeader().setVisible(False); self.tracking_table.verticalHeader().setDefaultSectionSize(52); self.tracking_table.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel); self.tracking_table.setMouseTracking(True)
        self.tracking_table.setItemDelegateForColumn(0,self.tracking_checkbox_delegate); self.tracking_table.setItemDelegateForColumn(1,self.tracking_order_number_delegate)
        self.tracking_table.setItemDelegateForColumn(9,self.shipping_status_delegate)
        th=self.tracking_table.horizontalHeader(); th.setSectionResizeMode(QHeaderView.Interactive); th.setStretchLastSection(False); th.setDefaultAlignment(Qt.AlignCenter)
        tw={0:64,1:155,2:225,3:190,4:170,5:390,6:330,7:70,8:120,9:225,10:150}
        for c,w in tw.items(): self.tracking_table.setColumnWidth(c,w)
        self.tracking_table.sortByColumn(3, Qt.AscendingOrder)
        outer.addWidget(self.tracking_table,1)

        self.tracking_search.textChanged.connect(lambda: self.tracking_search_timer.start()); self.tracking_carrier.currentTextChanged.connect(self.refresh_tracking); self.tracking_status_filter.currentTextChanged.connect(self.refresh_tracking)
        self.tracking_table.selectionModel().selectionChanged.connect(self._tracking_selection_changed); self.tracking_model.checkedChanged.connect(self._tracking_selection_changed)
        self.tracking_table.clicked.connect(self.tracking_table_clicked); self.tracking_table.doubleClicked.connect(self.tracking_table_double_clicked); self.tracking_order_number_delegate.copyRequested.connect(self.copy_order_number)
        self.tracking_bulk_btn.clicked.connect(self.bulk_tracking_tracking_page)
        self.tracking_refresh_btn.clicked.connect(self.refresh_all_tracking_status); self.tracking_check_selected.clicked.connect(self.check_selected_tracking)
        self.tracking_export_selected.clicked.connect(self.export_selected_tracking_orders); self.tracking_select_all.clicked.connect(lambda: self.tracking_model.set_all_checked(True)); self.tracking_clear_selected.clicked.connect(lambda: self.tracking_model.set_all_checked(False))
        return page

    def _build_pickup_tracking_page(self):
        page, outer=self._page_shell()
        header=QHBoxLayout(); titles=QVBoxLayout(); titles.setSpacing(2)
        t=QLabel("Pickup Tracking"); t.setObjectName("pageTitle")
        sub=QLabel("Only pickup orders still waiting to be collected are shown here"); sub.setObjectName("muted")
        titles.addWidget(t); titles.addWidget(sub); header.addLayout(titles); header.addStretch(1)
        self.pickup_export_btn=QPushButton("⇩  Export Pickup")
        self.pickup_export_btn.setObjectName("secondaryAccent")
        self.pickup_export_btn.setToolTip("Export the pickup orders currently shown on this page to CSV")
        header.addWidget(self.pickup_export_btn)
        self.pickup_refresh_btn=QPushButton(); self.pickup_refresh_btn.setVisible(False)
        outer.addLayout(header)

        controls=QHBoxLayout(); controls.setSpacing(8)
        self.pickup_search=QLineEdit(); self.pickup_search.setPlaceholderText("Search order, item, Apple Store, email…"); self.pickup_search.setMinimumWidth(360); controls.addWidget(self.pickup_search)
        self.pickup_count=QLabel("0 pickup orders"); self.pickup_count.setObjectName("muted"); controls.addWidget(self.pickup_count); controls.addStretch(1)
        self.pickup_check_selected=QPushButton(); self.pickup_check_selected.setVisible(False); self.pickup_check_selected.setEnabled(False)
        outer.addLayout(controls)
        self.pickup_feedback=QLabel("Manual status mode — Ready for Pickup and Processing orders remain here until you change the order status."); self.pickup_feedback.setObjectName("mutedSmall"); outer.addWidget(self.pickup_feedback)

        pick_tools = QHBoxLayout()
        self.pickup_selected_label = QLabel("0 selected"); pick_tools.addWidget(self.pickup_selected_label)
        self.pickup_export_selected_btn = QPushButton("Export Selected"); self.pickup_export_selected_btn.setEnabled(False); pick_tools.addWidget(self.pickup_export_selected_btn)
        self.pickup_select_all_btn = QPushButton("Select All"); pick_tools.addWidget(self.pickup_select_all_btn)
        self.pickup_clear_btn = QPushButton("Clear"); pick_tools.addWidget(self.pickup_clear_btn)
        self.pickup_bulk_status_btn = QPushButton("Bulk Status"); self.pickup_bulk_status_btn.setEnabled(False); pick_tools.addWidget(self.pickup_bulk_status_btn)
        pick_tools.addStretch(1); outer.addLayout(pick_tools)
        self.pickup_export_selected_btn.clicked.connect(self.export_selected_pickup_orders)
        self.pickup_select_all_btn.clicked.connect(lambda: self.pickup_tracking_model.set_all_checked(True))
        self.pickup_clear_btn.clicked.connect(lambda: self.pickup_tracking_model.set_all_checked(False))
        self.pickup_bulk_status_btn.clicked.connect(lambda: self.bulk_change_status(self.pickup_tracking_model))
        from apple_account_ui import actions_button
        pick_tools.addWidget(actions_button(self,self.pickup_tracking_model))
        self.pickup_tracking_model.checkedChanged.connect(self._pickup_selection_changed)
        self.pickup_table=OrderSelectionTableView(); self.pickup_table.setModel(self.pickup_tracking_model); self.pickup_table.setAlternatingRowColors(True); self.pickup_table.setMouseTracking(True); self.pickup_table.setItemDelegateForColumn(1,self.pickup_order_number_delegate); self.pickup_table.setItemDelegateForColumn(2,self.pickup_status_delegate)
        self.pickup_table.setItemDelegateForColumn(0,self.pickup_checkbox_delegate)
        self.pickup_table.setSelectionBehavior(QAbstractItemView.SelectRows); self.pickup_table.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.pickup_table.setEditTriggers(QAbstractItemView.NoEditTriggers); self.pickup_table.setSortingEnabled(True); self.pickup_table.setShowGrid(False)
        self.pickup_table.verticalHeader().setVisible(False); self.pickup_table.verticalHeader().setDefaultSectionSize(52); self.pickup_table.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
        ph=self.pickup_table.horizontalHeader(); ph.setSectionResizeMode(QHeaderView.Interactive); ph.setDefaultAlignment(Qt.AlignCenter); ph.setStretchLastSection(True)
        widths={0:64,1:170,2:180,3:250,4:185,5:170,6:330,7:70,8:150,9:190}
        for c,w in widths.items(): self.pickup_table.setColumnWidth(c,w)
        self.pickup_table.sortByColumn(4, Qt.AscendingOrder)
        outer.addWidget(self.pickup_table,1)
        note=QLabel("When an Apple email confirms collection, or you manually override the status to Picked Up, the order disappears from this page automatically.")
        note.setObjectName("mutedSmall"); outer.addWidget(note)
        self.pickup_search.textChanged.connect(self.refresh_pickup_tracking)
        self.pickup_export_btn.clicked.connect(self.export_pickup_tracking_orders)
        self.pickup_table.selectionModel().selectionChanged.connect(self._pickup_selection_changed)
        self.pickup_table.clicked.connect(self.pickup_table_clicked); self.pickup_table.doubleClicked.connect(self.pickup_table_double_clicked); self.pickup_order_number_delegate.copyRequested.connect(self.copy_order_number)
        # No Apple website checks are performed in manual override mode.
        return page

    def _build_day_orders_page(self):
        page, outer=self._page_shell()
        header=QHBoxLayout(); back=QPushButton("←  Order Dates"); back.setObjectName("secondaryAccent"); header.addWidget(back)
        titles=QVBoxLayout(); titles.setSpacing(1)
        self.day_title=QLabel("Orders"); self.day_title.setObjectName("pageTitle")
        self.day_subtitle=QLabel("Orders placed on the selected date"); self.day_subtitle.setObjectName("muted")
        titles.addWidget(self.day_title); titles.addWidget(self.day_subtitle); header.addLayout(titles); header.addStretch(1)
        self.day_search=QLineEdit(); self.day_search.setPlaceholderText("Search this date…"); self.day_search.setMinimumWidth(320); header.addWidget(self.day_search)
        self.day_export_all=QPushButton("⇩  Export Day"); self.day_export_all.setObjectName("secondaryAccent"); header.addWidget(self.day_export_all)
        outer.addLayout(header)

        self.day_tabs=QTabBar(); self.day_tabs.setExpanding(False); self.day_tabs.setDrawBase(False)
        for name in self.TAB_FILTERS: self.day_tabs.addTab(name)
        outer.addWidget(self.day_tabs)
        tools=QHBoxLayout(); tools.setSpacing(8)
        self.day_selected_label=QLabel("0 selected"); self.day_selected_label.setObjectName("mutedSmall"); tools.addWidget(self.day_selected_label)
        self.day_export_selected=QPushButton("⇩  Export Selected"); self.day_export_selected.setObjectName("secondaryAccent"); self.day_export_selected.setEnabled(False); tools.addWidget(self.day_export_selected)
        self.day_select_all=QPushButton("☑  Select All"); self.day_select_all.setObjectName("secondaryAccent"); tools.addWidget(self.day_select_all)
        self.day_clear_selected=QPushButton("Clear"); self.day_clear_selected.setObjectName("secondaryAccent"); tools.addWidget(self.day_clear_selected)
        tools.addStretch(1); hint=QLabel("Use the checkboxes to export only specific orders from this date"); hint.setObjectName("mutedSmall"); tools.addWidget(hint)
        outer.addLayout(tools)

        self.day_table=OrderSelectionTableView(); self.day_table.setModel(self.day_model); self.day_table.setAlternatingRowColors(True)
        self.day_table.setSelectionBehavior(QAbstractItemView.SelectRows); self.day_table.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.day_table.setEditTriggers(QAbstractItemView.NoEditTriggers); self.day_table.setSortingEnabled(True); self.day_table.setShowGrid(False); self.day_table.setWordWrap(False)
        self.day_table.setIconSize(QSize(44,44)); self.day_table.verticalHeader().setVisible(False); self.day_table.verticalHeader().setDefaultSectionSize(56)
        self.day_table.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded); self.day_table.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel); self.day_table.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel); self.day_table.setMouseTracking(True)
        self.day_table.setItemDelegateForColumn(0,self.day_checkbox_delegate); self.day_table.setItemDelegateForColumn(5,self.day_status_delegate); self.day_table.setItemDelegateForColumn(6,self.day_order_number_delegate)
        dh=self.day_table.horizontalHeader(); dh.setHighlightSections(False); dh.setStretchLastSection(False); dh.setSectionResizeMode(QHeaderView.Interactive); dh.setDefaultAlignment(Qt.AlignCenter)
        widths={0:64,1:72,2:96,3:330,4:64,5:225,6:138,7:210,8:240,9:330,10:108,11:126,12:220}
        for c,w in widths.items(): self.day_table.setColumnWidth(c,w)
        outer.addWidget(self.day_table,1)
        foot=QLabel("Click an Order # to open Apple Order Status. Hover ⧉ to copy. Click a Tracking # to open tracking."); foot.setObjectName("mutedSmall"); outer.addWidget(foot)

        back.clicked.connect(lambda: self.show_page(self.PAGE_RELEASES,self.releases_nav))
        self.day_search.textChanged.connect(self.refresh_day_orders); self.day_tabs.currentChanged.connect(self.refresh_day_orders)
        self.day_bulk_status_btn = QPushButton("Bulk Status"); self.day_bulk_status_btn.setEnabled(False)
        outer.insertWidget(3, self.day_bulk_status_btn, 0, Qt.AlignLeft)
        self.day_bulk_status_btn.clicked.connect(lambda: self.bulk_change_status(self.day_model))
        from apple_account_ui import actions_button
        tools.insertWidget(4,actions_button(self,self.day_model))
        self.day_model.checkedChanged.connect(self._day_selection_changed); self.day_table.clicked.connect(self.day_table_clicked); self.day_table.doubleClicked.connect(self.day_table_double_clicked)
        self.day_export_selected.clicked.connect(self.export_selected_day_orders); self.day_select_all.clicked.connect(lambda: self.day_model.set_all_checked(True)); self.day_clear_selected.clicked.connect(lambda: self.day_model.set_all_checked(False)); self.day_export_all.clicked.connect(self.export_all_day_orders)
        return page

    def show_page(self, index: int, selected_btn: QPushButton | None = None):
        self.stack.setCurrentIndex(index)
        selected_btn = selected_btn or self.orders_nav
        for btn in self._page_nav_buttons:
            btn.setObjectName("navSelected" if btn is selected_btn else "")
            btn.style().unpolish(btn); btn.style().polish(btn)
        if index == self.PAGE_APPLE:
            self.apple_page.refresh()
        elif index == self.PAGE_RELEASES:
            self.refresh_releases()
        elif index == self.PAGE_TRACKING:
            self.refresh_tracking()
        elif index == self.PAGE_PICKUP_TRACKING:
            self.refresh_pickup_tracking()
        elif index == self.PAGE_SCHEDULE:
            self.schedule_page.refresh_current()
        elif index == self.PAGE_DAY_ORDERS:
            self.refresh_day_orders()

    def apply_theme(self, theme: str):
        self.theme = "dark" if theme == "dark" else "light"
        self.settings.setValue("theme",self.theme)
        dark=self.theme=="dark"
        QApplication.instance().setProperty("trackerDark",dark)
        for calendar in self.findChildren(ReadableCalendar): calendar.set_dark(theme == "dark")
        self.theme_btn.setText("☀   Light Mode" if dark else "☾   Dark Mode")
        for model in (self.table_model,self.tracking_model,self.pickup_tracking_model,self.day_model):
            model.set_dark(dark)
        for delegate in (self.status_delegate,self.day_status_delegate,self.order_number_delegate,self.day_order_number_delegate,self.tracking_order_number_delegate,self.pickup_order_number_delegate,self.checkbox_delegate,self.day_checkbox_delegate,self.tracking_checkbox_delegate,self.pickup_status_delegate,self.pickup_checkbox_delegate,self.shipping_status_delegate):
            delegate.set_dark(dark)
        if hasattr(self, "schedule_page"):
            self.schedule_page.set_dark(dark)
            self.schedule_page.refresh_current()
        if dark:
            # Low-glare graphite/navy palette. No bright white dialog surfaces.
            c={"bg":"#0d1219","sidebar":"#10161f","panel":"#141c26","panel2":"#18222e","text":"#e6edf5","muted":"#94a3b8","border":"#283546","input":"#101821","alt":"#111923","accent":"#4f83ff","accentHover":"#6b98ff","soft":"#1a2a43","header":"#17212c","link":"#8eb4ff","scroll":"#3a4a5f","thumb":"#202b38"}
        else:
            c={"bg":"#f4f7fb","sidebar":"#ffffff","panel":"#ffffff","panel2":"#f7f9fc","text":"#182236","muted":"#6b7a90","border":"#dbe3ee","input":"#ffffff","alt":"#fafcff","accent":"#356df3","accentHover":"#285fdc","soft":"#edf3ff","header":"#f7f9fc","link":"#255fd6","scroll":"#c4cfdd","thumb":"#ffffff"}
        qss=f"""
        QWidget {{ font-family:'Segoe UI',Arial,sans-serif; font-size:13px; color:{c['text']}; }}
        QMainWindow, QDialog, QMessageBox, #content, #pageStack {{ background:{c['bg']}; }}
        QDialog QWidget, QMessageBox QWidget {{ color:{c['text']}; }}
        #sidebar {{ background:{c['sidebar']}; border-right:1px solid {c['border']}; }}
        #brandName {{ font-size:16px; font-weight:800; }} #pageTitle {{ font-size:29px; font-weight:800; }} #dialogTitle {{ font-size:22px; font-weight:800; }} #sectionTitle {{ font-size:18px; font-weight:750; }} #sectionLabel {{ font-weight:750; }}
        #muted {{ color:{c['muted']}; }} #mutedSmall {{ color:{c['muted']}; font-size:11px; }} #syncStatus {{ color:{c['accent']}; font-weight:650; }}
        QPushButton {{ background:{c['panel']}; border:1px solid {c['border']}; border-radius:10px; padding:8px 12px; font-weight:600; }}
        QPushButton:hover {{ background:{c['panel2']}; border-color:{c['accent']}; }}
        QPushButton:disabled {{ color:{c['muted']}; background:{c['panel2']}; border-color:{c['border']}; }}
        QPushButton[navButton='true'] {{ border:none; text-align:left; padding:11px 12px; background:transparent; font-weight:600; }}
        QPushButton[navButton='true']:hover {{ background:{c['panel2']}; }}
        #navSelected {{ background:{c['soft']}; color:{c['accent']}; border:none; text-align:left; padding:11px 12px; font-weight:800; }}
        #primaryButton {{ background:{c['accent']}; color:white; border:none; font-weight:750; padding:9px 15px; }} #primaryButton:hover {{ background:{c['accentHover']}; }}
        #secondaryAccent {{ color:{c['text']}; border:1px solid {c['border']}; background:{c['panel']}; }} #secondaryAccent:hover {{ border-color:{c['accent']}; color:{c['accent']}; }}
        #miniAction {{ padding:5px 9px; border-radius:8px; color:{c['muted']}; }} #miniAction:hover {{ color:{c['accent']}; border-color:{c['accent']}; }}
        #archivedBadge {{ background:{c['soft']}; color:{c['accent']}; border-radius:8px; padding:4px 8px; font-size:11px; font-weight:700; }}
        #dangerButton {{ color:#ef4444; border:1px solid #7f1d1d; }}
        QLineEdit,QComboBox,QDateEdit,QPlainTextEdit {{ background:{c['input']}; border:1px solid {c['border']}; border-radius:10px; padding:8px 10px; selection-background-color:{c['accent']}; }}
        QComboBox QAbstractItemView, QListView, QMenu {{ background:{c['panel']}; color:{c['text']}; border:1px solid {c['border']}; selection-background-color:{c['soft']}; selection-color:{c['text']}; }}
        QCheckBox {{ spacing:7px; }} QCheckBox::indicator {{ width:17px; height:17px; }}
        #upcomingFrame {{ background:{c['panel']}; border:1px solid {c['border']}; border-radius:13px; }}
        QPushButton[dateChip='true'] {{ min-width:122px; padding:5px 9px; background:{c['panel2']}; border:1px solid {c['border']}; border-radius:9px; font-size:11px; }} QPushButton[dateChip='true']:hover {{ border-color:{c['accent']}; }}
        QTabBar::tab {{ background:transparent; color:{c['muted']}; padding:9px 11px; margin-right:2px; border-radius:8px; }} QTabBar::tab:hover {{ background:{c['panel2']}; color:{c['text']}; }} QTabBar::tab:selected {{ color:{c['text']}; background:{c['panel']}; border:1px solid {c['border']}; font-weight:800; }}
        QTableView,QTableWidget {{ background:{c['panel']}; alternate-background-color:{c['alt']}; border:1px solid {c['border']}; border-radius:12px; gridline-color:{c['border']}; selection-background-color:{c['soft']}; selection-color:{c['text']}; outline:none; }}
        QTableView::item {{ border-bottom:1px solid {c['border']}; padding-left:9px; padding-right:9px; }} QTableView::item:hover {{ background:{c['soft']}; }}
        QTableView::indicator {{ width:18px; height:18px; }}
        QHeaderView::section {{ background:{c['header']}; color:{c['muted']}; border:none; border-bottom:1px solid {c['border']}; padding:11px 10px; font-weight:700; }}
        #calendarPanel,#schedulePanel,#detailCard,#releaseStats {{ background:{c['panel']}; border:1px solid {c['border']}; border-radius:14px; }} #scheduleCard,#itemSummaryCard {{ background:{c['panel2']}; border:1px solid {c['border']}; border-radius:13px; }}
        #releaseCard {{ background:{c['panel']}; border:1px solid {c['border']}; border-radius:14px; }} #releaseCard:hover {{ border-color:{c['accent']}; background:{c['panel2']}; }}
        #releaseLogo,#releaseHeroLogo {{ background:{c['soft']}; color:{c['accent']}; border-radius:24px; font-size:25px; font-weight:800; }} #releaseTitle {{ font-size:17px; font-weight:800; }} #releaseArrow {{ color:{c['muted']}; font-size:24px; }}
        #releaseThumb,#releaseThumbMore {{ background:{c['thumb']}; border:1px solid {c['border']}; border-radius:10px; color:{c['muted']}; }} #releaseMetric,#miniStat {{ background:{c['panel2']}; border-radius:9px; }} #metricLabel,.metricLabel {{ color:{c['muted']}; font-size:10px; font-weight:700; }} #metricValue {{ font-size:15px; font-weight:800; }}
        #productThumb {{ background:{c['panel']}; border:1px solid {c['border']}; border-radius:12px; font-size:26px; color:{c['muted']}; }} #cardItem {{ font-size:15px; font-weight:750; }} #typeBadge,#qtyBadge {{ background:{c['soft']}; color:{c['accent']}; border-radius:8px; padding:4px 8px; font-weight:700; }} #fulfillmentPrimary {{ font-weight:750; }} #linkButton {{ background:transparent; border:none; color:{c['link']}; padding:3px 2px; text-decoration:underline; }}
        #emptyState {{ background:{c['panel2']}; border:1px dashed {c['border']}; border-radius:13px; }} #emptyIcon {{ color:{c['muted']}; font-size:30px; }}
        QListWidget,QTextBrowser,QCalendarWidget {{ background:{c['panel']}; color:{c['text']}; border:1px solid {c['border']}; border-radius:10px; }} QCalendarWidget QWidget {{ background:{c['panel']}; color:{c['text']}; }} QCalendarWidget QToolButton {{ border:none; background:transparent; color:{c['text']}; padding:8px; font-weight:700; }} QCalendarWidget QAbstractItemView {{ background:{c['panel']}; color:{c['text']}; border:none; outline:none; selection-background-color:{c['accent']}; selection-color:white; }}
        QProgressBar {{ border:none; background:{c['border']}; border-radius:2px; }} QProgressBar::chunk {{ background:{c['accent']}; border-radius:2px; }} QScrollArea {{ background:transparent; border:none; }} QScrollArea > QWidget > QWidget {{ background:transparent; }} QToolTip {{ background:{c['panel']}; color:{c['text']}; border:1px solid {c['border']}; padding:5px; }}
        QScrollBar:vertical {{ background:transparent; width:12px; margin:4px 2px; }} QScrollBar::handle:vertical {{ background:{c['scroll']}; border-radius:5px; min-height:42px; }} QScrollBar::handle:vertical:hover {{ background:{c['accent']}; }} QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical {{ height:0; }}
        QScrollBar:horizontal {{ background:transparent; height:13px; margin:2px 8px 3px 8px; }} QScrollBar::handle:horizontal {{ background:{c['scroll']}; min-width:90px; border-radius:6px; }} QScrollBar::handle:horizontal:hover {{ background:{c['accent']}; }} QScrollBar::add-line:horizontal,QScrollBar::sub-line:horizontal {{ width:0; }} QScrollBar::add-page:horizontal,QScrollBar::sub-page:horizontal {{ background:transparent; }}
        """
        QApplication.instance().setStyleSheet(qss)
        for table in (self.table,self.tracking_table,self.pickup_table,self.day_table):
            table.viewport().update()

    def toggle_theme(self): self.apply_theme("light" if self.theme=="dark" else "dark")

    def show_first_run_hint(self):
        QMessageBox.information(self,APP_NAME,"Add your Gmail account first.\n\nUse a Google App Password rather than your normal Gmail password. The credential is stored in Windows Credential Manager.")

    def manage_accounts(self): AccountDialog(self.db,self).exec(); self.refresh_all()
    def open_settings(self): SettingsDialog(self.settings,self).exec()

    def _maybe_auto_check_update(self):
        if str(self.settings.value("updates_auto_check", "true")).lower() == "false":
            return
        # Avoid hammering GitHub if the user opens the app several times in one day.
        last = clean_text(str(self.settings.value("updates_last_check_utc", "") or ""))
        if last:
            try:
                prior = datetime.fromisoformat(last.replace("Z", "+00:00"))
                if prior.tzinfo is None:
                    prior = prior.replace(tzinfo=timezone.utc)
                if datetime.now(timezone.utc) - prior < timedelta(hours=6):
                    return
            except Exception:
                pass
        self.check_for_updates(False)

    def check_for_updates(self, manual=True):
        if self._update_check_worker and self._update_check_worker.isRunning():
            if manual:
                QMessageBox.information(self, APP_NAME, "An update check is already running.")
            return
        self._update_manual_request = bool(manual)
        if manual:
            self.sync_status.setText(f"Checking GitHub for {APP_NAME} updates…")
        worker = AppUpdateCheckWorker(self)
        self._update_check_worker = worker
        worker.result_ready.connect(self._update_check_finished)
        worker.failed.connect(self._update_check_failed)
        worker.start()

    def _update_check_finished(self, info):
        worker = self._update_check_worker
        self._update_check_worker = None
        if worker is not None:
            worker.deleteLater()
        self.settings.setValue("updates_last_check_utc", datetime.now(timezone.utc).isoformat())
        self.settings.sync()
        manual = self._update_manual_request
        self._update_manual_request = False
        if info is None:
            if manual:
                self.sync_status.setText(f"{APP_NAME} v{APP_VERSION} is up to date.")
                QMessageBox.information(self, APP_NAME, f"You already have the newest stable version: v{APP_VERSION}.")
            return
        self._update_pending_info = info
        notes = clean_text(info.notes) or "This release contains improvements and fixes."
        if len(notes) > 2200:
            notes = notes[:2200].rstrip() + "…"
        box = QMessageBox(self)
        box.setWindowTitle(f"{APP_NAME} update")
        box.setIcon(QMessageBox.Information)
        box.setText(f"{APP_NAME} v{info.version} is available.")
        box.setInformativeText(f"Installed: v{APP_VERSION}\n\n{notes}\n\nDownload, verify, install, and restart now?")
        update_btn = box.addButton("Update Now", QMessageBox.ButtonRole.AcceptRole)
        box.addButton("Later", QMessageBox.ButtonRole.RejectRole)
        box.exec()
        if box.clickedButton() is update_btn:
            self.install_update(info)

    def _update_check_failed(self, message):
        worker = self._update_check_worker
        self._update_check_worker = None
        if worker is not None:
            worker.deleteLater()
        manual = self._update_manual_request
        self._update_manual_request = False
        if manual:
            self.sync_status.setText("Update check could not complete.")
            QMessageBox.warning(self, APP_NAME, message)

    def _network_work_busy_for_update(self):
        page=getattr(self,'apple_page',None)
        if page and ((page.importer and page.importer.isRunning()) or
                     (page.worker and page.worker.isRunning() and page.worker.runner.sessions)):
            return True
        return bool((self.sync_worker and self.sync_worker.isRunning()) or
                    (self.verify_worker and self.verify_worker.isRunning()) or
                    self._ups_busy)

    def install_update(self, info: UpdateInfo):
        if self._network_work_busy_for_update():
            QMessageBox.information(self, APP_NAME, "Finish Gmail/UPS and profile imports, and disconnect the Apple browser before installing an app update. Queued jobs are preserved.")
            return
        if not can_self_update():
            QMessageBox.information(self, APP_NAME, "Automatic replacement works from the built Windows AhPaTaTracker.exe. Source-mode runs cannot replace the Python interpreter.")
            if info.release_url:
                QDesktopServices.openUrl(QUrl(info.release_url))
            return
        if self._update_download_worker and self._update_download_worker.isRunning():
            return

        dlg = QDialog(self); dlg.setWindowTitle(f"Updating {APP_NAME}"); dlg.setModal(True); dlg.resize(520, 180)
        layout = QVBoxLayout(dlg); layout.setContentsMargins(24,22,24,22); layout.setSpacing(12)
        title = QLabel(f"Downloading v{info.version}"); title.setObjectName("dialogTitle"); layout.addWidget(title)
        label = QLabel("Downloading the release asset from GitHub and verifying its SHA-256 checksum…")
        label.setObjectName("muted"); label.setWordWrap(True); layout.addWidget(label)
        bar = QProgressBar(); bar.setRange(0,0); layout.addWidget(bar)
        note = QLabel("The tracker will close, replace its EXE, and reopen automatically after verification.")
        note.setObjectName("mutedSmall"); note.setWordWrap(True); layout.addWidget(note)
        self._update_progress_dialog = dlg; self._update_progress_bar = bar; self._update_progress_label = label
        dlg.show()

        worker = AppUpdateDownloadWorker(info, self)
        self._update_download_worker = worker
        worker.progress.connect(self._update_download_progress)
        worker.downloaded.connect(lambda path: self._update_download_finished(info, path))
        worker.failed.connect(self._update_download_failed)
        worker.start()

    def _update_download_progress(self, current, total):
        bar = self._update_progress_bar
        label = self._update_progress_label
        if not bar or not label:
            return
        if total > 0:
            pct = max(0, min(100, int(current * 100 / total)))
            bar.setRange(0,100); bar.setValue(pct)
            label.setText(f"Downloading update… {current / 1048576:.1f} MB of {total / 1048576:.1f} MB")
        else:
            bar.setRange(0,0)
            label.setText(f"Downloading update… {current / 1048576:.1f} MB")

    def _clear_update_download_ui(self):
        worker = self._update_download_worker
        self._update_download_worker = None
        if worker is not None:
            worker.deleteLater()
        if self._update_progress_dialog:
            self._update_progress_dialog.close(); self._update_progress_dialog.deleteLater()
        self._update_progress_dialog = None; self._update_progress_bar = None; self._update_progress_label = None

    def _update_download_failed(self, message):
        self._clear_update_download_ui()
        QMessageBox.warning(self, APP_NAME, message)

    def _update_download_finished(self, info: UpdateInfo, path: str):
        self._clear_update_download_ui()
        try:
            script = make_update_script(Path(path), Path(sys.executable), info.version)
            launch_update_script(script)
        except UpdateError as exc:
            QMessageBox.critical(self, APP_NAME, f"The update downloaded and verified, but Windows could not stage the replacement.\n\n{exc}")
            return
        self._updating = True
        self.settings.setValue("updates_last_installed_request", info.version); self.settings.sync()
        QMessageBox.information(self, APP_NAME, f"v{info.version} downloaded and verified.\n\n{APP_NAME} will now close, replace the EXE, and reopen automatically.")
        self.close()  # closeEvent drains worker-owned sessions/databases before OTA replacement.

    def _update_range_label(self):
        if self.filter_start and self.filter_end:
            try:
                a=date.fromisoformat(self.filter_start); b=date.fromisoformat(self.filter_end); self.range_label.setText(f"Order dates: {a.strftime('%b %d, %Y')} – {b.strftime('%b %d, %Y')}")
            except Exception: self.range_label.setText(f"Order dates: {self.filter_start} – {self.filter_end}")
        else: self.range_label.setText("All order dates")

    def refresh_details(self):
        if self.sync_worker and self.sync_worker.isRunning(): return
        text=(f"Refresh Details will re-read Apple emails from {display_date_long(self.filter_start)} through {display_date_long(self.filter_end)} across All Mail, Spam, and Trash without deleting the local database. Continue?" if self.filter_start and self.filter_end else "Refresh Details re-reads existing Apple order emails across All Mail, Spam, and Trash without deleting the local database. Continue?")
        if QMessageBox.question(self,APP_NAME,text)!=QMessageBox.Yes: return
        self._start_sync_worker(refresh_all=True,start_date=self.filter_start,end_date=self.filter_end)

    def _cache_rebuild_block_reason(self) -> str:
        page = getattr(self, 'apple_page', None)
        workers = [self.sync_worker, self.verify_worker, self._update_download_worker]
        if page:
            workers.extend(getattr(page, name, None) for name in ('worker', 'importer', 'route_worker'))
        if self._ups_busy or self._updating or any(worker and worker.isRunning() for worker in workers):
            return ("Rebuild Cache is unavailable while Gmail, UPS, Apple, profile import, proxy checks, "
                    "or an app update is active. Finish that work first.\n\n"
                    "Use Full Account Sync or Refresh Details to refresh orders while preserving saved data.")
        return self.db.order_cache_rebuild_block_reason()

    def full_rescan(self):
        reason = self._cache_rebuild_block_reason()
        if reason:
            QMessageBox.information(self, APP_NAME, reason)
            return
        if QMessageBox.question(self,APP_NAME,"Rebuild Cache deletes the locally parsed order/event cache and rereads Apple order email. Gmail itself is not modified. Continue?")!=QMessageBox.Yes: return
        # The confirmation dialog runs an event loop: work or Apple state may
        # have appeared since the first check. The database also checks atomically.
        reason = self._cache_rebuild_block_reason()
        if reason:
            QMessageBox.information(self, APP_NAME, reason)
            return
        try:
            self.db.reset_order_cache()
        except ValueError as exc:
            QMessageBox.information(self, APP_NAME, str(exc))
            return
        except sqlite3.Error:
            QMessageBox.warning(self, APP_NAME, "Rebuild Cache could not complete safely. Finish any active work and try again, or use Full Account Sync / Refresh Details.")
            return
        self.refresh_all(); self.start_sync()

    def start_sync(self):
        if self.sync_worker and self.sync_worker.isRunning(): return
        if not self.db.list_accounts():
            self.manage_accounts()
            if not self.db.list_accounts(): return
        dlg=SyncRangeDialog(self.db,self.settings,self)
        if dlg.exec()!=QDialog.Accepted: return
        self.filter_start=dlg.start_iso(); self.filter_end=dlg.end_iso(); self.settings.setValue("dashboard_start_date",self.filter_start); self.settings.setValue("dashboard_end_date",self.filter_end); self.refresh_all()
        if dlg.sync_mode() == "full":
            # Full Account Sync intentionally scans all historical Apple order mail.
            # Dashboard dates remain a display filter only.
            self._start_sync_worker(True,"","",dlg.selected_account_ids())
        else:
            # Everyday mode: only UIDs newer than the saved per-mailbox checkpoint,
            # plus any isolated messages queued from an earlier failed fetch/parse.
            self._start_sync_worker(False,"","",dlg.selected_account_ids())

    def _start_sync_worker(self, refresh_all=False, start_date="", end_date="", account_ids=None):
        self.sync_btn.setEnabled(False); self.verify_btn.setEnabled(False); self.accounts_nav.setEnabled(False); self.rescan_nav.setEnabled(False); self.progress.setValue(0)
        if refresh_all and not (start_date or end_date):
            self.sync_status.setText("Full Account Sync — scanning all historical Apple order emails. Progress is saved after every batch and Gmail throttling is retried automatically…")
        elif refresh_all or start_date or end_date:
            self.sync_status.setText(f"Refreshing Apple order emails from {start_date or 'beginning'} through {end_date or 'today'}…")
        else:
            self.sync_status.setText("New Emails Only — checking Gmail UIDs newer than the saved checkpoint…")
        self.sync_worker=SyncWorker(db_path(),refresh_all=refresh_all,start_date=start_date,end_date=end_date,account_ids=account_ids); self.sync_worker.progress.connect(self.on_sync_progress); self.sync_worker.failed.connect(self.on_sync_failed); self.sync_worker.notice.connect(self.on_sync_notice); self.sync_worker.all_done.connect(self.on_sync_done); self.sync_worker.start()

    def on_sync_progress(self,current,total,message):
        self.sync_status.setText(message)
        if total<=0: self.progress.setRange(0,0)
        else: self.progress.setRange(0,100); self.progress.setValue(int(current*100/max(1,total)))

    def on_sync_notice(self, message):
        # Non-fatal problems never re-enable controls or stop the worker. They are
        # surfaced in the status line while the sync continues automatically.
        self.sync_status.setText(message)

    def on_sync_failed(self,message):
        self.sync_btn.setEnabled(True); self.verify_btn.setEnabled(True); self.accounts_nav.setEnabled(True); self.rescan_nav.setEnabled(True); self.progress.setRange(0,100); self.sync_status.setText(message); QMessageBox.warning(self,APP_NAME,message)

    def on_sync_done(self,processed,order_updates):
        self.sync_btn.setEnabled(True); self.verify_btn.setEnabled(True); self.accounts_nav.setEnabled(True); self.rescan_nav.setEnabled(True); self.progress.setRange(0,100); self.progress.setValue(100)
        cancel_count = int(getattr(self.sync_worker, "cancel_count", 0) or 0) if self.sync_worker else 0
        error_count = int(getattr(self.sync_worker, "error_count", 0) or 0) if self.sync_worker else 0
        deferred = int(getattr(self.sync_worker, "deferred_count", 0) or 0) if self.sync_worker else 0
        retries = int(getattr(self.sync_worker, "retry_count", 0) or 0) if self.sync_worker else 0
        parts = []
        if processed == 0:
            parts.append("no new Apple order emails found")
        else:
            parts.append(f"{processed:,} Apple emails checked")
            parts.append(f"{order_updates:,} order updates imported")
        if cancel_count:
            parts.append(f"{cancel_count:,} cancellation email{'s' if cancel_count != 1 else ''} detected")
        if retries:
            parts.append(f"{retries:,} automatic Gmail retr{'ies' if retries != 1 else 'y'}")
        if error_count:
            parts.append(f"{error_count:,} isolated error{'s' if error_count != 1 else ''}")
        if deferred:
            parts.append(f"{deferred:,} message{'s' if deferred != 1 else ''} queued for retry")
        self.sync_status.setText("Sync complete — " + " • ".join(parts) + ".")
        self.refresh_all()
        # Optionally refresh UPS shipments after Gmail sync. This uses the official
        # UPS API only; Apple pickup website checks remain disabled.
        QTimer.singleShot(150, self._auto_verify_if_enabled)

    def _ups_credentials_available(self) -> bool:
        try:
            cid, secret = load_ups_pair(keyring, APP_KEYRING_SERVICE)
            return bool(cid and secret)
        except Exception:
            return False

    def _auto_verify_if_enabled(self):
        if str(self.settings.value("ups_auto_refresh", "true")).lower() == "false":
            return
        if not self._ups_credentials_available():
            return
        if (self.sync_worker and self.sync_worker.isRunning()) or (self.verify_worker and self.verify_worker.isRunning()):
            return
        self.start_verification(force=False)

    def start_verification(self, force=True, order_ids=None):
        # Explicit [] is never interpreted as all orders.
        if order_ids is not None and not order_ids:
            self.sync_status.setText("No selected UPS orders to check.")
            return
        if self._ups_busy or (self.verify_worker and self.verify_worker.isRunning()):
            self.sync_status.setText("A UPS check is already running. Use Stop UPS to stop after the current request.")
            return
        if self.sync_worker and self.sync_worker.isRunning():
            self.sync_status.setText("Wait for Gmail sync to finish before starting UPS.")
            return
        if not self._ups_credentials_available():
            message = "UPS credentials missing. Open Settings > UPS API Tracking and save your Client ID and Secret."
            self.sync_status.setText(message); self.tracking_feedback.setText(message)
            for indicator in (self.ups_indicator, self.tracking_indicator):
                indicator.set_state("UPS not configured", error=True)
            return
        self._ups_busy = True; self._ups_active_ids.clear(); self._ups_report = []; self._ups_last_stats = {}
        self.verify_btn.setEnabled(False); self.tracking_refresh_btn.setEnabled(False)
        self.tracking_check_selected.setEnabled(False)
        self.tracking_refresh_btn.setText("Refreshing UPS...")
        self.ups_cancel_btn.setVisible(True); self.ups_cancel_btn.setEnabled(True)
        self._ups_repaint_timer.start()
        for indicator in (self.ups_indicator, self.tracking_indicator):
            indicator.set_state("Connecting to UPS...", busy=True)
        self.sync_status.setText("Preparing UPS package checks...")
        self.tracking_feedback.setText("Preparing UPS package checks...")
        self.progress.setRange(0,0)
        worker = VerificationWorker(db_path(), self.filter_start, self.filter_end,
                                    force=force, order_ids=order_ids, skip_apple=True, ups_only=True)
        self.verify_worker = worker
        worker.progress.connect(self.on_verify_progress)
        worker.package_started.connect(self._ups_package_started)
        worker.order_updated.connect(self._ups_order_updated)
        worker.failed.connect(self._ups_failed)
        worker.all_done.connect(self.on_verify_done)
        worker.finished.connect(self._tracking_selection_changed)
        worker.start()

    def on_verify_progress(self,current,total,message):
        self.sync_status.setText(message); self.tracking_feedback.setText(message)
        for indicator in (self.ups_indicator, self.tracking_indicator):
            indicator.set_state(f"UPS live check {current}/{total}" if total else "Connecting to UPS...", busy=True)
        if total > 0:
            self.progress.setRange(0,100); self.progress.setValue(int(current * 100 / total))

    def on_verify_done(self,checked,updated):
        worker = self.verify_worker
        if worker:
            self._ups_report = list(worker.report_lines)
            self._ups_last_stats = dict(worker.stats)
        self._finish_verification(int(checked or 0), int(updated or 0))

    def _on_apple_webengine_done(self,checked,updated):
        total_checked = self._verify_worker_checked + int(checked or 0)
        total_updated = self._verify_worker_updated + int(updated or 0)
        checker = self.apple_web_checker
        self.apple_web_checker = None
        if checker:
            checker.deleteLater()
        self._finish_verification(total_checked, total_updated)

    def _finish_verification(self,checked,updated):
        self._ups_busy = False; self._ups_active_ids.clear()
        self._ups_repaint_timer.stop(); self._ups_refresh_timer.stop()
        self.verify_btn.setEnabled(True); self.tracking_refresh_btn.setEnabled(True)
        self.tracking_refresh_btn.setText("Refresh UPS"); self.ups_cancel_btn.setVisible(False)
        self.progress.setRange(0,100)
        stats = self._ups_last_stats
        ok = int(stats.get("success",0)); errors = int(stats.get("errors",0)); skipped = int(stats.get("skipped",0))
        problem = errors > 0 or bool(stats.get("fatal")) or skipped > 0
        if checked:
            summary = (f"UPS: {checked:,} packages checked | {ok:,} successful | {errors:,} failed | "
                       f"{updated:,} order statuses changed | {skipped:,} not checked. See UPS Results for details.")
        elif problem:
            summary = "UPS check did not complete. " + str(stats.get("fatal") or "Some packages were not checked.") + " Open UPS Results."
        else:
            summary = "No eligible UPS shipments needed a check. Use Refresh UPS for the current active shipping view."
        self.progress.setValue(100 if not problem else int(checked * 100 / max(1, checked + skipped)))
        for indicator in (self.ups_indicator, self.tracking_indicator):
            indicator.set_state("UPS needs attention" if problem else "UPS check finished" if checked else "UPS idle", error=problem)
        self.sync_status.setText(summary); self.tracking_feedback.setText(summary)
        self.refresh_all()

    def refresh_all(self):
        self._update_range_label(); self.refresh_tabs(); self.refresh_upcoming(); self.refresh_table()
        self.refresh_releases(); self.refresh_tracking(); self.refresh_pickup_tracking()
        self.schedule_page.refresh_current()
        if self.current_order_day: self.refresh_day_orders()
        self.refresh_ups_cards()
        calendar = self.date_picker.calendarWidget()
        if isinstance(calendar,ReadableCalendar):
            calendar.set_dark(self.theme == "dark")

    def refresh_tabs(self):
        counts = self.db.tab_counts(self.filter_start,self.filter_end)
        self.tabs.blockSignals(True)
        try:
            for i,name in enumerate(self.TAB_FILTERS):
                glyph = "\u25a3" if name == "All Orders" else ("\u2302" if name == "Pickup Processing" else STATUS_GLYPHS.get(name,"-"))
                self.tabs.setTabText(i,f"{glyph}  {name}  {counts.get(name,0):,}")
                self.tabs.setTabVisible(i, name not in UPS_STATES or counts.get(name,0) > 0 or i == self.tabs.currentIndex())
        finally:
            self.tabs.blockSignals(False)

    def refresh_upcoming(self):
        while self.chip_layout.count():
            item=self.chip_layout.takeAt(0); w=item.widget();
            if w: w.deleteLater()
        rows=self.db.upcoming_deliveries(45,self.filter_start,self.filter_end); grouped={}
        for row in rows:
            e=grouped.setdefault(row["eta_date"],{"orders":0,"items":0,"kinds":[]}); e["orders"]+=int(row["order_count"] or 0); e["items"]+=int(row["item_count"] or 0); k=row["order_type"] or "Shipping";
            if k not in e["kinds"]: e["kinds"].append(k)
        if not grouped:
            e=QLabel("No future delivery or pickup dates"); e.setObjectName("muted"); self.chip_layout.addWidget(e)
        else:
            for iso,e in list(grouped.items())[:10]:
                try: d=date.fromisoformat(iso); top=d.strftime("%a %b %d")
                except Exception: d=date.today(); top=iso
                chip=QPushButton(f"{top}  •  {e['orders']} orders / {e['items']} items  •  {'/'.join(e['kinds'])}"); chip.setProperty("dateChip",True); chip.clicked.connect(lambda _=False,x=d:self.open_schedule(x)); self.chip_layout.addWidget(chip)
        self.chip_layout.addStretch(1)

    def current_filter(self):
        idx=self.tabs.currentIndex(); return self.TAB_FILTERS[idx] if 0<=idx<len(self.TAB_FILTERS) else "All Orders"

    def _tab_changed(self): self.refresh_table()

    def refresh_table(self):
        rows = self.db.query_orders(self.current_filter(),self.search_edit.text(),self.filter_start,self.filter_end)
        self.table_model.set_rows(rows); self.result_label.setText(f"{len(rows):,} orders")
        self._order_selection_changed()
        shipping_filter = self.current_filter() in ("Shipped", "Delivered") + tuple(UPS_STATES)
        self.bulk_main_btn.setVisible(shipping_filter)
        self.bulk_main_btn.setEnabled(shipping_filter and any(split_tracking_numbers(r["tracking_number"] or "") for r in rows))
        self.bulk_main_btn.setToolTip("Open tracking numbers in the current view" if self.bulk_main_btn.isEnabled() else "No tracking numbers in the current view")

    def _order_selection_changed(self,*_):
        count=len(self.table_model.checked_order_ids()); self.selected_label.setText(f"{count:,} selected"); self.export_selected_btn.setEnabled(count>0); self.bulk_status_btn.setEnabled(count>0)

    def _manual_edits_changed(self,*_):
        count = self.table_model.pending_order_count()
        self.save_overrides_btn.setEnabled(count > 0)
        self.save_overrides_btn.setText(f"Save Changes ({count})" if count else "Save Changes")
        if count:
            self.sync_status.setText(f"{count:,} order{'s' if count != 1 else ''} have unsaved manual changes.")

    def save_manual_overrides(self):
        changes = self.table_model.pending_changes()
        if not changes:
            return
        try:
            self.db.apply_manual_overrides(changes)
        except Exception as exc:
            QMessageBox.warning(self, APP_NAME, f"Could not save manual changes: {exc}")
            return
        count = len(changes)
        self.table_model.clear_pending()
        self.sync_status.setText(
            f"Saved manual override{'s' if count != 1 else ''} for {count:,} order{'s' if count != 1 else ''}. "
            "Manual overrides now have the highest priority and will survive future Gmail syncs."
        )
        self.refresh_all()

    def selected_order_ids(self):
        return self.table_model.checked_order_ids()

    def export_selected_orders(self):
        rows=self.db.orders_by_ids(self.selected_order_ids()); save_rows_csv(self,self.settings,rows,"apple_orders_selected",f"Selected orders — {len(rows):,}")

    def bulk_tracking_current_view(self):
        rows=[r for r in self.table_model.rows if split_tracking_numbers(r["tracking_number"] or "")]
        if not rows: return
        BulkTrackingDialog(rows,None,self,"Shipped orders — current view").exec()

    def copy_order_number(self,order_number): QApplication.clipboard().setText(order_number); self._copy_guard_until=time.monotonic()+0.45; self.sync_status.setText(f"Copied {order_number} to clipboard")

    def open_order_status(self, row):
        url = effective_apple_order_url(row)
        if url:
            QDesktopServices.openUrl(QUrl(url))

    def table_clicked(self,index):
        row=self.table_model.row_at(index.row());
        if not row: return
        key=self.table_model.COLUMNS[index.column()][0]
        if key in ("status", "qty"):
            # Status becomes a dropdown; Qty becomes a number editor. Changes are
            # staged until the top-right Save Changes button is pressed.
            self.table.edit(index)
            return
        if key=="order_number":
            if time.monotonic()<self._copy_guard_until: return
            self.open_order_status(row)
        elif key=="tracking_number" and row["tracking_number"]:
            url=safe_tracking_url(row["tracking_url"] or "") or direct_tracking_url(row["tracking_number"] or "",row["carrier"] or "")
            if url: QDesktopServices.openUrl(QUrl(url))

    def table_double_clicked(self,index):
        if index.data(Qt.CheckStateRole) is not None: return
        row=self.table_model.row_at(index.row())
        if row: OrderDetailDialog(self.db,row,self).exec()

    def open_selected_date(self):
        q=self.date_picker.date(); self.open_schedule(date(q.year(),q.month(),q.day()))
    def open_schedule(self,initial_date=None):
        self.show_page(self.PAGE_SCHEDULE,self.schedule_nav); self.schedule_page.set_date(initial_date or self.schedule_page.current_date or date.today())

    def refresh_releases(self):
        if not hasattr(self,"release_grid"): return
        while self.release_grid.count():
            item=self.release_grid.takeAt(0); w=item.widget()
            if w: w.deleteLater()
        include_archived = bool(self.show_archived_dates.isChecked()) if hasattr(self,"show_archived_dates") else False
        summaries=list(self.db.release_summaries(self.filter_start,self.filter_end,include_archived=include_archived))
        needle=self.release_search.text().strip().lower() if hasattr(self,"release_search") else ""
        if needle:
            filtered=[]
            for r in summaries:
                iso=r["order_day"] or ""
                try: long=date.fromisoformat(iso).strftime("%A %B %d %Y").lower()
                except Exception: long=iso.lower()
                if needle in iso.lower() or needle in long: filtered.append(r)
            summaries=filtered
        archived_visible=sum(1 for r in summaries if int(r.get("archived",0)))
        suffix=f"  •  {archived_visible:,} archived" if archived_visible else ""
        self.release_result.setText(f"{len(summaries):,} order date{'s' if len(summaries)!=1 else ''}{suffix}")
        if not summaries:
            empty=QLabel("No order dates found in the active range"); empty.setObjectName("muted"); empty.setAlignment(Qt.AlignCenter); self.release_grid.addWidget(empty,0,0,1,3); return
        for i,summary in enumerate(summaries):
            card=ReleaseCard(summary,self.image_cache,self.release_host)
            card.clicked.connect(self.open_release_day)
            card.archiveRequested.connect(self.set_release_archive)
            self.release_grid.addWidget(card,i//3,i%3)
        for c in range(3): self.release_grid.setColumnStretch(c,1)
        self.release_grid.setRowStretch((len(summaries)+2)//3,1)

    def set_release_archive(self, order_day: str, archive: bool):
        if archive:
            affected = {int(r["id"]) for r in self.db.orders_for_order_date(order_day)}
            pending = set(self.table_model.pending_changes()) | set(self.day_model.pending_changes())
            if pending & affected:
                QMessageBox.information(self,APP_NAME,"Save or discard unsaved edits for this date before archiving it.")
                return
            self.db.archive_order_day(order_day)
        else:
            self.db.restore_order_day(order_day)
        self.refresh_all()
        self.sync_status.setText(("Archived " if archive else "Restored ") + order_day + " across all pages, counts, exports and tracking.")

    def open_release_day(self,order_day):
        if order_day in self.db.archived_order_days():
            QMessageBox.information(self,APP_NAME,"This date is archived. Click Restore on its date card before opening its orders.")
            return
        self.current_order_day=clean_text(order_day)
        self.day_model.clear_checked()
        self.day_search.clear()
        self.day_tabs.setCurrentIndex(0)
        self.refresh_day_orders()
        self.show_page(self.PAGE_DAY_ORDERS,self.releases_nav)

    def refresh_tracking(self):
        if not hasattr(self,"tracking_model"): return
        rows=self.db.tracking_rows(self.tracking_search.text() if hasattr(self,"tracking_search") else "",self.tracking_carrier.currentText() if hasattr(self,"tracking_carrier") else "",self.tracking_status_filter.currentText() if hasattr(self,"tracking_status_filter") else "",self.filter_start,self.filter_end); self.tracking_model.set_rows(rows)
        if hasattr(self,"tracking_table") and self.tracking_table.isSortingEnabled():
            hh=self.tracking_table.horizontalHeader(); self.tracking_model.sort(hh.sortIndicatorSection(),hh.sortIndicatorOrder())
        if hasattr(self,"tracking_count"): self.tracking_count.setText(f"{len(rows):,} active shipment{'s' if len(rows)!=1 else ''}")
        if hasattr(self,"tracking_bulk_btn"): self.tracking_bulk_btn.setEnabled(bool(rows)); self._tracking_selection_changed()

    def _tracking_selection_changed(self,*_):
        ids = set(self.tracking_model.checked_order_ids())
        self.tracking_selected_label.setText(f"{len(ids):,} selected")
        self.tracking_export_selected.setEnabled(bool(ids))
        self.tracking_bulk_status.setEnabled(bool(ids))
        has_ups = any(int(r["id"]) in ids and ups_numbers_for_order(r) for r in self.tracking_model.rows)
        self.tracking_check_selected.setEnabled(has_ups and not self._ups_busy)

    def tracking_selected_ids(self):
        return self.tracking_model.checked_order_ids()

    def export_selected_tracking_orders(self):
        rows=self.db.orders_by_ids(self.tracking_model.checked_order_ids())
        if rows:
            save_rows_csv(self,self.settings,rows,"apple_shipping_selected",f"Selected shipping orders — {len(rows):,}")

    def check_selected_tracking(self):
        selected = set(self.tracking_selected_ids())
        ids = [int(r["id"]) for r in self.tracking_model.rows if int(r["id"]) in selected and ups_numbers_for_order(r)]
        if not ids:
            self.tracking_feedback.setText("Check the boxes beside one or more UPS orders first.")
            return
        self.start_verification(force=True,order_ids=ids)

    def refresh_all_tracking_status(self):
        ids = [int(r["id"]) for r in self.tracking_model.rows if ups_numbers_for_order(r)]
        if not ids:
            self.tracking_feedback.setText("No eligible UPS tracking numbers in this shipping view.")
            return
        self.start_verification(force=True,order_ids=ids)

    def bulk_tracking_tracking_page(self):
        rows=[r for r in self.tracking_model.rows if split_tracking_numbers(r["tracking_number"] or "")]
        if rows: BulkTrackingDialog(rows,None,self,"Shipping Tracking — current view").exec()

    def tracking_table_clicked(self,index):
        row=self.tracking_model.row_at(index.row());
        if not row: return
        key=self.tracking_model.COLUMNS[index.column()][0]
        if key=="order_number":
            if time.monotonic()<self._copy_guard_until: return
            self.open_order_status(row)
        elif key=="tracking_number":
            url=safe_tracking_url(row["tracking_url"] or "") or direct_tracking_url(row["tracking_number"] or "",row["carrier"] or "")
            if url: QDesktopServices.openUrl(QUrl(url))

    def tracking_table_double_clicked(self,index):
        if index.data(Qt.CheckStateRole) is not None: return
        row=self.tracking_model.row_at(index.row())
        if row: OrderDetailDialog(self.db,row,self).exec()

    def export_pickup_tracking_orders(self):
        rows=list(self.pickup_tracking_model.rows) if hasattr(self,"pickup_tracking_model") else []
        if not rows:
            QMessageBox.information(self,APP_NAME,"There are no pickup orders in the current view to export.")
            return
        save_rows_csv(
            self,
            self.settings,
            rows,
            "apple_pickup_tracking",
            f"Pickup Tracking — current view — {len(rows):,} order{'s' if len(rows)!=1 else ''}",
        )

    def refresh_pickup_tracking(self):
        if not hasattr(self,"pickup_tracking_model"): return
        rows=self.db.pickup_tracking_rows(self.pickup_search.text() if hasattr(self,"pickup_search") else "",self.filter_start,self.filter_end)
        self.pickup_tracking_model.set_rows(rows)
        if hasattr(self,"pickup_table") and self.pickup_table.isSortingEnabled():
            hh=self.pickup_table.horizontalHeader(); self.pickup_tracking_model.sort(hh.sortIndicatorSection(),hh.sortIndicatorOrder())
        if hasattr(self,"pickup_count"):
            self.pickup_count.setText(f"{len(rows):,} waiting pickup order{'s' if len(rows)!=1 else ''}")
        self._pickup_selection_changed()

    def _pickup_selection_changed(self,*_):
        if not hasattr(self,"pickup_selected_label"): return
        n = len(self.pickup_tracking_model.checked_order_ids())
        self.pickup_selected_label.setText(f"{n:,} selected")
        self.pickup_export_selected_btn.setEnabled(n > 0)
        self.pickup_bulk_status_btn.setEnabled(n > 0)

    def pickup_selected_ids(self):
        return self.pickup_tracking_model.checked_order_ids()

    def check_selected_pickup(self):
        selected=set(self.pickup_selected_ids())
        ids=[int(r["id"]) for r in self.pickup_tracking_model.rows if int(r["id"]) in selected and (r["status"] or "")=="Ready for Pickup"]
        if not ids:
            if hasattr(self,"pickup_feedback"): self.pickup_feedback.setText("Select one or more Ready for Pickup orders to check Apple Order Status.")
            return
        if hasattr(self,"pickup_feedback"): self.pickup_feedback.setText(f"Checking {len(ids):,} selected Ready for Pickup order{'s' if len(ids)!=1 else ''}…")
        self.start_verification(force=True,order_ids=ids)

    def refresh_all_pickup_status(self):
        ids=[int(r["id"]) for r in self.pickup_tracking_model.rows if (r["status"] or "")=="Ready for Pickup"]
        if not ids:
            if hasattr(self,"pickup_feedback"): self.pickup_feedback.setText("No Ready for Pickup orders need an Apple Order Status check.")
            return
        if hasattr(self,"pickup_feedback"): self.pickup_feedback.setText(f"Checking Apple Order Status for {len(ids):,} Ready for Pickup order{'s' if len(ids)!=1 else ''}…")
        self.start_verification(force=True,order_ids=ids)

    def pickup_table_clicked(self,index):
        row=self.pickup_tracking_model.row_at(index.row())
        if not row: return
        key=self.pickup_tracking_model.COLUMNS[index.column()][0]
        if key=="order_number":
            if time.monotonic()<self._copy_guard_until: return
            self.open_order_status(row)

    def pickup_table_double_clicked(self,index):
        if index.data(Qt.CheckStateRole) is not None: return
        row=self.pickup_tracking_model.row_at(index.row())
        if row: OrderDetailDialog(self.db,row,self).exec()

    def day_current_filter(self):
        idx=self.day_tabs.currentIndex(); return self.TAB_FILTERS[idx] if 0<=idx<len(self.TAB_FILTERS) else "All Orders"

    def refresh_day_orders(self):
        if not self.current_order_day or not hasattr(self,"day_model"): return
        rows=list(self.db.orders_for_order_date(self.current_order_day,self.filter_start,self.filter_end))
        filt=self.day_current_filter(); needle=self.day_search.text().strip().lower() if hasattr(self,"day_search") else ""
        if filt == "Pickup Processing":
            rows=[r for r in rows if (r["order_type"] or "").lower()=="pickup" and (r["status"] or "") not in ("Picked Up","Delivered","Canceled","Refunded","Returned to Sender")]
        elif filt!="All Orders":
            rows=[r for r in rows if (r["status"] or "")==filt]
        if needle:
            def matches(r):
                vals=[r["order_number"],r["item_summary"],r["tracking_number"],r["address"],r["pickup_store"],r["alias_emails"]]
                return any(needle in clean_text(v).lower() for v in vals)
            rows=[r for r in rows if matches(r)]
        self.day_model.set_rows(rows)
        try: pretty=display_date_long(self.current_order_day)
        except Exception: pretty=self.current_order_day
        self.day_title.setText(f"Orders — {pretty}")
        self.day_subtitle.setText(f"{len(rows):,} order{'s' if len(rows)!=1 else ''} in this view")
        all_rows=list(self.db.orders_for_order_date(self.current_order_day,self.filter_start,self.filter_end))
        counts={name:0 for name in self.TAB_FILTERS}
        counts["All Orders"]=len(all_rows)
        for r in all_rows:
            st=r["status"] or "Unknown"
            if st in counts: counts[st]+=1
            if (r["order_type"] or "").lower()=="pickup" and st not in ("Picked Up","Delivered","Canceled","Refunded","Returned to Sender"):
                counts["Pickup Processing"] += 1
        for i,name in enumerate(self.TAB_FILTERS):
            glyph = "▣" if name=="All Orders" else ("⌂" if name=="Pickup Processing" else STATUS_GLYPHS.get(name,"•"))
            self.day_tabs.setTabText(i,f"{glyph}  {name}  {counts.get(name,0):,}")
            self.day_tabs.setTabVisible(i, name not in UPS_STATES or counts.get(name,0) > 0 or i == self.day_tabs.currentIndex())
        self._day_selection_changed()

    def _day_selection_changed(self,*_):
        n=len(self.day_model.checked_order_ids())
        self.day_selected_label.setText(f"{n:,} selected")
        self.day_export_selected.setEnabled(n>0)
        self.day_bulk_status_btn.setEnabled(n>0)

    def export_selected_day_orders(self):
        rows=self.db.orders_by_ids(self.day_model.checked_order_ids())
        if rows: save_rows_csv(self,self.settings,rows,f"apple_orders_{self.current_order_day}_selected",f"Selected orders — {display_date_long(self.current_order_day)}")

    def export_all_day_orders(self):
        if not self.current_order_day: return
        rows=self.db.orders_for_order_date(self.current_order_day,self.filter_start,self.filter_end)
        save_rows_csv(self,self.settings,rows,f"apple_orders_{self.current_order_day}",f"Order date — {display_date_long(self.current_order_day)}")

    def day_table_clicked(self,index):
        row=self.day_model.row_at(index.row())
        if not row: return
        key=self.day_model.COLUMNS[index.column()][0]
        if key=="order_number":
            if time.monotonic()<self._copy_guard_until: return
            self.open_order_status(row)
        elif key=="tracking_number" and row["tracking_number"]:
            url=safe_tracking_url(row["tracking_url"] or "") or direct_tracking_url(row["tracking_number"] or "",row["carrier"] or "")
            if url: QDesktopServices.openUrl(QUrl(url))

    def day_table_double_clicked(self,index):
        if index.data(Qt.CheckStateRole) is not None: return
        row=self.day_model.row_at(index.row())
        if row: OrderDetailDialog(self.db,row,self).exec()

    def export_csv(self):
        current_rows=self.db.query_orders(self.current_filter(),self.search_edit.text(),self.filter_start,self.filter_end); total_count=self.db.tab_counts(self.filter_start,self.filter_end).get("All Orders",0); dlg=ExportDialog(self.settings,len(current_rows),total_count,self)
        if dlg.exec()!=QDialog.Accepted: return
        rows=self.db.query_orders("All Orders","",self.filter_start,self.filter_end) if dlg.scope_value()=="all" else current_rows
        if not rows: QMessageBox.information(self,APP_NAME,"There are no orders to export."); return
        fields=dlg.selected_fields(); labels=dict(EXPORT_FIELDS); desktop=Path.home()/"Desktop"; default_dir=desktop if desktop.exists() else Path.home(); suffix=f"_{self.filter_start}_to_{self.filter_end}" if self.filter_start and self.filter_end else f"_{date.today().isoformat()}"; path,_=QFileDialog.getSaveFileName(self,"Export Apple Orders",str(default_dir/f"apple_orders{suffix}.csv"),"CSV Files (*.csv)")
        if not path: return
        if not path.lower().endswith(".csv"): path+=".csv"
        with open(path,"w",newline="",encoding="utf-8-sig") as f:
            w=csv.writer(f); w.writerow([labels[k] for k in fields]); [w.writerow([export_value_for_field(r,k) for k in fields]) for r in rows]
        QMessageBox.information(self,APP_NAME,f"Exported {len(rows):,} orders with {len(fields)} selected fields to:\n{path}")

    def _animate_ups(self):
        self._ups_phase = (self._ups_phase + 1) % 30
        for table in (self.table,self.tracking_table,self.day_table):
            table.viewport().update()

    def _ups_package_started(self, order_ids, tracking_number):
        self._ups_active_ids = set(int(x) for x in order_ids)
        self._animate_ups()

    def _ups_order_updated(self, order_id):
        if not self._ups_refresh_timer.isActive(): self._ups_refresh_timer.start()

    def _ups_failed(self, message):
        self.sync_status.setText(message); self.tracking_feedback.setText(message)

    def cancel_ups(self):
        if self.verify_worker and self.verify_worker.isRunning():
            self.verify_worker.request_stop()
            self.ups_cancel_btn.setEnabled(False)
            self.tracking_feedback.setText("Stopping after the current UPS request. Existing successful results are kept.")

    def show_ups_results(self):
        dialog = QDialog(self); dialog.setWindowTitle("UPS check results"); dialog.resize(880,600)
        layout = QVBoxLayout(dialog)
        title = QLabel("UPS API results and errors"); title.setObjectName("sectionTitle"); layout.addWidget(title)
        hint = QLabel("A failed lookup preserves the last known status. Manual overrides remain the visible order status. No client secrets or tokens are included here.")
        hint.setWordWrap(True); layout.addWidget(hint)
        result = QPlainTextEdit(); result.setReadOnly(True)
        visible_numbers = {n for r in self.db.query_orders("All Orders","",self.filter_start,self.filter_end) for n in split_tracking_numbers(r["tracking_number"] or "")}
        lines = []
        for line in self._ups_report:
            match = re.match(r"([A-Z0-9]{7,34}):", line)
            if not match or match.group(1) in visible_numbers: lines.append(line)
        if not lines:
            for row in self.db.query_orders("All Orders","",self.filter_start,self.filter_end):
                if row_value(row,"tracking_checked_at"):
                    lines.append(row["order_number"] + "\n" + tracking_status_tip(row))
        result.setPlainText("\n\n".join(lines) or "No UPS check results yet. Use Shipping Tracking > Refresh UPS.")
        layout.addWidget(result,1)
        buttons = QDialogButtonBox(QDialogButtonBox.Close); buttons.rejected.connect(dialog.reject); layout.addWidget(buttons)
        dialog.exec()

    def refresh_ups_cards(self):
        if not hasattr(self,"ups_card_layout"): return
        while self.ups_card_layout.count():
            item = self.ups_card_layout.takeAt(0)
            if item.widget(): item.widget().deleteLater()
        counts = self.db.tab_counts(self.filter_start,self.filter_end)
        for state in ("Returning to Sender","Returned to Sender","Exception","Delayed","Out for Delivery","Partially Delivered","Mixed Shipments","Tracking Update"):
            count = counts.get(state,0)
            if not count: continue
            button = QPushButton(f"{state}  {count:,}")
            button.setObjectName("miniAction"); button.setToolTip("Show orders whose current status is " + state)
            button.clicked.connect(lambda _checked=False, st=state:self.tabs.setCurrentIndex(self.TAB_FILTERS.index(st)))
            self.ups_card_layout.addWidget(button)
        self.ups_card_layout.addStretch(1)

    def bulk_change_status(self, model):
        ids = list(model.checked_order_ids())
        if not ids: return
        rows = self.db.orders_by_ids(ids)
        if len(rows) != len(ids):
            self.refresh_all()
            QMessageBox.information(self,APP_NAME,"One or more checked orders are no longer visible. Please reselect them.")
            return
        dialog = BulkStatusDialog(len(ids),MANUAL_STATUS_OPTIONS,"Automatic (use detected status)",self)
        if dialog.exec() != QDialog.Accepted: return
        status = dialog.selected_status()
        if status is None: return
        try:
            self.db.apply_manual_overrides({int(x):{"status":str(status)} for x in ids})
        except Exception as exc:
            QMessageBox.warning(self,APP_NAME,"No bulk changes were saved: " + str(exc))
            return
        # Do not discard staged quantities or edits to other orders.
        for pending_model in (self.table_model,self.day_model):
            for order_id in ids: pending_model.pending_status.pop(int(order_id),None)
            pending_model.pendingChanged.emit()
        model.clear_checked()
        self.refresh_all()
        self.sync_status.setText(f"Saved {len(ids):,} order statuses as {status or 'Automatic'}. Quantities unchanged.")

    def export_selected_pickup_orders(self):
        ids = set(self.pickup_tracking_model.checked_order_ids())
        rows = [r for r in self.pickup_tracking_model.rows if int(r["id"]) in ids and self.db.is_order_visible(int(r["id"]))]
        if rows:
            save_rows_csv(self,self.settings,rows,"apple_pickup_selected",f"Selected pickup orders - {len(rows):,}")

    def _refresh_ups_views(self):
        self.refresh_tabs(); self.refresh_ups_cards()
        page=self.stack.currentIndex()
        if page==self.PAGE_ORDERS: self.refresh_table()
        elif page==self.PAGE_TRACKING: self.refresh_tracking()
        elif page==self.PAGE_PICKUP_TRACKING: self.refresh_pickup_tracking()
        elif page==self.PAGE_RELEASES: self.refresh_releases()
        elif page==self.PAGE_DAY_ORDERS: self.refresh_day_orders()
        elif page==self.PAGE_SCHEDULE: self.schedule_page.refresh_current()

def main():
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setApplicationVersion(APP_VERSION)
    app.setOrganizationName("Local")
    icon = resource_path("app_icon.ico")
    if icon.exists():
        app.setWindowIcon(QIcon(str(icon)))
    window = MainWindow()
    if icon.exists():
        window.setWindowIcon(QIcon(str(icon)))
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
