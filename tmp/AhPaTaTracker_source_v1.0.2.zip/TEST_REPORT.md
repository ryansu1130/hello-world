# v1.0.2 release validation

## Source and release scope

The original v1.0.2 package was recovered and all 40 source files plus both support
files matched its saved SHA-256 manifest. Its base is the published v1.0.1 source
archive, SHA-256 `39e461ba6b2f0214f23407efdcf4a15a595da02b6a2b174cf7b5b6eef670d3ea`.

Release review corrected three issues before publishing:

- Generic guest-order management controls no longer prove association or verify a
  phone. A new association requires the authenticated account listing; later reads
  can reuse a previously proven link.
- Rebuild Cache cannot erase order-linked Apple jobs, uncertain submissions,
  verification, observations or audit history. Its check and deletion are atomic,
  and active workers block the operation. Full Account Sync / Refresh Details
  remains the path for refreshing email while preserving this history.
- Order-detail timers follow dialog visibility and stop before database shutdown,
  including when the main window closes with a detail window still open.

## Executed on October 19, 2026: local release checks

Environment: Python 3.12.14 on Linux, PySide6-Essentials 6.12.0, Playwright 1.57.0.
These checks use temporary databases and synthetic records, with no authenticated
Apple session or live order changes.

| Check | Result |
|---|---|
| Core application suite: unittest discover, test_*.py | 204 passed |
| Existing Qt startup/interaction suite plus detail lifecycle regression | 14 passed |
| Apple workspace Qt suite including cache protection | 10 passed |
| Python source parsing | Passed for all application/test files |

`TEST_RESULTS.txt` contains the final core suite output. The GUI gates use temporary
settings/data and mocked network/credential calls. The new tests reproduce guest
association false positives, preserve uncertain submissions and verified phones,
check a concurrent database writer, and exercise close/reopen/owner-shutdown timers.

## Required Windows release gates

The repository workflow reconstructs the exact curated source archive, checks its
SHA-256 and version, then executes the 204 core tests, both Qt suites, and all
16 controlled browser scenarios on Windows before packaging the executable.
It creates a draft with `AhPaTaTracker.exe` and `AhPaTaTracker.exe.sha256`, verifies
both assets exist, and only then publishes the stable release. Existing versions
are not overwritten. Failed checks leave the previous stable release available.

The actual Windows result is recorded in GitHub Actions, not inferred from local
checks: https://github.com/ryansu1130/hello-world/actions.
The available stable binary is recorded at
https://github.com/ryansu1130/hello-world/releases/latest.

## Browser coverage and live limits

The current browser suite has 16 scenarios using real Chromium DOM interactions
with in-memory pages. Browser network requests are blocked; outcomes are synthetic.
The original development package recorded 13 passing scenarios. This release adds
three guest-management-control regressions. The complete 16-scenario suite is a
mandatory Windows release gate. A local browser download was unavailable during
release validation; no local run of the expanded suite is claimed.

Controlled DOM checks are not evidence of production Apple login, account identity,
association, phone challenges, cancellation, payment submission, or current page
compatibility. No live Apple account, order, payment, or user-machine OTA restart
was exercised during this release work. Cancellation and payment final submission
remain browser-assisted. Automatic raw-card reuse across a batch is not implemented.

## Preserved original development evidence

The recovered package includes the original `BROWSER_TEST_RESULTS.txt` and
`LOAD_TEST.json`. Its original local benchmark seeded 20,000 synthetic orders and
imported 50,000 synthetic profiles; these measurements were not rerun for release.
The original supplied profile-schema/privacy check is described in
`REQUIREMENTS_STATUS.md`; the supplied personal records are not publication inputs.

Only the reviewed application source, synthetic tests, documentation and app icons
are included in the source bundle. Profiles.json, databases, account cookies,
credentials, proxy secrets and payment records are excluded.
