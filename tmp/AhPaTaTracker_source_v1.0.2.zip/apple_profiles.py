"""Profile-to-phone import. No payment fields are read, returned or stored.

Top-level arrays stream one record at a time; nested containers are capped at
64 MiB and require a mapping if records cannot be identified unambiguously.
There is no file-count cap. A single record is capped at 8 MiB.
"""
from __future__ import annotations
import hashlib
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable
from urllib.parse import urlsplit

EMAIL = re.compile(r"[^\s@,;<>]+@[^\s@,;<>]+\.[^\s@,;<>]+")
ORDER = re.compile(r"\bW\d{8,15}\b", re.I)
BLOCKED = {'payment','payments','card','cards','creditcard','credit_card','cvv','cvc','password','credentials','tokens'}
def sensitive_key(key):
    k=re.sub(r'[^a-z0-9]','',str(key).lower())
    return (str(key).lower() in BLOCKED or any(x in k for x in ('creditcard','cardnumber','carddata','carddetails','cvv','cvc','securitycode','password','accesstoken','refreshtoken','authorization','recoverycode')) or k in ('pan','expiry','expiration','expirationdate'))

MAX_RECORD = 8 * 1024 * 1024
MAX_NESTED = 64 * 1024 * 1024

def email_key(value: Any) -> str:
    text = str(value or '').strip()
    if not EMAIL.fullmatch(text):
        raise ValueError('Invalid email')
    local, domain = text.rsplit('@', 1)
    return local + '@' + domain.lower().encode('idna').decode('ascii')

def aliases(value: str) -> list[str]:
    out=[]
    for m in EMAIL.finditer(value or ''):
        try: key=email_key(m.group().rstrip('.'))
        except ValueError: continue
        if key not in out: out.append(key)
    return out

@dataclass(frozen=True)
class Phone:
    original: str
    comparison: str
    normalized: str
    extension: str
    state: str
    note: str

def normalize_phone(value: Any, country: str = '') -> Phone:
    raw=str(value or '').strip()
    if not raw or len(raw)>100:
        return Phone(raw[:100], '', '', '', 'invalid', 'Missing or overlong phone value')
    # Preserve extensions in identity. Never equate a switchboard with an extension.
    match=re.search(r'(?:\bext\.?|\bextension|x|#)\s*(\d{1,8})\s*$', raw, re.I)
    extension=match.group(1) if match else ''
    main=raw[:match.start()].strip() if match else raw
    if re.search(r'[^\d\s+().\-]', main) or '+' in main[1:]:
        return Phone(raw,'raw:'+hashlib.sha256(raw.encode()).hexdigest(),'','', 'invalid','Unrecognized phone characters')
    digits=re.sub(r'\D','',main)
    cc=str(country or '').strip().lower()
    is_nanp=cc in ('us','usa','united states','united states of america','ca','canada','1','+1')
    if main.startswith('+') and 7<=len(digits)<=15 and not digits.startswith('0'):
        norm='+'+digits; state='valid'; note='Explicit country code'
    elif is_nanp and len(digits)==10:
        norm='+1'+digits; state='valid'; note='US/Canada country context'
    elif is_nanp and len(digits)==11 and digits.startswith('1'):
        norm='+'+digits; state='valid'; note='US/Canada country context'
    else:
        norm=digits; state='ambiguous' if 7<=len(digits)<=15 else 'invalid'
        note='Country context required' if state=='ambiguous' else 'Invalid digit count'
    key=(norm if state=='valid' else state+':'+digits) + (';ext='+extension if extension else '')
    return Phone(raw,key,norm,extension,state,note)

def field(record: dict, path: str) -> Any:
    if not path: return ''
    current=record
    for key in path.split('.'):
        if sensitive_key(key): raise ValueError('Sensitive fields cannot be mapped')
        if not isinstance(current,dict): return ''
        current=current.get(key)
    return current if isinstance(current,(str,int,float)) else ''

def safe_paths(record: dict, prefix: str='', depth: int=0) -> list[str]:
    if depth>5:return []
    out=[]
    for k,v in record.items():
        if sensitive_key(k):continue
        p=prefix+'.'+k if prefix else k
        if isinstance(v,dict):out.extend(safe_paths(v,p,depth+1))
        elif isinstance(v,(str,int,float)) or v is None:out.append(p)
    return out

def _array_stream(handle):
    """Streaming JSON array decoder with a bounded per-record buffer."""
    decoder=json.JSONDecoder(); buf=''; ended=False; need_value=True; first=True; after_comma=False
    while True:
        chunk=handle.read(65536)
        if not chunk:ended=True
        buf+=chunk
        while True:
            buf=buf.lstrip()
            if first:
                if not buf: break
                if not buf.startswith('['):raise ValueError('Expected a JSON array')
                buf=buf[1:];first=False;continue
            if not buf:break
            if need_value:
                if buf.startswith(']'):
                    if after_comma:raise ValueError('Trailing comma in array')
                    # Trailing content must be whitespace. Reading it is bounded.
                    tail=buf[1:]+handle.read(65536)
                    if tail.strip() or handle.read(1):raise ValueError('Unexpected content after JSON array')
                    return
                try:value, end=decoder.raw_decode(buf)
                except json.JSONDecodeError:
                    if ended:raise ValueError('Malformed JSON record') from None
                    if len(buf)>MAX_RECORD:raise ValueError('A profile exceeds the 8 MiB record limit')
                    break
                if end>MAX_RECORD:raise ValueError('A profile exceeds the 8 MiB record limit')
                buf=buf[end:];need_value=False;after_comma=False
                yield value
            else:
                if buf.startswith(','):
                    buf=buf[1:];need_value=True;after_comma=True
                    # A trailing comma is checked when the next value arrives.
                    buf=buf.lstrip()
                    if buf.startswith(']'):raise ValueError('Trailing comma in array')
                elif buf.startswith(']'):
                    tail=buf[1:]+handle.read(65536)
                    if tail.strip() or handle.read(1):raise ValueError('Unexpected content after array')
                    return
                else:raise ValueError('Expected comma between profiles')
        if ended:raise ValueError('Incomplete JSON array')

def _walk_records(value, prefix='$', depth=0):
    if depth>20:raise ValueError('JSON nesting is deeper than 20 levels')
    if isinstance(value,list):
        for i,v in enumerate(value):yield from _walk_records(v,f'{prefix}[{i}]',depth+1)
    elif isinstance(value,dict):
        # A record boundary has its own email. Only shipping/billing/contact
        # scalar subobjects are eligible; sibling collections are never paired.
        own=next((value[k] for k in ('email','emailAddress','email_address','alias') if isinstance(value.get(k),str)),None)
        contact=value.get('contact')
        if own or (isinstance(contact,dict) and isinstance(contact.get('email'),str)):
            yield prefix,value
        else:
            children=[(k,v) for k,v in value.items() if not sensitive_key(k) and isinstance(v,(list,dict))]
            if children:
                for k,v in children:yield from _walk_records(v,f'{prefix}.{k}',depth+1)
            else:yield prefix,value

def iter_records(path: Path, mapping: dict | None=None):
    mapping=mapping or {}
    with Path(path).open('r',encoding='utf-8-sig') as handle:
        first=''
        while not first or first.isspace():
            first=handle.read(1)
            if not first:raise ValueError('Empty JSON file')
        handle.seek(0)
        if first=='[':
            for i,record in enumerate(_array_stream(handle)):
                if mapping:yield f'$[{i}]',record
                else:yield from _walk_records(record,f'$[{i}]')
        else:
            if Path(path).stat().st_size>MAX_NESTED:
                raise ValueError('Nested document exceeds 64 MiB. Export its profile list as a top-level array for streaming.')
            value=json.load(handle)
            root=mapping.get('records_path','').strip()
            if root:
                for key in root.split('.'):
                    if sensitive_key(key):raise ValueError('Sensitive collections cannot be mapped')
                    value=value.get(key) if isinstance(value,dict) else None
                if value is None:raise ValueError('Mapped record collection not found')
            if mapping:
                if isinstance(value,list):
                    for i,v in enumerate(value):yield f'$.{root}[{i}]',v
                else:yield '$.'+root,value
            else:yield from _walk_records(value)

def candidates(record: dict, mapping: dict | None=None) -> list[dict]:
    if not isinstance(record,dict):raise ValueError('Profile is not an object')
    if mapping:
        email=email_key(field(record,mapping['email']))
        phones=[(mapping['phone'],field(record,mapping['phone']))]
        country=str(field(record,mapping.get('country','')) or mapping.get('default_country',''))
        order=str(field(record,mapping.get('order','')))
    else:
        email_path=next((p for p in ('email','emailAddress','email_address','alias','contact.email') if field(record,p)),None)
        if not email_path:raise ValueError('Unfamiliar schema: map email and phone paths')
        email=email_key(field(record,email_path))
        phone_paths=('shipping.phone','billing.phone','contact.phone','phone','phoneNumber','phone_number')
        phones=[(p,field(record,p)) for p in phone_paths if field(record,p)]
        country=str(field(record,'shipping.country') or field(record,'country') or field(record,'billing.country'))
        order=str(next((field(record,p) for p in ('orderNumber','order_number','order.number','orderId') if field(record,p)),''))
    m=ORDER.fullmatch(order.strip()); order=m.group().upper() if m else ''
    if not phones:raise ValueError('No phone field found in this logical profile')
    out=[]
    for phone_path,value in phones:
        phone=normalize_phone(value,country)
        if phone.comparison:
            out.append(dict(email=email,phone=phone,order_number=order,field_path=phone_path,country=country))
    if not out:raise ValueError('No usable phone values')
    return out

def file_fingerprint(path: Path) -> str:
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

def parse_proxy(line: str) -> dict:
    """Explicit URLs only, or HOST:PORT / HOST:PORT:USER:PASS. No auto hopping."""
    from urllib.parse import unquote
    value=line.strip()
    if not value or len(value)>2048:raise ValueError('Empty or overlong route')
    if '://' not in value:
        parts=value.split(':')
        if len(parts)==4:
            host,port,user,password=parts
            value=f'http://{host}:{port}'
        elif len(parts)==2:user=password='';value='http://'+value
        else:raise ValueError('Use scheme://[user:password@]host:port')
    else:user=password=''
    p=urlsplit(value)
    if p.scheme not in ('http','https','socks5') or not p.hostname or p.path not in ('','/') or p.query or p.fragment:
        raise ValueError('Invalid proxy URL')
    try:port=p.port
    except ValueError:raise ValueError('Invalid proxy port') from None
    if not port or not 1<=port<=65535:raise ValueError('Specify port 1-65535')
    host=p.hostname
    if re.search(r'[\s\x00-\x1f]',host):raise ValueError('Invalid proxy host')
    user=unquote(p.username or user);password=unquote(p.password or password)
    if re.search(r'[\r\n\x00]',user+password):raise ValueError('Invalid proxy credentials')
    return {'server':f'{p.scheme}://'+(f'[{host}]' if ':' in host else host)+f':{port}',
            'username':user,'password':password,'host':host,'port':port}
