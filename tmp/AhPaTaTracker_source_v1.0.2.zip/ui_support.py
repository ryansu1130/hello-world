"""Shared table hover, readable date popups and a truthful UPS activity indicator."""
from __future__ import annotations

import math
from datetime import date
from PySide6.QtCore import QDate, QEvent, QModelIndex, QSize, Qt, QTimer
from PySide6.QtGui import QColor, QFont, QPalette, QPainter, QPen, QTextCharFormat
from PySide6.QtWidgets import (
    QApplication, QAbstractItemView, QCalendarWidget, QComboBox, QDateEdit,
    QDialog, QDialogButtonBox, QHBoxLayout, QLabel, QStyle,
    QStyledItemDelegate, QStyleOptionViewItem, QTableView, QVBoxLayout, QWidget,
)


def row_option(option, index):
    opt = QStyleOptionViewItem(option)
    widget = option.widget
    while widget is not None and not isinstance(widget, QAbstractItemView):
        widget = widget.parentWidget()
    if widget is not None and getattr(widget, '_hover_row', -1) == index.row():
        # Use the existing selection-blue palette across *every* cell in the row.
        # This changes paint only, not the selection model or checkboxes.
        opt.state |= QStyle.StateFlag.State_Selected
        opt.palette.setColor(QPalette.ColorRole.HighlightedText,
                             opt.palette.color(QPalette.ColorRole.Text))
    return opt


class RowHoverDelegate(QStyledItemDelegate):
    def paint(self, painter, option, index):
        super().paint(painter, row_option(option, index), index)


def paint_cell_background(delegate, painter, option, index):
    opt = row_option(option, index)
    delegate.initStyleOption(opt, index)
    opt.text = ''
    opt.features &= ~QStyleOptionViewItem.ViewItemFeature.HasCheckIndicator
    opt.features &= ~QStyleOptionViewItem.ViewItemFeature.HasDecoration
    style = opt.widget.style() if opt.widget else QApplication.style()
    style.drawControl(QStyle.ControlElement.CE_ItemViewItem, opt, painter, opt.widget)
    return opt


class HoverTableView(QTableView):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._hover_row = -1
        self.setMouseTracking(True)
        self.viewport().setMouseTracking(True)
        self.setItemDelegate(RowHoverDelegate(self))

    def setModel(self, model):
        super().setModel(model)
        if model is not None:
            model.modelReset.connect(self._clear_hover)
            model.layoutChanged.connect(self._clear_hover)

    def _clear_hover(self, *_):
        self._hover_row = -1
        self.viewport().update()

    def mouseMoveEvent(self, event):
        idx = self.indexAt(event.position().toPoint())
        row = idx.row() if idx.isValid() else -1
        if row != self._hover_row:
            self._hover_row = row
            self.viewport().update()
        super().mouseMoveEvent(event)

    def leaveEvent(self, event):
        self._clear_hover()
        super().leaveEvent(event)

    def wheelEvent(self, event):
        self._clear_hover()
        super().wheelEvent(event)


class ReadableCalendar(QCalendarWidget):
    """Paint dates without elision and isolate calendar cells from table padding."""
    def __init__(self, parent=None):
        self._activity_counts = {}
        self._dark = False
        super().__init__(parent)
        self.setObjectName('trackerCalendar')
        self.setGridVisible(False)
        self.setVerticalHeaderFormat(QCalendarWidget.VerticalHeaderFormat.NoVerticalHeader)
        self.setHorizontalHeaderFormat(QCalendarWidget.HorizontalHeaderFormat.ShortDayNames)
        self.setMinimumSize(350, 336)
        self.setFont(QFont('Segoe UI', 10))
        self.set_dark(False)

    def minimumSizeHint(self):
        return QSize(350, 336)

    def sizeHint(self):
        return QSize(378, 350)

    def set_activity_counts(self, counts):
        self._activity_counts = {str(k): max(0, int(v)) for k, v in (counts or {}).items()}
        self.updateCells()

    def set_dark(self, dark):
        self._dark = bool(dark)
        bg = '#141c26' if self._dark else '#ffffff'
        fg = '#e6edf5' if self._dark else '#182236'
        border = '#283546' if self._dark else '#dbe3ee'
        # Qualified rules defeat the global QTableView::item padding that caused
        # two-digit days and weekday labels to turn into ellipses in date popups.
        self.setStyleSheet(f'''
            QCalendarWidget#trackerCalendar {{ background:{bg}; color:{fg}; border:1px solid {border}; border-radius:10px; }}
            QCalendarWidget#trackerCalendar QWidget {{ background:{bg}; color:{fg}; }}
            QCalendarWidget#trackerCalendar QAbstractItemView {{ border:0; border-radius:0; padding:0; margin:0; outline:0; font-size:13px; selection-background-color:#356df3; selection-color:white; }}
            QCalendarWidget#trackerCalendar QAbstractItemView::item {{ padding:0; margin:0; border:0; min-width:0; min-height:0; }}
            QCalendarWidget#trackerCalendar QHeaderView::section {{ padding:2px 0; margin:0; border:0; font-size:12px; }}
            QCalendarWidget#trackerCalendar QToolButton {{ padding:6px; margin:0; border:0; border-radius:6px; background:{bg}; color:{fg}; font-size:13px; font-weight:600; }}
            QCalendarWidget#trackerCalendar QSpinBox {{ background:{bg}; color:{fg}; padding:2px; min-width:70px; }}
            QCalendarWidget#trackerCalendar QMenu {{ background:{bg}; color:{fg}; }}
        ''')
        fmt = QTextCharFormat()
        fmt.setForeground(QColor(fg))
        for day in (Qt.DayOfWeek.Monday, Qt.DayOfWeek.Tuesday, Qt.DayOfWeek.Wednesday,
                    Qt.DayOfWeek.Thursday, Qt.DayOfWeek.Friday, Qt.DayOfWeek.Saturday,
                    Qt.DayOfWeek.Sunday):
            self.setWeekdayTextFormat(day, fmt)
        self.setHeaderTextFormat(fmt)
        self.updateCells()

    def paintCell(self, painter: QPainter, rect, qdate: QDate):
        painter.save()
        painter.setClipRect(rect)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        selected = qdate == self.selectedDate()
        in_month = qdate.month() == self.monthShown()
        enabled = self.minimumDate() <= qdate <= self.maximumDate()
        box = rect.adjusted(2, 2, -2, -2)
        bg = '#141c26' if self._dark else '#ffffff'
        painter.fillRect(rect, QColor(bg))
        if selected:
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QColor('#356df3'))
            painter.drawRoundedRect(box, 7, 7)
        elif qdate == QDate.currentDate():
            painter.setPen(QPen(QColor('#356df3'), 1))
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.drawRoundedRect(box, 7, 7)
        key = qdate.toString('yyyy-MM-dd')
        count = self._activity_counts.get(key, 0)
        font = QFont(self.font())
        font.setPixelSize(13)
        font.setBold(bool(selected or count))
        painter.setFont(font)
        fg = '#ffffff' if selected else '#e6edf5' if self._dark else '#182236'
        if (not in_month or not enabled) and not selected:
            fg = '#66788c' if self._dark else '#94a3b8'
        painter.setPen(QColor(fg))
        date_rect = box.adjusted(1, 0, -1, -18) if count and box.height() >= 36 else box
        painter.drawText(date_rect, Qt.AlignmentFlag.AlignCenter, str(qdate.day()))
        if count and box.height() >= 36:
            label = str(count)
            font.setPixelSize(10); font.setBold(True); painter.setFont(font)
            width = min(box.width()-2, max(20, painter.fontMetrics().horizontalAdvance(label)+8))
            badge = rect.__class__(box.center().x()-width//2, box.bottom()-18, width, 16)
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QColor('#ffffff' if selected else '#233b67' if self._dark else '#e6efff'))
            painter.drawRoundedRect(badge, 7, 7)
            painter.setPen(QColor('#255fd6' if selected or not self._dark else '#b6d1ff'))
            painter.drawText(badge, Qt.AlignmentFlag.AlignCenter, label)
        painter.restore()


def configure_date_edit(editor: QDateEdit):
    editor.setCalendarPopup(True)
    calendar = ReadableCalendar(editor)
    calendar.set_dark(QApplication.instance().property('trackerDark') is True)
    editor.setCalendarWidget(calendar)
    # Minimum popup dimensions are logical pixels, so Windows DPI scaling applies.
    editor.setMinimumWidth(145)
    return calendar


class LiveIndicator(QWidget):
    """Pulses only during an actual request batch, never pretends cached data is live."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self._busy = False
        self._phase = 0
        self._error = False
        self._text = 'UPS idle'
        self.setMinimumWidth(180)
        self.setFixedHeight(28)
        self.timer = QTimer(self)
        self.timer.setInterval(90)
        self.timer.timeout.connect(self._tick)

    def _tick(self):
        self._phase = (self._phase + 1) % 40
        self.update()

    def set_state(self, label, busy=False, error=False):
        self._text, self._busy, self._error = str(label), bool(busy), bool(error)
        self.setToolTip(str(label))
        if busy:
            self.timer.start()
        else:
            self.timer.stop()
        self.update()

    def paintEvent(self, event):
        p = QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing)
        color = QColor('#22c55e' if self._busy else '#f59e0b' if self._error else '#94a3b8')
        if self._busy:
            glow = QColor(color); glow.setAlpha(int(40+50*(math.sin(self._phase*math.pi/20)+1)/2))
            p.setPen(Qt.PenStyle.NoPen); p.setBrush(glow); p.drawEllipse(2, 4, 20, 20)
        p.setPen(Qt.PenStyle.NoPen); p.setBrush(color); p.drawEllipse(8, 10, 8, 8)
        p.setPen(self.palette().color(QPalette.ColorRole.WindowText))
        p.drawText(self.rect().adjusted(30,0,-3,0), Qt.AlignmentFlag.AlignVCenter,
                   p.fontMetrics().elidedText(self._text, Qt.TextElideMode.ElideRight, self.width()-35))
        p.end()


class BulkStatusDialog(QDialog):
    def __init__(self, count: int, options: list[str], automatic_label: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle('Change selected order statuses')
        self.resize(470, 240)
        layout = QVBoxLayout(self); layout.setContentsMargins(22,20,22,20); layout.setSpacing(14)
        title = QLabel(f'Update {count:,} selected orders'); title.setObjectName('sectionTitle'); layout.addWidget(title)
        note = QLabel('This saves a manual status override for every checked order. Gmail sync and UPS cannot replace it. Choose Automatic to remove only the status overrides.')
        note.setWordWrap(True); layout.addWidget(note)
        self.status = QComboBox(); self.status.addItem('Choose a status...', None)
        self.status.addItem(automatic_label, '')
        for value in options:
            self.status.addItem(value, value)
        layout.addWidget(self.status)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        self.save_button = buttons.button(QDialogButtonBox.StandardButton.Save)
        self.save_button.setText('Save Changes'); self.save_button.setObjectName('primaryButton'); self.save_button.setEnabled(False)
        self.status.currentIndexChanged.connect(lambda i: self.save_button.setEnabled(i > 0))
        buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject); layout.addWidget(buttons)

    def selected_status(self):
        return self.status.currentData()
