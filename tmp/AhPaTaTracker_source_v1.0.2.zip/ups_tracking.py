"""UPS production tracking: explicit errors, package identity and return-aware states.

Only the official Track API is called. No web scraping or proxy rotation.
This module intentionally has no Qt dependency so parsing can be tested offline.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
import base64
import re
import time
import uuid
from typing import Callable
from urllib.parse import quote, urlparse

import requests
from requests.auth import AuthBase
from ups_credentials import clean_credential, UPSCredentialError

UPS_BASE = "https://onlinetools.ups.com"
UPS_TOKEN_URL = UPS_BASE + "/security/v1/oauth/token"
UPS_TRACK_URL = UPS_BASE + "/api/track/v1/details/"

UPS_STATES = (
    'Label Created', 'In Transit', 'Out for Delivery', 'Delayed', 'Exception',
    'Returning to Sender', 'Returned to Sender', 'Partially Delivered',
    'Mixed Shipments', 'Tracking Update', 'Label Voided',
)
RETURN_STATES = {'Returning to Sender', 'Returned to Sender'}


def text(value) -> str:
    return re.sub(r'\s+', ' ', str(value or '')).strip()


def number(value) -> str:
    return re.sub(r'\s+', '', str(value or '')).upper()


def timestamp() -> str:
    return datetime.now(timezone.utc).isoformat()


def iso_day(value) -> str:
    value = text(value)
    try:
        return datetime.strptime(value, '%Y%m%d').date().isoformat()
    except ValueError:
        try:
            return datetime.fromisoformat(value.replace('Z', '+00:00')).date().isoformat()
        except ValueError:
            return ''


def clock_text(value) -> str:
    value = text(value)
    if re.fullmatch(r'\d{1,6}', value):
        value = value.zfill(6)
        try:
            dt = datetime.strptime(value, '%H%M%S')
            return dt.strftime('%I:%M %p').lstrip('0')
        except ValueError:
            return ''
    return value


def activity_at(activity: dict) -> str:
    d = iso_day(activity.get('date'))
    t = text(activity.get('time')).zfill(6)
    offset = text(activity.get('gmtOffset'))
    if d and activity.get('time') is not None and re.fullmatch(r'\d{6}', t):
        try:
            suffix = offset if re.fullmatch(r'[+-]\d{2}:\d{2}', offset) else ''
            return datetime.fromisoformat(f'{d}T{t[:2]}:{t[2:4]}:{t[4:6]}{suffix}').isoformat()
        except ValueError:
            pass
    gd = iso_day(activity.get('gmtDate'))
    gt = text(activity.get('gmtTime')).zfill(6)
    if gd and activity.get('gmtTime') is not None and re.fullmatch(r'\d{6}', gt):
        try:
            return datetime.fromisoformat(f'{gd}T{gt[:2]}:{gt[2:4]}:{gt[4:6]}+00:00').isoformat()
        except ValueError:
            pass
    return d or gd


def activity_key(activity: dict) -> str:
    # UPS documents newest-first. Sorting additionally tolerates reversed fixtures.
    return text(activity.get('gmtDate') or activity.get('date')) + text(activity.get('gmtTime') or activity.get('time')).zfill(6)


def status_text(status: dict) -> str:
    values = []
    for key in ('description', 'simplifiedTextDescription'):
        val = text(status.get(key))
        if val and val not in values:
            values.append(val)
    return ' / '.join(values)


def return_cancelled(value: str) -> bool:
    return bool(re.search(r'\breturn(?: to (?:the )?(?:sender|shipper))?(?: request)? (?:has been |was |is )?(?:cancelled|canceled|reversed)\b', value, re.I))


def return_state(value: str) -> str:
    t = text(value).lower()
    if return_cancelled(t):
        return ''
    if re.search(r'\b(?:has been |was |is )?returned to (?:the )?(?:sender|shipper|origin)\b|\breturn (?:has been )?(?:completed|delivered)\b|\bdelivered (?:back )?to (?:the )?(?:sender|shipper)\b', t):
        return 'Returned to Sender'
    if re.search(r'\breturn(?:ing)? to (?:the )?(?:sender|shipper|origin)\b|\breturn(?:ing|ed)? (?:the |this |your )?package to (?:the )?(?:sender|shipper)\b|\b(?:being|will be|to be) returned\b|\breturn in progress\b', t):
        # A future/ongoing return is not a completed return, even if the verb is 'returned'.
        return 'Returning to Sender'
    return ''


def classify(status: dict | str) -> str:
    s = status if isinstance(status, dict) else {'description': status}
    t = status_text(s).lower()
    ret = return_state(t)
    if ret:
        # Handle future tense before the completed-return phrase.
        if re.search(r'\b(?:will be|being|to be|is being) returned\b', t):
            return 'Returning to Sender'
        return ret
    if re.search(r'\b(?:not delivered|undelivered|delivery attempted|attempted delivery|unable to deliver|delivery exception|exception|we missed you|address (?:information )?(?:required|incorrect))\b', t):
        return 'Exception'
    if re.search(r'\b(?:delayed|delay|rescheduled)\b', t):
        return 'Delayed'
    if re.search(r'\bout for delivery\b|\bon (?:the )?vehicle for delivery\b', t):
        return 'Out for Delivery'
    if re.search(r'\b(?:delivered|delivery complete|delivery completed)\b', t):
        return 'Delivered'
    if re.search(r'\b(?:voided|shipment cancelled|shipment canceled|order processed: canceled)\b', t):
        return 'Label Voided'
    if re.search(r'\b(?:label created|shipment ready|information received|pre-shipment|order processed: ready)\b', t):
        return 'Label Created'
    if re.search(r'\b(?:on the way|in transit|departed|arrived at|arrival scan|departure scan|shipped|origin scan|pickup scan|picked up)\b', t):
        return 'In Transit'
    # Activity type is documented separately from the descriptions. Never guess
    # the many UPS detail/status codes (they have different code domains).
    typ = text(s.get('type')).upper()
    if typ == 'D':
        return 'Delivered'
    if typ == 'X':
        return 'Exception'
    if typ == 'I':
        return 'In Transit'
    return ''


@dataclass
class UPSResult:
    tracking_number: str
    status: str
    description: str = ''
    activity_description: str = ''
    status_code: str = ''
    activity_code: str = ''
    activity_type: str = ''
    event_at: str = ''
    delivered_at: str = ''
    returned_at: str = ''
    eta_date: str = ''
    delivery_window: str = ''
    checked_at: str = ''
    inference: str = ''
    package_count: int = 1

    def as_dict(self) -> dict:
        return asdict(self)

    @property
    def detail(self) -> str:
        parts = [f'UPS: {self.description or self.status}']
        if self.activity_description and self.activity_description != self.description:
            parts.append(f'Latest scan: {self.activity_description}')
        if self.event_at:
            parts.append(f'Scan time: {self.event_at}')
        if self.status_code or self.activity_code or self.activity_type:
            parts.append(f'Codes: current={self.status_code or "-"}; activity={self.activity_code or "-"}; type={self.activity_type or "-"}')
        if self.inference:
            parts.append(self.inference)
        return ' | '.join(parts)


class UPSCheckError(RuntimeError):
    def __init__(self, kind: str, message: str, http_status: int = 0, retry_after: int = 0,
                 stage: str = '', codes: tuple[str, ...] = (), transaction_id: str = ''):
        super().__init__(message)
        self.kind = kind
        self.http_status = http_status
        self.retry_after = retry_after
        self.stage = stage
        self.codes = codes
        self.transaction_id = transaction_id


def api_error_codes(data) -> tuple[str, ...]:
    if not isinstance(data, dict):
        return ()
    codes = []
    for container in (data.get('response'), data.get('trackResponse'), data):
        if not isinstance(container, dict):
            continue
        errors = container.get('errors') or []
        if isinstance(errors, dict):
            errors = [errors]
        if not isinstance(errors, list):
            continue
        for error in errors:
            code = str(error.get('code', '')).strip() if isinstance(error, dict) else ''
            if re.fullmatch(r'[A-Za-z0-9_-]{1,24}', code) and code not in codes:
                codes.append(code)
    if isinstance(data.get('error'), str) and re.fullmatch(r'[a-z_]{1,40}', data['error']):
        codes.append(data['error'])
    return tuple(codes)


class BearerAuth(AuthBase):
    """Explicit auth prevents requests from replacing Bearer with .netrc Basic auth."""
    def __init__(self, token: str):
        self._token = token

    def __call__(self, request):
        request.headers['Authorization'] = 'Bearer ' + self._token
        return request

    def __repr__(self):
        return 'BearerAuth(<redacted>)'


def api_errors(data) -> str:
    if not isinstance(data, dict):
        return ''
    out = []
    for container in (data.get('response'), data.get('trackResponse'), data):
        if not isinstance(container, dict):
            continue
        errors = container.get('errors') or []
        if isinstance(errors, dict):
            errors = [errors]
        if not isinstance(errors, list):
            continue
        for err in errors:
            if isinstance(err, dict):
                msg = text(err.get('message') or err.get('description'))
                code = text(err.get('code'))
                if msg or code:
                    out.append(f'{code}: {msg}' if code else msg)
    if isinstance(data.get('error'), str):
        out.append(text(data['error']) + ': ' + text(data.get('error_description')))
    # Redaction happens before limiting the displayed error length in the client.
    return '; '.join(dict.fromkeys(out))


def parse_ups_response(data: dict, tracking: str) -> UPSResult:
    tracking = number(tracking)
    errors = api_errors(data)
    if errors:
        raise UPSCheckError('api_error', errors)
    shipments = (data.get('trackResponse') or {}).get('shipment') or []
    packages = [p for s in shipments if isinstance(s, dict) for p in (s.get('package') or []) if isinstance(p, dict)]
    # Match the actual tracking number rather than taking package[0].
    matching = [p for p in packages if number(p.get('trackingNumber')) == tracking]
    if not matching:
        raise UPSCheckError('not_found', 'UPS returned no package matching the requested tracking number.')
    package = matching[0]
    current = package.get('currentStatus') or {}
    activities = sorted((a for a in package.get('activity', []) if isinstance(a, dict)), key=activity_key, reverse=True)
    latest = activities[0] if activities else {}
    latest_s = latest.get('status') or {}
    description = status_text(current) or text(package.get('statusDescription'))
    scan_description = status_text(latest_s)
    cur_state = classify(current or description)
    scan_state = classify(latest_s)

    # Return routing can remain in the activity history while currentStatus has
    # regressed to the generic 'On the Way'. Stop at an explicit reversed return.
    return_activity = None
    for act in activities:
        label = status_text(act.get('status') or {})
        if return_cancelled(label):
            break
        if return_state(label):
            return_activity = act
            break
    ret_current = return_state(description)
    ret_latest = return_state(scan_description)
    inference = ''
    status = cur_state or scan_state
    if ret_current or ret_latest:
        status = classify(description) if ret_current else classify(latest_s)
    elif return_activity and not return_cancelled(description):
        if cur_state == 'Delivered' or scan_state == 'Delivered':
            status = 'Returned to Sender'
            inference = 'Delivery after a return-to-sender scan is classified as returned to sender, not delivery to the customer. Return evidence: ' + status_text(return_activity.get('status') or {}) + ' at ' + activity_at(return_activity)
        elif cur_state not in ('Canceled', 'Label Voided'):
            status = 'Returning to Sender'
            inference = 'Return routing remains active in UPS scan history: ' + status_text(return_activity.get('status') or {}) + ' at ' + activity_at(return_activity)
    elif scan_state in ('Exception', 'Delayed') and cur_state in ('', 'In Transit', 'Tracking Update'):
        status = scan_state
    elif scan_state == 'Out for Delivery' and cur_state in ('', 'In Transit'):
        status = scan_state
    if not status:
        if description or scan_description:
            status = 'Tracking Update'
        else:
            raise UPSCheckError('unrecognized', 'UPS returned a matching package but no readable current status or scan.')

    dates = [d for d in package.get('deliveryDate', []) if isinstance(d, dict)]
    actual_day = next((iso_day(d.get('date')) for d in dates if d.get('type') == 'DEL' and iso_day(d.get('date'))), '')
    expected_day = next((iso_day(d.get('date')) for typ in ('RDD', 'SDD') for d in dates if d.get('type') == typ and iso_day(d.get('date'))), '')
    tm = package.get('deliveryTime') or {}
    begin, end = clock_text(tm.get('startTime')), clock_text(tm.get('endTime'))
    window = f'{begin} - {end}' if begin and end else begin or end
    if not window and tm.get('type') == 'EOD':
        window = 'By end of day'
    if not window and tm.get('type') == 'DEL':
        window = clock_text(tm.get('endTime') or tm.get('time'))
    event_at = activity_at(latest)
    delivered_at = ''
    returned_at = ''
    if status == 'Delivered':
        actual_scan = next((a for a in activities if classify(a.get('status') or {}) == 'Delivered'), {})
        delivered_at = activity_at(actual_scan) or actual_day
    if status == 'Returned to Sender':
        returned_at = event_at or actual_day
    if status in RETURN_STATES:
        # The return leg's ETA is not an incoming customer delivery.
        expected_day, window = '', ''
    return UPSResult(
        tracking, status, description, scan_description,
        text(current.get('statusCode') or current.get('code') or package.get('statusCode')),
        text(latest_s.get('statusCode') or latest_s.get('code')),
        text(latest_s.get('type')), event_at, delivered_at, returned_at,
        actual_day if status == 'Delivered' else expected_day, window,
        timestamp(), inference, max(1, int(package.get('packageCount') or 1)),
    )


def aggregate_results(expected_numbers: list[str], results: dict[str, dict]) -> tuple[str, str, str, str, str]:
    """Return one order state without claiming all packages arrived on partial data.

    The full per-package states and original UPS wording are persisted separately.
    Missing/failed packages can never complete the whole order.
    """
    expected = list(dict.fromkeys(number(n) for n in expected_numbers))
    found = [results[n] for n in expected if n in results and results[n].get('status')]
    if not found:
        return '', '', '', '', ''
    states = [r['status'] for r in found]
    expected_count = max([len(expected)] + [int(r.get('package_count') or 1) for r in found])
    complete = len(found) >= expected_count
    if complete and len(set(states)) == 1:
        state = states[0]
    elif any(s in RETURN_STATES for s in states):
        state = 'Mixed Shipments'
    elif 'Delivered' in states:
        state = 'Partially Delivered'
    elif 'Exception' in states:
        state = 'Exception'
    elif 'Delayed' in states:
        state = 'Delayed'
    elif 'Out for Delivery' in states:
        state = 'Out for Delivery'
    elif 'In Transit' in states:
        state = 'In Transit'
    else:
        state = 'Tracking Update'
    details = []
    for n in expected:
        r = results.get(n, {})
        if not r.get('status'):
            details.append(f'{n}: not verified' + (f' | {r["error"]}' if r.get('error') else ''))
            continue
        detail = (f'{n}: {r["status"]} | UPS: {r.get("description", "")} | Latest scan: {r.get("activity_description", "")}')
        if r.get('status_code') or r.get('activity_code'):
            detail += f' | Codes: current={r.get("status_code", "")}; activity={r.get("activity_code", "")}; type={r.get("activity_type", "")}'
        if r.get('event_at'): detail += f' | Scan time: {r["event_at"]}'
        if r.get('inference'): detail += f' | Interpretation: {r["inference"]}'
        if r.get('error'): detail += f' | Last check failed: {r["error"]}'
        details.append(detail)
    if expected_count > len(expected):
        details.append(f'UPS reports {expected_count} packages; only {len(expected)} tracking numbers are known for this order. Whole-order completion is not confirmed.')
    times = [r['delivered_at'] for r in found if r.get('delivered_at')]
    actual = max(times) if state == 'Delivered' and times else ''
    eta = max((r['eta_date'] for r in found if r.get('eta_date') and r['status'] not in RETURN_STATES), default='')
    windows = list(dict.fromkeys(r['delivery_window'] for r in found if r.get('delivery_window')))
    window = windows[0] if len(windows) == 1 else 'Multiple package windows' if windows else ''
    return state, '\n'.join(details), actual, eta, window


class UPSClient:
    """Production-only UPS client with separate OAuth and Tracking diagnostics."""
    _blocked_until = 0.0

    def __init__(self, client_id: str, client_secret: str, session=None, sleep: Callable = time.sleep):
        self.client_id = str(client_id or '').strip()
        self.client_secret = str(client_secret or '').strip()
        self.session = session or requests.Session()
        self.sleep = sleep
        self._token = ''
        self._expires_at = 0.0
        self._last_request = 0.0
        self.diagnostics = []
        self.oauth_ok = False
        self._sensitive = [self.client_id, self.client_secret]
        if self.client_id and self.client_secret:
            self._sensitive.append(base64.b64encode((self.client_id + ':' + self.client_secret).encode()).decode())

    def close(self):
        self.session.close()
        self._token = ''
        self._expires_at = 0.0
        self.client_id = self.client_secret = ''
        self._sensitive.clear()

    def _redact(self, message: str) -> str:
        # Include retired tokens so retry diagnostics cannot expose an old token.
        for secret in sorted(set(self._sensitive + [self._token]), key=len, reverse=True):
            if secret:
                message = message.replace(secret, '[redacted]')
                message = message.replace(quote(secret, safe=''), '[redacted]')
        return message

    def _note(self, message: str):
        self.diagnostics.append(self._redact(message)[:1200])

    def _json_request(self, method: str, url: str, *, stage: str = '', **kwargs) -> dict:
        endpoint = urlparse(url).path
        if endpoint.startswith('/api/track/v1/details/'):
            endpoint = '/api/track/v1/details/{tracking_number}'
        phase = stage or ('OAuth token' if '/oauth/token' in endpoint else 'Tracking API')
        transaction_id = str((kwargs.get('headers') or {}).get('transId') or '')
        remaining = type(self)._blocked_until - time.monotonic()
        if remaining > 0:
            raise UPSCheckError('rate_limited', f'{phase}: UPS cooldown is active. Retry in {int(remaining)+1} seconds.', 429, int(remaining)+1, stage=phase)
        pause = 0.25 - (time.monotonic() - self._last_request)
        if pause > 0:
            self.sleep(pause)
        response = None
        for attempt in range(3):
            try:
                self._last_request = time.monotonic()
                # Credential-bearing requests never follow redirects to another origin.
                response = self.session.request(method, url, timeout=(10, 25), allow_redirects=False, **kwargs)
            except requests.RequestException as exc:
                self._note(f'{phase}: {type(exc).__name__}; request attempt {attempt+1}/3.')
                if attempt < 2:
                    self.sleep(2 ** attempt)
                    continue
                raise UPSCheckError('network', f'{phase}: UPS connection failed ({type(exc).__name__}); the previous status was retained.', stage=phase) from None
            if response.status_code not in (500, 502, 503, 504) or attempt == 2:
                break
            self._note(f'{phase}: HTTP {response.status_code}; transient retry {attempt+1}/2.')
            self.sleep(2 ** attempt)
        try:
            data = response.json()
        except ValueError:
            data = {}
        code = int(response.status_code)
        error = self._redact(api_errors(data))[:500]
        codes = api_error_codes(data)
        codes = tuple(self._redact(c) for c in codes)
        self._note(f'{phase}: {method} onlinetools.ups.com{endpoint}; HTTP {code}' +
                   (f'; UPS code {", ".join(codes)}' if codes else '') +
                   (f'; request ID {transaction_id}' if transaction_id else ''))
        context = dict(stage=phase, codes=codes, transaction_id=transaction_id)
        if 300 <= code < 400:
            raise UPSCheckError('redirect', f'{phase}: unexpected HTTP {code} redirect. It was not followed; no credentials were sent to a different endpoint.', code, **context)
        if code == 429:
            retry = response.headers.get('Retry-After', '')
            try:
                seconds = max(1, int(retry))
            except (ValueError, TypeError):
                try:
                    seconds = max(1, int((parsedate_to_datetime(retry) - datetime.now(timezone.utc)).total_seconds()))
                except Exception:
                    seconds = 60
            type(self)._blocked_until = time.monotonic() + seconds
            raise UPSCheckError('rate_limited', f'{phase}: UPS rate limit reached. Retry after {seconds} seconds. ' + error, code, seconds, **context)
        if code in (401, 403) or '250002' in codes or '10401' in codes or 'invalid_client' in codes:
            kind = 'access' if code == 403 else 'auth'
            if phase == 'OAuth token':
                label = ('UPS access denied while requesting a token' if kind == 'access' else 'UPS rejected the OAuth token request')
                help_text = 'Re-copy BOTH Client ID and Client Secret from the SAME UPS app. Check app/account access in the UPS Developer Portal.'
            else:
                label = ('UPS access denied for Tracking' if kind == 'access' else 'UPS rejected the bearer token for Tracking')
                help_text = 'An OAuth token was obtained, but this Tracking call was rejected. Check that Tracking is included/enabled on the SAME UPS app and test the production Track endpoint in the UPS portal.'
            raise UPSCheckError(kind, f'{phase}: {label} (HTTP {code}). {error} {help_text}'.strip(), code, **context)
        if code == 404:
            msg = 'UPS did not find this tracking number' if phase == 'Tracking API' else 'UPS OAuth endpoint was not found'
            raise UPSCheckError('not_found', f'{phase}: {msg}. {error}'.strip(), code, **context)
        if code >= 400:
            raise UPSCheckError('http', f'{phase}: UPS HTTP {code}. {error}'.strip(), code, **context)
        if not isinstance(data, dict) or not data:
            raise UPSCheckError('invalid_response', f'{phase}: UPS returned an empty or non-JSON response.', code, **context)
        if error:
            raise UPSCheckError('api_error', f'{phase}: {error}', code, **context)
        return data

    def authenticate(self, force: bool = False) -> str:
        if not force and self._token and time.monotonic() < self._expires_at:
            return self._token
        self.oauth_ok = False
        try:
            cid = clean_credential(self.client_id, 'Client ID')
            secret = clean_credential(self.client_secret, 'Client Secret')
        except UPSCredentialError as exc:
            raise UPSCheckError('auth', 'Credentials: ' + str(exc), stage='Credentials') from None
        if not cid or not secret:
            raise UPSCheckError('auth', 'Credentials: enter and save the UPS Client ID and Client Secret in Settings first.', stage='Credentials')
        data = self._json_request(
            'POST', UPS_TOKEN_URL, stage='OAuth token',
            auth=(cid, secret), data={'grant_type': 'client_credentials'},
            headers={'Accept': 'application/json', 'Content-Type': 'application/x-www-form-urlencoded'},
        )
        token = data.get('access_token')
        if isinstance(token, str):
            self._sensitive.append(token)
        if not isinstance(token, str) or not token or any(c.isspace() or ord(c) < 33 or ord(c) > 126 for c in token):
            raise UPSCheckError('auth', 'OAuth token: UPS did not return a usable access token.', stage='OAuth token')
        if str(data.get('token_type', 'Bearer')).lower() != 'bearer':
            raise UPSCheckError('auth', 'OAuth token: UPS returned an unsupported token type.', stage='OAuth token')
        try:
            ttl = int(data.get('expires_in', 3600))
        except (ValueError, TypeError):
            ttl = 3600
        if ttl <= 0:
            raise UPSCheckError('auth', 'OAuth token: UPS returned an expired token.', stage='OAuth token')
        self._token = token
        self._expires_at = time.monotonic() + max(1, ttl - min(60, ttl // 10))
        self.oauth_ok = True
        self._note('OAuth token: PASS. Token obtained from PRODUCTION. Tracking permission is not proven by this step alone.')
        return token

    def track(self, tracking: str) -> UPSResult:
        tracking = number(tracking)
        if not re.fullmatch(r'[A-Z0-9]{7,34}', tracking):
            raise UPSCheckError('invalid_number', 'Invalid tracking-number format; no UPS request was sent.', stage='Input')
        for attempt in range(2):
            token = self.authenticate(force=bool(attempt))
            try:
                data = self._json_request(
                    'GET', UPS_TRACK_URL + quote(tracking, safe=''), stage='Tracking API',
                    params={'locale': 'en_US', 'returnSignature': 'false', 'returnMilestones': 'false', 'returnPOD': 'false'},
                    auth=BearerAuth(token),
                    headers={'Authorization': f'Bearer {token}', 'transId': uuid.uuid4().hex[:24],
                             'transactionSrc': 'AppleOrderTracker', 'Accept': 'application/json'},
                )
                try:
                    result = parse_ups_response(data, tracking)
                    self._note('Tracking API: PASS. Matching package status received.')
                    return result
                except UPSCheckError:
                    raise
                except (ValueError, TypeError, AttributeError, KeyError):
                    raise UPSCheckError('invalid_response', 'Tracking API: UPS returned a malformed package response; the previous status was retained.', stage='Tracking API') from None
            except UPSCheckError as exc:
                if exc.kind == 'auth' and (exc.http_status == 401 or '250002' in exc.codes) and attempt == 0:
                    self._note('Tracking API rejected the token. Obtaining one fresh production token and retrying this package ONCE.')
                    self._token = ''; self._expires_at = 0
                    continue
                raise
        raise UPSCheckError('auth', 'Tracking API: UPS authentication failed after refreshing the token.', stage='Tracking API')

    def diagnose(self, tracking: str = '') -> dict:
        """Read-only test. Does not write order data or disclose auth material."""
        self.diagnostics = ['Build: UPS-AUTH-20260924.', 'Environment: PRODUCTION (onlinetools.ups.com).',
                            'Authentication: Client Credentials; Basic for token, explicit Bearer for Tracking.']
        report = {'oauth_ok': False, 'tracking_ok': None, 'error_kind': '', 'stage': '', 'http_status': 0, 'ups_codes': []}
        self.oauth_ok = False
        try:
            if tracking and not re.fullmatch(r'[A-Z0-9]{7,34}', number(tracking)):
                raise UPSCheckError('invalid_number', 'Enter one valid UPS tracking number, without an order number or tracking URL.', stage='Input')
            self.authenticate(force=True)
            report['oauth_ok'] = True
            if tracking:
                result = self.track(tracking)
                report['tracking_ok'] = True
                report['status'] = result.status
                self._note('Package result: ' + result.status + '. Test only: no order status was saved; use Refresh UPS after a successful test.')
            else:
                self._note('Tracking API: NOT TESTED. Enter one real UPS number and click Test UPS Tracking.')
        except UPSCheckError as exc:
            report.update(oauth_ok=self.oauth_ok, tracking_ok=False if tracking else None,
                          error_kind=exc.kind, stage=exc.stage, http_status=exc.http_status, ups_codes=list(exc.codes))
            self._note(str(exc))
            self._note('No order status was changed. Do not run a full Gmail rescan to troubleshoot this API failure.')
            if report['oauth_ok'] and exc.kind in ('auth', 'access'):
                self._note('Next: open the UPS Developer Portal > My Apps > the same application > API products. Confirm Tracking is included/available. Then try the PRODUCTION Tracking API with this pair in the UPS portal. If UPS rejects it there too, contact UPS API support; app code cannot grant missing access.')
        report['lines'] = list(self.diagnostics)
        return report
