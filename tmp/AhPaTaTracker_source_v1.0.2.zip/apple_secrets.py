"""User-bound encrypted Apple session/proxy storage. No plaintext fallback.

Windows DPAPI is used in the shipped Windows application. Elsewhere secrets
remain memory-only. Session files contain Apple cookies only, never passwords,
page captures, localStorage, card fields, or CVVs.
"""
from __future__ import annotations
import ctypes
import json
import os
import re
from pathlib import Path

class SecretError(RuntimeError):pass

class SecretVault:
    def __init__(self, root):
        self.root=Path(root)/'apple_secure';self.memory={}
        self.root.mkdir(parents=True,exist_ok=True)
        try:self.root.chmod(0o700)
        except OSError:pass
    @property
    def persistent(self):return os.name=='nt'
    def _path(self,key):
        if not re.fullmatch(r'[a-zA-Z0-9_-]{1,100}',key):raise SecretError('Invalid secret reference')
        return self.root/(key+'.dpapi')
    def _crypt(self,data,protect):
        from ctypes import wintypes
        class Blob(ctypes.Structure):
            _fields_=[('length',wintypes.DWORD),('data',ctypes.POINTER(ctypes.c_ubyte))]
        buf=(ctypes.c_ubyte*len(data)).from_buffer_copy(data)
        src=Blob(len(data),buf);dst=Blob()
        fn=ctypes.windll.crypt32.CryptProtectData if protect else ctypes.windll.crypt32.CryptUnprotectData
        fn.argtypes=[ctypes.POINTER(Blob),ctypes.c_void_p,ctypes.POINTER(Blob),ctypes.c_void_p,ctypes.c_void_p,wintypes.DWORD,ctypes.POINTER(Blob)]
        fn.restype=wintypes.BOOL
        if not fn(ctypes.byref(src),None,None,None,None,1,ctypes.byref(dst)):
            raise SecretError('Windows could not protect/read the session for this Windows user')
        try:return ctypes.string_at(dst.data,dst.length)
        finally:
            ctypes.windll.kernel32.LocalFree.argtypes=[ctypes.c_void_p]
            ctypes.windll.kernel32.LocalFree(ctypes.cast(dst.data,ctypes.c_void_p))
    def put(self,key,value):
        path=self._path(key);data=json.dumps(value,separators=(',',':')).encode()
        if self.persistent:
            encoded=self._crypt(data,True);tmp=path.with_suffix('.tmp')
            with tmp.open('wb') as f:f.write(encoded);f.flush();os.fsync(f.fileno())
            os.replace(tmp,path)
        else:self.memory[key]=value
    def get(self,key,default=None):
        path=self._path(key)
        if not self.persistent:return self.memory.get(key,default)
        if not path.exists():return default
        try:return json.loads(self._crypt(path.read_bytes(),False))
        except (ValueError,OSError):raise SecretError('Protected session is unreadable; reconnect the Apple account') from None
    def delete(self,key):
        self.memory.pop(key,None);self._path(key).unlink(missing_ok=True)
