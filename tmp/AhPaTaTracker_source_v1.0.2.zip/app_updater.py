from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

import requests

DEFAULT_UPDATE_REPO = "ryansu1130/hello-world"
EXE_ASSET_NAME = "AhPaTaTracker.exe"
SHA_ASSET_NAME = "AhPaTaTracker.exe.sha256"


class UpdateError(RuntimeError):
    pass


@dataclass(frozen=True)
class UpdateInfo:
    version: str
    tag: str
    title: str
    notes: str
    release_url: str
    exe_url: str
    sha256_url: str
    published_at: str = ""
    size_bytes: int = 0


def normalize_version(value: str) -> str:
    value = str(value or "").strip()
    if value.lower().startswith("v"):
        value = value[1:]
    match = re.fullmatch(r"(\d+)\.(\d+)\.(\d+)(?:[-+][0-9A-Za-z.-]+)?", value)
    if not match:
        raise UpdateError(f"Invalid release version: {value or '(blank)'}")
    return ".".join(match.groups())


def version_tuple(value: str) -> tuple[int, int, int]:
    return tuple(int(x) for x in normalize_version(value).split("."))  # type: ignore[return-value]


def is_newer_version(candidate: str, current: str) -> bool:
    return version_tuple(candidate) > version_tuple(current)


def _request_json(session, url: str, timeout: int = 20) -> dict:
    try:
        response = session.get(
            url,
            headers={
                "Accept": "application/vnd.github+json",
                "User-Agent": "AhPaTaTracker-Updater",
                "X-GitHub-Api-Version": "2022-11-28",
            },
            timeout=timeout,
            allow_redirects=True,
        )
    except Exception as exc:
        raise UpdateError(f"Could not contact GitHub: {type(exc).__name__}.") from exc
    if response.status_code == 404:
        raise UpdateError("No published Ah Pa Ta Tracker release is available yet.")
    if response.status_code == 403 and response.headers.get("X-RateLimit-Remaining") == "0":
        raise UpdateError("GitHub update checking is temporarily rate-limited. Try again later.")
    try:
        response.raise_for_status()
    except Exception as exc:
        raise UpdateError(f"GitHub update check failed (HTTP {response.status_code}).") from exc
    try:
        data = response.json()
    except Exception as exc:
        raise UpdateError("GitHub returned an unreadable update response.") from exc
    if not isinstance(data, dict):
        raise UpdateError("GitHub returned an unexpected update response.")
    return data


def check_latest_release(current_version: str, repo: str = DEFAULT_UPDATE_REPO, session=requests) -> Optional[UpdateInfo]:
    repo = str(repo or "").strip()
    if not re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", repo):
        raise UpdateError("The configured GitHub update repository is invalid.")
    data = _request_json(session, f"https://api.github.com/repos/{repo}/releases/latest")
    if data.get("draft") or data.get("prerelease"):
        raise UpdateError("GitHub's latest release is not a stable published release.")
    tag = str(data.get("tag_name") or "").strip()
    version = normalize_version(tag)
    if not is_newer_version(version, current_version):
        return None

    assets = {}
    for asset in data.get("assets") or []:
        if isinstance(asset, dict) and asset.get("name"):
            assets[str(asset["name"])] = asset
    exe = assets.get(EXE_ASSET_NAME)
    checksum = assets.get(SHA_ASSET_NAME)
    if not exe or not checksum:
        raise UpdateError("The latest release is still building or is missing its Windows update assets. Try again shortly.")
    exe_url = str(exe.get("browser_download_url") or "")
    sha_url = str(checksum.get("browser_download_url") or "")
    if not exe_url.startswith("https://") or not sha_url.startswith("https://"):
        raise UpdateError("The release download links are invalid.")

    return UpdateInfo(
        version=version,
        tag=tag,
        title=str(data.get("name") or tag),
        notes=str(data.get("body") or "").strip(),
        release_url=str(data.get("html_url") or f"https://github.com/{repo}/releases/tag/{tag}"),
        exe_url=exe_url,
        sha256_url=sha_url,
        published_at=str(data.get("published_at") or ""),
        size_bytes=int(exe.get("size") or 0),
    )


def _fetch_checksum(info: UpdateInfo, session=requests, timeout: int = 20) -> str:
    try:
        response = session.get(
            info.sha256_url,
            headers={"User-Agent": "AhPaTaTracker-Updater"},
            timeout=timeout,
            allow_redirects=True,
        )
        response.raise_for_status()
    except Exception as exc:
        code = getattr(getattr(exc, "response", None), "status_code", None)
        suffix = f" (HTTP {code})" if code else ""
        raise UpdateError(f"Could not download the update checksum{suffix}.") from exc
    match = re.search(r"\b([0-9a-fA-F]{64})\b", response.text or "")
    if not match:
        raise UpdateError("The update checksum file is invalid.")
    return match.group(1).lower()


def download_and_verify(
    info: UpdateInfo,
    destination: Path,
    progress: Optional[Callable[[int, int], None]] = None,
    session=requests,
    timeout: int = 45,
) -> Path:
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    part = destination.with_name(destination.name + ".part")
    expected = _fetch_checksum(info, session=session, timeout=timeout)
    hasher = hashlib.sha256()
    total = 0
    try:
        response = session.get(
            info.exe_url,
            headers={"User-Agent": "AhPaTaTracker-Updater"},
            timeout=timeout,
            allow_redirects=True,
            stream=True,
        )
        response.raise_for_status()
        declared = int(response.headers.get("Content-Length") or info.size_bytes or 0)
        with open(part, "wb") as handle:
            for chunk in response.iter_content(chunk_size=1024 * 1024):
                if not chunk:
                    continue
                handle.write(chunk)
                hasher.update(chunk)
                total += len(chunk)
                if progress:
                    progress(total, declared)
    except Exception as exc:
        try:
            part.unlink(missing_ok=True)
        except Exception:
            pass
        code = getattr(getattr(exc, "response", None), "status_code", None)
        suffix = f" (HTTP {code})" if code else ""
        raise UpdateError(f"Could not download the Windows update{suffix}.") from exc

    actual = hasher.hexdigest().lower()
    if actual != expected:
        try:
            part.unlink(missing_ok=True)
        except Exception:
            pass
        raise UpdateError("The downloaded update failed SHA-256 verification and was deleted.")
    os.replace(part, destination)
    return destination


def update_download_path(version: str) -> Path:
    version = normalize_version(version)
    root = Path(os.environ.get("LOCALAPPDATA") or tempfile.gettempdir()) / "AhPaTaTracker" / "updates" / f"v{version}"
    root.mkdir(parents=True, exist_ok=True)
    return root / EXE_ASSET_NAME


def make_update_script(downloaded_exe: Path, current_exe: Path, version: str, pid: Optional[int] = None) -> Path:
    if os.name != "nt":
        raise UpdateError("Automatic installation is available only on Windows.")
    downloaded_exe = Path(downloaded_exe).resolve()
    current_exe = Path(current_exe).resolve()
    if current_exe.suffix.lower() != ".exe" or not current_exe.exists():
        raise UpdateError("The running Ah Pa Ta Tracker executable could not be identified.")
    if not downloaded_exe.exists():
        raise UpdateError("The verified update file is missing.")
    if downloaded_exe == current_exe:
        raise UpdateError("The update staging file cannot be the running executable.")

    safe_version = normalize_version(version)
    root = downloaded_exe.parent
    script = root / "apply_update.cmd"
    backup = current_exe.with_name(current_exe.stem + ".previous.exe")
    log = root / "update.log"
    process_id = int(pid if pid is not None else os.getpid())

    # Paths are inserted only into quoted SET statements. Double quotes are removed
    # defensively because Windows filenames cannot contain them.
    def q(value: Path) -> str:
        return str(value).replace('"', '')

    content = f'''@echo off\r\nsetlocal EnableExtensions\r\nset "TARGET={q(current_exe)}"\r\nset "NEW={q(downloaded_exe)}"\r\nset "BACKUP={q(backup)}"\r\nset "LOG={q(log)}"\r\necho Ah Pa Ta Tracker v{safe_version} update started > "%LOG%"\r\npowershell -NoProfile -ExecutionPolicy Bypass -Command "try {{ Wait-Process -Id {process_id} -ErrorAction SilentlyContinue }} catch {{}}" >> "%LOG%" 2>&1\r\ntimeout /t 1 /nobreak >nul\r\nif exist "%BACKUP%" del /q "%BACKUP%" >> "%LOG%" 2>&1\r\ncopy /y "%TARGET%" "%BACKUP%" >> "%LOG%" 2>&1\r\nset "UPDATED="\r\nfor /L %%I in (1,1,30) do (\r\n  copy /y "%NEW%" "%TARGET%" >> "%LOG%" 2>&1\r\n  if not errorlevel 1 (\r\n    set "UPDATED=1"\r\n    goto launch\r\n  )\r\n  timeout /t 1 /nobreak >nul\r\n)\r\necho Update replacement failed. >> "%LOG%"\r\nif exist "%BACKUP%" copy /y "%BACKUP%" "%TARGET%" >> "%LOG%" 2>&1\r\nstart "" notepad.exe "%LOG%"\r\nexit /b 1\r\n:launch\r\ndel /q "%NEW%" >> "%LOG%" 2>&1\r\nstart "" "%TARGET%"\r\ntimeout /t 2 /nobreak >nul\r\ndel /q "%~f0" >nul 2>nul\r\nexit /b 0\r\n'''
    script.write_text(content, encoding="utf-8", newline="")
    return script


def launch_update_script(script: Path) -> None:
    if os.name != "nt":
        raise UpdateError("Automatic installation is available only on Windows.")
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        subprocess.Popen(
            ["cmd.exe", "/d", "/c", str(Path(script).resolve())],
            creationflags=flags,
            close_fds=True,
            cwd=str(Path(script).resolve().parent),
        )
    except Exception as exc:
        raise UpdateError("The Windows updater helper could not be started.") from exc


def can_self_update() -> bool:
    return os.name == "nt" and bool(getattr(sys, "frozen", False)) and Path(sys.executable).suffix.lower() == ".exe"
