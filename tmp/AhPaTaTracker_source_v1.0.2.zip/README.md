# Ah Pa Ta Tracker v1.0.2 - Apple Account workspace

## Get the Windows release

This source revision is v1.0.2. It extends the published v1.0.1 tracker, whose
source archive SHA-256 was verified before editing. GitHub Actions validates
the source and builds the Windows application before publishing a stable release.

In v1.0.1 or newer, choose **Check for Updates** to install the latest successful
stable release. You do not need Python or a local build for this update path.
The app verifies the downloaded executable's SHA-256 before replacing it.
You can also download `AhPaTaTracker.exe` from
https://github.com/ryansu1130/hello-world/releases/latest.
The published release and its Windows CI result are the source of truth for
availability; source commits alone do not make an update available.

## What is implemented, and what is not proven

Implemented: an Apple Account page, isolated visible browser sessions, per-order
phone mapping and candidate verification, durable confirmed bulk jobs, authenticated
Apple observation storage, the required status precedence, practical browser
handoffs, and integration into the current orders/tracking/detail interfaces.

**Apple production integration is not live-verified.** The adapter uses actual
Playwright browser interaction, but its page-recognition rules were tested on
controlled synthetic DOM fixtures, not your authenticated Apple session. There is
no fabricated/private Apple API and no claim of guaranteed Apple compatibility.

**Cancellation and payment submission are browser-assisted.** The tracker queues
the exact approved targets, checks recognized eligibility, and reconciles Apple's
result. You may need to submit the final change on each actual Apple order page.
It does not collect raw cards or automatically apply one supplied card to every
order. An unfamiliar page pauses with instructions instead of guessing success.

See `REQUIREMENTS_STATUS.md` for the requirement-by-requirement result and gaps.
See `TEST_REPORT.md` for validation details and the remaining live Apple checks.

## Keep your current data

The app still uses `%LOCALAPPDATA%\AppleOrderTracker\orders.db`, the existing
Credential Manager names, and existing preferences. The legacy folder name is
intentional. Gmail/UPS settings, incremental sync, cancellation and Duo date
parsers, manual status/quantity overrides, archives, calendar, and exports remain.
No Gmail rescan, cache rebuild, or database deletion is needed for this update.

On first opening, an additive SQLite migration adds Apple workspace columns and
tables. It first makes `backups\before-apple-account-<timestamp>.db` alongside your
database. Close every older instance before upgrading. For rollback, close the
new app, save a copy of its database, then restore the pre-update backup and run
v1.0.1. That restores the old state and loses changes made after that backup;
never restore over a running application.

Apple cookies and proxy credentials are separate user-bound DPAPI encrypted files
in `apple_secure` beside the database. Copying those files to a different Windows
user does not provide portable access. Reauthenticate instead. On non-Windows
systems the new secret vault is memory-only, not an insecure plaintext fallback.

## Windows prerequisites / local build alternative

Use a current supported Windows system with Python 3.11 or newer for the source
builder, and install **Microsoft Edge or Google Chrome** for the Apple workspace.
Brave can be selected when installed but is experimental: compatibility with its
particular build is not guaranteed. These are normal visible browsers, not a hidden
Apple session or an imported normal-browser profile.

To build locally instead of publishing with GitHub:

1. Close Ah Pa Ta Tracker. Extract the entire package.
2. Open `apple_order_tracker` and run `build_windows.bat`.
3. Keep all new modules and the tests directory together. The builder installs
   dependencies under the short `%LOCALAPPDATA%\AOTB\venv` location, runs core and
   Qt checks, and packages Playwright's driver plus the existing app.
4. Open `dist\AhPaTaTracker.exe`. Use the same Windows user as your old version.
5. Do not rebuild the Gmail cache. Existing data loads automatically.

The Windows builder fails rather than silently distributing a failing test build.
Logs: `%LOCALAPPDATA%\AOTB\core_check.log` and `gui_check.log`.
The browser runtime uses an installed browser; it does not download a browser or
change your default-browser profile. Driver/browser compatibility errors are shown
as setup problems. They do not become an order failure or a phone mismatch.

## 1. Connect an Apple Account

Open **Apple Account > Connection > Add Apple Account** and enter the intended
account email. This is a destination identity, not the order alias or Gmail source.
Choose Edge, Chrome, or Brave, and normally keep the route **Direct (no proxy)**.

Click **Open Sign-in / Reconnect**. Enter the password, passkey, two-factor code,
or trusted-device approval directly in Apple's browser. The tracker never asks
for or stores the Apple password or verification code.

After signing in, show the account menu/order listing and click **Verify Sign-in**.
The adapter checks a recognized signed-in listing and compares a visible full
Apple Account email where available. If Apple does not expose that email in a
recognized region, inspect it yourself and use **Confirm Account Identity**.
This is labeled `User-confirmed identity + signed-in Apple listing`, not presented
as an independently observed full account email.

Each configured account has its own browser context, encrypted cookies, route and
queued actions. A visible different account identity blocks the action. A detected
expired session pauses the affected account until you sign in and verify again.

**Disconnect** closes the dedicated browser and retains encrypted app cookies.
**Sign Out / Forget** closes it and deletes the app's locally saved session. This
is not a promise to revoke every Apple session on Apple's servers or sign out your
normal browser. Use Apple's own sign-out/account controls for server-side logout.

## 2. Import JSON phone mappings

Open **Phone mappings > Import JSON files** and select multiple files. You can add
more later; no small fixed file-count limit is imposed. Arrays of profile records
are streamed. The supplied sample schema is supported: root `email`, nested
`shipping.phone`, `shipping.country`, with optional billing phones/order references.
Payment/card objects, passwords and tokens are excluded from extraction/storage.

For an unfamiliar schema use **Import with field mapping**. The preview exposes
field names, not card values. Map relative email/phone/country/order paths within
the same logical record; the importer will not pair unrelated sibling records.

Limits are explicit: approximately 8 MiB per streamed record, 64 MiB for a non-array
nested JSON document, and nesting depth 20. Records are committed in batches of
500. A bad file is reported while other files continue. The display shows up to
500 matching candidates; narrow the search for larger imports.

Complete aliases remain distinct, including plus tags and local-part case. Domains
are normalized consistently. Equivalent US/Canadian numbers can deduplicate when
country context is available; ambiguous other local numbers are flagged, not
silently assigned a country code. Original values, normalized values, extensions,
source filename, record/field paths and import time remain available.

Repeated imports do not multiply identical candidates. A verified phone belongs
to that order and destination account only; another order with the same alias may
use a different number.

The actual sample provided in this request contained three profiles, none matching
the alias shown in the screenshot. It was used privately for schema validation and
is not included here. Import the file containing the matching alias to populate
that order. No matching record means **No matching phone number found**, not a
phone borrowed from another profile.

## 3. Read/correct phone data on an order

Double-click an order. **Phone number(s)** is directly below **Alias email**.
It shows original candidate numbers and per-order states such as Untried, Mismatch,
Uncertain and Verified. The detail refreshes after mapping/verification changes.
Open **Apple account details / phone provenance** to inspect all source paths, copy
a candidate, add an explicit correction for this order, or reset an attempt.

Corrections are scoped to the exact order. Adding a candidate does not mark it
Apple-verified. The tracker does not confuse imported candidate data with a phone
actually reported by Apple.

## 4. Associate or refresh selected orders

On **Orders**, the date's order page, **Shipping Tracking**, or **Pickup Tracking**,
check the orders and open **Apple Actions**. Existing Select All selects the entire
filtered table, not just rows currently visible on screen. The main Orders table
is virtualized, not divided into a separate current-page/whole-results selector.
The frozen preview lists the exact destination account, orders, known items,
units, last-observed eligibility and full-order totals.

Choose **Link selected to Apple Account**, review, confirm, and queue. The worker:

- Checks the intended signed-in account and exact order.
- Uses the existing order-specific Apple link and supported Add to Apple Account UI.
- Ranks exact-order candidates first, then remaining exact-alias valid candidates.
- Advances a candidate only after a clear phone rejection. Timeouts, authentication
  requests, rate limits and unknown pages preserve the current candidate.
- Stops trying phones after confirmed association and records the successful phone
  only for that order. Already-associated does not retroactively verify a phone.
- Attempts an authenticated refresh after association.

Opening a page, signing in, or seeing cancellation/payment controls does not count
as linking. A new association must appear in the correct signed-in account's order
listing. Later refreshes can reuse that previously confirmed association when an
older order is absent from the current listing page.
If Apple exposes an unfamiliar phone field, login iframe, verification challenge,
or an unrecognized result, use **Show Apple browser**, complete the specific step,
then **Continue / Re-read Apple**. OTP/code fields are not used as order-phone inputs.

**Refresh selected from Apple** is read-only. **Refresh all filtered orders** has
an explicit count and preview. Background refresh is optional and off initially;
it checks linked active orders in limited cycles, not every completed order.

## 5. Source priority and item differences

Visible status: **manual override > latest usable authenticated Apple observation
> existing email/UPS reconciliation**. Lower sources retain their prior relative
logic. Manual quantity also remains highest priority.

Apple observations are stored while a manual override controls display. Removing
that override recomputes the visible state. A failed Apple read preserves the last
successful observation and exposes the latest attempt/error separately. Sequence
numbers and event-time checks reject stale observations completing out of order.

Order details show the connected/linked account, association state, Apple raw and
normalized status, source event date when recognized, last successful read, latest
attempt and current error. **View Apple items and eligibility** shows item-level
observations. An unknown status is surfaced as Apple Update rather than mapped
blindly to Processing. Partial/mixed statuses are retained.

Limit: DOM item/identifier discovery depends on the actual Apple layout. Unknown
or incomplete multi-item pages remain flagged. Existing calendar placement remains
order-level/earliest-estimate behavior; this update is not a complete per-item
shipment-allocation engine. The current browser enrichment recognizes UPS links
and labeled delivery/pickup fields; other carrier layouts may need adapter updates.
Existing email-based multi-carrier parsing is unchanged.

## 6. Cancel selected Apple orders/items

This is different from a local status override. Choose **Cancel selected on Apple**,
review the frozen batch and confirm it. Item selection is available only when a
prior authenticated observation supplied stable item IDs; array position is not
used as an order-item identity.

The worker rechecks current eligibility and relevant quantities. On a recognized
page it opens the cancellation control when unambiguous. **You perform the final
submission in Apple where a verified unattended final-action flow is unavailable.**
For partial orders, submit only the exact reviewed item identities.

Then click **Continue / Re-read Apple**. Only Apple's confirmed resulting order or
selected-item statuses produce success. An uncertain submission is reconciled,
not automatically submitted again. Ineligible selections are reported separately.
A job stopping does not reverse changes that Apple already accepted.

## 7. Update an existing order's payment method

Choose **Update payment for selected**, optionally identify the intended method as
`Visa ****1234` (masked metadata only), and confirm the exact batch. On each eligible
order the browser opens a recognized order-specific payment control or provides a
handoff. Enter/select the method on Apple's page, not inside the tracker.

The tracker never imports your JSON payment object, stores CVV/PAN, updates account
defaults as a substitute, or blindly resubmits after a decline. It does not automate
reusing a raw card across the batch. If Apple exposes a saved method, select it on
each applicable page. Then Continue/Re-read.

A method-update confirmation is distinct from payment clearance or resumed
fulfillment. When a masked method was specified, a recognized matching payment
summary is required; inability to verify it produces Uncertain. A clear decline
requires correction and a newly reviewed batch, not an automatic retry.

## 8. Durable jobs, pacing, proxies and restart recovery

**Jobs & results** shows recent jobs and paginated tasks (250 per page), counts,
required action, attempts, retry time and sanitized messages. Pause, Resume,
Stop Job and Retry eligible failures operate on stored work. Completed tasks stay
complete; a restart does not blindly repeat an uncertain mutation. The audit trail
and sanitized job export retain action/account/order/outcome, not session secrets.

There is one browser-owner scheduler and a per-order lock. Default pacing is 12
seconds between Apple jobs (configurable 5-600), not a guaranteed per-HTTP-resource
rate. Apple may load many resources inside one page. Retries use backoff/jitter,
server Retry-After and shared cooldown. Repeated failures pause a session. Login
expiry and phone mismatch remain distinct.

Optional proxy lists accept URL or host:port forms (and supported authenticated
forms). Entries are validated independently, credentials encrypted, and the chosen
route stays assigned to the browser session. The health test establishes TCP
reachability only; proxy authentication/routing is checked by actual browser use.
No cookie clearing, proxy hopping, CAPTCHA bypass or stealth is used to evade a
block. A route change requires disconnecting and respecting the current cooldown.

Do not promise or expect unlimited unattended requests. Apple may need user action,
reject a session, change its layout, or leave a particular action ineligible.

## Upgrade and rollback safeguards

Wait for imports to finish and disconnect Apple browsers before installing an OTA
update. The app's normal close path drains workers before closing the database.
Existing updater URL and asset names remain unchanged. The first version containing
this workspace is v1.0.2. Use the published Windows executable for consistent
release behavior. Rebuild Cache is blocked when it would erase durable Apple
history or while relevant workers are active. Use Full Account Sync or Refresh
Details to reread email while preserving linked orders and Apple job history.

## Official workflow references consulted

- Apple guest association / default changes: https://www.apple.com/shop/help/your_account
- Apple order states, split items and cancellation: https://www.apple.com/shop/help/viewing_changing_orders
- Apple payment help: https://www.apple.com/shop/help/payments
- Playwright browser compatibility: https://playwright.dev/python/docs/browsers
- Playwright session sensitivity: https://playwright.dev/python/docs/auth
- GitHub CLI browser authentication: https://cli.github.com/manual/gh_auth_login

These establish supported customer-facing concepts, not an automated Apple API or
proof that the private pages have been exercised by this implementation.
