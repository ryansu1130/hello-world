@echo off
setlocal
cd /d "%~dp0"
set "PYTHONUTF8=1"
set "PY=%LOCALAPPDATA%\AOTB\venv\Scripts\python.exe"
if not exist "%PY%" (
  echo Run build_windows.bat first to prepare the short-path environment.
  pause
  exit /b 1
)
"%PY%" "%~dp0AppleOrderTracker.py"
if errorlevel 1 pause
