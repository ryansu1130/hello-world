# v1.0.2 requirement-by-requirement result

Labels: **Implemented/tested** means local code and the identified offline tests
were executed. **Browser-assisted / live-unverified** means a real adapter exists,
but the private Apple service flow was not executed. It does not mean production
success. **Partial** identifies an unmet or narrower portion of the request.

| Prompt section | Delivered behavior | Verification and remaining limitation |
|---|---|---|
| 1. Inspect current application / workflow | Started from verified v1.0.1 source. Retains PySide6, SQLite, email/carrier paths and OTA. Reviewed official account/order/payment help. Additive backed-up migration. | Existing-source regression suite passed; no authenticated Apple session was available. |
| 2. Apple Account management | Dedicated page; multiple isolated accounts/browser contexts; interactive sign-in/2FA; identity/state/last-auth; reconnect; local encrypted cookies; expiry pause/resume. | Identity and expiry tested with controlled DOM. When full identity is not exposed, user confirmation is explicitly labeled. Local Forget is not server-wide logout/revocation. Passkey/2FA prompts are handed to the user; actual compatibility must be checked on their PC. |
| 3. Multiple JSON mappings | Streams arrays; nested logical records and custom path mapping; complete aliases; multiple phones; original/normalized/ext; provenance; idempotent import; per-file continuation; resource limits. Payment data excluded. | Actual supplied 3-record schema checked privately. 50k synthetic profiles imported. Large non-array documents have a stated size limit. Unfamiliar schemas require the field-mapping dialog. |
| 4. Existing order detail | Phone number(s) directly below Alias; untried/mismatch/uncertain/verified states; provenance/copy/correction; auto refresh; linked account, raw Apple status, timestamps and errors; item observation viewer. | Core checks and the 10-test Apple workspace Qt suite passed during release validation. |
| 5. Associate guest orders | Frozen account/order targets; exact order links; supported Add workflow; order-hint-first candidates; sequential explicit mismatches only; stop on confirmed association; per-order verified phone; later refresh. | Controlled real-browser DOM tests pass. Actual Apple selectors, account listing pagination and final association are live-unverified. Unknown UI gets a manual handoff; no opened-page success. |
| 6. Sessions/rate limits/proxies | One shared scheduler; pacing; jitter/backoff; Retry-After; cooldown/circuit; stable per-session route; imported proxy list; encrypted route secrets; browser choice including experimental Brave. | Queue/cooldown/route validation tests pass. Health label is TCP-only, not a verified working authenticated proxy. No rate-limit bypass/cookie clearing/proxy rotation. |
| 7. Current Apple details / refresh | Individual via one checked order, selected and filtered batch refresh; last successful versus latest attempt; raw/normalized source; stale sequence/event rejection; item statuses; partial aggregates; post-association/cancel/payment reconciliation. | Partial: enrichment requires recognized visible fields. Browser carrier enrichment currently recognizes UPS; other website layouts need validation. Existing calendar remains order-level, not full per-item shipment allocation. Unknown layouts do not invent missing data. |
| 8. Source hierarchy | Manual override first, authenticated Apple observation second, existing lower sources retain prior relative reconciliation. Cached successful Apple data survives transient errors. Manual removal recomputes. | SQLite/unit tests pass, including active manual override and older out-of-order response. Last-success times are displayed; no claim of perpetual freshness. |
| 9. Selected cancellation | Concrete confirmed order/item preview; stable item IDs only; quantity/eligibility recheck; frozen scope; no hidden additions; partial outcomes; uncertain reconciliation and post-action read. | Browser-assisted final submission, not fully unattended bulk cancellation. Item buttons and current eligibility must exist on real Apple pages. No real orders were canceled in tests. |
| 10. Payment update | Concrete selected existing-order batch, masked method label, Apple-page secure entry, eligibility check, confirmation read, mismatch/decline/uncertainty states, no raw card/CVV storage. | Partial: no automatic one-card application across many orders, no raw-card collection/reuse. User selects/enters a method on each Apple order page. A successful method change does not prove payment clearance. No real payment changed. |
| 11. Durable bulk jobs / large UI | Stored target IDs/snapshot hashes, state, attempts, timestamps, next retry; pause/resume/stop/retry; per-order locking; restart recovery; audit/export; virtual tables/paged task list; work off GUI thread. | 20k-order/50k-profile local benchmark passed. Existing Orders view is virtualized with checked/all-filtered selection, not a new separate current-page selector. Filter changes retain existing export-selection rules; confirmed jobs remain frozen independently. |
| 12. Tests | 204 core tests and 24 Qt checks passed for the release source. The original 13-scenario DOM suite passed during development; the expanded 16-scenario suite is a required Windows release gate. Original sample privacy/load evidence is retained. | Controlled tests are not live Apple integration tests. Windows tests and the EXE build are release gates; the actual result is recorded in GitHub Actions. User-machine OTA restart and live Apple flows remain unverified. |
| 13. Integrated code/migrations/setup/report | All source modules, builder, migration, usage guide, test suites/results, and publisher helper supplied. | The reviewed source is published through the existing GitHub repository. Its Windows workflow verifies the bundle and passes all gates before publishing the EXE/checksum. The latest stable GitHub release is authoritative for OTA availability. |

## Requested scenario coverage

| Scenario | Test or behavior |
|---|---|
| One alias / two phones | Both retained; real fixture-browser sequential mismatch then success. |
| Two orders / same alias / different verified phones | Per-order/per-account verification table and tests prevent universal promotion. |
| Equivalent phones/files | Comparison key deduplicates; provenance remains; country/extension tests. |
| Malformed file plus valid | Import summary reports error; valid records continue. |
| Unknown nested schema | Field-path preview/mapping; no unrelated sibling pairing. |
| Missing/rejected phones | Needs-phone-data outcome; other eligible work can continue. |
| Expired login / verification | Account pauses; current candidate is not marked mismatch. OTP fields not auto-filled. |
| Throttling | Explicit cooldown/Retry-After; no route switching. |
| Restart during work | Completed tasks retained; uncertain mutation reconciled rather than resubmitted. |
| Timeout after submission | Submitted flag persists; no automatic new submission/candidate. |
| Ineligible subset | Per-target ineligible/skipped outcome, not blanket success. |
| Manual override during refresh | Raw Apple observation retained; manual display unchanged. |
| Older response finishes later | Sequence/event guards retain newer observation. |
| Partial cancellation/shipment | Recognized item states retained; partial/mixed aggregate, not false whole-order completion. |
| Payment-method updated/payment pending | Separate operation-success message and unchanged fulfillment observation. |
| Large dataset | Measured 20k orders / 50k profiles; details in TEST_REPORT.md. |

## Release decision

This is an integrated, test-covered **browser-assisted** update, not a verified
unattended Apple account-management product. The user should first try one owned
order after authenticating, inspect the actual association/read results, and only
then authorize broader jobs. Controlled cancellation/payment tests did not touch
any real order. Unsupported pages must stay in an actionable paused/uncertain
state; do not mark success manually as a substitute for verification in the code.
