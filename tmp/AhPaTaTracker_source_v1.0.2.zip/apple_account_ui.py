"""Apple workspace UI integrated into the existing PySide tracker.

Browser work and profile imports use their own worker-owned SQLite connections.
No passwords/cards are collected here; the user enters those on Apple's page.
"""
from __future__ import annotations
import hashlib
import json
import re
import socket
import time
import uuid
from pathlib import Path
from PySide6.QtCore import Qt,QAbstractTableModel,QModelIndex,QThread,QTimer,Signal
from PySide6.QtWidgets import (QWidget,QDialog,QVBoxLayout,QHBoxLayout,QFormLayout,QLabel,QPushButton,
    QComboBox,QLineEdit,QSpinBox,QCheckBox,QTabWidget,QTableView,QHeaderView,QAbstractItemView,
    QFileDialog,QMessageBox,QApplication,QPlainTextEdit,QDialogButtonBox,QMenu,QListWidget,QListWidgetItem,QSplitter,QInputDialog)
from apple_accounts import AppleStore,safe_message,utc_now
from apple_profiles import safe_paths,iter_records,parse_proxy,normalize_phone,email_key
from apple_secrets import SecretVault
from apple_jobs import AppleRunner


class RecordModel(QAbstractTableModel):
    def __init__(self,columns,rows=(),parent=None):
        super().__init__(parent);self.columns=columns;self.rows=list(rows)
    def rowCount(self,parent=QModelIndex()):return 0 if parent.isValid() else len(self.rows)
    def columnCount(self,parent=QModelIndex()):return len(self.columns)
    def headerData(self,n,orientation,role=Qt.DisplayRole):
        if role==Qt.DisplayRole and orientation==Qt.Horizontal:return self.columns[n][1]
    def data(self,index,role=Qt.DisplayRole):
        if not index.isValid() or index.row()>=len(self.rows):return None
        row=self.rows[index.row()];key=self.columns[index.column()][0]
        if role in (Qt.DisplayRole,Qt.ToolTipRole):
            value=row.get(key,'')
            return '' if value is None else str(value)
        if role==Qt.TextAlignmentRole:return int(Qt.AlignLeft|Qt.AlignVCenter)
    def set_rows(self,rows):self.beginResetModel();self.rows=list(rows);self.endResetModel()
    def sort(self,column,order=Qt.AscendingOrder):
        key=self.columns[column][0]
        self.layoutAboutToBeChanged.emit();self.rows.sort(key=lambda r:str(r.get(key) or '').casefold(),reverse=order==Qt.DescendingOrder);self.layoutChanged.emit()


def table_for(model):
    t=QTableView();t.setModel(model);t.setSelectionBehavior(QAbstractItemView.SelectRows);t.setSelectionMode(QAbstractItemView.SingleSelection)
    t.setEditTriggers(QAbstractItemView.NoEditTriggers);t.setAlternatingRowColors(True);t.setWordWrap(False)
    t.verticalHeader().hide();t.verticalHeader().setDefaultSectionSize(38)
    t.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive);t.horizontalHeader().setStretchLastSection(True)
    for i in range(model.columnCount()):t.setColumnWidth(i,155)
    return t


def selected_record(table,model):
    index=table.currentIndex()
    return model.rows[index.row()] if index.isValid() and index.row()<len(model.rows) else None


class BrowserWorker(QThread):
    update=Signal(str,object)
    def __init__(self,owner):
        super().__init__(owner)
        self.runner=AppleRunner(type(owner.db),owner.db.path,owner.apple_order_url,owner.apple_eta_parser,
                                lambda event,data:self.update.emit(event,data))
    def run(self):self.runner.run()
    def send(self,*args,**kwargs):self.runner.send(*args,**kwargs)
    def request_stop(self):self.runner.stop()


class ImportWorker(QThread):
    progress=Signal(object);done=Signal(object)
    def __init__(self,dbtype,path,files,mapping,parent=None):
        super().__init__(parent);self.dbtype=dbtype;self.path=path;self.files=files;self.mapping=mapping;self.stop_requested=False
    def run(self):
        db=None
        try:
            db=self.dbtype(self.path);report=AppleStore(db).import_files(self.files,self.mapping,self.progress.emit,lambda:self.stop_requested)
            self.done.emit(report)
        except Exception as exc:self.done.emit({'errors':['Import failed: '+type(exc).__name__], 'accepted':0})
        finally:
            if db:db.close()


class MappingDialog(QDialog):
    def __init__(self,path,parent=None):
        super().__init__(parent);self.setWindowTitle('Profile field mapping');self.resize(680,480)
        lay=QVBoxLayout(self);note=QLabel('Choose paths within ONE logical profile. Never pair unrelated arrays. Payment/card fields are excluded.\nFor a nested collection use records_path (for example: profiles).');note.setWordWrap(True);lay.addWidget(note)
        fields=[]
        try:
            _,sample=next(iter_records(Path(path)))
            if isinstance(sample,dict):fields=safe_paths(sample)
        except Exception:pass
        preview=QPlainTextEdit('\n'.join(fields[:120]));preview.setReadOnly(True);preview.setMaximumHeight(140);lay.addWidget(preview)
        form=QFormLayout();self.inputs={}
        for key,title,default in [('records_path','Record collection path (blank for array)',''),('email','Email path','email'),('phone','Phone path','shipping.phone'),('country','Country path','shipping.country'),('order','Order number path (optional)','')]:
            box=QLineEdit(default);form.addRow(title,box);self.inputs[key]=box
        lay.addLayout(form)
        buttons=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel);buttons.accepted.connect(self.accept);buttons.rejected.connect(self.reject);lay.addWidget(buttons)
    def mapping(self):return {k:v.text().strip() for k,v in self.inputs.items()}


class PreviewDialog(QDialog):
    def __init__(self,store,ids,action,parent=None):
        super().__init__(parent);self.store=store;self.ids=list(ids);self.action=action;self.data=None;self.item_selections={}
        self.setWindowTitle('Review Apple '+action+' batch');self.resize(1000,640)
        lay=QVBoxLayout(self);head=QLabel('Review the exact Apple targets');head.setObjectName('dialogTitle');lay.addWidget(head)
        self.account=QComboBox()
        for c in store.connections():self.account.addItem(c['email']+' - '+c['state'],c['id'])
        form=QFormLayout();form.addRow('Destination Apple Account',self.account);self.method=QLineEdit();self.method.setPlaceholderText('Optional masked label only, e.g. Visa ****1234')
        if action=='payment':form.addRow('Intended payment method',self.method)
        lay.addLayout(form)
        self.count=QLabel();lay.addWidget(self.count)
        self.model=RecordModel([('order_number','Order #'),('item','Item'),('qty','Units'),('total','Order total'),('expected_status','Current status'),('scope_label','Scope'),('eligibility','Last observed eligibility')])
        self.table=table_for(self.model);self.table.setColumnWidth(1,310);lay.addWidget(self.table,1)
        item_btn=QPushButton('Choose items for highlighted order');item_btn.setVisible(action=='cancel');item_btn.clicked.connect(self.choose_items);lay.addWidget(item_btn,0,Qt.AlignLeft)
        warning={'associate':'Only matching imported phone candidates are tried. Opening a page or signing in is not counted as association.',
                 'refresh':'Read-only refresh. Manual overrides remain highest priority. Missing/unknown Apple data is not invented.',
                 'cancel':'This changes existing Apple orders. Eligibility is rechecked. Final cancellation is browser-assisted in this build; submit only the reviewed targets on Apple. Stop Job does not undo actions.',
                 'payment':'This can authorize or charge your payment method. Enter/select it directly on each Apple order page. The tracker does not collect or reuse raw card data and does not change account defaults. A method update does not prove payment cleared.'}[action]
        label=QLabel(warning);label.setWordWrap(True);lay.addWidget(label)
        self.confirm=QCheckBox('I authorize this exact account and selected order/item batch.');self.confirm.setVisible(action!='refresh');lay.addWidget(self.confirm)
        self.status=QLabel();self.status.setWordWrap(True);lay.addWidget(self.status)
        buttons=QDialogButtonBox(QDialogButtonBox.Cancel);self.go=buttons.addButton('Queue selected '+action,QDialogButtonBox.AcceptRole)
        self.go.clicked.connect(self.submit);buttons.rejected.connect(self.reject);lay.addWidget(buttons)
        self.account.currentIndexChanged.connect(lambda: self.confirm.setChecked(False));self.account.currentIndexChanged.connect(self.refresh);self.method.textChanged.connect(lambda:self.confirm.setChecked(False));self.refresh()
    def refresh(self):
        try:
            self.data=self.store.snapshot(self.ids,self.account.currentData(),self.action,self.method.text().strip() if self.action=='payment' else '',self.item_selections)
            display=[];units=0
            for r in self.data['orders']:
                value=dict(r);value['scope_label']='Selected items: '+', '.join(r['item_ids']) if r['item_ids'] else 'Whole order'
                if r['item_ids']:
                    units+=sum(int(i.get('qty') or 0) for i in r['observed_items'] if i.get('id') in r['item_ids'])
                else:units+=r['qty']
                display.append(value)
            self.model.set_rows(display);self.count.setText(f'{len(display):,} orders / {units:,} selected units. Apple item lines: '+(str(sum(len(r["item_ids"]) if r["item_ids"] else len(r["observed_items"]) for r in self.data["orders"])) if all(r["observed_items"] for r in self.data["orders"]) else 'not fully verified')+'. Totals are full-order amounts, not partial-item quotes.')
            self.status.setText('Eligibility will be read from Apple immediately before any action.');self.go.setEnabled(True)
        except ValueError as e:self.status.setText(str(e));self.go.setEnabled(False);self.data=None
    def choose_items(self):
        r=selected_record(self.table,self.model)
        if not r:return
        items=[i for i in r['observed_items'] if i.get('stable_id')]
        if not items:
            QMessageBox.information(self,'Item scope','Refresh from Apple first. No stable Apple item identifiers are available; selecting individual items by table position would be unsafe.');return
        dlg=QDialog(self);dlg.setWindowTitle('Choose exact Apple items');lay=QVBoxLayout(dlg);lst=QListWidget();lay.addWidget(lst)
        for i in items:
            entry=QListWidgetItem(f"{i['id']} | {i.get('item','')} | Qty {i.get('qty','?')} | {i.get('status','')}")
            entry.setData(Qt.UserRole,i['id']);entry.setFlags(entry.flags()|Qt.ItemIsUserCheckable)
            entry.setCheckState(Qt.Checked if not r['item_ids'] or i['id'] in r['item_ids'] else Qt.Unchecked);lst.addItem(entry)
        b=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel);b.accepted.connect(dlg.accept);b.rejected.connect(dlg.reject);lay.addWidget(b)
        if dlg.exec()==QDialog.Accepted:
            selected=[lst.item(i).data(Qt.UserRole) for i in range(lst.count()) if lst.item(i).checkState()==Qt.Checked]
            if not selected:QMessageBox.warning(self,'Item scope','Select at least one item, or remove this order from the batch.');return
            self.item_selections[r['id']]=selected;self.confirm.setChecked(False);self.refresh()
    def submit(self):
        self.refresh()
        if not self.data:return
        if self.action!='refresh' and not self.confirm.isChecked():self.status.setText('Confirm the exact batch before queueing.');return
        self.accept()


class PhoneDialog(QDialog):
    def __init__(self,db,order_id,parent=None):
        super().__init__(parent);self.db=db;self.store=AppleStore(db);self.oid=order_id;self.setWindowTitle('Order phone candidates');self.resize(990,520)
        lay=QVBoxLayout(self);row=db.order_by_id(order_id);lay.addWidget(QLabel('Exact aliases: '+(row['alias_emails'] or 'None')))
        self.account=QComboBox()
        for c in self.store.connections():self.account.addItem(c['email'],c['id'])
        lay.addWidget(self.account)
        self.model=RecordModel([('original','Phone'),('normalized','Normalized'),('quality','Validity'),('verification','For THIS order'),('order_match','Exact order hint'),('email','Alias')])
        self.table=table_for(self.model);lay.addWidget(self.table,1)
        tools=QHBoxLayout();sources=QPushButton('View provenance');add=QPushButton('Add/correct phone for this order');reset=QPushButton('Reset selected attempt for this order')
        for b in (sources,add,reset):tools.addWidget(b)
        lay.addLayout(tools);self.note=QLabel('A JSON candidate is not a verified number. Verification is per order and destination account.');self.note.setWordWrap(True);lay.addWidget(self.note)
        sources.clicked.connect(self.sources);add.clicked.connect(self.add);reset.clicked.connect(self.reset);self.account.currentIndexChanged.connect(self.refresh)
        close=QDialogButtonBox(QDialogButtonBox.Close);close.rejected.connect(self.reject);lay.addWidget(close);copy=QPushButton('Copy highlighted phone');copy.clicked.connect(self.copy_phone);lay.addWidget(copy)
        self.refresh()
    def refresh(self):self.model.set_rows(self.store.phone_candidates(self.db.order_by_id(self.oid),self.account.currentData() or ''))
    def sources(self):
        r=selected_record(self.table,self.model)
        if not r:return
        text='\n'.join(f"{s['filename']} | {s['record_path']}.{s['field_path']} | order hint {s['order_number'] or 'none'} | {s['imported_at']}" for s in self.store.phone_sources(r['id']))
        dlg=QDialog(self);dlg.setWindowTitle('Phone provenance');lay=QVBoxLayout(dlg);view=QPlainTextEdit(text);view.setReadOnly(True);lay.addWidget(view);dlg.resize(850,300);dlg.exec()
    def add(self):
        from apple_profiles import aliases
        row=self.db.order_by_id(self.oid);keys=aliases(row['alias_emails'] or '')
        if not keys:QMessageBox.warning(self,'Phone','This order has no exact alias. Import a matching order email first.');return
        dlg=QDialog(self);dlg.setWindowTitle('Order-specific phone correction');form=QFormLayout(dlg);alias=QComboBox();alias.addItems(keys);phone=QLineEdit();country=QComboBox();country.addItems(['Country not specified','United States','Canada'])
        form.addRow('Exact alias',alias);form.addRow('Phone (including country code)',phone);form.addRow('Country context',country)
        b=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel);b.accepted.connect(dlg.accept);b.rejected.connect(dlg.reject);form.addRow(b)
        if dlg.exec()!=QDialog.Accepted:return
        p=normalize_phone(phone.text(),country.currentText())
        if p.state=='invalid':QMessageBox.warning(self,'Phone',p.note);return
        with self.db.conn:
            self.db.conn.execute('INSERT OR IGNORE INTO apple_phone_candidates(email,phone_key,original,normalized,extension,quality,note) VALUES(?,?,?,?,?,?,?)',(alias.currentText(),p.comparison,p.original,p.normalized,p.extension,p.state,p.note))
            pid=self.db.conn.execute('SELECT id FROM apple_phone_candidates WHERE email=? AND phone_key=?',(alias.currentText(),p.comparison)).fetchone()[0]
            self.db.conn.execute('INSERT OR IGNORE INTO apple_phone_sources(candidate_id,file_hash,filename,record_path,field_path,order_number,original,imported_at) VALUES(?,?,?,?,?,?,?,?)',
                (pid,'manual-'+str(self.oid),'Manual entry',f'order[{self.oid}]','phone',row['order_number'],p.original,utc_now()))
        self.refresh()
    def reset(self):
        r=selected_record(self.table,self.model);cid=self.account.currentData()
        if r and cid:
            if QMessageBox.question(self,'Reset attempt','Clear this candidate result for this order/account only? It will become untried, not verified.')==QMessageBox.Yes:
                self.store.record_phone_result(self.oid,r['id'],cid,'Untried');self.refresh()


    def copy_phone(self):
        record=selected_record(self.table,self.model)
        if record:QApplication.clipboard().setText(record['original'])

class AppleDetailSection(QWidget):
    def __init__(self,db,oid,parent=None):
        super().__init__(parent);self.db=db;self.oid=oid;lay=QVBoxLayout(self);lay.setContentsMargins(0,0,0,0)
        self.button=QPushButton('Apple account details / phone provenance');self.button.clicked.connect(self.open);lay.addWidget(self.button)
        self.items_button=QPushButton('View Apple items and eligibility');self.items_button.clicked.connect(self.show_items);lay.addWidget(self.items_button)
        self.label=QLabel();self.label.setWordWrap(True);self.label.setTextInteractionFlags(Qt.TextSelectableByMouse);lay.addWidget(self.label)
        self.timer=QTimer(self);self.timer.setInterval(2000);self.timer.timeout.connect(self.refresh);self.refresh()
    def showEvent(self,event):
        super().showEvent(event)
        self.refresh();self.timer.start()
    def hideEvent(self,event):
        # QDialog.close()/reject() hide their children without destroying them.
        # A hidden details panel must not keep querying its owner's database.
        self.timer.stop()
        super().hideEvent(event)
    def refresh(self):
        row=self.db.order_by_id(self.oid)
        if not row:return
        s=AppleStore(self.db);cid=row['linked_apple_connection'] or row['account_status_connection'];c=s.connection(cid) if cid else None
        self.label.setText(f"Apple Account: {c['email'] if c else 'Not confirmed'} | Association: {row['association_state'] or 'Not associated'}\n"
            f"Apple reported: {row['account_raw_status'] or 'No authenticated observation'} | Success: {row['account_status_success_at'] or 'Never'}\n"
            f"Latest attempt: {row['account_status_attempt_at'] or 'Never'} | Attention: {row['account_status_error'] or 'None'}")
    def show_items(self):
        row=self.db.order_by_id(self.oid)
        if not row:return
        items=json.loads(row['account_items_json'] or '[]')
        d=QDialog(self);d.setWindowTitle('Apple item observations');d.resize(980,460);lay=QVBoxLayout(d)
        note=QLabel('Last successful authenticated observation. Missing fields remain unknown; estimates are not fulfillment guarantees.');note.setWordWrap(True);lay.addWidget(note)
        model=RecordModel([('item','Apple item'),('qty','Units'),('raw_status','Apple wording'),('status','Mapped status'),('cancel_eligible','Cancel offered'),('id','Item identity')],items,d)
        table=table_for(model);table.setColumnWidth(0,260);lay.addWidget(table)
        buttons=QDialogButtonBox(QDialogButtonBox.Close);buttons.rejected.connect(d.reject);lay.addWidget(buttons);d.exec()
    def open(self):PhoneDialog(self.db,self.oid,self).exec()


def phone_summary(db,row):
    store=AppleStore(db);cid=row['linked_apple_connection'] or row['account_status_connection'] or ''
    phones=store.phone_candidates(row,cid)
    if not phones:return 'No matching phone number found'
    return '\n'.join(p['original']+' - '+p['verification']+(' ('+p['quality']+')' if p['quality']!='valid' else '') for p in phones)


class AppleWorkspace(QWidget):
    changed=Signal()
    def __init__(self,owner):
        super().__init__(owner);self.owner=owner;self.db=owner.db;self.store=AppleStore(self.db);self.worker=None;self.importer=None;self.offset=0;self.active_job='';self._refreshing=False
        self.vault=SecretVault(self.db.path.parent)
        outer=QVBoxLayout(self);outer.setContentsMargins(30,24,30,20);outer.setSpacing(12)
        title=QLabel('Apple Account');title.setObjectName('pageTitle');outer.addWidget(title)
        note=QLabel('Connect securely, map exact-alias phones, and manage confirmed order jobs. Manual overrides stay highest priority.');note.setWordWrap(True);note.setObjectName('muted');outer.addWidget(note)
        self.banner=QLabel('Browser-assisted Apple workflow. No Apple actions run until you connect and queue a batch.');self.banner.setWordWrap(True);outer.addWidget(self.banner)
        self.tabs=QTabWidget();outer.addWidget(self.tabs,1);self._accounts_page();self._profiles_page();self._jobs_page();self._routes_page()
        self.timer=QTimer(self);self.timer.setInterval(2000);self.timer.timeout.connect(self._tick);self.timer.start();self.refresh()
    def ensure_worker(self):
        if self.worker is None or not self.worker.isRunning():
            self.worker=BrowserWorker(self.owner);self.worker.update.connect(self._event);self.worker.start()
        return self.worker
    def stopping(self):
        self.timer.stop()
        busy=bool(getattr(self,'route_worker',None) and self.route_worker.isRunning())
        if self.importer and self.importer.isRunning():self.importer.stop_requested=True;busy=True
        if self.worker and self.worker.isRunning():self.worker.request_stop();busy=True
        return busy
    def _event(self,event,data):
        if data.get('message'):self.banner.setText(data['message'])
        if event in ('changed','state','error'):
            self.refresh()
            if event=='changed':self.changed.emit()
    def _tick(self):
        if self.isVisible():self.refresh_jobs()
    def _accounts_page(self):
        page=QWidget();lay=QVBoxLayout(page);self.tabs.addTab(page,'Connection')
        row=QHBoxLayout();self.account=QComboBox();self.account.setMinimumWidth(430);row.addWidget(self.account,1)
        add=QPushButton('Add Apple Account');add.clicked.connect(self.add_account);row.addWidget(add);lay.addLayout(row)
        form=QFormLayout();self.browser=QComboBox();self.browser.addItems(['Edge','Chrome','Brave']);self.route=QComboBox();self.route.addItem('Direct (no proxy)','')
        form.addRow('Browser (dedicated app session)',self.browser);form.addRow('Stable network route',self.route)
        self.pace=QSpinBox();self.pace.setRange(5,600);self.pace.setValue(12);self.pace.setSuffix(' seconds between Apple jobs');form.addRow('Pacing - one shared Apple worker',self.pace)
        self.auto=QCheckBox('Refresh linked active orders in the background');self.interval=QSpinBox();self.interval.setRange(15,1440);self.interval.setValue(60);self.interval.setSuffix(' minutes')
        form.addRow(self.auto);form.addRow('Background interval (opt-in)',self.interval);lay.addLayout(form)
        controls=QHBoxLayout()
        for text,cmd in [('Open Sign-in / Reconnect','connect'),('Verify Sign-in','verify'),('Confirm Account Identity','confirm'),('Disconnect','disconnect'),('Sign Out / Forget','signout')]:
            button=QPushButton(text);button.clicked.connect(lambda _,c=cmd:self.connection_action(c));controls.addWidget(button)
        lay.addLayout(controls);self.connection_info=QLabel();self.connection_info.setWordWrap(True);lay.addWidget(self.connection_info)
        security=QLabel('Passwords, passkeys, two-factor codes and payment details stay on Apple\'s browser page.\nWindows saves Apple cookies and proxy credentials with user-bound DPAPI encryption. Only cookies are retained; no browser history or localStorage is imported.\nBrave is experimental: select Edge or Chrome if it cannot open. Apple may still require verification. No bypass or route rotation is performed.')
        security.setWordWrap(True);security.setObjectName('muted');lay.addWidget(security);lay.addStretch(1)
        self.account.currentIndexChanged.connect(self.account_changed);self.auto.toggled.connect(self.save_preferences);self.interval.valueChanged.connect(self.save_preferences)
    def _profiles_page(self):
        page=QWidget();lay=QVBoxLayout(page);self.tabs.addTab(page,'Phone mappings')
        row=QHBoxLayout();btn=QPushButton('Import JSON files');btn.setObjectName('primaryButton');btn.clicked.connect(lambda:self.import_profiles(False));row.addWidget(btn)
        custom=QPushButton('Import with field mapping');custom.clicked.connect(lambda:self.import_profiles(True));row.addWidget(custom)
        inspect=QPushButton('View selected sources');inspect.clicked.connect(self.inspect_profile);row.addWidget(inspect);row.addStretch(1);lay.addLayout(row)
        label=QLabel('Imported: exact email, phone, country context, optional order reference and provenance only. Payment objects are ignored. Equivalent formats deduplicate; plus aliases and order-specific verification remain distinct.');label.setWordWrap(True);lay.addWidget(label)
        self.phone_search=QLineEdit();self.phone_search.setPlaceholderText('Filter by complete alias or phone');self.phone_search.textChanged.connect(self.refresh_phones);lay.addWidget(self.phone_search)
        self.phone_model=RecordModel([('email','Exact alias'),('original','Original phone'),('normalized','Normalized phone'),('quality','Validity'),('sources','Sources')]);self.phone_table=table_for(self.phone_model);self.phone_table.setColumnWidth(0,320);lay.addWidget(self.phone_table,1)
        self.import_summary=QLabel('No import in this session. Showing up to 500 matching candidates; narrow the search for larger sets.');self.import_summary.setWordWrap(True);lay.addWidget(self.import_summary)
    def _jobs_page(self):
        page=QWidget();lay=QVBoxLayout(page);self.tabs.addTab(page,'Jobs & results')
        label=QLabel('Use Apple Actions beside the selection controls on Orders / Order Dates / either Tracking page. Targets are frozen at confirmation.');label.setWordWrap(True);lay.addWidget(label)
        self.jobs_model=RecordModel([('action','Action'),('email','Apple Account'),('state','Job state'),('done','Confirmed'),('total','Targets'),('attention','Needs attention'),('created_at','Created')]);self.jobs_table=table_for(self.jobs_model);self.jobs_table.setMaximumHeight(220);lay.addWidget(self.jobs_table)
        self.jobs_table.clicked.connect(self.job_selected)
        controls=QHBoxLayout()
        for name,cmd in [('Pause','pause'),('Resume','resume'),('Stop Job','stop'),('Retry eligible failures','retry')]:
            b=QPushButton(name);b.clicked.connect(lambda _,c=cmd:self.control(c));controls.addWidget(b)
        export=QPushButton('Export sanitized results');export.clicked.connect(self.export_job);controls.addWidget(export);lay.addLayout(controls)
        filters=QHBoxLayout();self.state_filter=QComboBox();self.state_filter.addItems(['All','attention','queued','running','awaiting_verification','needs_phone_data','cooling_down','uncertain','succeeded','associated','ineligible','declined','failed']);self.state_filter.currentTextChanged.connect(lambda:self.refresh_tasks(True));filters.addWidget(self.state_filter)
        prev=QPushButton('Previous 250');nxt=QPushButton('Next 250');prev.clicked.connect(lambda:self.page_tasks(-250));nxt.clicked.connect(lambda:self.page_tasks(250));filters.addWidget(prev);filters.addWidget(nxt);self.page_label=QLabel();filters.addWidget(self.page_label);filters.addStretch(1);lay.addLayout(filters)
        self.tasks_model=RecordModel([('id','Task'),('order_number','Order #'),('state','Outcome'),('attempts','Attempts'),('retry_display','Next eligible'),('message','Details')]);self.tasks_table=table_for(self.tasks_model);self.tasks_table.setColumnWidth(5,550);lay.addWidget(self.tasks_table,1)
        act=QHBoxLayout();open_btn=QPushButton('Show Apple browser');go=QPushButton('Continue / Re-read Apple');open_btn.clicked.connect(self.focus_task);go.clicked.connect(self.continue_task);act.addWidget(open_btn);act.addWidget(go);act.addStretch(1);lay.addLayout(act)
        caution=QLabel('Continue reconciles the current Apple page. It never repeats an uncertain cancellation or payment submission automatically. A decline requires a newly reviewed batch after correction.');caution.setWordWrap(True);lay.addWidget(caution)
    def _routes_page(self):
        page=QWidget();lay=QVBoxLayout(page);self.tabs.addTab(page,'Network routes')
        label=QLabel('Optional proxies: one stable route per session. Apple throttling pauses requests; it never clears cookies or switches proxies. Changing a route requires disconnecting and waiting out any cooldown.');label.setWordWrap(True);lay.addWidget(label)
        self.proxy_text=QPlainTextEdit();self.proxy_text.setPlaceholderText('One per line: http://host:port or http://user:password@host:port\nAlso accepts host:port:user:password. IPv6 requires URL form.');self.proxy_text.setMaximumHeight(140);lay.addWidget(self.proxy_text)
        controls=QHBoxLayout();save=QPushButton('Import routes');save.clicked.connect(self.import_routes);file_btn=QPushButton('Load proxy list');file_btn.clicked.connect(self.load_routes);test=QPushButton('Test selected connection');test.clicked.connect(self.test_route);controls.addWidget(save);controls.addWidget(file_btn);controls.addWidget(test);controls.addStretch(1);lay.addLayout(controls)
        self.routes_model=RecordModel([('server','Route (credentials hidden)'),('has_auth','Authentication'),('state','Connection health'),('last_check','Last check'),('message','Notes')]);self.routes_table=table_for(self.routes_model);self.routes_table.setColumnWidth(0,330);lay.addWidget(self.routes_table,1)
    def refresh(self):
        self._refreshing=True
        try:
            cid=self.account.currentData();self.account.blockSignals(True);self.account.clear()
            for c in self.store.connections():self.account.addItem(c['email']+' - '+c['state'],c['id'])
            i=self.account.findData(cid);self.account.setCurrentIndex(max(0,i));self.account.blockSignals(False)
            rid=self.route.currentData();self.route.clear();self.route.addItem('Direct (no proxy)','')
            routes=[dict(r) for r in self.db.conn.execute('SELECT * FROM apple_routes ORDER BY server')]
            for r in routes:self.route.addItem(r['server'],r['id'])
            self.route.setCurrentIndex(max(0,self.route.findData(rid)));self.routes_model.set_rows(routes)
            self.account_changed();self.refresh_phones();self.refresh_jobs()
        finally:self._refreshing=False
    def account_changed(self):
        c=self.store.connection(self.account.currentData())
        if not c:self.connection_info.setText('Add the intended Apple Account. This is separate from Gmail and order aliases.');return
        self._refreshing=True
        self.browser.setCurrentText(c['browser']);self.route.setCurrentIndex(max(0,self.route.findData(c['route_id'])));self.auto.setChecked(bool(c['auto_refresh']));self.interval.setValue(c['refresh_minutes']);self._refreshing=False
        self.connection_info.setText(f"Expected: {c['email']}\nState: {c['state']} | Identity evidence: {c['identity_method'] or 'Not verified'}\nLast authentication: {c['last_auth_at'] or 'Never'} | Latest check: {c['last_check_at'] or 'Never'}\n{c['reason']}")
    def add_account(self):
        email,ok=QInputDialog.getText(self,'Connect Apple Account','Expected Apple Account email (not the guest-order alias):')
        if not ok:return
        try:cid=self.store.add_connection(email,self.browser.currentText(),self.route.currentData() or '')
        except ValueError as e:QMessageBox.warning(self,'Apple Account',str(e));return
        self.refresh();self.account.setCurrentIndex(self.account.findData(cid))
    def save_preferences(self):
        if self._refreshing:return
        cid=self.account.currentData()
        if cid:
            with self.db.conn:self.db.conn.execute('UPDATE apple_connections SET auto_refresh=?,refresh_minutes=? WHERE id=?',(int(self.auto.isChecked()),self.interval.value(),cid))
    def connection_action(self,command):
        cid=self.account.currentData();c=self.store.connection(cid)
        if not c:self.banner.setText('Add/select an Apple Account first.');return
        if command=='connect':
            if c['next_at']>time.time():self.banner.setText('Apple cooldown is still active. Reconnecting cannot bypass it.');return
            changed=(c['browser']!=self.browser.currentText() or c['route_id']!=(self.route.currentData() or ''))
            if changed and c['state'] not in ('disconnected','browser_missing'):
                self.banner.setText('Disconnect before changing the browser or stable route.');return
            with self.db.conn:self.db.conn.execute('UPDATE apple_connections SET browser=?,route_id=? WHERE id=?',(self.browser.currentText(),self.route.currentData() or '',cid))
        confirmed=False
        if command=='confirm':
            confirmed=QMessageBox.question(self,'Confirm visible Apple identity',f"Have you checked inside the dedicated browser that the signed-in account is exactly {c['email']}?\n\nThis records USER-confirmed identity, not a remotely verified account email.")==QMessageBox.Yes
            if not confirmed:return
            command='verify'
        if command=='signout' and QMessageBox.question(self,'Forget app session','Close this app browser and delete its protected saved session? Other normal-browser sessions are unaffected.')!=QMessageBox.Yes:return
        worker=self.ensure_worker();worker.send('pace',seconds=self.pace.value());worker.send(command,connection_id=cid,identity_confirmed=confirmed)
        self.banner.setText('Working in the dedicated Apple browser...')
    def import_profiles(self,custom):
        if self.importer and self.importer.isRunning():self.banner.setText('A profile import is already running.');return
        files,_=QFileDialog.getOpenFileNames(self,'Import profile JSON','','JSON files (*.json);;All files (*)')
        if not files:return
        mapping=None
        if custom:
            dialog=MappingDialog(files[0],self)
            if dialog.exec()!=QDialog.Accepted:return
            mapping=dialog.mapping()
        self.importer=ImportWorker(type(self.db),self.db.path,files,mapping,self)
        self.importer.progress.connect(lambda r:self.import_summary.setText(f"{r.get('files',0)} files | {r.get('records',0):,} records | {r.get('new_candidates',0):,} new candidates"))
        self.importer.done.connect(self.import_done);self.importer.start()
    def import_done(self,r):
        self.import_summary.setText(' | '.join(f'{k}: {r.get(k,0):,}' for k in ('files','records','accepted','new_candidates','duplicates','invalid','unmatched_aliases')))
        self.refresh_phones();self.changed.emit()
        if r.get('errors'):
            box=QMessageBox(self);box.setWindowTitle('Profile import results');box.setText('Valid records were kept. Some files/records need attention; use Import with field mapping for unfamiliar schemas.');box.setDetailedText('\n'.join(r['errors']));box.exec()
    def refresh_phones(self):
        text=self.phone_search.text().strip() if hasattr(self,'phone_search') else ''
        rows=self.db.conn.execute('''SELECT p.*,(SELECT COUNT(*) FROM apple_phone_sources s WHERE s.candidate_id=p.id) AS sources FROM apple_phone_candidates p
            WHERE email LIKE ? ESCAPE '\\' OR normalized LIKE ? ESCAPE '\\' ORDER BY p.id DESC LIMIT 500''',('%'+text.replace('\\','\\\\').replace('%','\\%').replace('_','\\_')+'%',)*2).fetchall()
        self.phone_model.set_rows([dict(r) for r in rows])
    def inspect_profile(self):
        r=selected_record(self.phone_table,self.phone_model)
        if not r:return
        d=QDialog(self);d.setWindowTitle('Candidate sources');lay=QVBoxLayout(d);v=QPlainTextEdit('\n'.join(f"{s['filename']} {s['record_path']}.{s['field_path']} | Order hint: {s['order_number'] or 'none'}" for s in self.store.phone_sources(r['id'])));v.setReadOnly(True);lay.addWidget(v);d.resize(850,300);d.exec()
    def queue_batch(self,ids,action):
        if not self.store.connections():self.owner.show_page(self.owner.PAGE_APPLE,self.owner.apple_nav);self.banner.setText('Add your intended Apple Account before preparing a batch.');return
        d=PreviewDialog(self.store,ids,action,self)
        if d.exec()!=QDialog.Accepted:return
        try:jid=self.store.create_job(d.data,confirmed=action!='refresh',priority=5 if action=='refresh' else 10)
        except ValueError as e:QMessageBox.warning(self,'Apple job',str(e));return
        self.active_job=jid;self.offset=0;self.ensure_worker().send('wake');self.owner.show_page(self.owner.PAGE_APPLE,self.owner.apple_nav);self.tabs.setCurrentIndex(2);self.refresh_jobs()
        self.banner.setText('Batch queued. Connect and verify the chosen account to start. Final cancellation/payment submissions are performed in Apple\'s visible browser.')
    def refresh_jobs(self):
        self.jobs_model.set_rows(self.store.jobs())
        for i,r in enumerate(self.jobs_model.rows):
            if r['id']==self.active_job:self.jobs_table.selectRow(i);break
        self.refresh_tasks(False)
    def job_selected(self,index):
        r=selected_record(self.jobs_table,self.jobs_model)
        if r:self.active_job=r['id'];self.offset=0;self.refresh_tasks(False)
    def refresh_tasks(self,reset=False):
        if reset:self.offset=0
        task=selected_record(self.tasks_table,self.tasks_model);tid=task['id'] if task else None
        filt=self.state_filter.currentText();rows=self.store.tasks(self.active_job,'' if filt=='All' else filt,250,self.offset) if self.active_job else []
        for r in rows:r['retry_display']=time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(r['next_at'])) if r['next_at'] else ''
        self.tasks_model.set_rows(rows)
        for i,r in enumerate(rows):
            if r['id']==tid:self.tasks_table.selectRow(i);break
        self.page_label.setText(f'{self.offset+1}-{self.offset+len(rows)}' if rows else 'No tasks on this page')
    def page_tasks(self,delta):self.offset=max(0,self.offset+delta);self.refresh_tasks(False)
    def control(self,cmd):
        if not self.active_job:return
        if cmd=='stop':
            if QMessageBox.question(self,'Stop Job','Stop unfinished tasks? Completed Apple actions are NOT reversed. Uncertain actions remain marked uncertain.')!=QMessageBox.Yes:return
            self.ensure_worker().send('stop_job',job_id=self.active_job)
        else:self.store.job_control(self.active_job,cmd);self.ensure_worker().send('wake')
        self.refresh_jobs()
    def focus_task(self):
        t=selected_record(self.tasks_table,self.tasks_model)
        if t:self.ensure_worker().send('focus',connection_id=t['connection_id'],task_id=t['id'])
    def continue_task(self):
        t=selected_record(self.tasks_table,self.tasks_model)
        if t:self.ensure_worker().send('continue',task_id=t['id'])
    def export_job(self):
        if not self.active_job:return
        path,_=QFileDialog.getSaveFileName(self,'Export Apple job results','apple_job_results.csv','CSV (*.csv)')
        if path:self.store.export_job(self.active_job,path)
    def import_routes(self):
        errors=[];added=0
        for n,line in enumerate(self.proxy_text.toPlainText().splitlines(),1):
            if not line.strip():continue
            try:
                p=parse_proxy(line);old=self.db.conn.execute('SELECT id FROM apple_routes WHERE server=?',(p['server'],)).fetchone();rid=old[0] if old else uuid.uuid4().hex
                self.vault.put('route-'+rid,p)
                with self.db.conn:self.db.conn.execute('INSERT INTO apple_routes(id,server,has_auth) VALUES(?,?,?) ON CONFLICT(server) DO UPDATE SET has_auth=excluded.has_auth',(rid,p['server'],int(bool(p['username']))))
                added+=1
            except Exception as e:errors.append(f'Line {n}: '+(safe_message(str(e)) if isinstance(e,ValueError) else type(e).__name__))
        self.proxy_text.clear();self.refresh();self.banner.setText(f'{added} routes accepted. '+ '; '.join(errors[:6]))
    def load_routes(self):
        path,_=QFileDialog.getOpenFileName(self,'Load proxy list','','Text files (*.txt)')
        if path:
            try:
                if Path(path).stat().st_size>2*1024*1024:raise ValueError('Proxy list exceeds 2 MiB; split the list')
                self.proxy_text.setPlainText(Path(path).read_text(encoding='utf-8-sig'))
            except Exception:self.banner.setText('Could not load proxy list')
    def test_route(self):
        if getattr(self,'route_worker',None) and self.route_worker.isRunning():return
        r=selected_record(self.routes_table,self.routes_model)
        if not r:return
        # TCP health is not falsely presented as an authenticated proxy-routing test.
        p=parse_proxy(r['server']);worker=RouteTestWorker(p,self);self.route_worker=worker
        worker.done.connect(lambda ok:self.route_result(r['id'],ok));worker.start()
    def route_result(self,rid,ok):
        with self.db.conn:self.db.conn.execute('UPDATE apple_routes SET state=?,last_check=?,message=? WHERE id=?',('TCP reachable' if ok else 'Unreachable',utc_now(),'TCP only; actual proxy authentication/routing is checked when the Apple browser connects.',rid))
        self.refresh()


class RouteTestWorker(QThread):
    done=Signal(bool)
    def __init__(self,proxy,parent=None):super().__init__(parent);self.proxy=proxy
    def run(self):
        try:
            with socket.create_connection((self.proxy['host'],self.proxy['port']),timeout=5):pass
            self.done.emit(True)
        except OSError:self.done.emit(False)


def actions_button(owner,model):
    button=QPushButton('Apple Actions');button.setToolTip('Account association, authenticated refresh, cancellation and payment jobs')
    def show():
        menu=QMenu(button);ids=list(model.checked_order_ids())
        for label,action in [('Link selected to Apple Account','associate'),('Refresh selected from Apple','refresh'),('Cancel selected on Apple...','cancel'),('Update payment for selected...','payment')]:
            item=menu.addAction(label);item.setEnabled(bool(ids));item.triggered.connect(lambda _,a=action,targets=ids:owner.apple_page.queue_batch(targets,a))
        menu.addSeparator();all_item=menu.addAction(f'Refresh all {len(model.rows):,} filtered orders...');all_item.setEnabled(bool(model.rows))
        all_item.triggered.connect(lambda:owner.apple_page.queue_batch([int(r['id']) for r in model.rows],'refresh'))
        menu.exec(button.mapToGlobal(button.rect().bottomLeft()))
    button.clicked.connect(show);return button
