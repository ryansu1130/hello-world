"""Visible, conservative adapter for Apple's customer-facing web workflow.

No private endpoint, CAPTCHA bypass, cookie import from normal browsers, stealth,
proxy rotation, or raw-card automation. Unsupported/ambiguous pages hand control
to the user. Browser text is transient; only structured observations leave here.
"""
from __future__ import annotations
import hashlib
import json
import os
import re
import time
from pathlib import Path
from urllib.parse import urlsplit
from apple_accounts import safe_message
from apple_profiles import email_key

ORDER_LIST = 'https://secure.store.apple.com/shop/order/list'
ACCOUNT_HOME = 'https://secure.store.apple.com/shop/account/home'

class AppleFlowError(RuntimeError):
    def __init__(self,code,message,retry_after=0):
        super().__init__(message);self.code=code;self.retry_after=retry_after


def apple_host(url):
    try:p=urlsplit(url);host=(p.hostname or '').lower();return p.scheme=='https' and (host=='apple.com' or host.endswith('.apple.com')) and not p.username
    except ValueError:return False


def installed_browser(choice):
    relative={'Brave':'BraveSoftware/Brave-Browser/Application/brave.exe',
              'Edge':'Microsoft/Edge/Application/msedge.exe','Chrome':'Google/Chrome/Application/chrome.exe'}
    if choice not in relative:raise AppleFlowError('browser_missing','Choose Edge, Chrome or Brave')
    if os.name=='nt':
        roots=[os.environ.get(k,'') for k in ('PROGRAMFILES','PROGRAMFILES(X86)','LOCALAPPDATA')]
        for root in roots:
            path=Path(root)/relative[choice]
            if root and path.exists():return str(path)
    else:
        import shutil
        names={'Brave':['brave-browser','brave'],'Edge':['microsoft-edge'],'Chrome':['google-chrome','chromium','chromium-browser']}
        for n in names[choice]:
            p=shutil.which(n)
            if p:return p
    raise AppleFlowError('browser_missing',f'{choice} was not found. Install it or select another installed browser. Brave compatibility is not guaranteed.')


SNAPSHOT_JS = r'''() => {
 const visible=e=>!!(e && e.getClientRects().length && getComputedStyle(e).visibility!=='hidden');
 const txt=e=>(e.innerText||e.textContent||'').replace(/\s+/g,' ').trim();
 const headings=[...document.querySelectorAll('h1,h2,h3,h4,[role="status"],[aria-current="step"]')]
   .filter(visible).filter(e=>!e.closest('nav,footer,[role="navigation"]')).map(txt).filter(Boolean);
 const controls=[...document.querySelectorAll('button,a,[role="button"]')].filter(visible).map(e=>({text:txt(e),href:e.tagName==='A'?e.href:''}));
 const signs=controls.some(e=>/^(sign out|log out)$/i.test(e.text));
 const identities=[...document.querySelectorAll('[data-autom*="accountEmail"],[data-autom*="appleId"],[data-autom*="appleID"],#account-email,[aria-label="Apple Account"]')].filter(visible).map(txt);
 const rawItems=[...document.querySelectorAll('[data-item-id],[data-order-item-id],.order-item,.orderItem,.rs-order-product,.rs-order-item')].filter(visible);
 const nodes=rawItems.filter(e=>!rawItems.some(other=>other!==e && e.contains(other)));
 const items=nodes.map((e,i)=>({id:e.getAttribute('data-item-id')||e.getAttribute('data-order-item-id')||'',
   text:txt(e).slice(0,12000), headings:[...e.querySelectorAll('h2,h3,h4,[role="status"],[aria-current="step"]')].filter(visible).map(txt),
   cancel:[...e.querySelectorAll('button,a')].filter(visible).some(b=>/^cancel (item|order)$/i.test(txt(b)))}));
 const payRegions=[...document.querySelectorAll('[data-autom*="paymentSummary"],[data-autom*="paymentMethod"],.payment-summary')].filter(visible).map(txt);
 const payMatch=payRegions.join(' ').match(/(?:ending in|[*\u2022]{2,})\s*(\d{4})(?!\d)/i);
 const statusLabels=[...document.querySelectorAll('[data-autom*="statusLabel"],[data-autom*="statusDescription"],[data-autom*="orderStatus"],[class*="current-status"],[class*="status-description"]')]
   .filter(visible).filter(e=>!e.closest('nav,footer,[role="progressbar"]')).map(txt).filter(s=>s.length<240);
 // Never read form values (passwords, PAN, CVV, verification codes).
 return {payment_last4:payMatch?payMatch[1]:'',url:location.href,text:(document.body.innerText||'').slice(0,250000),headings,statusLabels,items,controls,
   identities,signed_in:signs,auth_prompt:([...document.querySelectorAll('input[autocomplete="one-time-code"],input[name*="securityCode"],input[id*="security-code"]')].some(visible)||headings.some(t=>/two.factor authentication|verification code|approve sign.in|use a passkey/i.test(t))),password_prompt:[...document.querySelectorAll('input[type=password]')].some(visible),
   phone_prompt:[...document.querySelectorAll('input[type=tel]')].some(visible),
   has_more:controls.some(c=>/^(show|view|load) (more|all)/i.test(c.text)),
   order_links:controls.filter(c=>/\/order\/|\/vieworder\//i.test(c.href)).map(c=>c.href)};
}'''

STATUS_PATTERNS = (
 ('Canceled',r'^(?:pickup )?cancel(?:l)?ed(?:\s|$)|your (?:order|item) (?:has been|was|is) cancel(?:l)?ed'),
 ('Picked Up',r'^picked up(?:\s+(?:on )?(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec|\d)|$)|your item has been picked up'),
 ('Delivered',r'^delivered(?:\s+(?:on )?(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec|\d)|$)|your (?:package|item|order) has been delivered'),
 ('Ready for Pickup',r'^ready for (?:pickup|pick up)$|your item is ready (?:to be picked up|for pickup)'),
 ('Preparing to Ship',r'^preparing to ship$'),('Shipping to Store',r'^shipping to store$'),
 ('Check in Today',r'^check in today$'),('Shipped',r'^shipped(?:\s+(?:on )?(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec|\d)|$)|your item is on the way'),
 ('Action Required',r'^(?:action required|payment action required|update your payment|payment declined)$'),
 ('Processing',r'^processing$'),('Order Placed',r'^order placed$'),('Refunded',r'^refunded$'),
)

def normalize_state(value):
    t=re.sub(r'\s+',' ',str(value or '')).strip()
    for state,pattern in STATUS_PATTERNS:
        if re.search(pattern,t,re.I):return state
    return ''


def aggregate_item_states(states):
    states=list(states)
    if not states:return 'Apple Update'
    unique=set(states)
    if '' in unique or 'Apple Update' in unique:return 'Apple Update'
    if len(unique)==1:return states[0]
    if 'Canceled' in unique:return 'Partially Canceled'
    if unique<= {'Delivered','Shipped','Processing','Preparing to Ship','Order Placed'}:
        return 'Partially Delivered' if 'Delivered' in unique else 'Partially Shipped'
    return 'Mixed Shipments'


def parse_snapshot(snap,expected,authenticated=False):
    if not apple_host(snap.get('url','')):raise AppleFlowError('unexpected_origin','Browser left the supported Apple website. Review it manually.')
    text=snap.get('text','')
    # URL alone is insufficient: a generic login/help page can retain the order URL.
    url_order=re.search(r'/(?:vieworder|guest|order/detail)/(W\d+)(?:/|$)',urlsplit(snap.get('url','')).path,re.I)
    if url_order and url_order.group(1).upper()!=expected.upper():raise AppleFlowError('order_mismatch','The Apple URL identifies a different order')
    if not re.search(r'\b'+re.escape(expected)+r'\b',text):raise AppleFlowError('order_mismatch','The page does not identify the requested order')
    if snap.get('password_prompt') or snap.get('auth_prompt'):raise AppleFlowError('auth_required','Apple sign-in or verification is required')
    if re.search(r'(too many (?:requests|attempts)|try again (?:in|later)|temporarily (?:blocked|unavailable))',text,re.I):
        raise AppleFlowError('throttled','Apple asks you to wait. The queue will cool down without changing routes.',300)
    if re.search(r'(associated with|added to|linked to) (?:a different|another) Apple (?:Account|ID)',text,re.I):
        raise AppleFlowError('another_account','Apple reports this order belongs to another account')
    if not authenticated:raise AppleFlowError('auth_required','An authenticated, identity-bound Apple session is required')
    statuses=[];raws=[]
    # Progress bars contain future steps. Only current status labels/headings or
    # explicit completed-action sentences count, never generic body keywords.
    for value in snap.get('statusLabels',[])+snap.get('headings',[]):
        state=normalize_state(value)
        if state and state not in statuses:statuses.append(state);raws.append(value)
    for match in re.finditer(r'Your (?:order|item|package) (?:has been (?:picked up|delivered|cancelled|canceled)|is ready for pickup)[^.\n]*',text,re.I):
        state=normalize_state(match.group())
        if state and state not in statuses:statuses.append(state);raws.append(match.group())
    items=[]
    for index,node in enumerate(snap.get('items') or []):
        item_text=node.get('text','');raw='';state=''
        for label in node.get('headings',[]):
            st=normalize_state(label)
            if st:state=st;raw=label;break
        if not state:
            for sentence in re.findall(r'Your (?:item|package) (?:has been|is ready)[^.\n]*',item_text,re.I):
                st=normalize_state(sentence)
                if st:state=st;raw=sentence;break
        name=next((h for h in node.get('headings',[]) if re.search(r'iPhone|iPad|Mac|AirPods|Watch|Apple Pencil|AirTag',h,re.I)), 'Apple item')
        qty=re.search(r'\b(?:Qty|Quantity)\s*:?\s*(\d{1,5})\b',item_text,re.I)
        stable=str(node.get('id') or '')
        items.append({'id':stable or 'dom-'+hashlib.sha256((name+str(index)).encode()).hexdigest()[:16],
                      'stable_id':bool(stable),'item':safe_message(name,200),'qty':int(qty.group(1)) if qty else None,
                      'raw_status':safe_message(raw,160),'status':state or 'Apple Update','cancel_eligible':bool(node.get('cancel'))})
    all_known=bool(items) and all(i['status']!='Apple Update' for i in items) and not snap.get('has_more')
    if items:
        normalized=aggregate_item_states(i['status'] for i in items) if all_known else 'Apple Update'
        raw=' | '.join(i['raw_status'] or 'Unmapped item status' for i in items)
    elif len(statuses)==1:
        normalized=statuses[0];raw=raws[0]
        # A generic completion heading in an unknown multi-item layout is not
        # enough to assert all items complete. A whole-order sentence is enough.
        whole=bool(re.search(r'Your order has been (?:delivered|cancelled|canceled)',text,re.I))
        if normalized in ('Delivered','Picked Up','Canceled') and not whole:
            # One clearly scoped product section as in Apple's standard detail
            # page can be read, but is marked not all-items-known for quantity.
            if len([h for h in snap.get('headings',[]) if normalize_state(h)])!=1:normalized='Apple Update'
    elif len(statuses)>1:
        normalized='Apple Update';raw=' | '.join(raws)
    else:
        labels=snap.get('statusLabels') or []
        if not labels:raise AppleFlowError('page_changed','No unambiguous current status region was found. Review the page; cached data is unchanged.')
        normalized='Apple Update';raw=' | '.join(labels)
    buttons=[c.get('text','') for c in snap.get('controls',[])]
    return {'authenticated':True,'order_number':expected,'status':normalized,'raw_status':safe_message(raw,240),
            'items':items,'all_items_known':all_known,
            'cancel_eligible':any(re.fullmatch(r'Cancel (?:Item|Order)',b,re.I) for b in buttons),
            'payment_eligible':any(re.fullmatch(r'(?:Update|Change|Edit) (?:Payment|Payment Method|Payment Information)',b,re.I) for b in buttons)}


class BrowserSession:
    def __init__(self,playwright,connection,vault,proxy=None):
        self.connection=connection;self.vault=vault;self.validated=False;self.identity_method='';self.observed_email=''
        self.rate_limit=0;self.response_error='';self.task_pages={}
        options={'headless':False,'executable_path':installed_browser(connection['browser'])}
        if proxy:options['proxy']={k:proxy[k] for k in ('server','username','password') if proxy.get(k)}
        self.browser=playwright.chromium.launch(**options)
        state=vault.get('session-'+connection['id'],{'cookies':[],'origins':[]})
        self.context=self.browser.new_context(storage_state=state,accept_downloads=False,viewport={'width':1280,'height':900})
        self.context.set_default_timeout(12000)
        self.context.set_default_navigation_timeout(45000)
        self.context.on('response',self._response)
        self.page=self.context.new_page();self.navigate(self.page,ORDER_LIST)
    def _response(self,response):
        if not apple_host(response.url):return
        if response.status==429:
            try:self.rate_limit=max(self.rate_limit,int(response.headers.get('retry-after','300')))
            except ValueError:
                from email.utils import parsedate_to_datetime
                from datetime import datetime,timezone
                try:delay=max(0,int((parsedate_to_datetime(response.headers.get('retry-after',''))-datetime.now(timezone.utc)).total_seconds()))
                except (ValueError,TypeError,OverflowError):delay=300
                self.rate_limit=max(self.rate_limit,delay)
        elif response.status in (401,403) and '/shop/' in response.url:self.response_error='auth_required' if response.status==401 else 'blocked'
    def navigate(self,page,url):
        if not apple_host(url):raise AppleFlowError('unsafe_url','The stored URL is not an HTTPS Apple order page')
        self.response_error='';self.rate_limit=0
        page.goto(url,wait_until='domcontentloaded')
        page.wait_for_timeout(900)
        if self.rate_limit:raise AppleFlowError('throttled','Apple returned a rate limit; queue cooling down',self.rate_limit)
    def snapshot(self,page):
        if self.response_error:
            raise AppleFlowError(self.response_error,'Apple returned an access or session error; cached data retained',300)
        if self.rate_limit:raise AppleFlowError('throttled','Apple returned a rate limit; queue cooling down',self.rate_limit)
        if not apple_host(page.url):raise AppleFlowError('unexpected_origin','Browser left the supported Apple site')
        return page.evaluate(SNAPSHOT_JS)
    def _signin_control(self,page):
        # Apple has used several labels for the customer account branch of the
        # order page. Click only a single visible, explicit Apple-account sign-in
        # control. Credentials/2FA remain entirely on Apple's page.
        patterns=(r'^Sign [Ii]n with (?:your )?Apple (?:Account|ID)$',
                  r'^Sign [Ii]n to (?:your )?Apple (?:Account|ID)$',
                  r'^Continue with (?:your )?Apple (?:Account|ID)$',
                  r'^Apple (?:Account|ID) Sign [Ii]n$')
        for pattern in patterns:
            node=self._unique_button(page,pattern)
            if node:return node
        return None
    def begin_sign_in(self):
        """Prepare the real Apple-account sign-in branch and report a UI state.

        This deliberately never fills credentials. It fixes the previous behavior
        where the app merely opened the guest "Find your order" page and then
        waited forever without selecting the Apple Account sign-in path.
        """
        self.page.bring_to_front();snap=self.snapshot(self.page)
        if self._account_view(snap):
            return 'checking_account','A saved Apple session is visible. Verifying the account now.'
        if snap.get('auth_prompt'):
            return 'waiting_verification','Complete Apple verification in the dedicated browser. The tracker will check automatically.'
        if snap.get('password_prompt'):
            return 'waiting_sign_in','Complete Apple sign-in in the dedicated browser. The tracker never reads your password.'
        control=self._signin_control(self.page)
        if control:
            control.click();self.page.wait_for_timeout(700);snap=self.snapshot(self.page)
            if snap.get('auth_prompt'):return 'waiting_verification','Complete Apple verification in the dedicated browser.'
            return 'waiting_sign_in','Apple Account sign-in is open in the dedicated browser. Complete sign-in and any verification.'
        # If Apple rendered only the guest-order branch, try the stable account
        # home route once. We never use or persist transient ssi query strings.
        if re.search(r'find your order|guest order',snap.get('text',''),re.I):
            try:
                self.navigate(self.page,ACCOUNT_HOME);snap=self.snapshot(self.page)
                if self._account_view(snap):return 'checking_account','A saved Apple session is visible. Verifying the account now.'
                control=self._signin_control(self.page)
                if control:
                    control.click();self.page.wait_for_timeout(700);snap=self.snapshot(self.page)
                    if snap.get('auth_prompt'):return 'waiting_verification','Complete Apple verification in the dedicated browser.'
                    return 'waiting_sign_in','Apple Account sign-in is open. Complete sign-in and any verification.'
            except AppleFlowError:
                raise
            except Exception:
                # A layout/navigation difference is a handoff, not a crash.
                pass
        return 'waiting_sign_in','In the dedicated Apple browser, choose the Apple Account sign-in option (not guest order lookup), then complete sign-in. The tracker will detect the session automatically.'
    def verify_identity(self,user_confirmed=False):
        # Never trust a guest page as authentication evidence. If a signed-in
        # account menu is visible on another Apple page, return to the order
        # listing before verifying identity and order access.
        snap=self.snapshot(self.page)
        if snap.get('password_prompt') or snap.get('auth_prompt'):
            self.validated=False
            raise AppleFlowError('auth_required','Complete Apple sign-in or verification in the dedicated browser; the tracker will check again automatically.')
        if not self._account_view(snap) and (snap.get('signed_in') or snap.get('identities')):
            self.navigate(self.page,ORDER_LIST);snap=self.snapshot(self.page)
        if not self._account_view(snap):
            self.validated=False
            if re.search(r'find your order|guest order',snap.get('text',''),re.I):
                raise AppleFlowError('auth_required','Apple is still showing guest-order lookup. Choose the Apple Account sign-in option in the dedicated browser and complete sign-in.')
            raise AppleFlowError('auth_required','Apple Account sign-in is not yet verified. Complete sign-in in the dedicated browser; no login is assumed from opening a page.')
        expected=self.connection['email'];seen=self._assert_identity(snap)
        if not seen and not user_confirmed:
            raise AppleFlowError('identity_confirmation','Apple does not expose the full account email in a recognized region. Check the account identity in the browser, then use Confirm Account Identity.')
        self.validated=True;self.identity_method='Apple page' if seen else 'User-confirmed identity + signed-in Apple listing'
        self.observed_email=expected if seen else ''
        self.save_session()
        return {'observed_email':self.observed_email,'method':self.identity_method}
    def _assert_identity(self,snap):
        from apple_profiles import aliases
        seen=[]
        for region in snap.get('identities',[]):seen+=aliases(region)
        if seen and self.connection['email'] not in seen:
            self.validated=False
            raise AppleFlowError('identity_mismatch','The visible Apple Account differs from this job destination. No order action was taken.')
        return seen
    def save_session(self):
        # Apple cookies only; origins/localStorage can contain unrelated data.
        cookies=[c for c in self.context.cookies() if (c.get('domain','').lstrip('.')=='apple.com' or c.get('domain','').endswith('.apple.com'))]
        self.vault.put('session-'+self.connection['id'],{'cookies':cookies,'origins':[]})
    def close(self,forget=False):
        if forget:self.vault.delete('session-'+self.connection['id'])
        elif self.validated:
            try:self.save_session()
            except Exception:pass
        self.browser.close();self.validated=False
    @staticmethod
    def _account_view(snap):
        if snap.get('password_prompt') or snap.get('auth_prompt'):return False
        if snap.get('signed_in'):return True
        if re.search(r'Sign in with your Apple (?:Account|ID)',snap.get('text',''),re.I):return False
        title=any(re.fullmatch(r'(Your Orders|Order Listing|Orders)',h,re.I) for h in snap.get('headings',[]))
        links=[u for u in snap.get('order_links',[]) if '/guest/' not in u]
        return bool(title and (links or re.search(r'(no orders|haven.t placed any orders|no recent orders)',snap.get('text',''),re.I)))
    def _linked_in_listing(self,number):
        if not self.validated:raise AppleFlowError('auth_required','Verify the connected Apple Account first')
        self.navigate(self.page,ORDER_LIST);snap=self.snapshot(self.page)
        if snap['password_prompt'] or snap.get('auth_prompt') or re.search(r'Sign in with your Apple (?:Account|ID)',snap['text'],re.I):
            self.validated=False;raise AppleFlowError('auth_required','Apple session expired. Sign in again.')
        # Never treat a guest URL alone as account association. The reference
        # must appear on a signed-in order list, not the order details page.
        self._assert_identity(snap)
        if not re.search(r'/shop/order/list/?$',urlsplit(snap['url']).path):
            raise AppleFlowError('auth_required','Apple did not return the account order listing; sign in again.')
        if not self._account_view(snap):
            raise AppleFlowError('auth_required','Open the account menu on the order listing so the signed-in state can be verified')
        return any(re.search(r'\b'+re.escape(number)+r'\b',link) for link in snap.get('order_links',[]))
    def _management_evidence(self,snap):
        controls=[c.get('text','') for c in snap.get('controls',[])]
        if not self.validated or snap.get('password_prompt') or snap.get('auth_prompt'):return False
        if any(re.search(r'Add to Apple|^Sign In$',t,re.I) for t in controls):return False
        return any(re.fullmatch(r'Cancel (?:Item|Order)|(?:Update|Change) Payment(?: Method| Information)?',t,re.I) for t in controls)
    def task_page(self,task,url,reuse=False):
        page=self.task_pages.get(task['id'])
        if page is None or page.is_closed():page=self.context.new_page();self.task_pages[task['id']]=page;reuse=False
        if not reuse:self.navigate(page,url)
        page.bring_to_front();return page
    def _unique_button(self,page,pattern):
        nodes=page.get_by_role('button',name=re.compile(pattern,re.I))
        matches=[nodes.nth(i) for i in range(nodes.count()) if nodes.nth(i).is_visible()]
        if not matches:
            nodes=page.get_by_role('link',name=re.compile(pattern,re.I));matches=[nodes.nth(i) for i in range(nodes.count()) if nodes.nth(i).is_visible()]
        return matches[0] if len(matches)==1 else None
    def read_order(self,task,row,url,reuse=False):
        if not self.validated:raise AppleFlowError('auth_required','Verify the destination account before running Apple jobs')
        linked=self._linked_in_listing(row['order_number'])
        known=(row['linked_apple_connection']==self.connection['id'] and row['association_state'] in ('associated','already_associated'))
        page=self.task_page(task,url,reuse);snap=self.snapshot(page)
        self._assert_identity(snap)
        if not linked and not known:
            raise AppleFlowError('needs_association','Order association is not proven by the signed-in Apple order listing. Order-page controls alone are not treated as account association.')
        if any(re.search(r'Add to Apple (?:Account|ID)',c['text'],re.I) for c in snap.get('controls',[])):
            raise AppleFlowError('needs_association','Apple still offers Add to Apple Account. Association is not confirmed.')
        observation=parse_snapshot(snap,row['order_number'],True)
        self._enrich(observation,snap,row)
        return page,snap,observation
    def _enrich(self,obs,snap,row):
        # Reuse the tracker's date/carrier parser for a narrowly labeled line,
        # not billing/payment fields. No hidden form values are examined.
        from dateutil import parser as dates
        from datetime import datetime
        text=snap['text'];labels={}
        raw=obs.get('raw_status','')
        match=re.search(r'^(?:Picked Up|Delivered|Cancel(?:l)?ed)\s+(?:on\s+)?([A-Za-z]{3,9}\s+\d{1,2}(?:,?\s+\d{4})?)$',raw,re.I)
        if match and hasattr(self,'eta_parser'):
            try:
                base=dates.parse(row['order_date']) if row['order_date'] else datetime.now()
                event,_=self.eta_parser(match.group(1),base)
                if event:obs['event_at']=event
            except (ValueError,TypeError):pass
        for name in ('Delivers','Delivery Date','Pickup Date','Arrival Time','Check-in Time','Pickup Store','In-Store pickup location'):
            m=re.search(re.escape(name)+r'\s*:?\s*([^\n]+)',text,re.I)
            if m:labels[name]=m.group(1).strip()[:180]
        eta=labels.get('Delivers') or labels.get('Delivery Date') or labels.get('Pickup Date')
        if eta:
            # The main parser is injected at runtime to avoid duplicate business logic.
            if hasattr(self,'eta_parser'):
                try:
                    base=dates.parse(row['order_date']) if row['order_date'] else datetime.now()
                    iso,label=self.eta_parser(eta,base)
                    if iso:obs['eta_date']=iso;obs['eta_text']=label
                except (ValueError,TypeError):pass
        obs['pickup_store']=labels.get('Pickup Store') or labels.get('In-Store pickup location') or ''
        obs['pickup_time']=labels.get('Arrival Time') or labels.get('Check-in Time') or ''
        track=[]
        for c in snap['controls']:
            match=re.fullmatch(r'1Z[A-Z0-9]{16}',c.get('text',''),re.I)
            if match and match.group().upper() not in track:track.append(match.group().upper())
        if track:obs['tracking_number']=', '.join(track);obs['carrier']='UPS'
    def associate(self,store,task,row,url,pace,stopping):
        number=row['order_number'];cid=self.connection['id']
        if self._linked_in_listing(number):
            if task['submitted']:
                store.association(task,'associated',task.get('candidate_id'))
                return 'associated','Previously uncertain association now confirmed in the account listing'
            store.association(task,'already_associated');return 'already_associated','Order appears in the authenticated account listing'
        page=self.task_page(task,url,reuse=bool(task['submitted']));snap=self.snapshot(page)
        self._assert_identity(snap)
        if not re.search(r'\b'+re.escape(number)+r'\b',snap['text']):
            raise AppleFlowError('order_mismatch','Requested order is not visible; no association attempted')
        known=(row['linked_apple_connection']==cid and row['association_state'] in ('associated','already_associated'))
        if known:
            store.association(task,'already_associated');return 'already_associated','Previously proven association retained; the current listing does not need to re-prove it.'
        # Management controls on a guest-order detail page are not enough to
        # establish account association and must never verify a submitted phone.
        if self._management_evidence(snap) and not task['submitted']:
            store.association(task,'awaiting_verification')
            return 'awaiting_verification','Order management controls are visible, but association is not proven by the signed-in account listing. Complete the Apple handoff and re-read the listing.'
        if re.search(r'(associated with|added to) (?:another|a different) Apple',snap['text'],re.I):
            store.association(task,'another_account');return 'ineligible','Apple reports a different associated account'
        if task['submitted']:
            # Reconciliation only. Never advance a candidate after an uncertain response.
            if self._linked_in_listing(number):
                store.association(task,'associated',task.get('candidate_id'));return 'associated','Association confirmed in the signed-in account listing'
            if task.get('candidate_id') and self._mismatch(snap):
                store.record_phone_result(row['id'],task['candidate_id'],cid,'Mismatch')
                store.result(task,'queued','Apple explicitly rejected this order phone; next exact-alias candidate will be eligible',clear_submission=True)
                task['submitted']=0
                return 'queued','Phone mismatch confirmed; remaining candidates retained'
            return 'uncertain','Association not confirmed. Review the open browser; do not repeat the submitted candidate.'
        if not re.search(r'\b'+re.escape(number)+r'\b',snap['text']):raise AppleFlowError('order_mismatch','Requested order is not visible')
        add=self._unique_button(page,r'^Add to Apple (?:Account|ID)$')
        if add:
            add.click();page.wait_for_timeout(800);snap=self.snapshot(page)
        if snap['password_prompt'] or snap.get('auth_prompt'):raise AppleFlowError('auth_required','Complete Apple sign-in, passkey or verification-code approval in the browser')
        phone_inputs=page.locator('input[type="tel"]')
        phone_inputs=[phone_inputs.nth(i) for i in range(phone_inputs.count()) if phone_inputs.nth(i).is_visible()]
        phone_context=bool(re.search(r'phone (?:number)?.{0,160}(?:order|used|verification|verify)|(?:order|verify).{0,160}phone',snap['text'],re.I|re.S))
        if len(phone_inputs)!=1 or not phone_context:
            store.mark_submitted(task)
            store.association(task,'awaiting_verification')
            return 'awaiting_verification','Complete Add to Apple Account in the open browser, then Continue / Re-read Apple. No verified phone is assumed.'
        valid=[p for p in store.phone_candidates(row,cid) if p['quality']=='valid' and p['verification'] not in ('Mismatch','Uncertain')]
        if not valid:
            store.association(task,'needs_phone_data');return 'needs_phone_data','No untried valid exact-alias phone remains. Import/correct profiles; confirmed mismatches are not cycled.'
        for phone in valid:
            if stopping():return 'queued','Paused before further phone submissions; remaining candidates retained'
            phone_inputs[0].fill(phone['original'])
            form=phone_inputs[0].locator('xpath=ancestor::form[1]')
            button=self._unique_button(form if form.count()==1 else page,r'^(?:Continue|Verify|Add to Apple Account)$')
            if not button:
                store.mark_submitted(task,phone['id'])
                store.record_phone_result(row['id'],phone['id'],cid,'Uncertain')
                return 'awaiting_verification','Phone is filled. Review and submit in Apple, then Continue / Re-read Apple.'
            store.mark_submitted(task,phone['id'])
            button.click();page.wait_for_timeout(1300);snap=self.snapshot(page)
            if re.search(r'too many|try again later',snap['text'],re.I):
                raise AppleFlowError('throttled','Apple verification limit reached; remaining candidates retained',300)
            if self._mismatch(snap):
                store.record_phone_result(row['id'],phone['id'],cid,'Mismatch')
                store.c.execute('UPDATE apple_tasks SET submitted=0 WHERE id=?',(task['id'],));store.c.commit();task['submitted']=0
                until=time.monotonic()+max(5,pace)
                while time.monotonic()<until:
                    if stopping():return 'queued','Paused between phone candidates; completed mismatches retained'
                    page.wait_for_timeout(250)
                continue
            if self._linked_in_listing(number):
                store.association(task,'associated',phone['id']);self.save_session()
                return 'associated','Apple confirmed association in this account listing; phone verified only for this order'
            store.record_phone_result(row['id'],phone['id'],cid,'Uncertain')
            return 'uncertain','Phone submission has no confirmed result. Reconcile before trying a different number.'
        store.association(task,'needs_phone_data');return 'needs_phone_data','No matching phone verified; all usable candidates were explicitly rejected'
    @staticmethod
    def _mismatch(snap):
        return bool(re.search(r'(?:phone number.{0,65}(?:does not match|doesn.t match|incorrect|not match)|(?:incorrect|invalid) phone number)',snap.get('text',''),re.I))
    def mutation(self,store,task,row,url):
        page,snap,obs=self.read_order(task,row,url,reuse=bool(task['submitted']))
        store.save_observation(task,obs)
        scope=json.loads(task['scope']);selected=set(scope.get('item_ids') or [])
        if task['action']=='cancel':
            if not task['submitted'] and obs.get('all_items_known'):
                frozen={i['id']:i for i in scope.get('observed_items',[]) if i.get('stable_id')}
                if selected:
                    for item in obs['items']:
                        if item['id'] in selected and frozen.get(item['id'],{}).get('qty') not in (None,item.get('qty')):
                            return 'awaiting_verification','Apple item quantity differs from the approved preview. Stop this job and review a new batch.'
                elif all(isinstance(i.get('qty'),int) for i in obs['items']) and sum(i['qty'] for i in obs['items'])!=scope['qty']:
                    return 'awaiting_verification','Apple order quantity differs from the approved preview. Stop this job and review a new batch.'
            if selected:
                live={i['id']:i for i in obs['items'] if i.get('stable_id')}
                if not selected.issubset(live):return 'uncertain','Selected item identities cannot be matched on the current Apple page'
                if all(live[i]['status']=='Canceled' for i in selected):return 'succeeded','Apple confirms every selected item is canceled'
            elif obs['status']=='Canceled':return 'succeeded','Apple confirms order cancellation'
            if task['submitted']:return 'uncertain','Cancellation submission is not confirmed. Read current Apple state; do not resubmit automatically.'
            eligible=any(i.get('cancel_eligible') for i in obs['items'] if not selected or i['id'] in selected) or (not selected and obs['cancel_eligible'])
            if not eligible:return 'ineligible','Apple exposes no recognized cancellation action for this exact selection'
            # Final cancellation is handed to the user unless there is one explicit
            # whole-order confirmation naming this exact order. Partial-item and
            # unfamiliar layouts stay browser-assisted rather than canceling extras.
            store.mark_submitted(task)
            if not selected:
                button=self._unique_button(page,r'^Cancel Order$')
                if button:button.click();page.wait_for_timeout(600)
            return 'awaiting_verification','Review only the confirmed target order/items in Apple and submit its cancellation. Then Continue / Re-read Apple. No cancellation is marked successful until Apple confirms.'
        if task['submitted']:
            if re.search(r'(?:payment (?:method|information) (?:has been |was )?(?:successfully )?updated|your payment details have been updated)',snap['text'],re.I):
                expected=json.loads(task['snapshot']).get('method','') if task.get('snapshot') else ''
                if expected and snap.get('payment_last4')!=expected[-4:]:
                    return 'uncertain','Apple reports a method update, but the intended masked method could not be verified. Review the payment summary; no automatic resubmission.'
                return 'succeeded','Apple confirms the payment-method update. This does not prove payment cleared or fulfillment resumed.'
            if re.search(r'(?:card|payment).{0,30}(?:declined|not accepted)',snap['text'],re.I):return 'declined','Apple reports a decline. Automatic retries are disabled until you correct and explicitly reauthorize.'
            return 'uncertain','No order-specific payment-update confirmation found. Reconcile in Apple before another submission.'
        if not obs['payment_eligible']:return 'ineligible','Apple exposes no recognized order-specific payment-update action'
        button=self._unique_button(page,r'^(?:Update|Change|Edit) (?:Payment|Payment Method|Payment Information)$')
        store.mark_submitted(task)
        if button:button.click()
        return 'awaiting_verification','Enter or choose the payment method directly on this Apple order page and submit there. Card data is not collected by the tracker. Then Continue / Re-read Apple.'
    def finish_page(self,task_id):
        page=self.task_pages.pop(task_id,None)
        if page and not page.is_closed():page.close()
