@echo off
setlocal EnableExtensions
set "PYTHONUTF8=1"
cd /d "%~dp0"

echo ======================================================
echo Ah Pa Ta Tracker v1.0.4 - Windows EXE Builder
echo ======================================================
echo.
echo This builder uses a SHORT dependency/work path under LocalAppData.
echo That avoids the Windows 260-character path limit that can break
ECHO PySide6 installation when this project is extracted under Desktop.
echo.

where py >nul 2>nul
if errorlevel 1 (
  echo Python launcher ^(py^) was not found.
  echo Install Python 3.11 or 3.12 from https://www.python.org/downloads/windows/
  pause
  exit /b 1
)

set "BUILD_CACHE=%LOCALAPPDATA%\AOTB"
set "VENV_DIR=%BUILD_CACHE%\venv"
set "WORK_DIR=%BUILD_CACHE%\work"
set "SPEC_DIR=%BUILD_CACHE%\spec"

if not exist "%BUILD_CACHE%" mkdir "%BUILD_CACHE%"
if errorlevel 1 goto :fail

if exist "%VENV_DIR%\Scripts\python.exe" (
  "%VENV_DIR%\Scripts\python.exe" -c "import sys; print(sys.executable)" >nul 2>nul
  if errorlevel 1 (
    echo Recreating damaged short-path build environment...
    rmdir /s /q "%VENV_DIR%" >nul 2>nul
  )
)

if not exist "%VENV_DIR%\Scripts\python.exe" (
  echo Creating short-path virtual environment at:
  echo   %VENV_DIR%
  py -3 -m venv "%VENV_DIR%"
  if errorlevel 1 goto :fail
)

call "%VENV_DIR%\Scripts\activate.bat"
if errorlevel 1 goto :fail

python -m pip install --upgrade pip
if errorlevel 1 goto :fail
python -m pip install -r "%~dp0requirements.txt"
if errorlevel 1 goto :pip_fail

echo.
echo Running offline parser, sync, Apple workspace, UPS and database checks...
python -m unittest discover -s "%~dp0tests" -p "test_*.py" -v > "%BUILD_CACHE%\core_check.log" 2>&1
if errorlevel 1 (
  type "%BUILD_CACHE%\core_check.log"
  echo Core checks failed. The EXE was not rebuilt.
  goto :fail
)
echo Running Qt startup and interaction checks with temporary test data...
python "%~dp0tests\gui_smoke.py" > "%BUILD_CACHE%\gui_check.log" 2>&1
if errorlevel 1 (
  type "%BUILD_CACHE%\gui_check.log"
  echo GUI checks failed. The EXE was not rebuilt.
  echo Log: %BUILD_CACHE%\gui_check.log
  goto :fail
)
echo Running Apple workspace UI checks...
python "%~dp0tests\gui_apple_smoke.py" >> "%BUILD_CACHE%\gui_check.log" 2>&1
if errorlevel 1 (
  type "%BUILD_CACHE%\gui_check.log"
  goto :fail
)
echo Running v1.0.4 update/proxy/theme UI checks...
python "%~dp0tests\gui_v103_smoke.py" >> "%BUILD_CACHE%\gui_check.log" 2>&1
if errorlevel 1 (
  type "%BUILD_CACHE%\gui_check.log"
  goto :fail
)
echo Running v1.0.4 production-readiness UI checks...
python "%~dp0tests\gui_v104_smoke.py" >> "%BUILD_CACHE%\gui_check.log" 2>&1
if errorlevel 1 (
  type "%BUILD_CACHE%\gui_check.log"
  goto :fail
)
echo Checks passed. Building the application...

if exist "%WORK_DIR%" rmdir /s /q "%WORK_DIR%" >nul 2>nul
if exist "%SPEC_DIR%" rmdir /s /q "%SPEC_DIR%" >nul 2>nul
mkdir "%WORK_DIR%" >nul 2>nul
mkdir "%SPEC_DIR%" >nul 2>nul

if exist "%~dp0dist\AhPaTaTracker.exe" del /q "%~dp0dist\AhPaTaTracker.exe" >nul 2>nul
if exist "%~dp0dist\AppleOrderTracker.exe" del /q "%~dp0dist\AppleOrderTracker.exe" >nul 2>nul

echo.
echo Building one-file Windows application...
python -m PyInstaller --noconfirm --clean --onefile --windowed --exclude-module PySide6.QtWebEngineCore --exclude-module PySide6.QtWebEngineWidgets --collect-all keyring --collect-all playwright --icon="%~dp0app_icon.ico" --add-data "%~dp0app_icon.ico;." --distpath "%~dp0dist" --workpath "%WORK_DIR%" --specpath "%SPEC_DIR%" --name AhPaTaTrackerApp "%~dp0AppleOrderTracker.py"
if errorlevel 1 goto :fail

echo Building persistent native launcher...
python "%~dp0tools\build_native_launcher.py" --source "%~dp0launcher\Program.cs" --payload "%~dp0dist\AhPaTaTrackerApp.exe" --output "%~dp0dist\AhPaTaTracker.exe" --version 1.0.4 --icon "%~dp0app_icon.ico"
if errorlevel 1 goto :fail
python "%~dp0tools\verify_native_launcher.py" "%~dp0dist\AhPaTaTracker.exe" --version 1.0.4
if errorlevel 1 goto :fail

echo.
echo ======================================================
echo BUILD COMPLETE - Ah Pa Ta Tracker v1.0.4
echo EXE: %~dp0dist\AhPaTaTracker.exe
echo.
echo SYNC MODES:
echo 1. New Emails Only - default and fastest. Uses saved Gmail UID checkpoints.
echo 2. Full Account Sync - explicitly scans all historical Apple order mail.
echo.
echo LARGE SYNC RESILIENCE:
echo - Checkpoints are saved after every batch.
echo - Gmail OVERQUOTA / bandwidth / timeout errors pause and retry automatically.
echo - Missing or malformed individual UIDs are isolated and queued for retry.
echo - A bad message does not stop later messages from importing.
echo - Historical Refresh Details does not damage the new-email checkpoint.
echo.
echo IMPORTANT:
echo - On a brand-new account, New Emails Only starts from NOW.
echo   Use Full Account Sync once if you want existing historical orders.
echo - Gmail App Password/authentication failures cannot be bypassed; that account
ECHO   is skipped while other selected accounts continue.
echo - Existing database and credentials are reused from:
echo   %%LOCALAPPDATA%%\AppleOrderTracker
ECHO   This legacy folder name is intentionally retained so upgrades keep your data.
echo ======================================================
pause
exit /b 0

:pip_fail
echo.
echo Dependency installation failed.
echo The builder already uses a short path: %VENV_DIR%
echo If the error still mentions Windows Long Path support, restart Windows and
ECHO try again, or enable Win32 long paths in Windows Group Policy/registry.
echo.
goto :fail

:fail
echo.
echo Build failed. Review the error above.
pause
exit /b 1
