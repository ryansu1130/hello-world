"""Apple workspace UI integrated into the existing PySide tracker.

Browser work and profile imports use their own worker-owned SQLite connections.
No passwords/cards are collected here; the user enters those on Apple's page.
"""
from __future__ import annotations
import hashlib
import json
import re
import socket
import time
import uuid
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from PySide6.QtCore import Qt,QAbstractTableModel,QModelIndex,QThread,QTimer,Signal
from PySide6.QtWidgets import (QWidget,QDialog,QVBoxLayout,QHBoxLayout,QFormLayout,QLabel,QPushButton,
    QComboBox,QLineEdit,QSpinBox,QCheckBox,QTabWidget,QTableView,QHeaderView,QAbstractItemView,
    QFileDialog,QMessageBox,QApplication,QPlainTextEdit,QDialogButtonBox,QMenu,QListWidget,QListWidgetItem,QSplitter,QInputDialog)
from apple_accounts import AppleStore,safe_message,utc_now
from apple_profiles import safe_paths,iter_records,parse_proxy,proxy_identity,normalize_phone,email_key
from apple_secrets import SecretVault
from apple_jobs import AppleRunner


class RecordModel(QAbstractTableModel):
    def __init__(self,columns,rows=(),parent=None):
        super().__init__(parent);self.columns=columns;self.rows=list(rows)
    def rowCount(self,parent=QModelIndex()):return 0 if parent.isValid() else len(self.rows)
    def columnCount(self,parent=QModelIndex()):return len(self.columns)
    def headerData(self,n,orientation,role=Qt.DisplayRole):
        if role==Qt.DisplayRole and orientation==Qt.Horizontal:return self.columns[n][1]
    def data(self,index,role=Qt.DisplayRole):
        if not index.isValid() or index.row()>=len(self.rows):return None
        row=self.rows[index.row()];key=self.columns[index.column()][0]
        if role in (Qt.DisplayRole,Qt.ToolTipRole):
            value=row.get(key,'')
            return '' if value is None else str(value)
        if role==Qt.TextAlignmentRole:return int(Qt.AlignLeft|Qt.AlignVCenter)
    def set_rows(self,rows):self.beginResetModel();self.rows=list(rows);self.endResetModel()
    def sort(self,column,order=Qt.AscendingOrder):
        key=self.columns[column][0]
        self.layoutAboutToBeChanged.emit();self.rows.sort(key=lambda r:str(r.get(key) or '').casefold(),reverse=order==Qt.DescendingOrder);self.layoutChanged.emit()


class RouteModel(RecordModel):
    selection_changed=Signal()
    def __init__(self,columns,rows=(),parent=None):
        super().__init__(columns,rows,parent);self.selected_ids=set()
    def data(self,index,role=Qt.DisplayRole):
        if index.isValid() and index.column()==0:
            if role==Qt.CheckStateRole:
                rid=str(self.rows[index.row()].get('id','')) if index.row()<len(self.rows) else ''
                return Qt.Checked if rid and rid in self.selected_ids else Qt.Unchecked
            if role==Qt.DisplayRole:return ''
        return super().data(index,role)
    def flags(self,index):
        flags=super().flags(index)
        if index.isValid() and index.column()==0:
            return flags|Qt.ItemIsUserCheckable|Qt.ItemIsEnabled
        return flags
    def setData(self,index,value,role=Qt.EditRole):
        if index.isValid() and index.column()==0 and role==Qt.CheckStateRole:
            rid=str(self.rows[index.row()].get('id',''))
            if not rid:return False
            if value==Qt.Checked:self.selected_ids.add(rid)
            else:self.selected_ids.discard(rid)
            self.dataChanged.emit(index,index,[Qt.CheckStateRole]);self.selection_changed.emit();return True
        return False
    def set_rows(self,rows):
        ids={str(r.get('id','')) for r in rows};self.selected_ids.intersection_update(ids)
        super().set_rows(rows);self.selection_changed.emit()
    def clear_selection(self):
        if not self.selected_ids:return
        self.selected_ids.clear()
        if self.rows:self.dataChanged.emit(self.index(0,0),self.index(len(self.rows)-1,0),[Qt.CheckStateRole])
        self.selection_changed.emit()
    def select_all(self):
        self.selected_ids={str(r.get('id','')) for r in self.rows if r.get('id') and r.get('saved',True)}
        if self.rows:self.dataChanged.emit(self.index(0,0),self.index(len(self.rows)-1,0),[Qt.CheckStateRole])
        self.selection_changed.emit()



def table_for(model):
    t=QTableView();t.setModel(model);t.setSelectionBehavior(QAbstractItemView.SelectRows);t.setSelectionMode(QAbstractItemView.SingleSelection)
    t.setEditTriggers(QAbstractItemView.NoEditTriggers);t.setAlternatingRowColors(True);t.setWordWrap(False)
    t.verticalHeader().hide();t.verticalHeader().setDefaultSectionSize(38)
    t.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive);t.horizontalHeader().setStretchLastSection(True)
    for i in range(model.columnCount()):t.setColumnWidth(i,155)
    return t


def selected_record(table,model):
    index=table.currentIndex()
    return model.rows[index.row()] if index.isValid() and index.row()<len(model.rows) else None


class BrowserWorker(QThread):
    update=Signal(str,object)
    def __init__(self,owner):
        super().__init__(owner)
        self.runner=AppleRunner(type(owner.db),owner.db.path,owner.apple_order_url,owner.apple_eta_parser,
                                lambda event,data:self.update.emit(event,data))
    def run(self):self.runner.run()
    def send(self,*args,**kwargs):self.runner.send(*args,**kwargs)
    def request_stop(self):self.runner.stop()


class ImportWorker(QThread):
    progress=Signal(object);done=Signal(object)
    def __init__(self,dbtype,path,files,mapping,parent=None):
        super().__init__(parent);self.dbtype=dbtype;self.path=path;self.files=files;self.mapping=mapping;self.stop_requested=False
    def run(self):
        db=None
        try:
            db=self.dbtype(self.path);report=AppleStore(db).import_files(self.files,self.mapping,self.progress.emit,lambda:self.stop_requested)
            self.done.emit(report)
        except Exception as exc:self.done.emit({'errors':['Import failed: '+type(exc).__name__], 'accepted':0})
        finally:
            if db:db.close()


class MappingDialog(QDialog):
    def __init__(self,path,parent=None):
        super().__init__(parent);self.setWindowTitle('Profile field mapping');self.resize(900,620);self.setMinimumSize(760,520)
        lay=QVBoxLayout(self);note=QLabel('Choose paths within ONE logical profile. Never pair unrelated arrays. Payment/card fields are excluded.\nFor a nested collection use records_path (for example: profiles).');note.setWordWrap(True);lay.addWidget(note)
        fields=[]
        try:
            _,sample=next(iter_records(Path(path)))
            if isinstance(sample,dict):fields=safe_paths(sample)
        except Exception:pass
        preview=QPlainTextEdit('\n'.join(fields[:120]));preview.setReadOnly(True);preview.setMaximumHeight(140);lay.addWidget(preview)
        form=QFormLayout();self.inputs={}
        for key,title,default in [('records_path','Record collection path (blank for array)',''),('email','Email path','email'),('phone','Phone path','shipping.phone'),('country','Country path','shipping.country'),('order','Order number path (optional)','')]:
            box=QLineEdit(default);form.addRow(title,box);self.inputs[key]=box
        lay.addLayout(form)
        buttons=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel);buttons.accepted.connect(self.accept);buttons.rejected.connect(self.reject);lay.addWidget(buttons)
    def mapping(self):return {k:v.text().strip() for k,v in self.inputs.items()}


class PreviewDialog(QDialog):
    def __init__(self,store,ids,action,parent=None):
        super().__init__(parent);self.store=store;self.ids=list(ids);self.action=action;self.data=None;self.item_selections={}
        self.setWindowTitle('Review Apple '+action+' batch');geo=QApplication.primaryScreen().availableGeometry() if QApplication.primaryScreen() else None;self.resize(int(geo.width()*0.90) if geo else 1400,int(geo.height()*0.86) if geo else 820);self.setMinimumSize(1100,700)
        lay=QVBoxLayout(self);head=QLabel('Review the exact Apple targets');head.setObjectName('dialogTitle');lay.addWidget(head)
        self.account=QComboBox()
        for c in store.connections():self.account.addItem(c['email']+' - '+c['state'],c['id'])
        form=QFormLayout();form.addRow('Destination Apple Account',self.account);self.method=QLineEdit();self.method.setPlaceholderText('Optional masked label only, e.g. Visa ****1234')
        if action=='payment':form.addRow('Intended payment method',self.method)
        lay.addLayout(form)
        self.count=QLabel();lay.addWidget(self.count)
        self.model=RecordModel([('order_number','Order #'),('item','Item'),('qty','Units'),('total','Order total'),('expected_status','Current status'),('scope_label','Scope'),('eligibility','Last observed eligibility')])
        self.table=table_for(self.model);self.table.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel);hdr=self.table.horizontalHeader();hdr.setSectionResizeMode(0,QHeaderView.ResizeToContents);hdr.setSectionResizeMode(1,QHeaderView.Stretch);[hdr.setSectionResizeMode(i,QHeaderView.ResizeToContents) for i in range(2,self.model.columnCount())];lay.addWidget(self.table,1)
        item_btn=QPushButton('Choose items for highlighted order');item_btn.setVisible(action=='cancel');item_btn.clicked.connect(self.choose_items);lay.addWidget(item_btn,0,Qt.AlignLeft)
        warning={'associate':'Only matching imported phone candidates are tried. Opening a page or signing in is not counted as association.',
                 'refresh':'Read-only refresh. Manual overrides remain highest priority. Missing/unknown Apple data is not invented.',
                 'cancel':'This changes existing Apple orders. Eligibility is rechecked. Final cancellation is browser-assisted in this build; submit only the reviewed targets on Apple. Stop Job does not undo actions.',
                 'payment':'This can authorize or charge your payment method. Enter/select it directly on each Apple order page. The tracker does not collect or reuse raw card data and does not change account defaults. A method update does not prove payment cleared.'}[action]
        label=QLabel(warning);label.setWordWrap(True);lay.addWidget(label)
        self.confirm=QCheckBox('I authorize this exact account and selected order/item batch.');self.confirm.setVisible(action!='refresh');lay.addWidget(self.confirm)
        self.status=QLabel();self.status.setWordWrap(True);lay.addWidget(self.status)
        buttons=QDialogButtonBox(QDialogButtonBox.Cancel);self.go=buttons.addButton('START '+action.upper()+' JOB',QDialogButtonBox.AcceptRole);self.go.setObjectName('primaryButton')
        self.go.clicked.connect(self.submit);buttons.rejected.connect(self.reject);lay.addWidget(buttons)
        self.account.currentIndexChanged.connect(lambda: self.confirm.setChecked(False));self.account.currentIndexChanged.connect(self.refresh);self.method.textChanged.connect(lambda:self.confirm.setChecked(False));self.refresh()
    def refresh(self):
        try:
            self.data=self.store.snapshot(self.ids,self.account.currentData(),self.action,self.method.text().strip() if self.action=='payment' else '',self.item_selections)
            display=[];units=0
            for r in self.data['orders']:
                value=dict(r);value['scope_label']='Selected items: '+', '.join(r['item_ids']) if r['item_ids'] else 'Whole order'
                if r['item_ids']:
                    units+=sum(int(i.get('qty') or 0) for i in r['observed_items'] if i.get('id') in r['item_ids'])
                else:units+=r['qty']
                display.append(value)
            self.model.set_rows(display);self.count.setText(f'{len(display):,} orders / {units:,} selected units. Apple item lines: '+(str(sum(len(r["item_ids"]) if r["item_ids"] else len(r["observed_items"]) for r in self.data["orders"])) if all(r["observed_items"] for r in self.data["orders"]) else 'not fully verified')+'. Totals are full-order amounts, not partial-item quotes.')
            connection=self.store.connection(self.account.currentData())
            if not connection or connection.get('state')!='connected':
                self.status.setText('Connect and verify this Apple Account first. Close this review, complete Setup, then press START again.');self.go.setEnabled(False)
            else:
                self.status.setText('Ready. Eligibility will be re-read from Apple immediately before any consequential action.');self.go.setEnabled(True)
        except ValueError as e:self.status.setText(str(e));self.go.setEnabled(False);self.data=None
    def choose_items(self):
        r=selected_record(self.table,self.model)
        if not r:return
        items=[i for i in r['observed_items'] if i.get('stable_id')]
        if not items:
            QMessageBox.information(self,'Item scope','Refresh from Apple first. No stable Apple item identifiers are available; selecting individual items by table position would be unsafe.');return
        dlg=QDialog(self);dlg.setWindowTitle('Choose exact Apple items');lay=QVBoxLayout(dlg);lst=QListWidget();lay.addWidget(lst)
        for i in items:
            entry=QListWidgetItem(f"{i['id']} | {i.get('item','')} | Qty {i.get('qty','?')} | {i.get('status','')}")
            entry.setData(Qt.UserRole,i['id']);entry.setFlags(entry.flags()|Qt.ItemIsUserCheckable)
            entry.setCheckState(Qt.Checked if not r['item_ids'] or i['id'] in r['item_ids'] else Qt.Unchecked);lst.addItem(entry)
        b=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel);b.accepted.connect(dlg.accept);b.rejected.connect(dlg.reject);lay.addWidget(b)
        if dlg.exec()==QDialog.Accepted:
            selected=[lst.item(i).data(Qt.UserRole) for i in range(lst.count()) if lst.item(i).checkState()==Qt.Checked]
            if not selected:QMessageBox.warning(self,'Item scope','Select at least one item, or remove this order from the batch.');return
            self.item_selections[r['id']]=selected;self.confirm.setChecked(False);self.refresh()
    def submit(self):
        self.refresh()
        if not self.data:return
        if self.action!='refresh' and not self.confirm.isChecked():self.status.setText('Confirm the exact batch before queueing.');return
        self.accept()


class PhoneDialog(QDialog):
    def __init__(self,db,order_id,parent=None):
        super().__init__(parent);self.db=db;self.store=AppleStore(db);self.oid=order_id;self.setWindowTitle('Order phone candidates');self.resize(1250,700);self.setMinimumSize(950,600)
        lay=QVBoxLayout(self);row=db.order_by_id(order_id);lay.addWidget(QLabel('Exact aliases: '+(row['alias_emails'] or 'None')))
        self.account=QComboBox()
        for c in self.store.connections():self.account.addItem(c['email'],c['id'])
        lay.addWidget(self.account)
        self.model=RecordModel([('original','Phone'),('normalized','Normalized'),('quality','Validity'),('verification','For THIS order'),('order_match','Exact order hint'),('email','Alias')])
        self.table=table_for(self.model);lay.addWidget(self.table,1)
        tools=QHBoxLayout();sources=QPushButton('View provenance');add=QPushButton('Add/correct phone for this order');reset=QPushButton('Reset selected attempt for this order')
        for b in (sources,add,reset):tools.addWidget(b)
        lay.addLayout(tools);self.note=QLabel('A JSON candidate is not a verified number. Verification is per order and destination account.');self.note.setWordWrap(True);lay.addWidget(self.note)
        sources.clicked.connect(self.sources);add.clicked.connect(self.add);reset.clicked.connect(self.reset);self.account.currentIndexChanged.connect(self.refresh)
        close=QDialogButtonBox(QDialogButtonBox.Close);close.rejected.connect(self.reject);lay.addWidget(close);copy=QPushButton('Copy highlighted phone');copy.clicked.connect(self.copy_phone);lay.addWidget(copy)
        self.refresh()
    def refresh(self):self.model.set_rows(self.store.phone_candidates(self.db.order_by_id(self.oid),self.account.currentData() or ''))
    def sources(self):
        r=selected_record(self.table,self.model)
        if not r:return
        text='\n'.join(f"{s['filename']} | {s['record_path']}.{s['field_path']} | order hint {s['order_number'] or 'none'} | {s['imported_at']}" for s in self.store.phone_sources(r['id']))
        dlg=QDialog(self);dlg.setWindowTitle('Phone provenance');lay=QVBoxLayout(dlg);view=QPlainTextEdit(text);view.setReadOnly(True);lay.addWidget(view);dlg.resize(850,300);dlg.exec()
    def add(self):
        from apple_profiles import aliases
        row=self.db.order_by_id(self.oid);keys=aliases(row['alias_emails'] or '')
        if not keys:QMessageBox.warning(self,'Phone','This order has no exact alias. Import a matching order email first.');return
        dlg=QDialog(self);dlg.setWindowTitle('Order-specific phone correction');form=QFormLayout(dlg);alias=QComboBox();alias.addItems(keys);phone=QLineEdit();country=QComboBox();country.addItems(['Country not specified','United States','Canada'])
        form.addRow('Exact alias',alias);form.addRow('Phone (including country code)',phone);form.addRow('Country context',country)
        b=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel);b.accepted.connect(dlg.accept);b.rejected.connect(dlg.reject);form.addRow(b)
        if dlg.exec()!=QDialog.Accepted:return
        p=normalize_phone(phone.text(),country.currentText())
        if p.state=='invalid':QMessageBox.warning(self,'Phone',p.note);return
        with self.db.conn:
            self.db.conn.execute('INSERT OR IGNORE INTO apple_phone_candidates(email,phone_key,original,normalized,extension,quality,note) VALUES(?,?,?,?,?,?,?)',(alias.currentText(),p.comparison,p.original,p.normalized,p.extension,p.state,p.note))
            pid=self.db.conn.execute('SELECT id FROM apple_phone_candidates WHERE email=? AND phone_key=?',(alias.currentText(),p.comparison)).fetchone()[0]
            self.db.conn.execute('INSERT OR IGNORE INTO apple_phone_sources(candidate_id,file_hash,filename,record_path,field_path,order_number,original,imported_at) VALUES(?,?,?,?,?,?,?,?)',
                (pid,'manual-'+str(self.oid),'Manual entry',f'order[{self.oid}]','phone',row['order_number'],p.original,utc_now()))
        self.refresh()
    def reset(self):
        r=selected_record(self.table,self.model);cid=self.account.currentData()
        if r and cid:
            if QMessageBox.question(self,'Reset attempt','Clear this candidate result for this order/account only? It will become untried, not verified.')==QMessageBox.Yes:
                self.store.record_phone_result(self.oid,r['id'],cid,'Untried');self.refresh()


    def copy_phone(self):
        record=selected_record(self.table,self.model)
        if record:QApplication.clipboard().setText(record['original'])

class AppleDetailSection(QWidget):
    def __init__(self,db,oid,parent=None):
        super().__init__(parent);self.db=db;self.oid=oid;lay=QVBoxLayout(self);lay.setContentsMargins(0,0,0,0)
        self.button=QPushButton('Apple account details / phone provenance');self.button.clicked.connect(self.open);lay.addWidget(self.button)
        self.items_button=QPushButton('View Apple items and eligibility');self.items_button.clicked.connect(self.show_items);lay.addWidget(self.items_button)
        self.label=QLabel();self.label.setWordWrap(True);self.label.setTextInteractionFlags(Qt.TextSelectableByMouse);lay.addWidget(self.label)
        self.timer=QTimer(self);self.timer.setInterval(2000);self.timer.timeout.connect(self.refresh);self.timer.start();self.refresh()
    def refresh(self):
        row=self.db.order_by_id(self.oid)
        if not row:return
        s=AppleStore(self.db);cid=row['linked_apple_connection'] or row['account_status_connection'];c=s.connection(cid) if cid else None
        self.label.setText(f"Apple Account: {c['email'] if c else 'Not confirmed'} | Association: {row['association_state'] or 'Not associated'}\n"
            f"Apple reported: {row['account_raw_status'] or 'No authenticated observation'} | Success: {row['account_status_success_at'] or 'Never'}\n"
            f"Latest attempt: {row['account_status_attempt_at'] or 'Never'} | Attention: {row['account_status_error'] or 'None'}")
    def show_items(self):
        row=self.db.order_by_id(self.oid)
        if not row:return
        items=json.loads(row['account_items_json'] or '[]')
        d=QDialog(self);d.setWindowTitle('Apple item observations');d.resize(980,460);lay=QVBoxLayout(d)
        note=QLabel('Last successful authenticated observation. Missing fields remain unknown; estimates are not fulfillment guarantees.');note.setWordWrap(True);lay.addWidget(note)
        model=RecordModel([('item','Apple item'),('qty','Units'),('raw_status','Apple wording'),('status','Mapped status'),('cancel_eligible','Cancel offered'),('id','Item identity')],items,d)
        table=table_for(model);table.setColumnWidth(0,260);lay.addWidget(table)
        buttons=QDialogButtonBox(QDialogButtonBox.Close);buttons.rejected.connect(d.reject);lay.addWidget(buttons);d.exec()
    def open(self):PhoneDialog(self.db,self.oid,self).exec()


def phone_summary(db,row):
    store=AppleStore(db);cid=row['linked_apple_connection'] or row['account_status_connection'] or ''
    phones=store.phone_candidates(row,cid)
    if not phones:return 'No matching phone number found'
    return '\n'.join(p['original']+' - '+p['verification']+(' ('+p['quality']+')' if p['quality']!='valid' else '') for p in phones)


class AppleWorkspace(QWidget):
    changed=Signal()
    def __init__(self,owner):
        super().__init__(owner);self.setObjectName('content');self.owner=owner;self.db=owner.db;self.store=AppleStore(self.db);self.worker=None;self.importer=None;self.offset=0;self.active_job='';self._refreshing=False
        self.vault=SecretVault(self.db.path.parent);self.pending_routes=[];self.route_dirty=False;self.route_errors=[];self.route_test_worker=None;self._last_probe=0;self._last_tab_index=0;self._changing_tab=False
        outer=QVBoxLayout(self);outer.setContentsMargins(30,24,30,20);outer.setSpacing(12)
        head=QHBoxLayout();titles=QVBoxLayout();title=QLabel('Apple Account (Apple ID)');title.setObjectName('pageTitle');titles.addWidget(title)
        note=QLabel('Connect an Apple Account, map guest-order phone numbers when needed, and run confirmed Apple jobs.');note.setWordWrap(True);note.setObjectName('muted');titles.addWidget(note);head.addLayout(titles);head.addStretch(1)
        help_btn=QPushButton('Getting Started');help_btn.setObjectName('secondaryAccent');help_btn.clicked.connect(self.show_getting_started);head.addWidget(help_btn);outer.addLayout(head)
        self.banner=QLabel('Ready. Start on Connection; proxies are optional.');self.banner.setObjectName('appleBanner');self.banner.setWordWrap(True);outer.addWidget(self.banner)
        self.tabs=QTabWidget();outer.addWidget(self.tabs,1);self._accounts_page();self._profiles_page();self._jobs_page();self._routes_page();self.tabs.currentChanged.connect(self._tab_changed)
        self.timer=QTimer(self);self.timer.setInterval(2000);self.timer.timeout.connect(self._tick);self.timer.start();self.refresh()
    def ensure_worker(self):
        if self.worker is None or not self.worker.isRunning():
            self.worker=BrowserWorker(self.owner);self.worker.update.connect(self._event);self.worker.start()
        return self.worker
    def stopping(self):
        self.timer.stop()
        busy=bool(self.route_test_worker and self.route_test_worker.isRunning())
        if self.route_test_worker and self.route_test_worker.isRunning():self.route_test_worker.stop_requested.set()
        if self.importer and self.importer.isRunning():self.importer.stop_requested=True;busy=True
        if self.worker and self.worker.isRunning():self.worker.request_stop();busy=True
        return busy
    def _event(self,event,data):
        if data.get('message'):self.banner.setText(data['message'])
        if event in ('changed','state','error'):
            self.refresh()
            if event=='changed':self.changed.emit()
    def _tick(self):
        if not self.isVisible():return
        self.refresh_jobs()
        c=self.store.connection(self.account.currentData()) if hasattr(self,'account') else None
        if c and c['state'] in ('waiting_sign_in','waiting_verification','checking_account') and self.worker and self.worker.isRunning():
            if time.monotonic()-self._last_probe>=5:
                self._last_probe=time.monotonic();self.worker.send('probe',connection_id=c['id'])
    def _accounts_page(self):
        page=QWidget();page.setObjectName('applePage');lay=QVBoxLayout(page);lay.setContentsMargins(18,18,18,18);lay.setSpacing(12);self.tabs.addTab(page,'Connection')
        purpose=QLabel('Step 1 of 4 — connect the Apple Account that owns the orders. Sign-in and two-factor verification happen only in the dedicated browser.');purpose.setWordWrap(True);purpose.setObjectName('muted');lay.addWidget(purpose)
        row=QHBoxLayout();self.account=QComboBox();self.account.setMinimumWidth(360);self.account.setMaximumWidth(620);row.addWidget(self.account,1)
        add=QPushButton('Add Apple Account');add.clicked.connect(self.add_account);row.addWidget(add);row.addStretch(1);lay.addLayout(row)
        form=QFormLayout();form.setHorizontalSpacing(18);form.setVerticalSpacing(10);self.browser=QComboBox();self.browser.addItems(['Edge','Chrome','Brave']);self.browser.setMaximumWidth(420);self.route=QComboBox();self.route.addItem('Direct (no proxy)','');self.route.setMaximumWidth(520)
        form.addRow('Browser',self.browser);form.addRow('Proxy / network route (optional)',self.route)
        self.pace=QSpinBox();self.pace.setRange(5,600);self.pace.setValue(12);self.pace.setSuffix(' seconds between Apple jobs');self.pace.setMaximumWidth(320);form.addRow('Job pacing',self.pace)
        self.auto=QCheckBox('Refresh linked active orders in the background');self.interval=QSpinBox();self.interval.setRange(15,1440);self.interval.setValue(60);self.interval.setSuffix(' minutes');self.interval.setMaximumWidth(220)
        form.addRow(self.auto);form.addRow('Background interval',self.interval);lay.addLayout(form)
        controls=QHBoxLayout();self.connect_btn=QPushButton('Connect Apple Account');self.connect_btn.setObjectName('primaryButton');self.connect_btn.clicked.connect(self.primary_connection_action);controls.addWidget(self.connect_btn)
        self.verify_btn=QPushButton('Check sign-in again');self.verify_btn.clicked.connect(lambda:self.connection_action('verify'));controls.addWidget(self.verify_btn)
        self.confirm_identity_btn=QPushButton('Confirm visible account');self.confirm_identity_btn.clicked.connect(lambda:self.connection_action('confirm'));controls.addWidget(self.confirm_identity_btn)
        controls.addStretch(1);self.disconnect_btn=QPushButton('Disconnect');self.disconnect_btn.clicked.connect(lambda:self.connection_action('disconnect'));controls.addWidget(self.disconnect_btn)
        self.forget_btn=QPushButton('Forget saved session…');self.forget_btn.setObjectName('dangerButton');self.forget_btn.clicked.connect(lambda:self.connection_action('signout'));controls.addWidget(self.forget_btn);lay.addLayout(controls)
        self.connection_info=QLabel();self.connection_info.setWordWrap(True);self.connection_info.setObjectName('appleBanner');lay.addWidget(self.connection_info)
        self.connection_steps=QLabel('1. Click Connect Apple Account.  2. Sign in in the browser and complete any Apple verification.  3. Return here; the tracker checks the session automatically.');self.connection_steps.setWordWrap(True);lay.addWidget(self.connection_steps)
        security=QLabel('Your Apple password, passkey, two-factor code, and payment details stay on Apple\'s page. The tracker stores only its protected app-session cookies and protected proxy credentials. Brave remains experimental; Edge or Chrome is recommended.')
        security.setWordWrap(True);security.setObjectName('muted');lay.addWidget(security);lay.addStretch(1)
        self.account.currentIndexChanged.connect(self.account_changed);self.auto.toggled.connect(self.save_preferences);self.interval.valueChanged.connect(self.save_preferences)

    def _profiles_page(self):
        page=QWidget();page.setObjectName('applePage');lay=QVBoxLayout(page);lay.setContentsMargins(18,18,18,18);lay.setSpacing(10);self.tabs.addTab(page,'Phone mappings');purpose=QLabel('Step 2 of 4 — optional for guest orders. Import exact-alias phone candidates from JSON; payment fields are ignored.');purpose.setWordWrap(True);purpose.setObjectName('muted');lay.addWidget(purpose)
        row=QHBoxLayout();btn=QPushButton('Import JSON files');btn.setObjectName('primaryButton');btn.clicked.connect(lambda:self.import_profiles(False));row.addWidget(btn)
        custom=QPushButton('Import with field mapping');custom.clicked.connect(lambda:self.import_profiles(True));row.addWidget(custom)
        inspect=QPushButton('View selected sources');inspect.clicked.connect(self.inspect_profile);row.addWidget(inspect);row.addStretch(1);lay.addLayout(row)
        label=QLabel('Imported: exact email, phone, country context, optional order reference and provenance only. Payment objects are ignored. Equivalent formats deduplicate; plus aliases and order-specific verification remain distinct.');label.setWordWrap(True);lay.addWidget(label)
        self.phone_search=QLineEdit();self.phone_search.setPlaceholderText('Filter by complete alias or phone');self.phone_search.textChanged.connect(self.refresh_phones);lay.addWidget(self.phone_search)
        self.phone_model=RecordModel([('email','Exact alias'),('original','Original phone'),('normalized','Normalized phone'),('quality','Validity'),('sources','Sources')]);self.phone_table=table_for(self.phone_model);self.phone_table.setColumnWidth(0,320);lay.addWidget(self.phone_table,1)
        self.import_summary=QLabel('No import in this session. Showing up to 500 matching candidates; narrow the search for larger sets.');self.import_summary.setWordWrap(True);lay.addWidget(self.import_summary)
    def _jobs_page(self):
        page=QWidget();page.setObjectName('applePage');lay=QVBoxLayout(page);lay.setContentsMargins(18,18,18,18);lay.setSpacing(10);self.tabs.addTab(page,'Jobs & results');purpose=QLabel('Step 3 of 4 — select orders on the tracker, choose Apple Actions, then follow each queued task here.');purpose.setWordWrap(True);purpose.setObjectName('muted');lay.addWidget(purpose)
        label=QLabel('Use Apple Actions beside the selection controls on Orders / Order Dates / either Tracking page. Targets are frozen at confirmation.');label.setWordWrap(True);lay.addWidget(label)
        self.jobs_model=RecordModel([('action','Action'),('email','Apple Account'),('state','Job state'),('done','Confirmed'),('total','Targets'),('attention','Needs attention'),('created_at','Created')]);self.jobs_table=table_for(self.jobs_model);self.jobs_table.setSelectionMode(QAbstractItemView.ExtendedSelection);self.jobs_table.setMaximumHeight(250);lay.addWidget(self.jobs_table)
        self.jobs_table.clicked.connect(self.job_selected)
        controls=QHBoxLayout()
        for name,cmd in [('Pause','pause'),('Resume','resume'),('Stop Job','stop'),('Retry eligible failures','retry')]:
            b=QPushButton(name);b.clicked.connect(lambda _,c=cmd:self.control(c));controls.addWidget(b)
        remove=QPushButton('Remove selected…');remove.clicked.connect(self.remove_selected_jobs);controls.addWidget(remove)
        completed=QPushButton('Remove completed');completed.clicked.connect(self.remove_completed_jobs);controls.addWidget(completed)
        export=QPushButton('Export sanitized results');export.clicked.connect(self.export_job);controls.addWidget(export);lay.addLayout(controls)
        filters=QHBoxLayout();self.state_filter=QComboBox();self.state_filter.addItems(['All','attention','queued','running','awaiting_verification','needs_phone_data','cooling_down','uncertain','succeeded','associated','ineligible','declined','failed']);self.state_filter.currentTextChanged.connect(lambda:self.refresh_tasks(True));filters.addWidget(self.state_filter)
        prev=QPushButton('Previous 250');nxt=QPushButton('Next 250');prev.clicked.connect(lambda:self.page_tasks(-250));nxt.clicked.connect(lambda:self.page_tasks(250));filters.addWidget(prev);filters.addWidget(nxt);self.page_label=QLabel();filters.addWidget(self.page_label);filters.addStretch(1);lay.addLayout(filters)
        self.tasks_model=RecordModel([('id','Task'),('order_number','Order #'),('state','Outcome'),('attempts','Attempts'),('retry_display','Next eligible'),('message','Details')]);self.tasks_table=table_for(self.tasks_model);self.tasks_table.setColumnWidth(5,550);lay.addWidget(self.tasks_table,1)
        act=QHBoxLayout();open_btn=QPushButton('Show Apple browser');go=QPushButton('Continue / Re-read Apple');open_btn.clicked.connect(self.focus_task);go.clicked.connect(self.continue_task);act.addWidget(open_btn);act.addWidget(go);act.addStretch(1);lay.addLayout(act)
        caution=QLabel('Continue reconciles the current Apple page. It never repeats an uncertain cancellation or payment submission automatically. A decline requires a newly reviewed batch after correction.');caution.setWordWrap(True);lay.addWidget(caution)
    def _routes_page(self):
        page=QWidget();page.setObjectName('applePage');lay=QVBoxLayout(page);lay.setContentsMargins(18,18,18,18);lay.setSpacing(10);self.tabs.addTab(page,'Proxies')
        label=QLabel('Step 4 of 4 — optional. Import or paste proxies, preview valid rows, then explicitly save them. Testing checks only the selected saved proxy endpoints; it does not prove Apple sign-in works.');label.setWordWrap(True);label.setObjectName('muted');lay.addWidget(label)
        self.proxy_text=QPlainTextEdit();self.proxy_text.setPlaceholderText('One per line: http://host:port or http://user:password@host:port\nAlso accepts host:port:user:password. IPv6 requires URL form.');self.proxy_text.setMaximumHeight(130);self.proxy_text.textChanged.connect(self._proxy_text_changed);lay.addWidget(self.proxy_text)
        controls=QHBoxLayout();preview=QPushButton('Preview Import');preview.clicked.connect(self.preview_routes);file_btn=QPushButton('Load Proxy List');file_btn.clicked.connect(self.load_routes);self.save_routes_btn=QPushButton('Save Proxies');self.save_routes_btn.setObjectName('primaryButton');self.save_routes_btn.clicked.connect(self.save_routes);controls.addWidget(preview);controls.addWidget(file_btn);controls.addWidget(self.save_routes_btn);controls.addStretch(1);lay.addLayout(controls)
        self.route_save_status=QLabel('Saved proxies persist across restarts. Enabled routes may be used automatically after a transport/proxy failure; explicit Apple throttling still uses cooldown/backoff.');self.route_save_status.setWordWrap(True);self.route_save_status.setObjectName('muted');lay.addWidget(self.route_save_status)
        manage=QHBoxLayout();add_route=QPushButton('Add proxy…');add_route.clicked.connect(self.add_route);edit_route=QPushButton('Edit selected…');edit_route.clicked.connect(self.edit_selected_route);delete_route=QPushButton('Delete selected…');delete_route.clicked.connect(self.delete_selected_routes);delete_all=QPushButton('Delete all…');delete_all.clicked.connect(self.delete_all_routes);enable=QPushButton('Enable selected');enable.clicked.connect(lambda:self.set_selected_routes_enabled(True));disable=QPushButton('Disable selected');disable.clicked.connect(lambda:self.set_selected_routes_enabled(False));[manage.addWidget(b) for b in (add_route,edit_route,delete_route,delete_all,enable,disable)];manage.addStretch(1);lay.addLayout(manage)
        self.routes_model=RouteModel([('selected','Select'),('enabled_display','Enabled'),('server','Proxy (credentials hidden)'),('auth_display','Authentication'),('state','Test state'),('last_check','Last test'),('message','Result / notes')]);self.routes_model.selection_changed.connect(self._route_selection_changed);self.routes_table=table_for(self.routes_model);self.routes_table.setSortingEnabled(True);self.routes_table.setColumnWidth(0,65);self.routes_table.setColumnWidth(1,80);self.routes_table.setColumnWidth(2,310);self.routes_table.setColumnWidth(3,180);lay.addWidget(self.routes_table,1)
        test_row=QHBoxLayout();self.route_selection_label=QLabel('0 selected');test_row.addWidget(self.route_selection_label);select_all=QPushButton('Select all');select_all.clicked.connect(self.routes_model.select_all);test_row.addWidget(select_all);clear=QPushButton('Clear selection');clear.clicked.connect(self.routes_model.clear_selection);test_row.addWidget(clear);self.test_routes_btn=QPushButton('Test Selected (0)');self.test_routes_btn.clicked.connect(self.test_selected_routes);test_row.addWidget(self.test_routes_btn);self.stop_routes_btn=QPushButton('Stop Tests');self.stop_routes_btn.clicked.connect(self.stop_route_tests);self.stop_routes_btn.setEnabled(False);test_row.addWidget(self.stop_routes_btn);test_row.addStretch(1);lay.addLayout(test_row)
        detail=QLabel('Passed = the configured proxy endpoint accepted a TCP connection within the timeout. This test never falls back to Direct, never changes the active Apple session, and never sends an Apple order action.');detail.setWordWrap(True);detail.setObjectName('muted');lay.addWidget(detail)

    def refresh(self):
        self._refreshing=True
        try:
            cid=self.account.currentData();self.account.blockSignals(True);self.account.clear()
            for c in self.store.connections():self.account.addItem(c['email']+' - '+c['state'],c['id'])
            i=self.account.findData(cid);self.account.setCurrentIndex(max(0,i));self.account.blockSignals(False)
            rid=self.route.currentData();self.route.clear();self.route.addItem('Direct (no proxy)','')
            routes=self.store.route_rows(False)
            for r in routes:self.route.addItem(r['server']+(' (credentials)' if r.get('has_auth') else '')+(' [disabled]' if not r.get('enabled',1) else ''),r['id'])
            self.route.setCurrentIndex(max(0,self.route.findData(rid)));self._set_route_rows(routes)
            self.account_changed();self.refresh_phones();self.refresh_jobs()
        finally:self._refreshing=False
    def account_changed(self):
        c=self.store.connection(self.account.currentData())
        if not c:
            self.connection_info.setText('No Apple Account configured yet. Add the account that owns the orders, then connect it.');self.connect_btn.setText('Connect Apple Account');self.connect_btn.setEnabled(False);self.verify_btn.setVisible(False);self.confirm_identity_btn.setVisible(False);self.disconnect_btn.setEnabled(False);self.forget_btn.setEnabled(False);return
        self._refreshing=True
        self.browser.setCurrentText(c['browser']);self.route.setCurrentIndex(max(0,self.route.findData(c['route_id'])));self.auto.setChecked(bool(c['auto_refresh']));self.interval.setValue(c['refresh_minutes']);self._refreshing=False
        state=c['state'] or 'disconnected';friendly={'disconnected':'Not connected','opening_browser':'Opening browser','waiting_sign_in':'Waiting for you to sign in','waiting_verification':'Waiting for Apple verification','checking_account':'Checking account','connected':'Connected','identity_confirmation':'Account identity needs confirmation','session_expired':'Session expired','connection_failed':'Connection failed','connection_cancelled':'Connection cancelled','auth_required':'Waiting for sign-in','route_switching':'Switching network route','circuit_open':'Network attention required','awaiting_action':'Waiting for your action'}.get(state,state.replace('_',' ').title())
        self.connection_info.setText(f"Expected account: {c['email']}\nStatus: {friendly}\nIdentity evidence: {c['identity_method'] or 'Not verified'}\nLast authentication: {c['last_auth_at'] or 'Never'}\n{c['reason'] or ''}")
        if state=='connected':self.connection_info.setObjectName('appleStatusGood');self.connect_btn.setText('Reopen / Reconnect Browser')
        elif state in ('connection_failed','session_expired'):self.connection_info.setObjectName('appleStatusBad');self.connect_btn.setText('Reconnect Apple Account')
        else:self.connection_info.setObjectName('appleBanner');self.connect_btn.setText('Connect Apple Account' if state in ('disconnected','connection_cancelled','browser_missing') else 'Reopen Apple Browser')
        self.connection_info.style().unpolish(self.connection_info);self.connection_info.style().polish(self.connection_info)
        waiting=state in ('opening_browser','waiting_sign_in','waiting_verification','checking_account')
        if state in ('waiting_sign_in','waiting_verification','checking_account'):
            self.connect_btn.setText('Show Apple Sign-in Browser')
        self.connect_btn.setEnabled(state!='opening_browser');self.connect_btn.setToolTip('Bring the dedicated Apple browser to the front.' if waiting and state!='opening_browser' else '')
        self.verify_btn.setVisible(state not in ('disconnected','connection_cancelled','browser_missing','opening_browser','connection_failed'));self.verify_btn.setText('Check sign-in again');self.confirm_identity_btn.setVisible(state=='identity_confirmation');self.disconnect_btn.setEnabled(state not in ('disconnected','connection_cancelled'));self.forget_btn.setEnabled(True)

    def primary_connection_action(self):
        c=self.store.connection(self.account.currentData())
        if c and c.get('state') in ('waiting_sign_in','waiting_verification','checking_account','identity_confirmation'):
            self.ensure_worker().send('focus',connection_id=c['id']);self.feedback('Apple sign-in browser brought forward. Complete the Apple Account sign-in/verification there; this page checks automatically.');return
        self.connection_action('connect')
    def add_account(self):
        email,ok=QInputDialog.getText(self,'Connect Apple Account','Expected Apple Account email (not the guest-order alias):')
        if not ok:return
        try:cid=self.store.add_connection(email,self.browser.currentText(),self.route.currentData() or '')
        except ValueError as e:QMessageBox.warning(self,'Apple Account',str(e));return
        self.refresh();self.account.setCurrentIndex(self.account.findData(cid))
    def save_preferences(self):
        if self._refreshing:return
        cid=self.account.currentData()
        if cid:
            with self.db.conn:self.db.conn.execute('UPDATE apple_connections SET auto_refresh=?,refresh_minutes=? WHERE id=?',(int(self.auto.isChecked()),self.interval.value(),cid))
    def connection_action(self,command):
        cid=self.account.currentData();c=self.store.connection(cid)
        if not c:self.feedback('Add or select an Apple Account first.');return
        if command=='connect':
            if c['next_at']>time.time():self.feedback('Apple cooldown is still active. Reconnecting cannot bypass it.');return
            changed=(c['browser']!=self.browser.currentText() or c['route_id']!=(self.route.currentData() or ''))
            if changed and c['state'] not in ('disconnected','browser_missing'):
                self.feedback('Disconnect before changing the browser or proxy route.');return
            with self.db.conn:self.db.conn.execute('UPDATE apple_connections SET browser=?,route_id=? WHERE id=?',(self.browser.currentText(),self.route.currentData() or '',cid))
        confirmed=False
        if command=='confirm':
            confirmed=QMessageBox.question(self,'Confirm visible Apple identity',f"Have you checked inside the dedicated browser that the signed-in account is exactly {c['email']}?\n\nThis records USER-confirmed identity, not a remotely verified account email.")==QMessageBox.Yes
            if not confirmed:return
            command='verify'
        if command=='signout' and QMessageBox.question(self,'Forget app session','Close this app browser and delete its protected saved session? Other normal-browser sessions are unaffected.')!=QMessageBox.Yes:return
        worker=self.ensure_worker();worker.send('pace',seconds=self.pace.value());worker.send(command,connection_id=cid,identity_confirmed=confirmed)
        self.feedback('Opening/checking the dedicated Apple browser… Follow the instructions in that window; this page will update automatically.')
    def import_profiles(self,custom):
        if self.importer and self.importer.isRunning():self.feedback('A profile import is already running.');return
        files,_=QFileDialog.getOpenFileNames(self,'Import profile JSON','','JSON files (*.json);;All files (*)')
        if not files:return
        mapping=None
        if custom:
            dialog=MappingDialog(files[0],self)
            if dialog.exec()!=QDialog.Accepted:return
            mapping=dialog.mapping()
        self.feedback(f'Importing {len(files):,} JSON file(s)…');self.importer=ImportWorker(type(self.db),self.db.path,files,mapping,self)
        self.importer.progress.connect(lambda r:self.import_summary.setText(f"{r.get('files',0)} files | {r.get('records',0):,} records | {r.get('new_candidates',0):,} new candidates"))
        self.importer.done.connect(self.import_done);self.importer.start()
    def import_done(self,r):
        self.import_summary.setText(' | '.join(f'{k}: {r.get(k,0):,}' for k in ('files','records','accepted','new_candidates','duplicates','invalid','unmatched_aliases')))
        self.refresh_phones();self.changed.emit();self.feedback('Phone mapping import finished. '+self.import_summary.text())
        if r.get('errors'):
            box=QMessageBox(self);box.setWindowTitle('Profile import results');box.setText('Valid records were kept. Some files/records need attention; use Import with field mapping for unfamiliar schemas.');box.setDetailedText('\n'.join(r['errors']));box.exec()
    def refresh_phones(self):
        text=self.phone_search.text().strip() if hasattr(self,'phone_search') else ''
        rows=self.db.conn.execute('''SELECT p.*,(SELECT COUNT(*) FROM apple_phone_sources s WHERE s.candidate_id=p.id) AS sources FROM apple_phone_candidates p
            WHERE email LIKE ? ESCAPE '\\' OR normalized LIKE ? ESCAPE '\\' ORDER BY p.id DESC LIMIT 500''',('%'+text.replace('\\','\\\\').replace('%','\\%').replace('_','\\_')+'%',)*2).fetchall()
        self.phone_model.set_rows([dict(r) for r in rows])
    def inspect_profile(self):
        r=selected_record(self.phone_table,self.phone_model)
        if not r:return
        d=QDialog(self);d.setWindowTitle('Candidate sources');lay=QVBoxLayout(d);v=QPlainTextEdit('\n'.join(f"{s['filename']} {s['record_path']}.{s['field_path']} | Order hint: {s['order_number'] or 'none'}" for s in self.store.phone_sources(r['id'])));v.setReadOnly(True);lay.addWidget(v);d.resize(850,300);d.exec()
    def queue_batch(self,ids,action):
        if not self.store.connections():self.owner.show_page(self.owner.PAGE_APPLE,self.owner.apple_nav);self.banner.setText('Add your intended Apple Account before preparing a batch.');return
        d=PreviewDialog(self.store,ids,action,self)
        if d.exec()!=QDialog.Accepted:return
        try:jid=self.store.create_job(d.data,confirmed=action!='refresh',priority=5 if action=='refresh' else 10)
        except ValueError as e:QMessageBox.warning(self,'Apple job',str(e));return
        self.active_job=jid;self.offset=0;self.ensure_worker().send('wake');self.owner.show_page(self.owner.PAGE_APPLE,self.owner.apple_nav);self.tabs.setCurrentIndex(2);self.refresh_jobs()
        self.feedback('Batch queued. Connect and verify the chosen account to start. Final cancellation/payment submissions are performed in Apple\'s visible browser.')
    def refresh_jobs(self):
        self.jobs_model.set_rows(self.store.jobs())
        for i,r in enumerate(self.jobs_model.rows):
            if r['id']==self.active_job:self.jobs_table.selectRow(i);break
        self.refresh_tasks(False)
    def job_selected(self,index):
        r=selected_record(self.jobs_table,self.jobs_model)
        if r:self.active_job=r['id'];self.offset=0;self.refresh_tasks(False)
    def refresh_tasks(self,reset=False):
        if reset:self.offset=0
        task=selected_record(self.tasks_table,self.tasks_model);tid=task['id'] if task else None
        filt=self.state_filter.currentText();rows=self.store.tasks(self.active_job,'' if filt=='All' else filt,250,self.offset) if self.active_job else []
        for r in rows:r['retry_display']=time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(r['next_at'])) if r['next_at'] else ''
        self.tasks_model.set_rows(rows)
        for i,r in enumerate(rows):
            if r['id']==tid:self.tasks_table.selectRow(i);break
        self.page_label.setText(f'{self.offset+1}-{self.offset+len(rows)}' if rows else 'No tasks on this page')
    def page_tasks(self,delta):self.offset=max(0,self.offset+delta);self.refresh_tasks(False)
    def control(self,cmd):
        if not self.active_job:return
        if cmd=='stop':
            if QMessageBox.question(self,'Stop Job','Stop unfinished tasks? Completed Apple actions are NOT reversed. Uncertain actions remain marked uncertain.')!=QMessageBox.Yes:return
            self.ensure_worker().send('stop_job',job_id=self.active_job)
        else:self.store.job_control(self.active_job,cmd);self.ensure_worker().send('wake')
        self.refresh_jobs()
    def _selected_job_ids(self):
        rows=sorted({i.row() for i in self.jobs_table.selectionModel().selectedRows()}) if self.jobs_table.selectionModel() else []
        ids=[self.jobs_model.rows[i]['id'] for i in rows if 0<=i<len(self.jobs_model.rows)]
        if not ids and self.active_job:ids=[self.active_job]
        return ids
    def remove_selected_jobs(self):
        ids=self._selected_job_ids()
        if not ids:self.feedback('Select one or more jobs to remove from this view.');return
        active=[]
        for jid in ids:
            row=self.db.conn.execute("SELECT state FROM apple_jobs WHERE id=?",(jid,)).fetchone()
            if row and row['state'] in ('queued','running','paused'):active.append(jid)
        stop_active=False
        if active:
            if QMessageBox.question(self,'Stop and remove jobs',f'{len(active):,} selected job(s) are still active. Stop unfinished tasks and remove all {len(ids):,} selected job(s) from this view? Completed Apple actions are NOT reversed.')!=QMessageBox.Yes:return
            stop_active=True
        elif QMessageBox.question(self,'Remove jobs',f'Remove {len(ids):,} selected job(s) from this view? Audit records are retained.')!=QMessageBox.Yes:return
        removed=0
        for jid in ids:
            try:removed+=int(bool(self.store.archive_job(jid,stop_unfinished=stop_active)))
            except ValueError:pass
        if self.active_job in ids:self.active_job='';self.offset=0
        self.feedback(f'Removed {removed:,} job(s) from the Jobs view. Completed Apple actions were not reversed.');self.refresh_jobs()
    def remove_completed_jobs(self):
        n=self.store.archive_completed_jobs();self.feedback(f'Removed {n:,} completed/stopped job(s) from the Jobs view. Audit records were retained.');self.active_job='';self.offset=0;self.refresh_jobs()

    def focus_task(self):
        t=selected_record(self.tasks_table,self.tasks_model)
        if t:self.ensure_worker().send('focus',connection_id=t['connection_id'],task_id=t['id'])
    def continue_task(self):
        t=selected_record(self.tasks_table,self.tasks_model)
        if t:self.ensure_worker().send('continue',task_id=t['id'])
    def export_job(self):
        if not self.active_job:return
        path,_=QFileDialog.getSaveFileName(self,'Export Apple job results','apple_job_results.csv','CSV (*.csv)')
        if path:self.store.export_job(self.active_job,path)
    def _proxy_text_changed(self):
        if getattr(self,'_refreshing',False):return
        self.route_dirty=bool(self.proxy_text.toPlainText().strip()) or bool(self.pending_routes)
        self._update_route_controls()
    def _set_route_rows(self,saved_rows):
        rows=[]
        for r in saved_rows:
            x=dict(r);x['enabled_display']='Yes' if x.get('enabled',1) else 'No';x['auth_display']='Credentials configured' if x.get('has_auth') else 'No credentials';x['state']=x.get('state') or 'Not tested';x['saved']=True;rows.append(x)
        saved_ids={str(r.get('id')) for r in rows}
        for p in self.pending_routes:
            if p['id'] in saved_ids:continue
            rows.append({'id':p['id'],'enabled_display':'Yes','server':p['server'],'auth_display':'Credentials configured' if p.get('username') else 'No credentials','state':'Unsaved','last_check':'','message':'Save before testing','has_auth':int(bool(p.get('username'))),'saved':False,'revision':1})
        self.routes_model.set_rows(rows);self._route_selection_changed();self._update_route_controls()
    def preview_routes(self):
        errors=[];valid=[];seen=set()
        for n,line in enumerate(self.proxy_text.toPlainText().splitlines(),1):
            if not line.strip():continue
            try:
                proxy=parse_proxy(line);rid=proxy_identity(proxy)
                if rid in seen:continue
                seen.add(rid);proxy['id']=rid;valid.append(proxy)
            except Exception as exc:errors.append(f"Line {n}: {safe_message(str(exc)) if isinstance(exc,ValueError) else type(exc).__name__}")
        self.pending_routes=valid;self.route_errors=errors;self.route_dirty=bool(valid or errors or self.proxy_text.toPlainText().strip());self.refresh()
        message=f'Previewed {len(valid):,} valid proxy configuration(s)'
        if errors:message+=f'; {len(errors):,} rejected. '+ '; '.join(errors[:4])
        if valid:message+=' — click Save Proxies to persist the valid rows.'
        self.feedback(message);self.route_save_status.setText(message)
    def save_routes(self):
        if not self.pending_routes and self.proxy_text.toPlainText().strip():self.preview_routes()
        if not self.pending_routes:
            if self.route_errors:self.feedback('No valid proxies are ready to save. Correct the rejected rows and preview again.')
            else:self.feedback('There are no unsaved valid proxies to save.')
            return False
        try:
            # Secrets are stored first in the protected vault. SQLite stores only endpoint metadata/fingerprints.
            for proxy in self.pending_routes:self.vault.put('route-'+proxy['id'],proxy)
            with self.db.conn:
                for proxy in self.pending_routes:
                    self.db.conn.execute("INSERT INTO apple_routes(id,identity,server,state,last_check,message,has_auth,revision) VALUES(?,?,?,'Not tested','','Saved; not tested',?,1) ON CONFLICT(identity) DO UPDATE SET server=excluded.server,has_auth=excluded.has_auth",
                        (proxy['id'],proxy['id'],proxy['server'],int(bool(proxy.get('username')))))
            count=len(self.pending_routes);rejected=len(self.route_errors);self.pending_routes=[];self.route_dirty=False
            self._refreshing=True;self.proxy_text.clear();self._refreshing=False;self.refresh()
            message=f'Saved {count:,} proxy configuration(s). They will be available after restart.'
            if rejected:message+=f' {rejected:,} rejected row(s) were not saved.'
            self.route_save_status.setText(message);self.feedback(message);return True
        except Exception as exc:
            self.route_dirty=True;message='Save failed. Unsaved proxy edits were kept so you can retry. '+safe_message(str(exc));self.route_save_status.setText(message);self.feedback(message);self._update_route_controls();return False
    def load_routes(self):
        path,_=QFileDialog.getOpenFileName(self,'Load proxy list','','Text files (*.txt)')
        if path:
            try:
                if Path(path).stat().st_size>2*1024*1024:raise ValueError('Proxy list exceeds 2 MiB; split the list')
                self._refreshing=True;self.proxy_text.setPlainText(Path(path).read_text(encoding='utf-8-sig'));self._refreshing=False;self.route_dirty=True;self.preview_routes()
            except Exception as exc:self.feedback('Could not load proxy list: '+safe_message(str(exc)))
    def add_route(self):
        text,ok=QInputDialog.getText(self,'Add proxy','Proxy (http://host:port, http://user:password@host:port, or host:port:user:password):')
        if not ok or not text.strip():return
        try:
            proxy=parse_proxy(text.strip());proxy['id']=proxy_identity(proxy);self.vault.put('route-'+proxy['id'],proxy)
            with self.db.conn:self.db.conn.execute("INSERT INTO apple_routes(id,identity,server,state,last_check,message,has_auth,revision,enabled) VALUES(?,?,?,'Not tested','','Saved; not tested',?,1,1) ON CONFLICT(identity) DO UPDATE SET server=excluded.server,has_auth=excluded.has_auth,revision=apple_routes.revision+1",(proxy['id'],proxy['id'],proxy['server'],int(bool(proxy.get('username')))))
            self.feedback('Proxy saved. Select it to test, edit, enable/disable, or delete.');self.refresh()
        except Exception as exc:self.feedback('Proxy was not saved: '+safe_message(str(exc)))
    def edit_selected_route(self):
        ids=list(self.routes_model.selected_ids)
        if len(ids)!=1:self.feedback('Select exactly one saved proxy to edit.');return
        rid=ids[0];row=self.db.conn.execute('SELECT * FROM apple_routes WHERE id=?',(rid,)).fetchone()
        if not row:self.feedback('The selected proxy no longer exists.');self.refresh();return
        text,ok=QInputDialog.getText(self,'Edit proxy','Enter the complete replacement proxy. Saved passwords are never displayed:',QLineEdit.EchoMode.Normal,row['server'])
        if not ok or not text.strip():return
        try:
            proxy=parse_proxy(text.strip());new_id=proxy_identity(proxy);proxy['id']=new_id;self.vault.put('route-'+new_id,proxy)
            enabled=int(row['enabled']) if 'enabled' in row.keys() else 1
            with self.db.conn:
                self.db.conn.execute("INSERT INTO apple_routes(id,identity,server,state,last_check,message,has_auth,revision,enabled) VALUES(?,?,?,'Not tested','','Edited; retest this route',?,1,?) ON CONFLICT(identity) DO UPDATE SET server=excluded.server,has_auth=excluded.has_auth,state='Not tested',last_check='',message='Edited; retest this route',revision=apple_routes.revision+1,enabled=excluded.enabled",(new_id,new_id,proxy['server'],int(bool(proxy.get('username'))),enabled))
                if new_id!=rid:
                    self.db.conn.execute('UPDATE apple_connections SET route_id=? WHERE route_id=?',(new_id,rid));self.db.conn.execute('DELETE FROM apple_routes WHERE id=?',(rid,))
            if new_id!=rid:self.vault.delete('route-'+rid)
            self.routes_model.selected_ids={new_id};self.feedback('Proxy updated. Retest it before relying on it for failover.');self.refresh()
        except Exception as exc:self.feedback('Proxy edit failed: '+safe_message(str(exc)))
    def delete_selected_routes(self):
        ids=list(self.routes_model.selected_ids)
        if not ids:self.feedback('Select one or more saved proxies to delete.');return
        if QMessageBox.question(self,'Delete selected proxies',f'Delete {len(ids):,} selected proxy configuration(s)? Accounts using one of these routes will fall back to Direct until another route is chosen.')!=QMessageBox.Yes:return
        self.store.delete_routes(ids)
        for rid in ids:self.vault.delete('route-'+rid)
        self.routes_model.clear_selection();self.feedback(f'Deleted {len(ids):,} proxy configuration(s).');self.refresh()
    def delete_all_routes(self):
        ids=[r['id'] for r in self.store.route_rows(False)]
        if not ids:self.feedback('There are no saved proxies to delete.');return
        if QMessageBox.question(self,'Delete all proxies',f'Delete all {len(ids):,} saved proxy configurations? This cannot be undone.')!=QMessageBox.Yes:return
        self.store.delete_routes(ids)
        for rid in ids:self.vault.delete('route-'+rid)
        self.routes_model.clear_selection();self.feedback(f'Deleted all {len(ids):,} saved proxies.');self.refresh()
    def set_selected_routes_enabled(self,enabled):
        ids=list(self.routes_model.selected_ids)
        if not ids:self.feedback('Select one or more saved proxies first.');return
        self.store.set_route_enabled(ids,enabled);self.feedback(('Enabled ' if enabled else 'Disabled ')+f'{len(ids):,} selected proxy route(s).');self.refresh()

    def _route_selection_changed(self):
        n=len(self.routes_model.selected_ids) if hasattr(self,'routes_model') else 0
        if hasattr(self,'route_selection_label'):self.route_selection_label.setText(f'{n:,} selected')
        if hasattr(self,'test_routes_btn'):self.test_routes_btn.setText(f'Test Selected ({n:,})');self._update_route_controls()
    def _update_route_controls(self):
        if not hasattr(self,'save_routes_btn'):return
        testing=bool(self.route_test_worker and self.route_test_worker.isRunning())
        self.save_routes_btn.setEnabled(bool(self.route_dirty) and not testing)
        selected=len(self.routes_model.selected_ids) if hasattr(self,'routes_model') else 0
        self.test_routes_btn.setEnabled(selected>0 and not self.route_dirty and not testing)
        self.stop_routes_btn.setEnabled(testing)
        if self.route_dirty and selected:self.test_routes_btn.setToolTip('Save pending proxy changes before testing the selected saved proxies.')
        elif not selected:self.test_routes_btn.setToolTip('Select one or more saved proxies using the checkboxes.')
        else:self.test_routes_btn.setToolTip('Tests exactly the selected saved proxy endpoints; no direct fallback.')
    def test_selected_routes(self):
        if self.route_dirty:self.feedback('Save pending proxy changes before testing.');return
        if self.route_test_worker and self.route_test_worker.isRunning():self.feedback('A proxy test batch is already running.');return
        selected=tuple(sorted(self.routes_model.selected_ids))
        if not selected:self.feedback('Select one or more saved proxies first.');return
        frozen=[]
        for rid in selected:
            row=self.db.conn.execute('SELECT * FROM apple_routes WHERE id=?',(rid,)).fetchone()
            proxy=self.vault.get('route-'+rid) if row else None
            if row and proxy:frozen.append({'id':rid,'revision':int(row['revision'] or 1),'proxy':dict(proxy)})
            elif row:
                with self.db.conn:self.db.conn.execute("UPDATE apple_routes SET state='Failed',last_check=?,message='Protected proxy credentials are unavailable; save this proxy again.' WHERE id=?",(utc_now(),rid))
        if not frozen:self.refresh();self.feedback('None of the selected proxies had an available saved configuration.');return
        with self.db.conn:
            for item in frozen:self.db.conn.execute("UPDATE apple_routes SET state='Queued',message='Waiting for proxy endpoint test' WHERE id=?",(item['id'],))
        self.refresh();self.feedback(f'Testing exactly {len(frozen):,} selected saved proxy endpoint(s), up to 3 at a time…')
        worker=RouteTestBatchWorker(frozen,self);self.route_test_worker=worker;worker.result.connect(self._route_test_result);worker.finished_batch.connect(self._route_test_finished);worker.start();self._update_route_controls()
    def _route_test_result(self,rid,state,message):
        row=self.db.conn.execute('SELECT id FROM apple_routes WHERE id=?',(rid,)).fetchone()
        if row:
            with self.db.conn:self.db.conn.execute('UPDATE apple_routes SET state=?,last_check=?,message=? WHERE id=?',(state,utc_now() if state in ('Passed','Failed','Stopped') else '',safe_message(message),rid))
        self.refresh()
    def _route_test_finished(self,passed,failed,stopped):
        self.feedback(f'Proxy tests finished: {passed} passed, {failed} failed, {stopped} stopped. Passed means TCP reachability of the saved proxy endpoint only.')
        self.route_test_worker=None;self.refresh();self._update_route_controls()
    def stop_route_tests(self):
        if self.route_test_worker and self.route_test_worker.isRunning():self.route_test_worker.stop_requested.set();self.feedback('Stop requested. Tests already in progress may finish; queued tests will be marked stopped.')
    def _confirm_route_leave(self):
        if not self.route_dirty:return True
        box=QMessageBox(self);box.setWindowTitle('Unsaved proxy changes');box.setText('Proxy edits have not been saved.');box.setInformativeText('Save the valid proxy configurations before leaving?')
        save=box.addButton('Save Proxies',QMessageBox.AcceptRole);discard=box.addButton('Discard',QMessageBox.DestructiveRole);cancel=box.addButton('Cancel',QMessageBox.RejectRole);box.exec()
        if box.clickedButton() is save:return bool(self.save_routes())
        if box.clickedButton() is discard:self.pending_routes=[];self.route_errors=[];self.route_dirty=False;self._refreshing=True;self.proxy_text.clear();self._refreshing=False;self.refresh();return True
        return False
    def _tab_changed(self,index):
        if self._changing_tab:return
        previous=self._last_tab_index
        if previous==3 and index!=3 and self.route_dirty:
            if not self._confirm_route_leave():
                self._changing_tab=True;self.tabs.setCurrentIndex(3);self._changing_tab=False;return
        self._last_tab_index=index
    def confirm_pending_route_exit(self):return self._confirm_route_leave()
    def feedback(self,message):
        self.banner.setText(str(message));
        if hasattr(self.owner,'sync_status'):self.owner.sync_status.setText(str(message))
    def show_getting_started(self):
        text=("1. CONNECT: add the Apple Account that owns the orders, click Connect Apple Account, and finish sign-in/2FA in the dedicated Apple browser. Wait for Connected.\n\n"
              "2. IMPORT: add JSON phone mappings and, if desired, saved proxies. Proxies are a failover pool for network/proxy failures, not just login.\n\n"
              "3. SELECT: on any order table, click one checkbox, Ctrl-click individual rows, or Shift-click a range. Select All is also available.\n\n"
              "4. ACTION + START: choose Link, Refresh, Cancel, or Payment Update beside the order selection and press START. Review the exact frozen targets.\n\n"
              "5. RESULTS: Jobs & results shows progress, cooldowns, attention items, retries, and lets you stop/remove job history.\n\n"
              "Passwords, two-factor codes and raw payment details stay on Apple's page. Explicit Apple throttling is respected with cooldown/backoff rather than bypassed by proxy rotation.")
        QMessageBox.information(self,'Getting Started — Apple Account',text)


class RouteTestBatchWorker(QThread):
    result=Signal(str,str,str);finished_batch=Signal(int,int,int)
    def __init__(self,items,parent=None):super().__init__(parent);self.items=list(items);self.stop_requested=threading.Event()
    def _one(self,item):
        rid=item['id'];proxy=item['proxy']
        if self.stop_requested.is_set():return rid,'Stopped','Stopped before testing began'
        self.result.emit(rid,'Testing','Opening TCP connection to the saved proxy endpoint…')
        try:
            with socket.create_connection((proxy['host'],int(proxy['port'])),timeout=5):pass
            if self.stop_requested.is_set():return rid,'Passed','Proxy endpoint reachable (TCP). Stop was requested after this test started.'
            return rid,'Passed','Proxy endpoint reachable (TCP only; Apple sign-in not tested)'
        except OSError as exc:return rid,'Failed','Proxy endpoint TCP connection failed: '+type(exc).__name__
    def run(self):
        passed=failed=stopped=0
        with ThreadPoolExecutor(max_workers=3,thread_name_prefix='proxy-test') as pool:
            futures=[pool.submit(self._one,item) for item in self.items]
            for future in as_completed(futures):
                try:rid,state,message=future.result()
                except Exception:continue
                if state=='Passed':passed+=1
                elif state=='Stopped':stopped+=1
                else:failed+=1
                self.result.emit(rid,state,message)
        self.finished_batch.emit(passed,failed,stopped)


def actions_button(owner,model):
    """Compact action selector + one explicit START control for order tables."""
    wrap=QWidget();layout=QHBoxLayout(wrap);layout.setContentsMargins(0,0,0,0);layout.setSpacing(6)
    action=QComboBox();action.setMinimumWidth(190)
    action.addItem('Link to Apple Account','associate');action.addItem('Refresh from Apple','refresh');action.addItem('Cancel on Apple…','cancel');action.addItem('Update payment…','payment')
    start=QPushButton('START');start.setObjectName('primaryButton');start.setToolTip('Run the selected Apple action for the checked orders')
    def run():
        ids=list(model.checked_order_ids())
        if not ids:
            QMessageBox.information(wrap,'Apple action','Select one or more orders first. You can Shift-click checkboxes to select a range.')
            return
        owner.apple_page.queue_batch(ids,action.currentData())
    start.clicked.connect(run);layout.addWidget(action);layout.addWidget(start);return wrap
