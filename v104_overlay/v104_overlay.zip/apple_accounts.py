"""Durable Apple workspace: phones, connections, snapshots, and frozen bulk jobs.

This module is Qt/browser independent. Authentication secrets are deliberately
not represented in its schema. Only a browser adapter can create a confirmed
Apple observation; opening a URL is never a confirmation.
"""
from __future__ import annotations
import csv
import hashlib
import json
import re
import sqlite3
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from apple_profiles import aliases, email_key, candidates, file_fingerprint, iter_records

SCHEMA_VERSION = 3
APPLE_EXTRA_STATUSES = ('Partially Canceled','Partially Shipped','Apple Update')
TERMINAL_TASKS = {'associated','already_associated','succeeded','ineligible','stopped','skipped','declined'}
ACTIONS = {'associate','refresh','cancel','payment'}


def utc_now():return datetime.now(timezone.utc).isoformat()

def safe_message(value, limit=600):
    """Diagnostics are fixed/adapted messages, never raw page/exception dumps."""
    text=str(value or '')
    text=re.sub(r'https?://\S+', '[URL omitted]', text)
    text=re.sub(r'(?i)(bearer|cookie|password|token|authorization|secret|cvv|cvc)\s*[:= ]\s*\S+',r'\1 [redacted]',text)
    text=re.sub(r'(?<!\w)(?:\d[ -]?){13,19}(?!\w)','[number redacted]',text)
    return re.sub(r'[\x00-\x08\x0b-\x1f]',' ',text)[:limit]


def backup_before_apple_migration(path):
    path=Path(path)
    if not path.exists():return
    c=sqlite3.connect(path,timeout=30)
    try:
        if c.execute("SELECT 1 FROM sqlite_master WHERE name='apple_schema'").fetchone():return
        folder=path.parent/'backups';folder.mkdir(parents=True,exist_ok=True)
        dest=folder/('before-apple-account-'+datetime.now().strftime('%Y%m%d-%H%M%S')+'.db')
        with sqlite3.connect(dest) as target:c.backup(target)
    finally:c.close()


def install_schema(conn):
    cols={r[1] for r in conn.execute('PRAGMA table_info(orders)')}
    additions={'account_status':'TEXT','account_raw_status':'TEXT','account_status_success_at':'TEXT',
               'account_status_event_at':'TEXT','account_status_attempt_at':'TEXT','account_status_error':'TEXT',
               'account_status_seq':'INTEGER NOT NULL DEFAULT 0','account_status_connection':'TEXT',
               'account_qty':'INTEGER','account_eta_text':'TEXT','account_items_json':'TEXT',
               'association_state':'TEXT','linked_apple_connection':'TEXT'}
    for k,t in additions.items():
        if k not in cols:conn.execute(f'ALTER TABLE orders ADD COLUMN {k} {t}')
    conn.executescript('''
    CREATE TABLE IF NOT EXISTS apple_schema(version INTEGER PRIMARY KEY);
    INSERT OR IGNORE INTO apple_schema VALUES(1);
    CREATE TABLE IF NOT EXISTS apple_meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
    INSERT OR IGNORE INTO apple_meta VALUES('sequence','0');
    CREATE TABLE IF NOT EXISTS apple_connections(
      id TEXT PRIMARY KEY,email TEXT NOT NULL UNIQUE,observed_email TEXT NOT NULL DEFAULT '',
      identity_method TEXT NOT NULL DEFAULT '',state TEXT NOT NULL DEFAULT 'disconnected',
      last_auth_at TEXT NOT NULL DEFAULT '',last_check_at TEXT NOT NULL DEFAULT '',
      reason TEXT NOT NULL DEFAULT '',browser TEXT NOT NULL DEFAULT 'Edge',route_id TEXT NOT NULL DEFAULT '',
      generation INTEGER NOT NULL DEFAULT 1,next_at REAL NOT NULL DEFAULT 0,failures INTEGER NOT NULL DEFAULT 0,
      auto_refresh INTEGER NOT NULL DEFAULT 0,refresh_minutes INTEGER NOT NULL DEFAULT 60,last_auto REAL NOT NULL DEFAULT 0);
    CREATE TABLE IF NOT EXISTS apple_routes(
      id TEXT PRIMARY KEY,identity TEXT NOT NULL UNIQUE,server TEXT NOT NULL,state TEXT NOT NULL DEFAULT 'Not tested',
      last_check TEXT NOT NULL DEFAULT '',message TEXT NOT NULL DEFAULT '',has_auth INTEGER NOT NULL DEFAULT 0,
      revision INTEGER NOT NULL DEFAULT 1,enabled INTEGER NOT NULL DEFAULT 1);
    CREATE TABLE IF NOT EXISTS apple_phone_candidates(
      id INTEGER PRIMARY KEY,email TEXT NOT NULL,phone_key TEXT NOT NULL,original TEXT NOT NULL,
      normalized TEXT NOT NULL,extension TEXT NOT NULL DEFAULT '',quality TEXT NOT NULL,note TEXT NOT NULL DEFAULT '',
      UNIQUE(email,phone_key));
    CREATE INDEX IF NOT EXISTS apple_phone_email ON apple_phone_candidates(email);
    CREATE TABLE IF NOT EXISTS apple_phone_sources(
      id INTEGER PRIMARY KEY,candidate_id INTEGER NOT NULL REFERENCES apple_phone_candidates(id) ON DELETE CASCADE,
      file_hash TEXT NOT NULL,filename TEXT NOT NULL,record_path TEXT NOT NULL,field_path TEXT NOT NULL,
      order_number TEXT NOT NULL DEFAULT '',original TEXT NOT NULL,imported_at TEXT NOT NULL,
      UNIQUE(candidate_id,file_hash,record_path,field_path));
    CREATE TABLE IF NOT EXISTS apple_phone_verification(
      order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,candidate_id INTEGER NOT NULL REFERENCES apple_phone_candidates(id),
      connection_id TEXT NOT NULL,result TEXT NOT NULL,updated_at TEXT NOT NULL,
      PRIMARY KEY(order_id,candidate_id,connection_id));
    CREATE TABLE IF NOT EXISTS apple_observations(
      id INTEGER PRIMARY KEY,order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
      connection_id TEXT NOT NULL,sequence INTEGER NOT NULL,observed_at TEXT NOT NULL,event_at TEXT NOT NULL DEFAULT '',
      raw_status TEXT NOT NULL,normalized_status TEXT NOT NULL,payload TEXT NOT NULL,UNIQUE(order_id,sequence));
    CREATE TABLE IF NOT EXISTS apple_jobs(
      id TEXT PRIMARY KEY,connection_id TEXT NOT NULL REFERENCES apple_connections(id),
      action TEXT NOT NULL,state TEXT NOT NULL,created_at TEXT NOT NULL,snapshot TEXT NOT NULL,
      confirmation_hash TEXT NOT NULL,priority INTEGER NOT NULL DEFAULT 10,archived_at TEXT NOT NULL DEFAULT '');
    CREATE TABLE IF NOT EXISTS apple_tasks(
      id INTEGER PRIMARY KEY,job_id TEXT NOT NULL REFERENCES apple_jobs(id) ON DELETE CASCADE,
      order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,state TEXT NOT NULL DEFAULT 'queued',
      attempts INTEGER NOT NULL DEFAULT 0,next_at REAL NOT NULL DEFAULT 0,sequence INTEGER NOT NULL DEFAULT 0,
      candidate_id INTEGER,submitted INTEGER NOT NULL DEFAULT 0,error_code TEXT NOT NULL DEFAULT '',
      message TEXT NOT NULL DEFAULT '',updated_at TEXT NOT NULL,scope TEXT NOT NULL,
      UNIQUE(job_id,order_id));
    CREATE INDEX IF NOT EXISTS apple_task_queue ON apple_tasks(state,next_at);
    CREATE TABLE IF NOT EXISTS apple_order_locks(order_id INTEGER PRIMARY KEY,task_id INTEGER NOT NULL REFERENCES apple_tasks(id) ON DELETE CASCADE);
    CREATE TABLE IF NOT EXISTS apple_audit(
      id INTEGER PRIMARY KEY,at TEXT NOT NULL,order_id INTEGER,connection_id TEXT,job_id TEXT,
      action TEXT NOT NULL,outcome TEXT NOT NULL,message TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS apple_audit_order ON apple_audit(order_id,id);
    ''')
    # v1.0.3 removes the old UNIQUE(server) constraint so two exact proxy
    # configurations may share a host/port while using different credentials.
    route_cols={r[1] for r in conn.execute('PRAGMA table_info(apple_routes)')}
    if 'identity' not in route_cols:
        conn.execute('ALTER TABLE apple_routes RENAME TO apple_routes_v102')
        conn.execute("""CREATE TABLE apple_routes(
          id TEXT PRIMARY KEY,identity TEXT NOT NULL UNIQUE,server TEXT NOT NULL,state TEXT NOT NULL DEFAULT 'Not tested',
          last_check TEXT NOT NULL DEFAULT '',message TEXT NOT NULL DEFAULT '',has_auth INTEGER NOT NULL DEFAULT 0,
          revision INTEGER NOT NULL DEFAULT 1,enabled INTEGER NOT NULL DEFAULT 1)""")
        for row in conn.execute('SELECT id,server,state,last_check,message,has_auth FROM apple_routes_v102'):
            identity=hashlib.sha256(('legacy\0'+str(row[1])).encode('utf-8')).hexdigest()
            conn.execute('INSERT INTO apple_routes(id,identity,server,state,last_check,message,has_auth,revision) VALUES(?,?,?,?,?,?,?,1)',
                         (row[0],identity,row[1],row[2] or 'Not tested',row[3],row[4],row[5]))
        conn.execute('DROP TABLE apple_routes_v102')
        conn.execute('UPDATE apple_schema SET version=?',(SCHEMA_VERSION,))
    elif 'revision' not in route_cols:
        conn.execute('ALTER TABLE apple_routes ADD COLUMN revision INTEGER NOT NULL DEFAULT 1')
    route_cols={r[1] for r in conn.execute('PRAGMA table_info(apple_routes)')}
    if 'enabled' not in route_cols:
        conn.execute('ALTER TABLE apple_routes ADD COLUMN enabled INTEGER NOT NULL DEFAULT 1')
    job_cols={r[1] for r in conn.execute('PRAGMA table_info(apple_jobs)')}
    if 'archived_at' not in job_cols:
        conn.execute("ALTER TABLE apple_jobs ADD COLUMN archived_at TEXT NOT NULL DEFAULT ''")
    current=conn.execute('SELECT COALESCE(MAX(version),1) FROM apple_schema').fetchone()[0]
    if int(current)<SCHEMA_VERSION:
        conn.execute('DELETE FROM apple_schema')
        conn.execute('INSERT INTO apple_schema(version) VALUES(?)',(SCHEMA_VERSION,))
    conn.commit()


class AppleStore:
    def __init__(self,db):self.db=db;self.c=db.conn
    def connections(self):return [dict(r) for r in self.c.execute('SELECT * FROM apple_connections ORDER BY email')]
    def connection(self,cid):
        row=self.c.execute('SELECT * FROM apple_connections WHERE id=?',(cid,)).fetchone()
        return dict(row) if row else None
    def add_connection(self,email,browser='Edge',route_id=''):
        email=email_key(email)
        existing=self.c.execute('SELECT id FROM apple_connections WHERE email=?',(email,)).fetchone()
        if existing:return existing[0]
        cid=uuid.uuid4().hex
        with self.c:self.c.execute('INSERT INTO apple_connections(id,email,browser,route_id) VALUES(?,?,?,?)',(cid,email,browser,route_id))
        return cid
    def connection_state(self,cid,state,reason='',observed_email='',method=''):
        now=utc_now()
        with self.c:
            self.c.execute("UPDATE apple_connections SET state=?,reason=?,last_check_at=? WHERE id=?",(state,safe_message(reason),now,cid))
            if state=='connected':
                self.c.execute("UPDATE apple_connections SET last_auth_at=?,observed_email=?,identity_method=?,failures=0 WHERE id=?",(now,observed_email,method,cid))
    def audit(self,oid,cid,jid,action,outcome,message):
        self.c.execute('INSERT INTO apple_audit(at,order_id,connection_id,job_id,action,outcome,message) VALUES(?,?,?,?,?,?,?)',
                       (utc_now(),oid,cid,jid,action,outcome,safe_message(message)))
    def all_alias_keys(self):
        keys=set()
        for row in self.c.execute('SELECT alias_emails FROM orders'):
            keys.update(aliases(row[0] or ''))
        return keys
    def import_files(self,paths,mapping=None,progress=None,stop=None):
        report={'files':0,'records':0,'accepted':0,'new_candidates':0,'duplicates':0,'invalid':0,'unmatched_aliases':0,'errors':[],'needs_mapping':[]}
        known=self.all_alias_keys();unmatched=set()
        for filename in paths:
            if stop and stop():break
            p=Path(filename);report['files']+=1
            try:
                digest=file_fingerprint(p)
                for record_path,record in iter_records(p,mapping):
                    if stop and stop():break
                    report['records']+=1
                    try:found=candidates(record,mapping)
                    except ValueError as e:
                        report['invalid']+=1
                        if len(report['errors'])<100:report['errors'].append(f'{p.name} {record_path}: {safe_message(e)}')
                        if 'schema' in str(e).lower() and p.name not in report['needs_mapping']:report['needs_mapping'].append(p.name)
                        continue
                    report['accepted']+=1
                    for value in found:
                        phone=value['phone'];email=value['email']
                        if email not in known:unmatched.add(email)
                        if phone.state!='valid':report['invalid']+=1
                        cur=self.c.execute('''INSERT OR IGNORE INTO apple_phone_candidates(email,phone_key,original,normalized,extension,quality,note)
                            VALUES(?,?,?,?,?,?,?)''',(email,phone.comparison,phone.original,phone.normalized,phone.extension,phone.state,phone.note))
                        report['new_candidates']+=cur.rowcount
                        if not cur.rowcount:report['duplicates']+=1
                        cid=self.c.execute('SELECT id FROM apple_phone_candidates WHERE email=? AND phone_key=?',(email,phone.comparison)).fetchone()[0]
                        self.c.execute('''INSERT OR IGNORE INTO apple_phone_sources(candidate_id,file_hash,filename,record_path,field_path,order_number,original,imported_at)
                            VALUES(?,?,?,?,?,?,?,?)''',(cid,digest,p.name,record_path,value['field_path'],value['order_number'],phone.original,utc_now()))
                    if report['records']%500==0:
                        self.c.commit()
                        if progress:progress(dict(report))
                self.c.commit()
            except (ValueError,OSError,UnicodeError) as e:
                self.c.commit()  # Earlier valid records remain usable.
                if len(report['errors'])<100:report['errors'].append(p.name+': '+safe_message(e))
            if progress:progress(dict(report))
        report['unmatched_aliases']=len(unmatched)
        return report
    def phone_candidates(self,order,connection_id=''):
        keys=aliases(order['alias_emails'] or '')
        if not keys:return []
        marks=','.join('?' for _ in keys)
        rows=self.c.execute(f'''SELECT p.*,
            COALESCE(v.result,'Untried') AS verification,
            EXISTS(SELECT 1 FROM apple_phone_sources s WHERE s.candidate_id=p.id AND s.order_number=?) AS order_match
            FROM apple_phone_candidates p LEFT JOIN apple_phone_verification v ON v.candidate_id=p.id AND v.order_id=? AND v.connection_id=?
            WHERE p.email IN ({marks}) ORDER BY order_match DESC, CASE WHEN v.result='Verified' THEN 0 ELSE 1 END,p.id''',
            [order['order_number'],order['id'],connection_id]+keys).fetchall()
        return [dict(r) for r in rows]
    def phone_sources(self,candidate_id):
        return [dict(r) for r in self.c.execute('SELECT filename,record_path,field_path,order_number,original,imported_at FROM apple_phone_sources WHERE candidate_id=? ORDER BY id',(candidate_id,))]
    def record_phone_result(self,oid,pid,cid,result):
        if result not in ('Mismatch','Verified','Uncertain','Untried'):raise ValueError('Invalid phone result')
        with self.c:
            if result=='Verified':
                self.c.execute("UPDATE apple_phone_verification SET result='Untried' WHERE order_id=? AND connection_id=? AND result='Verified'",(oid,cid))
            self.c.execute('''INSERT INTO apple_phone_verification VALUES(?,?,?,?,?) ON CONFLICT(order_id,candidate_id,connection_id)
                DO UPDATE SET result=excluded.result,updated_at=excluded.updated_at''',(oid,pid,cid,result,utc_now()))
    def next_sequence(self):
        self.c.execute("UPDATE apple_meta SET value=CAST(value AS INTEGER)+1 WHERE key='sequence'")
        return int(self.c.execute("SELECT value FROM apple_meta WHERE key='sequence'").fetchone()[0])
    def snapshot(self,ids,connection_id,action,method='',item_selections=None):
        if action not in ACTIONS:raise ValueError('Unknown Apple action')
        connection=self.connection(connection_id)
        if not connection:raise ValueError('Choose the destination Apple Account')
        if method and not re.fullmatch(r'[A-Za-z ]{1,25}\s+\*{4}\d{4}',method):
            raise ValueError('Payment label must contain only a brand and masked last four, e.g. Visa ****1234')
        ids=list(dict.fromkeys(map(int,ids)))
        if not ids:raise ValueError('Select at least one order')
        found={}
        for start in range(0,len(ids),400):
            for row in self.db.orders_by_ids(ids[start:start+400]):found[int(row['id'])]=dict(row)
        if len(found)!=len(ids):raise ValueError('Selection includes missing or archived orders; review again')
        records=[]
        for oid in ids:
            r=found[oid]
            scope=(item_selections or {}).get(oid,[])
            items=json.loads(r.get('account_items_json') or '[]')
            valid_ids={str(i.get('id')) for i in items if i.get('stable_id')}
            if scope and not set(scope).issubset(valid_ids):raise ValueError('An item selection no longer matches the latest Apple snapshot')
            eligibility='Not checked on Apple'
            if action in ('cancel','payment') and r.get('account_status_connection')==connection_id:
                latest=self.c.execute('SELECT payload,observed_at FROM apple_observations WHERE order_id=? AND connection_id=? ORDER BY sequence DESC LIMIT 1',(oid,connection_id)).fetchone()
                if latest:
                    payload=json.loads(latest['payload']);offered=payload.get('cancel_eligible' if action=='cancel' else 'payment_eligible',False)
                    if action=='cancel' and scope:offered=all(i.get('cancel_eligible',False) for i in items if i.get('id') in scope)
                    eligibility=('Offered' if offered else 'Not offered')+' as of '+latest['observed_at']
            records.append({'id':oid,'order_number':r['order_number'],'qty':int(r.get('qty') or 0),'eligibility':eligibility,
                            'item':r.get('item_summary') or '', 'total':r.get('total') or '',
                            'item_ids':list(scope),'observed_items':items,'expected_status':r.get('status') or ''})
        data={'connection_id':connection_id,'account_email':connection['email'],'action':action,'orders':records,'method':method}
        return data
    def create_job(self,snapshot,confirmed=False,priority=10):
        action=snapshot['action']
        if action not in ACTIONS:raise ValueError('Unknown Apple action')
        if action!='refresh' and not confirmed:raise ValueError('Confirm the exact batch before submitting')
        cid=snapshot['connection_id'];connection=self.connection(cid)
        if not connection or connection['email']!=snapshot['account_email']:raise ValueError('Destination account changed')
        # Revalidate immutable identities against the live database, not current UI filters.
        for selected in snapshot['orders']:
            row=self.db.order_by_id(selected['id'])
            if not row or not self.db.is_order_visible(selected['id']) or row['order_number']!=selected['order_number']:
                raise ValueError('An order changed or was archived since preview. Nothing was queued')
        payload=json.dumps(snapshot,ensure_ascii=False,sort_keys=True,separators=(',',':'))
        digest=hashlib.sha256(payload.encode()).hexdigest();jid=uuid.uuid4().hex;now=utc_now()
        with self.c:
            self.c.execute('INSERT INTO apple_jobs(id,connection_id,action,state,created_at,snapshot,confirmation_hash,priority,archived_at) VALUES(?,?,?,?,?,?,?,?,?)',(jid,cid,action,'queued',now,payload,digest,int(priority),''))
            for r in snapshot['orders']:
                state='queued';msg=''
                if action=='refresh' and self.c.execute('''SELECT 1 FROM apple_tasks t JOIN apple_jobs j ON j.id=t.job_id
                    WHERE t.order_id=? AND j.connection_id=? AND j.action='refresh' AND t.state IN ('queued','running','cooling_down','awaiting_verification')''',(r['id'],cid)).fetchone():
                    state='skipped';msg='Coalesced with an existing refresh'
                self.c.execute('INSERT INTO apple_tasks(job_id,order_id,state,updated_at,scope,message) VALUES(?,?,?,?,?,?)',
                               (jid,r['id'],state,now,json.dumps(r,ensure_ascii=False),msg))
            self.audit(None,cid,jid,action,'confirmed' if confirmed else 'queued',f"Frozen batch: {len(snapshot['orders'])} orders")
        return jid
    def jobs(self,limit=200):
        return [dict(r) for r in self.c.execute('''SELECT j.id,j.action,j.state,j.created_at,c.email,COUNT(t.id) AS total,
            SUM(CASE WHEN t.state IN ('succeeded','associated','already_associated') THEN 1 ELSE 0 END) AS done,
            SUM(CASE WHEN t.state IN ('awaiting_verification','needs_phone_data','uncertain','failed','declined') THEN 1 ELSE 0 END) AS attention
            FROM apple_jobs j JOIN apple_connections c ON c.id=j.connection_id LEFT JOIN apple_tasks t ON t.job_id=j.id
            WHERE COALESCE(j.archived_at,'')=''
            GROUP BY j.id ORDER BY j.created_at DESC LIMIT ?''',(limit,))]
    def tasks(self,jid,filter_state='',limit=500,offset=0):
        sql='''SELECT t.*,o.order_number,j.action,j.connection_id FROM apple_tasks t JOIN orders o ON o.id=t.order_id
               JOIN apple_jobs j ON j.id=t.job_id WHERE t.job_id=?''';args=[jid]
        if filter_state=='attention':sql+=" AND t.state IN ('awaiting_verification','needs_phone_data','uncertain','failed','declined')"
        elif filter_state:sql+=' AND t.state=?';args.append(filter_state)
        sql+=' ORDER BY t.id LIMIT ? OFFSET ?';args += [limit,offset]
        return [dict(r) for r in self.c.execute(sql,args)]
    def job_control(self,jid,command):
        if command not in ('pause','resume','stop','retry'):raise ValueError('Unsupported queue control')
        with self.c:
            if command=='pause':self.c.execute("UPDATE apple_jobs SET state='paused' WHERE id=?",(jid,))
            elif command=='resume':self.c.execute("UPDATE apple_jobs SET state='queued' WHERE id=? AND state!='stopped'",(jid,))
            elif command=='retry':
                self.c.execute("UPDATE apple_jobs SET state='queued' WHERE id=? AND state!='stopped'",(jid,))
                self.c.execute("UPDATE apple_tasks SET state='queued',next_at=0 WHERE job_id=? AND state IN ('failed','needs_phone_data') AND submitted=0",(jid,))
            else:
                self.c.execute("UPDATE apple_jobs SET state='stopped' WHERE id=?",(jid,))
                self.c.execute("UPDATE apple_tasks SET state=CASE WHEN submitted=1 THEN 'uncertain' ELSE 'stopped' END,message='Stopped; completed Apple actions are not reversed' WHERE job_id=? AND state NOT IN ('succeeded','associated','already_associated','ineligible','declined','skipped')",(jid,))
                self.c.execute('DELETE FROM apple_order_locks WHERE task_id IN (SELECT id FROM apple_tasks WHERE job_id=? AND submitted=0)',(jid,))
    def archive_job(self,jid,stop_unfinished=False):
        """Hide a job from the active Jobs view while preserving its audit trail.

        Queued/running/paused work must be stopped explicitly (or with
        stop_unfinished=True) before it can be archived. Completed Apple actions
        are never reversed by removing a job from the UI.
        """
        row=self.c.execute("SELECT state FROM apple_jobs WHERE id=? AND COALESCE(archived_at,'')=''",(jid,)).fetchone()
        if not row:return False
        active=row['state'] in ('queued','running','paused')
        unfinished=self.c.execute("SELECT COUNT(*) FROM apple_tasks WHERE job_id=? AND state NOT IN ('associated','already_associated','succeeded','ineligible','stopped','skipped','declined')",(jid,)).fetchone()[0]
        if active and unfinished and not stop_unfinished:
            raise ValueError('Stop this active job before removing it, or choose Stop and Remove.')
        if unfinished and stop_unfinished:self.job_control(jid,'stop')
        with self.c:
            self.c.execute('UPDATE apple_jobs SET archived_at=? WHERE id=?',(utc_now(),jid))
            self.audit(None,None,jid,'job_history','archived','Removed from Jobs view; completed Apple actions were not reversed')
        return True
    def archive_completed_jobs(self):
        with self.c:
            rows=self.c.execute("SELECT id FROM apple_jobs WHERE COALESCE(archived_at,'')='' AND state IN ('finished','stopped')").fetchall()
            now=utc_now()
            for row in rows:self.c.execute('UPDATE apple_jobs SET archived_at=? WHERE id=?',(now,row['id']))
        return len(rows)
    def archive_all_finished_history(self):
        return self.archive_completed_jobs()
    def route_rows(self,enabled_only=False):
        sql="SELECT * FROM apple_routes" + (" WHERE enabled=1" if enabled_only else "") + " ORDER BY CASE state WHEN 'Passed' THEN 0 WHEN 'Not tested' THEN 1 ELSE 2 END,last_check DESC,server,id"
        return [dict(r) for r in self.c.execute(sql)]
    def next_failover_route(self,current_id=''):
        rows=self.route_rows(True)
        for row in rows:
            if row['id']!=current_id and row.get('state') not in ('Failed','Stopped'):
                return row
        return None
    def set_route_enabled(self,route_ids,enabled):
        ids=list(dict.fromkeys(str(i) for i in route_ids if i))
        if not ids:return 0
        marks=','.join('?' for _ in ids)
        with self.c:self.c.execute(f'UPDATE apple_routes SET enabled=?,revision=revision+1 WHERE id IN ({marks})',[int(bool(enabled))]+ids)
        return self.c.total_changes
    def delete_routes(self,route_ids):
        ids=list(dict.fromkeys(str(i) for i in route_ids if i))
        if not ids:return []
        marks=','.join('?' for _ in ids)
        in_use=[r['id'] for r in self.c.execute(f'SELECT DISTINCT route_id AS id FROM apple_connections WHERE route_id IN ({marks})',ids)]
        with self.c:
            self.c.execute(f"UPDATE apple_connections SET route_id='' WHERE route_id IN ({marks})",ids)
            self.c.execute(f'DELETE FROM apple_routes WHERE id IN ({marks})',ids)
        return in_use

    def resume_task(self,task_id):
        with self.c:
            row=self.c.execute('SELECT job_id,state FROM apple_tasks WHERE id=?',(task_id,)).fetchone()
            if not row:return
            if row['state'] in TERMINAL_TASKS:return
            self.c.execute("UPDATE apple_tasks SET state='queued',next_at=0,message='Reconcile Apple state before continuing' WHERE id=?",(task_id,))
            self.c.execute("UPDATE apple_jobs SET state='queued' WHERE id=? AND state!='stopped'",(row['job_id'],))
    def recover(self):
        with self.c:
            self.c.execute("UPDATE apple_tasks SET state=CASE WHEN submitted=1 THEN 'uncertain' ELSE 'queued' END,message='Restart recovery: reconcile before repeating a mutation' WHERE state='running'")
            self.c.execute("DELETE FROM apple_order_locks WHERE task_id IN (SELECT id FROM apple_tasks WHERE state IN ('queued','succeeded','associated','already_associated','stopped','skipped','ineligible'))")
            self.c.execute("UPDATE apple_connections SET state='disconnected',reason='Reconnect to restore the protected session' WHERE state IN ('connected','connecting','awaiting_action')")
    def take_next(self,ready_connections,pace=10):
        if not ready_connections:return None
        now=time.time();marks=','.join('?' for _ in ready_connections)
        cooldown=self.c.execute("SELECT value FROM apple_meta WHERE key='global_cooldown'").fetchone()
        if cooldown and float(cooldown[0])>now:return None
        with self.c:
            row=self.c.execute(f'''SELECT t.*,j.connection_id,j.action,j.snapshot,j.confirmation_hash,j.state AS job_state
                 FROM apple_tasks t JOIN apple_jobs j ON j.id=t.job_id JOIN apple_connections c ON c.id=j.connection_id
                 WHERE t.state IN ('queued','cooling_down') AND t.next_at<=? AND j.state IN ('queued','running')
                 AND c.state='connected' AND c.next_at<=? AND j.connection_id IN ({marks})
                 AND NOT EXISTS(SELECT 1 FROM apple_order_locks l WHERE l.order_id=t.order_id AND l.task_id!=t.id)
                 ORDER BY j.priority ASC,t.id LIMIT 1''',[now,now]+list(ready_connections)).fetchone()
            if not row:return None
            task=dict(row)
            payload=task['snapshot']; scope=json.loads(task['scope']); frozen=json.loads(payload)
            valid=(hashlib.sha256(payload.encode()).hexdigest()==task['confirmation_hash'] and
                   frozen['connection_id']==task['connection_id'] and frozen['action']==task['action'] and
                   any(i==scope for i in frozen['orders']))
            order=self.db.order_by_id(task['order_id'])
            if not valid or not order or order['order_number']!=scope['order_number']:
                self.c.execute("UPDATE apple_tasks SET state='failed',error_code='scope_changed',message='Frozen batch identity changed; prepare a new preview' WHERE id=?",(task['id'],));return None
            if not self.db.is_order_visible(task['order_id']):
                self.c.execute("UPDATE apple_tasks SET state='skipped',message='Order is archived' WHERE id=?",(task['id'],));return None
            sequence=self.next_sequence()
            self.c.execute("UPDATE apple_tasks SET state='running',attempts=attempts+1,sequence=?,updated_at=? WHERE id=?",(sequence,utc_now(),task['id']))
            self.c.execute("UPDATE apple_jobs SET state='running' WHERE id=?",(task['job_id'],))
            self.c.execute('INSERT OR REPLACE INTO apple_order_locks VALUES(?,?)',(task['order_id'],task['id']))
            self.c.execute('UPDATE apple_connections SET next_at=? WHERE id=?',(now+max(5,pace),task['connection_id']))
            task['sequence']=sequence;task['attempts']+=1
            return task
    def mark_submitted(self,task,candidate_id=None):
        with self.c:
            self.c.execute('UPDATE apple_tasks SET submitted=1,candidate_id=?,updated_at=? WHERE id=?',(candidate_id,utc_now(),task['id']))
            self.audit(task['order_id'],task['connection_id'],task['job_id'],task['action'],'submission_started','Outcome must be reconciled before another submission')
        task['submitted']=1;task['candidate_id']=candidate_id
    def result(self,task,state,message='',error='',retry_at=0,clear_submission=False):
        with self.c:
            self.c.execute('UPDATE apple_tasks SET state=?,message=?,error_code=?,next_at=?,updated_at=? WHERE id=?',
                           (state,safe_message(message),error,retry_at,utc_now(),task['id']))
            if clear_submission:self.c.execute('UPDATE apple_tasks SET submitted=0 WHERE id=?',(task['id'],))
            if state not in ('uncertain','awaiting_verification','running'):
                self.c.execute('DELETE FROM apple_order_locks WHERE task_id=?',(task['id'],))
            self.audit(task['order_id'],task['connection_id'],task['job_id'],task['action'],state,message)
            pending=self.c.execute("SELECT COUNT(*) FROM apple_tasks WHERE job_id=? AND state NOT IN ('associated','already_associated','succeeded','ineligible','stopped','skipped','declined')",(task['job_id'],)).fetchone()[0]
            if not pending:self.c.execute("UPDATE apple_jobs SET state='finished' WHERE id=? AND state!='stopped'",(task['job_id'],))
    def save_observation(self,task,observation):
        row=self.db.order_by_id(task['order_id'])
        if not row:raise ValueError('Order disappeared')
        if not observation.get('authenticated') or observation.get('order_number')!=row['order_number']:
            raise ValueError('No authenticated matching order observation')
        normalized=str(observation.get('status') or '')
        if not normalized:raise ValueError('No current status was extracted')
        if int(task['sequence'])<=int(row['account_status_seq'] or 0):return False
        now=utc_now();event=str(observation.get('event_at') or '')
        raw=safe_message(observation.get('raw_status'),240)
        old_event=row['account_status_event_at'] or ''
        if event and old_event and event < old_event:return False
        # Only a strict allowlist of structured order fields is persisted. No DOM,
        # cookies, hidden fields, payment input values, or network bodies.
        allow=('order_number','status','raw_status','items','eta_date','eta_text','pickup_store','pickup_time',
               'carrier','tracking_number','event_at','cancel_eligible','payment_eligible','all_items_known')
        clean={k:observation[k] for k in allow if k in observation}
        items=[]
        for item in clean.get('items') or []:
            items.append({k:item[k] for k in ('id','stable_id','item','qty','raw_status','status','cancel_eligible','eta_text','tracking_number') if k in item})
        clean['items']=items
        with self.c:
            self.c.execute('INSERT OR IGNORE INTO apple_observations(order_id,connection_id,sequence,observed_at,event_at,raw_status,normalized_status,payload) VALUES(?,?,?,?,?,?,?,?)',
                           (row['id'],task['connection_id'],task['sequence'],now,event,raw,normalized,json.dumps(clean,ensure_ascii=False)))
            self.c.execute('''UPDATE orders SET account_status=?,account_raw_status=?,account_status_success_at=?,account_status_event_at=?,
                account_status_attempt_at=?,account_status_error='',account_status_seq=?,account_status_connection=?,account_items_json=? WHERE id=?''',
                (normalized,raw,now,event,now,task['sequence'],task['connection_id'],json.dumps(items,ensure_ascii=False),row['id']))
            for key in ('eta_date','eta_text','pickup_store','pickup_time','carrier','tracking_number'):
                value=str(clean.get(key) or '')
                if value:
                    if key=='eta_date' and not re.fullmatch(r'\d{4}-\d{2}-\d{2}',value):continue
                    self.c.execute(f'UPDATE orders SET {key}=? WHERE id=?',(value,row['id']))
            if clean.get('all_items_known') and items and all(isinstance(i.get('qty'),int) and i['qty']>0 for i in items):
                qty=sum(i['qty'] for i in items)
                self.c.execute('UPDATE orders SET account_qty=?,qty=COALESCE(manual_qty,?) WHERE id=?',(qty,qty,row['id']))
            self.db.recompute_order_status(int(row['account_id']),row['order_number'],commit=False)
            self.audit(row['id'],task['connection_id'],task['job_id'],task['action'],'observed',f"{row['status']} -> {normalized}; manual override retained")
        return True
    def record_attempt(self,oid,error=''):
        with self.c:self.c.execute('UPDATE orders SET account_status_attempt_at=?,account_status_error=? WHERE id=?',(utc_now(),safe_message(error),oid))
    def association(self,task,state,phone_id=None):
        if state not in ('associated','already_associated','another_account','ineligible','uncertain','awaiting_verification','needs_phone_data'):raise ValueError('Invalid association outcome')
        with self.c:
            self.c.execute('UPDATE orders SET association_state=? WHERE id=?',(state,task['order_id']))
            if state in ('associated','already_associated'):
                self.c.execute('UPDATE orders SET linked_apple_connection=? WHERE id=?',(task['connection_id'],task['order_id']))
        if phone_id and state=='associated':self.record_phone_result(task['order_id'],phone_id,task['connection_id'],'Verified')
    def export_job(self,jid,path):
        # Result text is already sanitized. Never export URLs, aliases, phones,
        # payment references, or session material in job diagnostics.
        with Path(path).open('w',newline='',encoding='utf-8-sig') as f:
            writer=csv.writer(f);writer.writerow(['Order #','Action','Outcome','Attempts','Updated','Error','Details'])
            offset=0
            while True:
                rows=self.tasks(jid,limit=500,offset=offset)
                if not rows:break
                for r in rows:writer.writerow([r['order_number'],r['action'],r['state'],r['attempts'],r['updated_at'],r['error_code'],r['message']])
                offset+=len(rows)
