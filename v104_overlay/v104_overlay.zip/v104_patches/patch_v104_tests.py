from pathlib import Path

# Keep all published regression-test additions, changing only assertions/fixtures
# whose expected application version or connected-session prerequisite changed in
# v1.0.4.
for name in ('tests/test_stable_sync.py','tests/gui_v103_smoke.py'):
    p=Path(name)
    if not p.exists():
        raise SystemExit(f'missing published regression test: {name}')
    s=p.read_text().replace("'1.0.3'","'1.0.4'").replace('v1.0.3','v1.0.4')
    p.write_text(s)

p=Path('tests/gui_apple_smoke.py')
if not p.exists(): raise SystemExit('missing tests/gui_apple_smoke.py')
s=p.read_text()
s=s.replace("s,cid=self.connection();rows=self.window.db.query_orders();ids=[r['id'] for r in rows[:2]]\n        d=ui.PreviewDialog",
            "s,cid=self.connection();s.connection_state(cid,'connected','', 'owner@example.test','Apple page');rows=self.window.db.query_orders();ids=[r['id'] for r in rows[:2]]\n        d=ui.PreviewDialog")
s=s.replace("s,cid=self.connection();oid=self.window.db.query_orders()[0]['id'];d=ui.PreviewDialog",
            "s,cid=self.connection();s.connection_state(cid,'connected','', 'owner@example.test','Apple page');oid=self.window.db.query_orders()[0]['id'];d=ui.PreviewDialog")
p.write_text(s)
