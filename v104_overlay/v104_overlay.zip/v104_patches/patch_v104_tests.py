from pathlib import Path

# Keep all published regression-test additions, changing only assertions/fixtures
# whose expected application version or connected-session prerequisite changed in
# v1.0.4.
for name in ('tests/test_stable_sync.py','tests/gui_v103_smoke.py'):
    p=Path(name)
    if not p.exists():
        raise SystemExit(f'missing published regression test: {name}')
    s=p.read_text(encoding='utf-8').replace("'1.0.3'","'1.0.4'").replace('v1.0.3','v1.0.4')
    p.write_text(s,encoding='utf-8')

p=Path('tests/gui_apple_smoke.py')
if not p.exists(): raise SystemExit('missing tests/gui_apple_smoke.py')
s=p.read_text(encoding='utf-8')
s=s.replace("s,cid=self.connection();rows=self.window.db.query_orders();ids=[r['id'] for r in rows[:2]]\n        d=ui.PreviewDialog",
            "s,cid=self.connection();s.connection_state(cid,'connected','', 'owner@example.test','Apple page');rows=self.window.db.query_orders();ids=[r['id'] for r in rows[:2]]\n        d=ui.PreviewDialog")
s=s.replace("s,cid=self.connection();oid=self.window.db.query_orders()[0]['id'];d=ui.PreviewDialog",
            "s,cid=self.connection();s.connection_state(cid,'connected','', 'owner@example.test','Apple page');oid=self.window.db.query_orders()[0]['id'];d=ui.PreviewDialog")
p.write_text(s,encoding='utf-8')

p=Path('tests/test_v103_unit.py')
if p.exists():
    s=p.read_text(encoding='utf-8')
    s=s.replace("self.assertFalse(self.db.reset_order_cache());self.assertIsNotNone(self.db.order_by_id(self.oid))",
                "with self.assertRaisesRegex(ValueError,'Full Account Sync'):self.db.reset_order_cache()\n        self.assertIsNotNone(self.db.order_by_id(self.oid))")
    s=s.replace("self.assertTrue(self.db.reset_order_cache());self.assertIsNone(self.db.order_by_id(self.oid))",
                "self.assertIsNone(self.db.reset_order_cache());self.assertIsNone(self.db.order_by_id(self.oid))")

    old="self.session._linked_in_listing=lambda n:False;self.session.task_page=lambda *a,**k:object();self.session.snapshot=lambda p:self._snap();self.session._assert_identity=lambda s:set()"
    new="self.session._linked_in_listing=lambda n:False;self.session._unique_button=lambda *a,**k:None;self.session.task_page=lambda *a,**k:type('P',(),{'locator':lambda self,*a,**k:type('L',(),{'count':lambda self:0})()})() ;self.session.snapshot=lambda p:self._snap();self.session._assert_identity=lambda s:set()"
    s=s.replace(old,new,1)
    p.write_text(s,encoding='utf-8')
