from pathlib import Path
p=Path('apple_browser.py')
s=p.read_text()
if '    def begin_sign_in(self):\n' not in s:
    marker='    def verify_identity(self,user_confirmed=False):\n'
    if marker not in s: raise SystemExit('browser verify_identity anchor missing')
    methods=r'''    def _signin_control(self,page):
        # Click only one explicit Apple Account sign-in branch. The application
        # never fills passwords, passkeys, or two-factor codes.
        patterns=(r'^Sign [Ii]n with (?:your )?Apple (?:Account|ID)$',
                  r'^Sign [Ii]n to (?:your )?Apple (?:Account|ID)$',
                  r'^Continue with (?:your )?Apple (?:Account|ID)$',
                  r'^Apple (?:Account|ID) Sign [Ii]n$')
        for pattern in patterns:
            node=self._unique_button(page,pattern)
            if node:return node
        return None
    def begin_sign_in(self):
        """Enter Apple's account sign-in branch without reading credentials."""
        self.page.bring_to_front();snap=self.snapshot(self.page)
        if self._account_view(snap):
            return 'checking_account','A saved Apple session is visible. Verifying the account now.'
        if snap.get('auth_prompt'):
            return 'waiting_verification','Complete Apple verification in the dedicated browser. The tracker will check automatically.'
        if snap.get('password_prompt'):
            return 'waiting_sign_in','Complete Apple sign-in in the dedicated browser. The tracker never reads your password.'
        control=self._signin_control(self.page)
        if control:
            control.click();self.page.wait_for_timeout(700);snap=self.snapshot(self.page)
            if snap.get('auth_prompt'):return 'waiting_verification','Complete Apple verification in the dedicated browser.'
            return 'waiting_sign_in','Apple Account sign-in is open in the dedicated browser. Complete sign-in and any verification.'
        if re.search(r'find your order|guest order',snap.get('text',''),re.I):
            try:
                self.navigate(self.page,ACCOUNT_HOME);snap=self.snapshot(self.page)
                if self._account_view(snap):return 'checking_account','A saved Apple session is visible. Verifying the account now.'
                control=self._signin_control(self.page)
                if control:
                    control.click();self.page.wait_for_timeout(700);snap=self.snapshot(self.page)
                    if snap.get('auth_prompt'):return 'waiting_verification','Complete Apple verification in the dedicated browser.'
                    return 'waiting_sign_in','Apple Account sign-in is open. Complete sign-in and any verification.'
            except AppleFlowError:
                raise
            except Exception:
                pass
        return 'waiting_sign_in','In the dedicated Apple browser, choose the Apple Account sign-in option (not guest order lookup), then complete sign-in. The tracker will detect the session automatically.'
'''
    s=s.replace(marker,methods+marker,1)
if 'def begin_sign_in' not in s or 'def _signin_control' not in s:
    raise SystemExit('v1.0.4 browser sign-in patch did not apply')
p.write_text(s)
