import imaplib
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from core_loader import load_core

core = load_core()


def sample_raw(order='W1477775326', msgid='stable-sync', item='iPhone Duo 256GB Star White'):
    return (
        b'From: Apple Store <your_order_US@orders.apple.com>\r\n'
        b'To: example@gmail.com\r\n'
        + f"Subject: We're processing your order {order}\r\n".encode()
        + b'Date: Fri, 16 Oct 2026 12:25:13 +0000\r\n'
        + f'Message-ID: <{msgid}>\r\n'.encode()
        + b'Content-Type: text/plain; charset=UTF-8\r\n\r\n'
        + f'Order Number {order}\r\n'.encode()
        + b'Ordered on Oct 16, 2026\r\nItems to Be Shipped\r\nShipment 1:\r\n'
        + b'Delivers: Dec 15 - Dec 22 by Express Delivery\r\n'
        + f'{item}\r\n'.encode()
        + b'$1,999.00\r\nQty 1\r\nShipping Address\r\n123 Main St\r\nPortland OR 97201\r\n'
    )


class FakeSearchIMAP:
    def __init__(self):
        self.calls=[]
    def uid(self, *args):
        self.calls.append(args)
        if 'X-GM-RAW' in args:
            return 'OK', [b'']
        if 'FROM' in args and '"orders.apple.com"' in args:
            return 'OK', [b'101 202']
        return 'OK', [b'']


class SearchFallbackTests(unittest.TestCase):
    def test_standard_imap_fallback_when_xgmraw_is_empty(self):
        c=core.GmailIMAPClient('example@gmail.com','pw','imap.gmail.com',993)
        c.imap=FakeSearchIMAP()
        ok,uids=c.search_apple_uids_checked()
        self.assertTrue(ok)
        self.assertEqual(uids,[101,202])


class BaseFakeClient:
    seen_last_uids=[]
    fetch_calls=0
    highest=5000
    found=[4500]
    messages={4500: sample_raw()}

    def __init__(self,*a,**k):
        self.connected=False
    def connect(self):
        self.connected=True
    def close(self):
        self.connected=False
    def mailboxes_to_scan(self):
        return [('All Mail','ALL')]
    def select_mailbox(self, mailbox):
        return True
    def highest_uid(self, mailbox):
        return self.highest
    def search_apple_uids_checked(self,last_uid=0,start_date='',end_date=''):
        type(self).seen_last_uids.append(last_uid)
        return True,list(type(self).found)
    def fetch_many(self,uids):
        type(self).fetch_calls += 1
        return {u:type(self).messages[u] for u in uids if u in type(self).messages}
    def fetch(self, uid):
        if uid in type(self).messages:
            return type(self).messages[uid]
        raise RuntimeError(f'Email UID {uid} had no usable message body.')


class SyncCheckpointTests(unittest.TestCase):
    def setUp(self):
        BaseFakeClient.seen_last_uids=[]
        BaseFakeClient.fetch_calls=0
        BaseFakeClient.highest=5000
        BaseFakeClient.found=[4500]
        BaseFakeClient.messages={4500: sample_raw()}

    def make_db(self):
        td=tempfile.TemporaryDirectory()
        path=Path(td.name)/'orders.db'
        db=core.Database(path)
        aid=db.add_account('example@gmail.com')
        db.close()
        return td,path,aid

    def test_new_only_uses_saved_checkpoint_not_history(self):
        td,path,aid=self.make_db()
        try:
            db=core.Database(path)
            db.conn.execute('UPDATE accounts SET last_uid=4000 WHERE id=?',(aid,)); db.conn.commit(); db.close()
            with mock.patch.object(core,'GmailIMAPClient',BaseFakeClient), mock.patch.object(core.keyring,'get_password',return_value='pw'):
                w=core.SyncWorker(path,account_ids=[aid]); w.run()
            self.assertEqual(BaseFakeClient.seen_last_uids,[4000])
            db=core.Database(path)
            self.assertEqual(len(db.query_orders()),1)
            self.assertEqual(int(db.list_accounts()[0]['last_uid']),5000)
            db.close()
        finally: td.cleanup()

    def test_first_new_only_establishes_baseline_without_downloading_history(self):
        td,path,aid=self.make_db()
        try:
            class NeverSearch(BaseFakeClient):
                seen_last_uids=[]; fetch_calls=0
                def search_apple_uids_checked(self,*a,**k):
                    raise AssertionError('new-only first use should baseline, not historical scan')
            with mock.patch.object(core,'GmailIMAPClient',NeverSearch), mock.patch.object(core.keyring,'get_password',return_value='pw'):
                w=core.SyncWorker(path,account_ids=[aid]); w.run()
            db=core.Database(path)
            self.assertEqual(len(db.query_orders()),0)
            self.assertEqual(int(db.list_accounts()[0]['last_uid']),5000)
            db.close()
        finally: td.cleanup()

    def test_legacy_events_with_zero_checkpoint_resume_from_max_imported_uid(self):
        td,path,aid=self.make_db()
        try:
            db=core.Database(path)
            parsed=core.AppleMailParser().parse(sample_raw(order='W1477775300',msgid='legacy'), 'example@gmail.com')
            db.save_update(aid,3000,parsed)
            db.conn.execute('UPDATE accounts SET last_uid=0, spam_last_uid=0, trash_last_uid=0 WHERE id=?',(aid,)); db.conn.commit(); db.close()
            class ResumeClient(BaseFakeClient):
                seen_last_uids=[]; found=[4500]; messages={4500:sample_raw(order='W1477775326',msgid='new')}
            with mock.patch.object(core,'GmailIMAPClient',ResumeClient), mock.patch.object(core.keyring,'get_password',return_value='pw'):
                w=core.SyncWorker(path,account_ids=[aid]); w.run()
            self.assertEqual(ResumeClient.seen_last_uids,[3000])
            db=core.Database(path)
            self.assertEqual(len(db.query_orders()),2)
            self.assertEqual(int(db.list_accounts()[0]['last_uid']),5000)
            db.close()
        finally: td.cleanup()

    def test_historical_refresh_does_not_change_incremental_checkpoint(self):
        td,path,aid=self.make_db()
        try:
            db=core.Database(path); db.conn.execute('UPDATE accounts SET last_uid=4000 WHERE id=?',(aid,)); db.conn.commit(); db.close()
            class RangeClient(BaseFakeClient):
                seen_last_uids=[]; found=[123]; messages={123:sample_raw()}
            with mock.patch.object(core,'GmailIMAPClient',RangeClient), mock.patch.object(core.keyring,'get_password',return_value='pw'):
                w=core.SyncWorker(path,refresh_all=True,start_date='2026-10-15',end_date='2026-10-17',account_ids=[aid]); w.run()
            db=core.Database(path)
            self.assertEqual(int(db.list_accounts()[0]['last_uid']),4000)
            self.assertEqual(len(db.query_orders()),1)
            db.close()
        finally: td.cleanup()

    def test_full_account_sync_explicitly_starts_from_uid_zero(self):
        td,path,aid=self.make_db()
        try:
            db=core.Database(path)
            db.conn.execute('UPDATE accounts SET last_uid=4000 WHERE id=?',(aid,)); db.conn.commit(); db.close()
            BaseFakeClient.found=[123]
            BaseFakeClient.messages={123:sample_raw()}
            with mock.patch.object(core,'GmailIMAPClient',BaseFakeClient), mock.patch.object(core.keyring,'get_password',return_value='pw'):
                w=core.SyncWorker(path,refresh_all=True,account_ids=[aid]); w.run()
            self.assertEqual(BaseFakeClient.seen_last_uids,[0])
            db=core.Database(path)
            rows=db.query_orders()
            self.assertEqual(len(rows),1)
            self.assertEqual(rows[0]['eta_date'],'2026-12-15')
            self.assertEqual(int(db.list_accounts()[0]['last_uid']),5000)
            db.close()
        finally: td.cleanup()

    def test_overquota_retries_same_batch_and_continues(self):
        td,path,aid=self.make_db()
        try:
            db=core.Database(path); db.conn.execute('UPDATE accounts SET last_uid=4000 WHERE id=?',(aid,)); db.conn.commit(); db.close()
            class QuotaOnce(BaseFakeClient):
                seen_last_uids=[]; fetch_calls=0
                def fetch_many(self,uids):
                    type(self).fetch_calls += 1
                    if type(self).fetch_calls == 1:
                        raise imaplib.IMAP4.error('[OVERQUOTA] Account exceeded command or bandwidth limits.')
                    return super().fetch_many(uids)
            QuotaOnce.found=[4500]; QuotaOnce.messages={4500:sample_raw()}
            with mock.patch.object(core,'GmailIMAPClient',QuotaOnce), mock.patch.object(core.keyring,'get_password',return_value='pw'), mock.patch.object(core.SyncWorker,'_sleep_interruptible',return_value=True):
                w=core.SyncWorker(path,account_ids=[aid]); w.run()
            self.assertGreaterEqual(w.retry_count,1)
            db=core.Database(path); self.assertEqual(len(db.query_orders()),1); db.close()
        finally: td.cleanup()

    def test_missing_uid_is_queued_but_later_email_imports(self):
        td,path,aid=self.make_db()
        try:
            db=core.Database(path); db.conn.execute('UPDATE accounts SET last_uid=4000 WHERE id=?',(aid,)); db.conn.commit(); db.close()
            class MissingOne(BaseFakeClient):
                seen_last_uids=[]; fetch_calls=0; found=[4500,4600]; messages={4600:sample_raw(order='W1477775327',msgid='second')}
                def fetch_many(self,uids):
                    return {4600:type(self).messages[4600]}
                def fetch(self,uid):
                    if uid == 4500:
                        raise RuntimeError('Email UID 4500 had no usable message body.')
                    return type(self).messages[uid]
            with mock.patch.object(core,'GmailIMAPClient',MissingOne), mock.patch.object(core.keyring,'get_password',return_value='pw'), mock.patch.object(core.SyncWorker,'_sleep_interruptible',return_value=True):
                w=core.SyncWorker(path,account_ids=[aid]); w.run()
            db=core.Database(path)
            self.assertEqual(len(db.query_orders()),1)
            self.assertEqual(db.sync_failure_count(aid),1)
            self.assertEqual(int(db.list_accounts()[0]['last_uid']),5000)
            db.close()
        finally: td.cleanup()

    def test_parser_error_on_one_email_does_not_stop_next_email(self):
        td,path,aid=self.make_db()
        try:
            db=core.Database(path); db.conn.execute('UPDATE accounts SET last_uid=4000 WHERE id=?',(aid,)); db.conn.commit(); db.close()
            class TwoMessages(BaseFakeClient):
                seen_last_uids=[]; found=[4500,4600]; messages={4500:sample_raw(order='W1477775326',msgid='bad'),4600:sample_raw(order='W1477775327',msgid='good')}
            original=core.AppleMailParser.parse
            def flaky(self,raw,source):
                if b'<bad>' in raw: raise ValueError('synthetic parser failure')
                return original(self,raw,source)
            with mock.patch.object(core,'GmailIMAPClient',TwoMessages), mock.patch.object(core.keyring,'get_password',return_value='pw'), mock.patch.object(core.AppleMailParser,'parse',flaky):
                w=core.SyncWorker(path,account_ids=[aid]); w.run()
            db=core.Database(path)
            self.assertEqual(len(db.query_orders()),1)
            self.assertEqual(db.sync_failure_count(aid),1)
            db.close()
        finally: td.cleanup()


class BrandingTests(unittest.TestCase):
    def test_brand_and_version(self):
        self.assertEqual(core.APP_NAME,'Ah Pa Ta Tracker')
        self.assertEqual(core.APP_VERSION,'1.0.4')


if __name__=='__main__':
    unittest.main()
