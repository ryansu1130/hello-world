import sqlite3
import tempfile
import unittest
from pathlib import Path

from core_loader import load_core
from apple_accounts import AppleStore, install_schema, SCHEMA_VERSION
from apple_browser import BrowserSession, AppleFlowError
from apple_jobs import AppleRunner

core=load_core()


class _FakePage:
    def __init__(self):self.front=False;self.waits=[]
    def bring_to_front(self):self.front=True
    def wait_for_timeout(self,n):self.waits.append(n)


class _FakeButton:
    def __init__(self):self.clicked=False
    def click(self):self.clicked=True


class SignInHandoffTests(unittest.TestCase):
    def test_guest_page_clicks_explicit_apple_account_signin(self):
        s=BrowserSession.__new__(BrowserSession);s.page=_FakePage();s.validated=False
        button=_FakeButton();snaps=[
            {'url':'https://secure.store.apple.com/shop/order/list','text':'Find your order. Sign in with your Apple Account','headings':['Find your order.'],'signed_in':False,'password_prompt':False,'auth_prompt':False,'order_links':[]},
            {'url':'https://secure.store.apple.com/shop/signIn/orders','text':'Apple Account Sign In','headings':['Sign In'],'signed_in':False,'password_prompt':True,'auth_prompt':False,'order_links':[]},
        ]
        s.snapshot=lambda page:snaps.pop(0)
        s._signin_control=lambda page:button
        state,message=s.begin_sign_in()
        self.assertTrue(s.page.front);self.assertTrue(button.clicked)
        self.assertEqual(state,'waiting_sign_in');self.assertIn('sign-in',message.lower())

    def test_guest_page_is_never_verified_as_connected(self):
        s=BrowserSession.__new__(BrowserSession);s.page=_FakePage();s.validated=False;s.connection={'email':'owner@example.test'}
        s.snapshot=lambda page:{'url':'https://secure.store.apple.com/shop/order/list','text':'Find your order','headings':['Find your order.'],'signed_in':False,'password_prompt':False,'auth_prompt':False,'order_links':[],'identities':[]}
        with self.assertRaises(AppleFlowError) as cm:s.verify_identity()
        self.assertEqual(cm.exception.code,'auth_required');self.assertFalse(s.validated)


class SchemaAndJobHistoryTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.db=core.Database(Path(self.tmp.name)/'orders.db');self.store=AppleStore(self.db)
        a=self.db.add_account('mail@example.test')
        from test_apple_workspace import event
        self.db.save_update(a,1,event());self.oid=self.db.query_orders()[0]['id']
        self.cid=self.store.add_connection('owner@example.test');self.store.connection_state(self.cid,'connected')
    def tearDown(self):self.db.close();self.tmp.cleanup()
    def test_v3_schema_adds_route_enabled_and_job_archive(self):
        self.assertEqual(SCHEMA_VERSION,3)
        self.assertIn('enabled',{r[1] for r in self.db.conn.execute('PRAGMA table_info(apple_routes)')})
        self.assertIn('archived_at',{r[1] for r in self.db.conn.execute('PRAGMA table_info(apple_jobs)')})
    def test_active_job_requires_stop_before_remove(self):
        jid=self.store.create_job(self.store.snapshot([self.oid],self.cid,'refresh'))
        with self.assertRaises(ValueError):self.store.archive_job(jid)
        self.assertTrue(self.store.archive_job(jid,stop_unfinished=True))
        self.assertFalse(any(r['id']==jid for r in self.store.jobs()))
        self.assertTrue(self.store.tasks(jid))
    def test_completed_job_can_be_removed_without_deleting_audit(self):
        jid=self.store.create_job(self.store.snapshot([self.oid],self.cid,'refresh'));t=self.store.take_next({self.cid})
        self.store.result(t,'succeeded','done');before=self.db.conn.execute('SELECT COUNT(*) FROM apple_audit WHERE job_id=?',(jid,)).fetchone()[0]
        self.assertTrue(self.store.archive_job(jid));after=self.db.conn.execute('SELECT COUNT(*) FROM apple_audit WHERE job_id=?',(jid,)).fetchone()[0]
        self.assertGreaterEqual(after,before);self.assertFalse(any(r['id']==jid for r in self.store.jobs()))
    def test_failover_pool_skips_disabled_and_failed_routes(self):
        with self.db.conn:
            self.db.conn.execute("INSERT INTO apple_routes(id,identity,server,state,enabled) VALUES('a','a','http://a:1','Failed',1)")
            self.db.conn.execute("INSERT INTO apple_routes(id,identity,server,state,enabled) VALUES('b','b','http://b:2','Passed',0)")
            self.db.conn.execute("INSERT INTO apple_routes(id,identity,server,state,enabled) VALUES('c','c','http://c:3','Passed',1)")
        self.assertEqual(self.store.next_failover_route('a')['id'],'c')
        self.assertIsNone(self.store.next_failover_route('c'))


class RunnerFailoverTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.path=Path(self.tmp.name)/'orders.db';self.db=core.Database(self.path);self.store=AppleStore(self.db)
        a=self.db.add_account('mail@example.test')
        from test_apple_workspace import event
        self.db.save_update(a,1,event());self.oid=self.db.query_orders()[0]['id']
        self.cid=self.store.add_connection('owner@example.test')
        with self.db.conn:
            self.db.conn.execute("INSERT INTO apple_routes(id,identity,server,state,enabled) VALUES('r1','r1','http://r1:1','Passed',1)")
            self.db.conn.execute("INSERT INTO apple_routes(id,identity,server,state,enabled) VALUES('r2','r2','http://r2:2','Passed',1)")
            self.db.conn.execute("UPDATE apple_connections SET route_id='r1' WHERE id=?",(self.cid,))
        self.store.connection_state(self.cid,'connected')
        self.jid=self.store.create_job(self.store.snapshot([self.oid],self.cid,'refresh'));self.task=self.store.take_next({self.cid})
        self.runner=AppleRunner(type(self.db),self.path,lambda r:'https://secure.store.apple.com/shop/order/list',lambda *a:(None,''))
        class S:
            def close(self):pass
        self.runner.sessions[self.cid]=S();self.runner.ready.add(self.cid)
    def tearDown(self):self.db.close();self.tmp.cleanup()
    def test_transport_failure_switches_route_but_throttle_does_not(self):
        self.runner._failure(self.store,self.task,AppleFlowError('connection_failure','network failed'))
        self.assertEqual(self.store.connection(self.cid)['route_id'],'r2')
        state=self.store.tasks(self.jid)[0]['state'];self.assertEqual(state,'cooling_down')
    def test_explicit_throttle_keeps_current_route(self):
        # Fresh task because previous failure logic is not involved in this test.
        before=self.store.connection(self.cid)['route_id']
        self.runner._failure(self.store,self.task,AppleFlowError('throttled','wait',600))
        self.assertEqual(self.store.connection(self.cid)['route_id'],before)
        self.assertGreater(self.store.connection(self.cid)['next_at'],0)


if __name__=='__main__':unittest.main(verbosity=2)
