"""v1.0.4 Qt regression gate. Temporary data only; no Apple/proxy network calls."""
import sys
import unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parent))
import gui_smoke as g
import apple_account_ui as ui
from apple_accounts import AppleStore
from PySide6.QtCore import Qt, QPoint
from PySide6.QtWidgets import QMessageBox, QPushButton, QComboBox
from PySide6.QtTest import QTest


class V104GUITests(unittest.TestCase):
    setUp=g.GUITests.setUp
    tearDown=g.GUITests.tearDown

    def page(self):
        p=self.window.apple_page;self.window.show_page(self.window.PAGE_APPLE,self.window.apple_nav);g.APP.processEvents();return p

    def connected(self):
        p=self.page();s=AppleStore(self.window.db);cid=s.add_connection('owner@example.test');s.connection_state(cid,'connected','', 'owner@example.test','Apple page');p.refresh();return p,s,cid

    def test_preview_is_large_and_requires_connected_session(self):
        p=self.page();s=AppleStore(self.window.db);cid=s.add_connection('owner@example.test');oid=self.window.db.query_orders()[0]['id']
        d=ui.PreviewDialog(s,[oid],'associate',self.window);self.assertGreaterEqual(d.width(),1100);self.assertGreaterEqual(d.height(),700);self.assertFalse(d.go.isEnabled());d.close()
        s.connection_state(cid,'connected','', 'owner@example.test','Apple page');d=ui.PreviewDialog(s,[oid],'associate',self.window);self.assertTrue(d.go.isEnabled());self.assertTrue(d.go.text().startswith('START'));d.close()

    def test_proxy_select_all_enable_disable_and_delete(self):
        p,s,cid=self.connected();p.tabs.setCurrentIndex(3)
        p.proxy_text.setPlainText('127.0.0.1:8080:u1:p1\n127.0.0.1:8081:u2:p2');p.preview_routes();self.assertTrue(p.save_routes())
        p.routes_model.select_all();self.assertEqual(len(p.routes_model.selected_ids),2);p.set_selected_routes_enabled(False)
        self.assertEqual(self.window.db.conn.execute('SELECT COUNT(*) FROM apple_routes WHERE enabled=0').fetchone()[0],2)
        p.set_selected_routes_enabled(True);self.assertEqual(self.window.db.conn.execute('SELECT COUNT(*) FROM apple_routes WHERE enabled=1').fetchone()[0],2)
        with patch.object(QMessageBox,'question',return_value=QMessageBox.Yes):p.delete_selected_routes()
        self.assertEqual(self.window.db.conn.execute('SELECT COUNT(*) FROM apple_routes').fetchone()[0],0)

    def test_jobs_can_be_stopped_and_removed_from_view(self):
        p,s,cid=self.connected();oid=self.window.db.query_orders()[0]['id'];jid=s.create_job(s.snapshot([oid],cid,'refresh'));p.refresh_jobs();p.active_job=jid
        with patch.object(QMessageBox,'question',return_value=QMessageBox.Yes):p.remove_selected_jobs()
        self.assertFalse(any(r['id']==jid for r in s.jobs()));self.assertTrue(s.tasks(jid))

    def test_order_action_widget_has_selector_and_start(self):
        p=self.page();w=ui.actions_button(self.window,self.window.table_model)
        self.assertIsNotNone(w.findChild(QComboBox));buttons=w.findChildren(QPushButton);self.assertTrue(any(b.text()=='START' for b in buttons));w.deleteLater()

    def test_shift_click_checks_contiguous_range(self):
        table=self.window.table;model=self.window.table_model
        self.assertGreaterEqual(model.rowCount(),3)
        first=model.index(0,0);third=model.index(2,0)
        QTest.mouseClick(table.viewport(),Qt.LeftButton,Qt.NoModifier,table.visualRect(first).center());g.APP.processEvents()
        QTest.mouseClick(table.viewport(),Qt.LeftButton,Qt.ShiftModifier,table.visualRect(third).center());g.APP.processEvents()
        ids=[int(model.rows[i]['id']) for i in range(3)];self.assertTrue(set(ids).issubset(set(model.checked_order_ids())))

    def test_dark_and_light_render_updated_workspace(self):
        p=self.page()
        for theme in ('light','dark'):
            self.window.apply_theme(theme);g.APP.processEvents();shot=self.window.grab();self.assertFalse(shot.isNull());self.assertTrue(shot.save(str(Path.cwd()/f'v104_{theme}.png')))


if __name__=='__main__':unittest.main(verbosity=2)
