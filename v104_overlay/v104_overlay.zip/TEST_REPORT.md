# Ah Pa Ta Tracker v1.0.4 validation report

## Local development checks completed

- Python source/test compilation: required before packaging.
- Exact published-source reconstruction plus v1.0.4 overlay: **220 offline/unit tests passed**.
- New v1.0.4 unit coverage includes sign-in branch initiation, refusal to authenticate guest pages, schema-v3 route/job fields, guarded job removal, audit retention, route enable/disable/failover and no proxy switch on explicit throttling.
- Controlled Chromium DOM contract suite from the exact published source: **16/16 scenarios passed locally** in isolated browser processes. It covers identity switching, phone-candidate sequencing, uncertain association reconciliation, already-associated/account-list evidence, guest controls, session expiry, rate limiting, authenticated refresh, cancellation handoff/confirmation, and payment-update confirmation. The new explicit Apple Account sign-in branch is additionally covered by v1.0.4 unit tests. The Windows GitHub workflow repeats the authoritative browser suite.

## Local environment limitation

PySide6 is not installed in this Linux development runtime, so native Qt GUI smoke tests and a Windows PyInstaller/native-launcher build cannot be truthfully reported as locally executed. The repository's Windows release workflow is the authoritative packaging/UI gate and must pass before publication.

## Mandatory v1.0.4 Windows release gates

1. Reconstruct the published stable base and v1.0.3 overlay.
2. Verify and overlay the exact v1.0.4 changed files.
3. Run the complete offline unit suite.
4. Run existing tracker Qt regression checks.
5. Run Apple workspace Qt checks.
6. Run historical v1.0.3 Qt regression checks.
7. Run v1.0.4 Qt checks for large dialogs, connected-session START gate, proxy CRUD/selection, job removal, action selector and Shift-click selection in both themes.
8. Run the complete controlled browser-DOM suite with no Apple network mutation.
9. Build the PyInstaller payload on Windows.
10. Build and verify the persistent native launcher.
11. Generate the public EXE SHA-256.
12. Publish the stable GitHub release only if every gate succeeds.

## Live Apple verification boundary

Automated tests cannot provide a real user's Apple Account password/passkey/2FA approval. They also do not cancel a real order or change a real payment method. The final live validation therefore remains:

1. Connect one owned Apple Account in the visible dedicated browser and complete Apple's verification.
2. Confirm the tracker reports the expected account as Connected.
3. Associate or refresh one owned test order and confirm the result is visible in Apple's account/order listing and in the tracker.
4. Only after that succeeds, authorize broader owned-order jobs.

Unknown Apple page layouts remain a handoff/needs-attention state and must not be manually relabeled as a verified success in code.
