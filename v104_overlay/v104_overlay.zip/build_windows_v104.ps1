$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

$version = (Get-Content version.json -Raw | ConvertFrom-Json).version
if ($version -ne '1.0.4') { throw "Expected version 1.0.4, got $version" }

python -m pip install -r requirements.txt
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

python -m unittest discover -s tests -p "test_*.py" -v
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

$env:QT_QPA_PLATFORM = 'offscreen'
python tests/gui_smoke.py
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
python tests/gui_apple_smoke.py
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
python tests/gui_v103_smoke.py
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
python tests/gui_v104_smoke.py
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Remove-Item Env:QT_QPA_PLATFORM -ErrorAction SilentlyContinue

if (Test-Path tests/browser_suite.py) {
  python tests/browser_suite.py
  if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}

Remove-Item -Recurse -Force build, dist -ErrorAction SilentlyContinue
python -m PyInstaller --noconfirm --clean --onefile --windowed `
  --exclude-module PySide6.QtWebEngineCore `
  --exclude-module PySide6.QtWebEngineWidgets `
  --collect-all keyring --collect-all playwright `
  --icon="app_icon.ico" --add-data "app_icon.ico;." `
  --name AhPaTaTrackerApp AppleOrderTracker.py
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

python tools/build_native_launcher.py `
  --source launcher/Program.cs `
  --payload dist/AhPaTaTrackerApp.exe `
  --output dist/AhPaTaTracker.exe `
  --version $version `
  --icon app_icon.ico
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

$hash = (Get-FileHash dist/AhPaTaTracker.exe -Algorithm SHA256).Hash.ToLower()
"$hash  AhPaTaTracker.exe" | Out-File dist/AhPaTaTracker.exe.sha256 -Encoding ascii -NoNewline
Write-Host "Built dist/AhPaTaTracker.exe (native launcher + verified payload)"
Write-Host "SHA-256: $hash"
