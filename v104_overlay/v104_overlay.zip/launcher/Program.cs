using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Windows.Forms;

[assembly: System.Reflection.AssemblyTitle("Ah Pa Ta Tracker")]
[assembly: System.Reflection.AssemblyProduct("Ah Pa Ta Tracker")]
[assembly: System.Reflection.AssemblyDescription("Safe native launcher for Ah Pa Ta Tracker")]
[assembly: System.Reflection.AssemblyCompany("Ah Pa Ta Tracker")]
[assembly: System.Reflection.AssemblyVersion("1.0.4.0")]
[assembly: System.Reflection.AssemblyFileVersion("1.0.4.0")]

namespace AhPaTaLauncher
{
    internal static class Program
    {
        private static readonly byte[] Magic = Encoding.ASCII.GetBytes("AHPATA-LAUNCH-03"); // 16 bytes
        private const int FooterSize = 96;

        [STAThread]
        private static void Main(string[] args)
        {
            try
            {
                string self = Process.GetCurrentProcess().MainModule.FileName;
                Log("Persistent launcher started: " + self);
                Footer footer = ReadFooter(self);
                string baseDir = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "AppleOrderTracker", "runtime", footer.Version);
                Directory.CreateDirectory(baseDir);
                string payload = Path.Combine(baseDir, "AhPaTaTrackerApp.exe");
                EnsurePayload(self, payload, footer);

                string token = Guid.NewGuid().ToString("N");
                string ackDir = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "AppleOrderTracker", "startup");
                Directory.CreateDirectory(ackDir);
                string ack = Path.Combine(ackDir, "ack-" + token + ".json");
                TryDelete(ack);

                ProcessStartInfo info = new ProcessStartInfo();
                info.FileName = payload;
                info.Arguments = JoinArguments(args);
                info.WorkingDirectory = Path.GetDirectoryName(self);
                info.UseShellExecute = false;
                info.EnvironmentVariables["AHPATA_LAUNCHER_PATH"] = self;
                info.EnvironmentVariables["AHPATA_RUNTIME_DIR"] = baseDir;
                info.EnvironmentVariables["AHPATA_STARTUP_ACK"] = ack;
                info.EnvironmentVariables["AHPATA_LAUNCH_TOKEN"] = token;
                SanitizeEnvironment(info);

                Process child = Process.Start(info);
                if (child == null)
                    throw new InvalidOperationException("The application process did not start.");

                bool acknowledged = WaitForAcknowledgment(child, ack, token, TimeSpan.FromSeconds(55));
                if (!acknowledged)
                {
                    TryDelete(ack);
                    Log("Updated application did not acknowledge startup; automatic downgrade is intentionally disabled after possible database initialization.");
                    string detail = child.HasExited
                        ? "The updated application closed before startup completed (exit code " + child.ExitCode + ")."
                        : "The updated application did not confirm startup in time.";
                    MessageBox.Show(
                        detail + "\n\nA previous executable was kept when available, but Ah Pa Ta Tracker will not automatically downgrade after database initialization. " +
                        "Open Ah Pa Ta Tracker again or download the latest release from GitHub.",
                        "Ah Pa Ta Tracker update could not start",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                    Environment.ExitCode = 12;
                    return;
                }
                TryDelete(ack);
                Log("Updated application acknowledged startup: v" + footer.Version);
                TryDelete(Path.Combine(Path.GetDirectoryName(self), Path.GetFileNameWithoutExtension(self) + ".previous.exe"));
                CleanupOldRuntime(Path.GetDirectoryName(baseDir), baseDir);
            }
            catch (Exception ex)
            {
                Log("Launcher startup error: " + ex.GetType().Name + ": " + ex.Message);
                MessageBox.Show(
                    "Ah Pa Ta Tracker could not start the installed application.\n\n" + ex.Message,
                    "Ah Pa Ta Tracker startup error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                Environment.ExitCode = 11;
            }
        }

        private sealed class Footer
        {
            public long PayloadSize;
            public byte[] Sha256;
            public string Version;
        }

        private static Footer ReadFooter(string self)
        {
            using (FileStream stream = new FileStream(self, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                if (stream.Length < FooterSize)
                    throw new InvalidDataException("The launcher payload footer is missing.");
                stream.Seek(-FooterSize, SeekOrigin.End);
                byte[] footer = ReadExactly(stream, FooterSize);
                for (int i = 0; i < Magic.Length; i++)
                    if (footer[i] != Magic[i])
                        throw new InvalidDataException("The launcher payload signature is invalid.");
                long size = BitConverter.ToInt64(footer, 16);
                if (size <= 0 || size > stream.Length - FooterSize)
                    throw new InvalidDataException("The launcher payload size is invalid.");
                byte[] hash = new byte[32];
                Buffer.BlockCopy(footer, 24, hash, 0, hash.Length);
                string version = Encoding.UTF8.GetString(footer, 56, 32).TrimEnd('\0', ' ');
                if (String.IsNullOrWhiteSpace(version))
                    throw new InvalidDataException("The launcher version is missing.");
                return new Footer { PayloadSize = size, Sha256 = hash, Version = version };
            }
        }

        private static void EnsurePayload(string self, string destination, Footer footer)
        {
            if (File.Exists(destination) && FixedTimeEquals(HashFile(destination), footer.Sha256))
                return;

            string temp = destination + ".new-" + Guid.NewGuid().ToString("N");
            try
            {
                using (FileStream source = new FileStream(self, FileMode.Open, FileAccess.Read, FileShare.Read))
                using (FileStream output = new FileStream(temp, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                {
                    source.Seek(source.Length - FooterSize - footer.PayloadSize, SeekOrigin.Begin);
                    CopyExactly(source, output, footer.PayloadSize);
                    output.Flush(true);
                }
                if (!FixedTimeEquals(HashFile(temp), footer.Sha256))
                    throw new InvalidDataException("The embedded application failed its SHA-256 verification.");
                if (File.Exists(destination))
                {
                    string old = destination + ".previous";
                    TryDelete(old);
                    File.Replace(temp, destination, old, true);
                    TryDelete(old);
                }
                else
                {
                    File.Move(temp, destination);
                }
            }
            finally
            {
                TryDelete(temp);
            }
        }

        private static void SanitizeEnvironment(ProcessStartInfo info)
        {
            List<string> remove = new List<string>();
            foreach (System.Collections.DictionaryEntry entry in info.EnvironmentVariables)
            {
                string key = Convert.ToString(entry.Key) ?? "";
                string upper = key.ToUpperInvariant();
                if (upper.StartsWith("_PYI_") || upper == "_MEIPASS2" || upper == "PYTHONHOME" ||
                    upper == "PYTHONPATH" || upper == "PYTHONEXECUTABLE")
                    remove.Add(key);
            }
            foreach (string key in remove)
                info.EnvironmentVariables.Remove(key);
            info.EnvironmentVariables["PYINSTALLER_RESET_ENVIRONMENT"] = "1";
        }

        private static bool WaitForAcknowledgment(Process child, string ack, string token, TimeSpan timeout)
        {
            Stopwatch watch = Stopwatch.StartNew();
            while (watch.Elapsed < timeout)
            {
                if (child.HasExited)
                    return false;
                try
                {
                    if (File.Exists(ack))
                    {
                        string text = File.ReadAllText(ack, Encoding.UTF8);
                        if (text.IndexOf(token, StringComparison.Ordinal) >= 0)
                            return true;
                    }
                }
                catch (IOException) { }
                catch (UnauthorizedAccessException) { }
                Thread.Sleep(200);
            }
            return false;
        }

        private static void CleanupOldRuntime(string runtimeRoot, string keep)
        {
            try
            {
                if (String.IsNullOrEmpty(runtimeRoot) || !Directory.Exists(runtimeRoot)) return;
                foreach (string directory in Directory.GetDirectories(runtimeRoot))
                {
                    if (String.Equals(Path.GetFullPath(directory), Path.GetFullPath(keep), StringComparison.OrdinalIgnoreCase))
                        continue;
                    try
                    {
                        DateTime age = Directory.GetLastWriteTimeUtc(directory);
                        if (age < DateTime.UtcNow.AddDays(-14)) Directory.Delete(directory, true);
                    }
                    catch { }
                }
            }
            catch { }
        }

        private static byte[] HashFile(string path)
        {
            using (SHA256 sha = SHA256.Create())
            using (FileStream stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read))
                return sha.ComputeHash(stream);
        }

        private static bool FixedTimeEquals(byte[] left, byte[] right)
        {
            if (left == null || right == null || left.Length != right.Length) return false;
            int difference = 0;
            for (int i = 0; i < left.Length; i++) difference |= left[i] ^ right[i];
            return difference == 0;
        }

        private static byte[] ReadExactly(Stream stream, int count)
        {
            byte[] data = new byte[count];
            int offset = 0;
            while (offset < count)
            {
                int read = stream.Read(data, offset, count - offset);
                if (read <= 0) throw new EndOfStreamException();
                offset += read;
            }
            return data;
        }

        private static void CopyExactly(Stream source, Stream output, long count)
        {
            byte[] buffer = new byte[1024 * 1024];
            long remaining = count;
            while (remaining > 0)
            {
                int request = (int)Math.Min(buffer.Length, remaining);
                int read = source.Read(buffer, 0, request);
                if (read <= 0) throw new EndOfStreamException();
                output.Write(buffer, 0, read);
                remaining -= read;
            }
        }

        private static string JoinArguments(string[] args)
        {
            return String.Join(" ", args.Select(QuoteArgument).ToArray());
        }

        private static string QuoteArgument(string arg)
        {
            if (arg == null) return "\"\"";
            if (arg.Length > 0 && arg.IndexOfAny(new char[] { ' ', '\t', '\n', '\v', '\"' }) < 0) return arg;
            StringBuilder result = new StringBuilder();
            result.Append('\"');
            int backslashes = 0;
            foreach (char c in arg)
            {
                if (c == '\\') { backslashes++; continue; }
                if (c == '\"')
                {
                    result.Append('\\', backslashes * 2 + 1);
                    result.Append('\"');
                    backslashes = 0;
                    continue;
                }
                result.Append('\\', backslashes);
                backslashes = 0;
                result.Append(c);
            }
            result.Append('\\', backslashes * 2);
            result.Append('\"');
            return result.ToString();
        }

        private static void Log(string message)
        {
            try
            {
                string path = Environment.GetEnvironmentVariable("AHPATA_UPDATE_LOG");
                if (String.IsNullOrWhiteSpace(path))
                    path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "AhPaTaTracker", "updates", "launcher.log");
                Directory.CreateDirectory(Path.GetDirectoryName(path));
                File.AppendAllText(path, "[" + DateTimeOffset.Now.ToString("o") + "] " + message + Environment.NewLine, Encoding.UTF8);
            }
            catch { }
        }

        private static void TryDelete(string path)
        {
            try { if (!String.IsNullOrEmpty(path) && File.Exists(path)) File.Delete(path); }
            catch { }
        }
    }
}
