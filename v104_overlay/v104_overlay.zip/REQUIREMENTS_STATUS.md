# Ah Pa Ta Tracker v1.0.4 requirement status

## 1. Simple end-to-end Apple Account mode
Implemented the intended Connect → Import data → Select orders → Choose action → START → Jobs/results flow. The Apple action control is now a compact action selector plus one START button. Confirmed jobs freeze account/action/target identity before execution.

## 2. Required Apple actions
- **Associate guest order:** existing real-browser adapter retained; v1.0.4 adds an idempotent already-associated result and a corrected sign-in handoff.
- **Authenticated refresh:** existing Apple observation path retained; manual override remains first priority, authenticated Apple remains second.
- **Cancellation:** eligibility/read-before-act and uncertainty reconciliation retained; final action remains browser-assisted where Apple requires user interaction or an unrecognized layout.
- **Payment update:** order-specific eligibility, confirmation and reconciliation retained; raw card/CVV collection/reuse is intentionally not implemented. Payment entry stays on Apple's page and a method update is not equated with payment clearance.

## 3. Apple Account session — blocking defect
The browser session now explicitly distinguishes guest-order lookup from Apple Account authentication. `begin_sign_in()` brings the isolated account browser forward, detects password/verification/signed-in states, selects only an explicit Apple Account sign-in control when present, falls back to a stable Apple Account destination when appropriate, and never fills passwords or OTP codes. `verify_identity()` refuses to authenticate a guest page and verifies signed-in/order-list evidence before account actions are enabled.

Live Apple credentials are not available to automated tests, so a real owned-account sign-in/2FA remains the final user verification step.

## 4. Apple Account UI
The normal path is reduced to five steps with clear state/feedback. Advanced browser/routing settings remain available but are no longer the primary workflow. Review/mapping/detail dialogs open substantially larger and use available desktop space more effectively.

## 5. Proxy management
Implemented Add, Edit, Delete selected, Delete all, Enable selected, Disable selected, Select all, Clear selection, Save and exact Test Selected controls. Saved routes have stable IDs/revisions, credentials remain masked/protected, and deleted active routes are reset safely to Direct.

## 6. Proxy purpose and recovery policy
Enabled healthy routes form an optional transport failover pool for genuine proxy/network failures. When a non-submitted task hits a transport failure/timeout, the worker can bind the account session to the next healthy route and reconnect before retrying. Explicit Apple throttling/429 responses continue to use cooldown/backoff/Retry-After and do not cause route rotation or cookie clearing.

## 7. Jobs/results removal
Implemented local archival for selected or completed jobs, with confirmation. Active jobs must be stopped first or explicitly Stop-and-Remove. Task/audit records are retained and removing a job never implies reversal of completed Apple actions.

## 8. Shift-click selection
Order/tracking views preserve checked stable order IDs across refresh/sort/filter/page changes. Shift-click selects a contiguous visible range from the last selection anchor. Existing checkbox and all/filtered selection mechanisms remain available.

## 9. Larger review windows
Batch review opens at approximately 90% of the available desktop with a 1100×700 minimum when space allows, plus improved column sizing. Mapping/phone dialogs were enlarged as well.

## 10. Production defensive behavior
Already-associated orders return a handled idempotent outcome. Durable job state, per-order locking, cooldowns, restart recovery, mutation reconciliation, sanitized logging, browser-close/session-expiry handling and unknown-layout handoff remain. Expected operational failures update job/result state rather than intentionally terminating the process.

## 11. Update / GitHub release
v1.0.4 source, build metadata, Windows build gate, overlay metadata and release notes are prepared for the existing `ryansu1130/hello-world` release workflow. Publication is considered complete only after the master workflow passes and publishes `AhPaTaTracker.exe` plus its SHA-256.

## Verification boundary
Automated tests do not authenticate to private Apple production pages and do not mutate real orders or payment methods. Live Apple sign-in/2FA, a real guest-order association, cancellation and payment changes require user participation on owned orders. These are not claimed as live-verified until that validation occurs.
